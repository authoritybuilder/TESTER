/**
 * Phase 4 — catalogue preview backfill (offline / build-time; never at page view, never one Claude call per tile).
 *   npm run backfill [-- --only id1,id2] [--limit N] [--concurrency 3] [--force]
 * For each of the 4,437 scenes: canonical record → VisualSceneSpec → compiled HTML → real Chromium raster → WebP thumbnail,
 * with QA metrics and a resumable manifest. Then writes the machine-generated coverage report.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import type { GalleryIndex } from '../features/prompt-studio/catalog/schema.ts';
import { hydrateScene } from '../features/prompt-studio/catalog/store.ts';
import { hashHex, stableStringify } from '../features/prompt-studio/shared/util.ts';
import { renderArtboardHtml } from '../features/prompt-studio/visual-engine/artboard-renderer.ts';
import { hamming, measureRaster, sha256, toWebp } from '../features/prompt-studio/visual-engine/asset-pipeline.ts';
import { cacheKey, PreviewLedger, runQueue, type PreviewRecord } from '../features/prompt-studio/visual-engine/render-queue.ts';
import { RenderWorker } from '../features/prompt-studio/visual-engine/render-worker.ts';
import { planScene } from '../features/prompt-studio/visual-engine/scene-planner.ts';
import { RENDERER_VERSION } from '../features/prompt-studio/visual-engine/scene-schema.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const arg = (n: string): string | undefined => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : undefined; };
const flag = (n: string): boolean => process.argv.includes('--' + n);
const THUMB_LONG = 560;

async function main(): Promise<void> {
  const t0 = Date.now();
  const indexPath = join(ROOT, 'public/data/index.json');
  const index = JSON.parse(readFileSync(indexPath, 'utf8')) as GalleryIndex;
  let scenes = index.scenes;
  const only = arg('only')?.split(','); if (only) scenes = scenes.filter(s => only.includes(s.id));
  const limit = arg('limit'); if (limit) scenes = scenes.slice(0, Number(limit));
  const worker = await RenderWorker.launch();
  const ledger = new PreviewLedger(join(ROOT, 'data/visual/preview-manifest.json'), RENDERER_VERSION, 'chromium ' + worker.browserVersion());
  let rendered = 0, cached = 0, failed = 0;
  const failures: Array<{ id: string; error: string }> = [];

  await runQueue(scenes, Number(arg('concurrency') ?? 3), async e => {
    const stored = JSON.parse(readFileSync(join(ROOT, 'public/data/scenes', e.cat, e.id + '.json'), 'utf8')) as unknown;
    const scene = hydrateScene(stored, e.id);
    const spec = planScene(scene);
    const specHash = hashHex(stableStringify(spec));
    const key = cacheKey(e.id, scene.provenance.canonical_sha256, specHash, RENDERER_VERSION);
    const specPath = join(ROOT, 'data/visual/specs', e.cat, e.id + '.spec.json'), htmlPath = join(ROOT, 'data/visual/html', e.cat, e.id + '.html'), thumbPath = join(ROOT, 'public/thumbs', e.cat, e.id + '.webp');
    const staleQa = flag('recheck-qa') && (ledger.manifest.records[e.id]?.qa?.textOverflow?.length ?? 0) > 0; // re-measure scenes flagged by an older QA rule
    if (!flag('force') && !staleQa && ledger.isFresh(e.id, key, [specPath, htmlPath, thumbPath])) { cached++; return; }
    const scale = Math.min(1, (THUMB_LONG * 2) / Math.max(spec.output.width, spec.output.height)); // render at 2× thumb size, then downsample (crisper)
    const out = await worker.render({ spec, scale, lighting: scene.dna.lightingVariant });
    const stats = await measureRaster(out.png);
    const thumb = await toWebp(out.png, { width: spec.output.width >= spec.output.height ? THUMB_LONG : Math.round(THUMB_LONG * spec.output.width / spec.output.height), quality: 78 });
    const tm = await sharp(thumb).metadata();
    const stored_html = renderArtboardHtml(spec, { fonts: { mode: 'linked', base: '/fonts/' }, lighting: scene.dna.lightingVariant, title: `${scene.display_title} — preview` }).html;
    for (const p of [specPath, htmlPath, thumbPath]) mkdirSync(dirname(p), { recursive: true });
    writeFileSync(specPath, JSON.stringify(spec)); writeFileSync(htmlPath, stored_html); writeFileSync(thumbPath, thumb);
    const flat = spec.artDirection.layerPlan;
    delete ledger.manifest.records[e.id]?.error;
    const rec: PreviewRecord = {
      sceneId: e.id, category: e.cat, cacheKey: key, sourceSha256: scene.provenance.canonical_sha256, visualSpecHash: specHash, rendererVersion: RENDERER_VERSION, status: 'rendered',
      spec: `data/visual/specs/${e.cat}/${e.id}.spec.json`, html: `data/visual/html/${e.cat}/${e.id}.html`, thumb: `public/thumbs/${e.cat}/${e.id}.webp`,
      htmlSha256: sha256(stored_html), thumbSha256: sha256(thumb), thumbBytes: thumb.length, width: spec.output.width, height: spec.output.height, thumbWidth: tm.width ?? 0, thumbHeight: tm.height ?? 0, aspect: spec.output.aspect,
      fidelity: spec.artDirection.previewFidelity, medium: spec.artDirection.medium, family: spec.artDirection.compositionFamily, layers: flat.length, conceptLayers: flat.filter(l => l.role === 'concept').length,
      qa: { decoded: stats.width > 0, blank: stats.blank, stdevLuma: Math.round(stats.stdevLuma * 10) / 10, distinctColours: stats.distinctColours, edgeDensity: Math.round(stats.edgeDensity * 1000) / 1000, dhash: stats.dhash, textOverflow: out.overflow, missingFonts: out.missingFonts, blockedRequests: out.blockedRequests.length, problems: out.problems,
        pass: stats.width > 0 && !stats.blank && out.missingFonts.length === 0 && out.blockedRequests.length === 0 && out.problems.length === 0 },
      renderMs: out.ms, renderedAt: new Date().toISOString(),
    };
    ledger.put(rec); rendered++;
  }, (e, err) => { failed++; const msg = err instanceof Error ? err.message : String(err); failures.push({ id: e.id, error: msg }); const prev = ledger.manifest.records[e.id]; if (prev?.status === 'rendered') prev.error = msg.slice(0, 300); /* keep the last good preview; the failure is reported and fails the gate */ else ledger.put({ ...(prev ?? ({ sceneId: e.id, category: e.cat } as PreviewRecord)), status: 'failed', error: msg.slice(0, 300) }); },
  done => { if (done % 200 === 0) { ledger.save(); console.log(`[backfill] ${done}/${scenes.length} rendered=${rendered} cached=${cached} failed=${failed} ${Math.round((Date.now() - t0) / 1000)}s`); } });
  ledger.save(); await worker.close();

  // ---- update gallery index with the verified hash of each preview (cache-busting + provenance)
  for (const s of index.scenes) { const r = ledger.manifest.records[s.id]; if (r?.status === 'rendered') { s.hash = r.visualSpecHash; s.fidelity = r.fidelity as typeof s.fidelity; s.family = r.family; } }
  if (!only && !limit) writeFileSync(indexPath, JSON.stringify(index));

  // ---- coverage report (machine-generated from the manifest + files on disk)
  const recs = index.scenes.map(s => ledger.manifest.records[s.id]);
  const ok = recs.filter((r): r is PreviewRecord => !!r && r.status === 'rendered');
  const missingFiles = ok.filter(r => ![r.spec, r.html, r.thumb].every(f => existsSync(join(ROOT, f)))).map(r => r.sceneId);
  const byThumb = new Map<string, string[]>(); for (const r of ok) byThumb.set(r.thumbSha256, [...(byThumb.get(r.thumbSha256) ?? []), r.sceneId]);
  const exactDupGroups = [...byThumb.values()].filter(g => g.length > 1);
  const byHash = new Map<string, string[]>(); for (const r of ok) byHash.set(r.qa.dhash, [...(byHash.get(r.qa.dhash) ?? []), r.sceneId]);
  const sameDhashGroups = [...byHash.values()].filter(g => g.length > 1).sort((a, b) => b.length - a.length);
  // near-duplicate signal: within each composition family, pairs with dHash distance ≤ 3
  const fam = new Map<string, PreviewRecord[]>(); for (const r of ok) fam.set(r.family, [...(fam.get(r.family) ?? []), r]);
  let nearPairs = 0; const nearExamples: string[] = [];
  for (const g of fam.values()) for (let i = 0; i < g.length; i++) for (let j = i + 1; j < g.length; j++) if (hamming(g[i]!.qa.dhash, g[j]!.qa.dhash) <= 3) { nearPairs++; if (nearExamples.length < 40) nearExamples.push(`${g[i]!.sceneId} ~ ${g[j]!.sceneId}`); }
  const count = (f: (r: PreviewRecord) => string): Record<string, number> => { const o: Record<string, number> = {}; for (const r of ok) o[f(r)] = (o[f(r)] ?? 0) + 1; return Object.fromEntries(Object.entries(o).sort((a, b) => b[1] - a[1])); };
  const report = {
    generatedAt: new Date().toISOString(), rendererVersion: RENDERER_VERSION, browser: ledger.manifest.browser, run: { scenesRequested: scenes.length, renderedThisRun: rendered, cachedThisRun: cached, failedThisRun: failed, durationSec: Math.round((Date.now() - t0) / 1000) },
    coverage: { sourceRecords: index.totalScenes, specsCompiled: ok.length, htmlArtboards: ok.length, browserRasterised: ok.length, qaPass: ok.filter(r => r.qa.pass).length, blankFrames: ok.filter(r => r.qa.blank).map(r => r.sceneId), failedRenders: recs.filter(r => !r || r.status === 'failed').length, missingFiles, withTextOverflow: ok.filter(r => r.qa.textOverflow.length).length, coveragePct: Math.round((ok.filter(r => r.qa.pass).length / index.totalScenes) * 10000) / 100 },
    releaseGate: { requirement: '100% of gallery tiles display a verified scene-specific visual', pass: ok.length === index.totalScenes && ok.every(r => r.qa.pass) && missingFiles.length === 0 && failures.length === 0 && exactDupGroups.length === 0 },
    duplicates: { pixelIdenticalGroups: exactDupGroups.length, pixelIdenticalExamples: exactDupGroups.slice(0, 20), identicalDhashGroups: sameDhashGroups.length, identicalDhashScenes: sameDhashGroups.reduce((a, g) => a + g.length, 0), identicalDhashExamples: sameDhashGroups.slice(0, 20), nearDuplicatePairsWithinFamily: nearPairs, nearExamples, note: 'dHash is a 64-bit perceptual signal on a 9×8 greyscale reduction; matching hashes flag candidates for human review, they do not prove sameness.' },
    distribution: { fidelity: count(r => r.fidelity), medium: count(r => r.medium), aspect: count(r => r.aspect), distinctFamilies: fam.size, topFamilies: Object.entries(count(r => r.family)).slice(0, 30) },
    bytes: { thumbsTotal: ok.reduce((a, r) => a + r.thumbBytes, 0), thumbAvg: Math.round(ok.reduce((a, r) => a + r.thumbBytes, 0) / Math.max(1, ok.length)) },
    cost: { claudeApiCalls: 0, photoProviderCalls: 0, note: 'Deterministic tier only; no paid API was called for this backfill.' },
    failures,
  };
  mkdirSync(join(ROOT, 'data/reports'), { recursive: true });
  if (!only && !limit) {
    writeFileSync(join(ROOT, 'data/reports/thumbnail-coverage.json'), JSON.stringify(report, null, 2));
    const csv = ['scene_id,category,status,qa_pass,fidelity,medium,family,aspect,width,height,spec_path,html_path,thumb_path,thumb_bytes,thumb_sha256,html_sha256,visual_spec_hash,dhash,text_overflow_layers,rendered_at'];
    for (const s of index.scenes) { const r = ledger.manifest.records[s.id]; csv.push(r && r.status === 'rendered' ? [r.sceneId, r.category, r.status, r.qa.pass, r.fidelity, r.medium, '"' + r.family + '"', r.aspect, r.width, r.height, r.spec, r.html, r.thumb, r.thumbBytes, r.thumbSha256, r.htmlSha256, r.visualSpecHash, r.qa.dhash, '"' + r.qa.textOverflow.join(' ') + '"', r.renderedAt].join(',') : [s.id, s.cat, r?.status ?? 'missing', false].join(',')); }
    writeFileSync(join(ROOT, 'data/reports/thumbnail-coverage.csv'), csv.join('\n'));
  }
  if (!only && !limit) {
    const pct = (n: number): string => ((n / index.totalScenes) * 100).toFixed(1) + '%'; const tb = (o: Record<string, number>): string => Object.entries(o).map(([k, v]) => `| ${k} | ${v} | ${pct(v)} |`).join('\n');
    const md = `# Prompt Studio — thumbnail coverage (machine-generated)\n\n> Generated by \`npm run backfill\` on ${report.generatedAt} from \`data/visual/preview-manifest.json\` and the files on disk. Do not edit by hand.\n> Full per-scene list (all ${index.totalScenes} IDs with spec, HTML and image paths, checksums and QA status): \`data/reports/thumbnail-coverage.csv\`. Raw numbers: \`data/reports/thumbnail-coverage.json\`.\n\n## Coverage gate\n\n| Measure | Count |\n|---|---|\n| Source records | ${report.coverage.sourceRecords} |\n| VisualSceneSpecs compiled and schema-valid | ${report.coverage.specsCompiled} |\n| HTML artboards written | ${report.coverage.htmlArtboards} |\n| Rasterised by ${report.browser} | ${report.coverage.browserRasterised} |\n| Automated QA pass (decodes, not blank, fonts loaded, no blocked requests, no renderer problems) | ${report.coverage.qaPass} |\n| Failed renders | ${report.coverage.failedRenders} |\n| Blank frames | ${report.coverage.blankFrames.length} |\n| Missing files | ${missingFiles.length} |\n| Scenes with text spilling >12% beyond its box | ${report.coverage.withTextOverflow} |\n| Pixel-identical thumbnail groups | ${exactDupGroups.length} |\n\n**Automated release gate: ${report.releaseGate.pass ? 'PASS' : 'FAIL'}** (${report.releaseGate.requirement}; also requires zero failures and zero pixel-identical groups). This gate is automated evidence only — see “Human review” below.\n\n## This run\n\nRequested ${report.run.scenesRequested} · rendered ${report.run.renderedThisRun} · served from cache ${report.run.cachedThisRun} · failed ${report.run.failedThisRun} · ${report.run.durationSec}s. Cache key = sha256(sceneId + source sha256 + visualSpecHash + rendererVersion \`${RENDERER_VERSION}\`). Paid API calls: ${report.cost.claudeApiCalls} Claude, ${report.cost.photoProviderCalls} photo provider.\n\n## What the previews are (provenance labels)\n\n| Label stored per scene | Scenes | Share |\n|---|---|---|\n${tb(report.distribution.fidelity)}\n\n- \`final-html-asset\` → shown as **HTML visual**: the graphic is the finished asset.\n- \`composition-concept\` → shown as **Composition concept**: an illustrated stand-in for a photograph; layout, type and colour are real, the person/setting/objects are illustration.\n- \`photo-required\` → shown as **Needs your photo**: the asset’s value is a real photo (product, headshot, hands at work); the illustration marks where it goes.\n\n## Duplicate and near-duplicate signals\n\n| Signal | Value |\n|---|---|\n| Pixel-identical groups (sha256 of the WebP) | ${exactDupGroups.length} |\n| Groups sharing an identical 64-bit dHash | ${sameDhashGroups.length} (${report.duplicates.identicalDhashScenes} scenes) |\n| Pairs within one composition family at dHash distance ≤ 3 | ${nearPairs} |\n| Distinct composition families | ${fam.size} |\n\n${report.duplicates.note} Identical-dHash groups are mostly the same template written for several niches or lighting variants of one base scene; they are listed in the JSON report for human review.\n\nLargest families: ${report.distribution.topFamilies.slice(0, 10).map(([k, v]) => `\`${k}\` ${v}`).join(', ')}.\n\n## Sizes\n\nThumbnails: ${(report.bytes.thumbsTotal / 1048576).toFixed(1)} MB total, ${(report.bytes.thumbAvg / 1024).toFixed(1)} KB average (WebP, ${THUMB_LONG}px long side, rendered at 2× then downsampled).\n\n## Aspect ratios\n\n| Aspect | Scenes | Share |\n|---|---|---|\n${tb(report.distribution.aspect)}\n\n## Human review\n\nNo human has reviewed these previews yet. During the build, Claude inspected contact sheets covering a stratified sample (one scene per category plus one per otherwise-uncovered composition family — IDs in \`data/reports/review-sample.json\`, sheets in \`docs/evidence/review-sheet-*.webp\`). Human sign-off across every niche cluster remains a launch requirement.\n`;
    writeFileSync(join(ROOT, 'docs/PROMPT_STUDIO_THUMBNAIL_COVERAGE.md'), md);
  }
  console.log(JSON.stringify({ run: report.run, coverage: { ...report.coverage, blankFrames: report.coverage.blankFrames.length, missingFiles: missingFiles.length }, releaseGate: report.releaseGate.pass, duplicates: { pixelIdentical: exactDupGroups.length, identicalDhashGroups: sameDhashGroups.length, nearPairs }, bytes: report.bytes, failures: failures.slice(0, 5) }, null, 1));
}
main().catch(e => { console.error(e); process.exit(1); });
