/** Dev tool: render a set of scene ids to a contact sheet PNG for visual inspection. tsx scripts/preview-sheet.ts out.png id1 id2 … | --sample N [seed] */
import { readFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
import { hydrateScene } from '../features/prompt-studio/catalog/store.ts';
import type { GalleryIndex } from '../features/prompt-studio/catalog/schema.ts';
import { rng } from '../features/prompt-studio/shared/util.ts';
import { RenderWorker } from '../features/prompt-studio/visual-engine/render-worker.ts';
import { planScene } from '../features/prompt-studio/visual-engine/scene-planner.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const [out, ...rest] = process.argv.slice(2);
const index = JSON.parse(readFileSync(join(ROOT, 'public/data/index.json'), 'utf8')) as GalleryIndex;
let ids = rest;
if (rest[0] === '--sample') { const r = rng(rest[2] ?? 's'); const pool = rest[3] ? index.scenes.filter(s => new RegExp(rest[3]!).test(s.asset + ' ' + s.family + ' ' + s.id)) : index.scenes; ids = Array.from({ length: Number(rest[1]) }, () => pool[Math.floor(r() * pool.length)]!.id); }
const w = await RenderWorker.launch(); const cell = 440; const tiles: Array<{ input: Buffer; left: number; top: number }> = []; const cols = Math.min(4, ids.length);
let i = 0;
for (const id of ids) {
  const e = index.scenes.find(s => s.id === id); if (!e) { console.log('missing', id); continue; }
  const c = hydrateScene(JSON.parse(readFileSync(join(ROOT, 'public/data/scenes', e.cat, id + '.json'), 'utf8')), id);
  const spec = planScene(c);
  const r = await w.render({ spec, scale: Math.min(1, cell / Math.max(spec.output.width, spec.output.height)), lighting: c.dna.lightingVariant });
  const img = await sharp(r.png).resize(cell - 12, cell - 12, { fit: 'contain', background: '#1b1b1b' }).png().toBuffer();
  tiles.push({ input: img, left: (i % cols) * cell + 6, top: Math.floor(i / cols) * cell + 6 }); i++;
  console.log(`${id} | ${e.family} | ${e.fidelity} | ${c.dna.environmentKind} | pose ${c.dna.pose} | overflow ${r.overflow.join(',') || '-'} | ${r.ms}ms`);
}
await sharp({ create: { width: cols * cell, height: Math.ceil(i / cols) * cell, channels: 3, background: '#1b1b1b' } }).composite(tiles).png().toFile(out!);
await w.close();
