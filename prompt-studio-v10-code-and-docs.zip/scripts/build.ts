/** Production build: bundles the Prompt Studio module for the browser. `npm run build` */
import { build } from 'esbuild';
import { statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(ROOT, 'public', 'app.js');
const r = await build({ entryPoints: [join(ROOT, 'features/prompt-studio/app/standalone.ts')], bundle: true, format: 'esm', target: 'es2022', minify: true, sourcemap: false, outfile: out, legalComments: 'none', metafile: true, logLevel: 'warning' });
const nodeOnly = Object.keys(r.metafile.inputs).filter(f => /render-worker|asset-pipeline|sanitiser|creative-director|render-queue|server\//.test(f));
if (nodeOnly.length) { console.error('Server-only modules leaked into the browser bundle:', nodeOnly); process.exit(1); }
console.log(`built public/app.js ${(statSync(out).size / 1024).toFixed(0)} KB from ${Object.keys(r.metafile.inputs).length} modules`);
