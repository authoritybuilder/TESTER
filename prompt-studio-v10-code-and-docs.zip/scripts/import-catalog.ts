/**
 * Phase 0/1 importer: nested archives → validated canonical catalogue.
 *   npm run import
 * - Extracts BOTH nested ZIPs into versioned cache directories (path-traversal checked, never overwriting source).
 * - Compares them field by field, selects the canonical source by documented precedence, validates every record,
 *   and writes public/data/scenes/<category>/<id>.json + public/data/index.json + checksums + an import report.
 * - A record that fails validation aborts the import (non-zero exit). Nothing is ever substituted.
 */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildCanonical, galleryEntry, GOALS } from '../features/prompt-studio/catalog/canonical.ts';
import { CanonicalSceneSchema, OriginalSceneSchema, PLATFORM_KEYS, type CanonicalScene, type GalleryIndex, type OriginalScene } from '../features/prompt-studio/catalog/schema.ts';
import { dehydrateScene, hydrateScene } from '../features/prompt-studio/catalog/store.ts';
import { hashHex, stableStringify } from '../features/prompt-studio/shared/util.ts';
import { planScene } from '../features/prompt-studio/visual-engine/scene-planner.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const CACHE = join(ROOT, '.cache', 'source');
const ARCHIVES = { final: 'PROMPTSTUDIO-v9918-FINAL.zip', rebuilt: 'PROMPTSTUDIO-rebuilt.zip' } as const;
const sha256 = (b: Buffer | string): string => createHash('sha256').update(b).digest('hex');

function safeExtract(zipName: string, dest: string): number {
  const zip = join(ROOT, zipName);
  if (!existsSync(zip)) throw new Error(`Missing source archive ${zipName}`);
  const entries = execFileSync('unzip', ['-Z1', zip], { maxBuffer: 64 * 1024 * 1024 }).toString().split('\n').filter(Boolean);
  const root = resolve(dest);
  for (const e of entries) { const t = resolve(root, e); if (e.startsWith('/') || e.split('/').includes('..') || !(t === root || t.startsWith(root + sep))) throw new Error(`Unsafe path in ${zipName}: ${e}`); }
  rmSync(root, { recursive: true, force: true }); mkdirSync(root, { recursive: true });
  execFileSync('unzip', ['-q', '-n', zip, '-d', root]);
  return entries.length;
}
function findPromptsDir(base: string): string {
  const direct = join(base, 'prompts'); if (existsSync(direct)) return direct;
  for (const d of readdirSync(base, { withFileTypes: true })) if (d.isDirectory()) { const p = join(base, d.name, 'prompts'); if (existsSync(p)) return p; }
  throw new Error('No prompts/ directory in ' + base);
}
function loadTree(dir: string): Map<string, { cat: string; raw: Buffer }> {
  const out = new Map<string, { cat: string; raw: Buffer }>();
  for (const cat of readdirSync(dir)) for (const f of readdirSync(join(dir, cat))) if (f.endsWith('.json')) { const id = f.slice(0, -5); if (out.has(id)) throw new Error(`Duplicate scene id ${id}`); out.set(id, { cat, raw: readFileSync(join(dir, cat, f)) }); }
  return out;
}
const flat = (o: unknown, pre = '', acc: Record<string, string> = {}): Record<string, string> => {
  if (o && typeof o === 'object' && !Array.isArray(o)) for (const [k, v] of Object.entries(o)) flat(v, pre ? `${pre}.${k}` : k, acc); else acc[pre] = typeof o === 'string' ? o : JSON.stringify(o);
  return acc;
};

function main(): void {
  const t0 = Date.now();
  const counts = { final: safeExtract(ARCHIVES.final, join(CACHE, 'final')), rebuilt: safeExtract(ARCHIVES.rebuilt, join(CACHE, 'rebuilt')) };
  const finalDir = findPromptsDir(join(CACHE, 'final')), rebuiltDir = findPromptsDir(join(CACHE, 'rebuilt'));
  const F = loadTree(finalDir), R = loadTree(rebuiltDir);
  const legacyIndex = JSON.parse(readFileSync(join(ROOT, 'legacy', 'index.json'), 'utf8')) as { version: string; categories: Record<string, { label: string; scene_ids: string[] }>; scenes: Record<string, Record<string, unknown>> };

  // ---- integrity: ids and categories agree across both archives and the legacy index
  const problems: string[] = [];
  if (F.size !== R.size) problems.push(`record count differs: final=${F.size} rebuilt=${R.size}`);
  for (const id of F.keys()) { if (!R.has(id)) problems.push(`id only in final: ${id}`); if (!legacyIndex.scenes[id]) problems.push(`id missing from legacy index: ${id}`); }
  for (const id of R.keys()) if (!F.has(id)) problems.push(`id only in rebuilt: ${id}`);
  for (const [cat, c] of Object.entries(legacyIndex.categories)) for (const id of c.scene_ids) if (F.get(id)?.cat !== cat) problems.push(`index category mismatch: ${id} listed under ${cat}, file under ${F.get(id)?.cat}`);
  if (problems.length) { console.error(problems.slice(0, 20).join('\n')); throw new Error(`Source integrity failed with ${problems.length} problem(s)`); }

  // ---- field-level comparison + precedence evidence
  const diffCounts: Record<string, number> = {}; const indexAgree = { final: 0, rebuilt: 0, neither: 0 };
  const scenarioCount = new Map<string, number>();
  const parsed = new Map<string, OriginalScene>();
  for (const [id, f] of F) {
    const o = OriginalSceneSchema.parse(JSON.parse(f.raw.toString('utf8')));
    if (o.id !== id) throw new Error(`id/filename mismatch ${id} vs ${o.id}`);
    parsed.set(id, o); scenarioCount.set(o.scenario, (scenarioCount.get(o.scenario) ?? 0) + 1);
  }
  // Build into a staging directory and swap only after every record has validated: a failed import never leaves the live catalogue missing.
  const liveScenes = join(ROOT, 'public', 'data', 'scenes'); const outScenes = liveScenes + '.staging';
  rmSync(outScenes, { recursive: true, force: true });
  const checksums: Record<string, { category: string; final: string; rebuilt: string; canonical: string }> = {};
  const entries: GalleryIndex['scenes'] = []; const cats: GalleryIndex['categories'] = {};
  const stats = { paletteSource: {} as Record<string, number>, subjectKind: {} as Record<string, number>, envKind: {} as Record<string, number>, fidelity: {} as Record<string, number>, family: {} as Record<string, number>, defects: {} as Record<string, number>, unmatchedProps: {} as Record<string, number>, zonesParsed: 0, noOverlay: 0, noZones: 0, genericTaglines: 0 };
  const bump = (o: Record<string, number>, k: string): void => { o[k] = (o[k] ?? 0) + 1; };
  const { resolveProp } = { resolveProp: (t: string) => propResolver(t) };

  for (const [id, f] of [...F].sort((a, b) => a[0].localeCompare(b[0]))) {
    const o = parsed.get(id)!; const r = R.get(id)!; const ro = JSON.parse(r.raw.toString('utf8')) as OriginalScene;
    const ff = flat(o), rf = flat(ro); const alt: Record<string, string> = {};
    for (const k of new Set([...Object.keys(ff), ...Object.keys(rf)])) if (ff[k] !== rf[k]) { alt[k] = rf[k] ?? '(absent)'; bump(diffCounts, k); }
    const ix = legacyIndex.scenes[id]!;
    const agreesFinal = ix.tagline === o.tagline && ix.sub === o.sub, agreesRebuilt = ix.tagline === ro.tagline && ix.sub === ro.sub;
    if (agreesFinal) indexAgree.final++; else if (agreesRebuilt) indexAgree.rebuilt++; else indexAgree.neither++;
    const c: CanonicalScene = CanonicalSceneSchema.parse(buildCanonical({
      original: o, category: f.cat, canonicalArchive: ARCHIVES.final, canonicalPath: `promptstudio/prompts/${f.cat}/${id}.json`, canonicalSha256: sha256(f.raw),
      alternateArchive: ARCHIVES.rebuilt, alternateSha256: sha256(r.raw), alternateDifferences: alt,
      indexFields: { cat: String(ix.cat ?? f.cat), catLabel: String(ix.catLabel ?? o.niche), lighting: String(ix.lighting ?? ''), baseScene: String(ix.baseScene ?? ''), keywords: Array.isArray(ix.keywords) ? (ix.keywords as string[]) : [] },
      sourceVersion: legacyIndex.version, sharedScenarioCount: scenarioCount.get(o.scenario) ?? 1,
    }));
    // every platform prompt must be present (schema enforces non-empty)
    for (const k of PLATFORM_KEYS) if (!c.original_platform_prompts[k]) throw new Error(`${id}: missing platform prompt ${k}`);
    const body = JSON.stringify(dehydrateScene(c));
    if (stableStringify(hydrateScene(JSON.parse(body), id)) !== stableStringify(c)) throw new Error(`${id}: stored record does not round-trip to the canonical record`);
    mkdirSync(join(outScenes, f.cat), { recursive: true });
    writeFileSync(join(outScenes, f.cat, id + '.json'), body);
    checksums[id] = { category: f.cat, final: c.provenance.canonical_sha256, rebuilt: c.provenance.alternate_sha256, canonical: sha256(body) };
    const spec = planScene(c);
    entries.push(galleryEntry(c, { fidelity: spec.artDirection.previewFidelity, medium: spec.artDirection.medium, family: spec.artDirection.compositionFamily, hash: hashHex(stableStringify(spec)) }));
    cats[f.cat] ??= { label: legacyIndex.categories[f.cat]?.label ?? o.niche, count: 0, channel: o.channelType }; cats[f.cat]!.count++;
    bump(stats.paletteSource, c.dna.paletteSource); bump(stats.subjectKind, c.dna.subjectKind); bump(stats.envKind, c.dna.environmentKind); bump(stats.fidelity, spec.artDirection.previewFidelity); bump(stats.family, spec.artDirection.compositionFamily);
    for (const d of c.provenance.source_defects) bump(stats.defects, d.replace(/“.*?”/g, '…').replace(/\d+ other/, 'N other').replace(/: \{.*$/, ''));
    for (const p of c.dna.props) if (!resolveProp(p)) bump(stats.unmatchedProps, p.toLowerCase());
    if (c.dna.zones.length) stats.zonesParsed++; else if (c.dna.noOverlay) stats.noOverlay++; else stats.noZones++;
    if (c.provenance.transformations.some(t => t.startsWith('visible_scene←derived'))) stats.genericTaglines++;
  }

  rmSync(liveScenes + '.previous', { recursive: true, force: true }); if (existsSync(liveScenes)) renameSync(liveScenes, liveScenes + '.previous'); renameSync(outScenes, liveScenes); rmSync(liveScenes + '.previous', { recursive: true, force: true });
  const index: GalleryIndex = { version: `v10.0.0 (source ${legacyIndex.version})`, generatedAt: new Date().toISOString().slice(0, 10), totalScenes: entries.length, categories: Object.fromEntries(Object.entries(cats).sort()), scenes: entries };
  mkdirSync(join(ROOT, 'public', 'data'), { recursive: true }); mkdirSync(join(ROOT, 'data', 'manifests'), { recursive: true }); mkdirSync(join(ROOT, 'data', 'reports'), { recursive: true });
  writeFileSync(join(ROOT, 'public', 'data', 'index.json'), JSON.stringify(index));
  writeFileSync(join(ROOT, 'public', 'data', 'goals.json'), JSON.stringify(GOALS.map(g => ({ key: g.key, label: g.label }))));
  writeFileSync(join(ROOT, 'data', 'manifests', 'source-checksums.json'), JSON.stringify(checksums, null, 0));
  const report = {
    generatedAt: new Date().toISOString(), durationMs: Date.now() - t0,
    archives: Object.fromEntries(Object.entries(ARCHIVES).map(([k, n]) => [k, { file: n, sha256: sha256(readFileSync(join(ROOT, n))), zipEntries: counts[k as keyof typeof counts] }])),
    records: { final: F.size, rebuilt: R.size, legacyIndex: Object.keys(legacyIndex.scenes).length, canonicalWritten: entries.length, categories: Object.keys(cats).length, byteIdenticalAcrossArchives: [...F].filter(([id, f]) => f.raw.equals(R.get(id)!.raw)).length },
    fieldDifferencesFinalVsRebuilt: Object.fromEntries(Object.entries(diffCounts).sort((a, b) => b[1] - a[1])),
    legacyIndexAgreesWith: indexAgree,
    precedence: 'FINAL (v9.9.18) is canonical: its tagline/sub agree with the shipped index.json v9.9.18; rebuilt values are preserved per record under provenance.alternate_differences.',
    stats: { ...stats, family: undefined, distinctFamilies: Object.keys(stats.family).length, topFamilies: Object.entries(stats.family).sort((a, b) => b[1] - a[1]).slice(0, 25), unmatchedProps: Object.entries(stats.unmatchedProps).sort((a, b) => b[1] - a[1]).slice(0, 60), unmatchedPropPhrases: Object.keys(stats.unmatchedProps).length },
    distinct: { scenarios: scenarioCount.size, specHashes: new Set(entries.map(e => e.hash)).size },
  };
  writeFileSync(join(ROOT, 'data', 'reports', 'import-report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ records: report.records, legacyIndexAgreesWith: indexAgree, diff: report.fieldDifferencesFinalVsRebuilt, subjectKind: stats.subjectKind, fidelity: stats.fidelity, paletteSource: stats.paletteSource, zones: { parsed: stats.zonesParsed, noOverlay: stats.noOverlay, none: stats.noZones }, distinct: report.distinct, distinctFamilies: report.stats.distinctFamilies, unmatchedPropPhrases: report.stats.unmatchedPropPhrases, ms: report.durationMs }, null, 1));
}
import { resolveProp as propResolver } from '../features/prompt-studio/visual-engine/illustration/props.ts';
main();
