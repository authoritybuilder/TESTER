const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const root = process.argv[2];
const srv = http.createServer((q, s) => {
  let p = decodeURIComponent(q.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.join(root, p);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { s.writeHead(404); return s.end('nf'); }
  s.writeHead(200, { 'content-type': p.endsWith('.html') ? 'text/html' : p.endsWith('.json') ? 'application/json' : 'application/octet-stream' });
  fs.createReadStream(f).pipe(s);
});
srv.listen(4801, async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const reqs = [];
  await page.route('**/*', r => { const u = r.request().url(); if (u.startsWith('http://localhost:4801')) return r.continue(); reqs.push(u); return r.abort(); });
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 200)));
  page.on('response', r => { if (r.status() === 404) reqs.push('404 ' + r.url()); });
  await page.goto('http://localhost:4801/', { waitUntil: 'load' });
  await page.waitForTimeout(2500);
  await page.screenshot({ path: 'before/01-forced-wizard-overlay.png' });
  const wiz = await page.evaluate(() => { const w = document.getElementById('wizard'); const cs = getComputedStyle(w); return { display: cs.display, position: cs.position, z: cs.zIndex, title: document.title, desc: document.querySelector('meta[name=description]').content }; });
  console.log('WIZARD', JSON.stringify(wiz));
  await page.click('#wizSkip').catch(e => console.log('skip err', e.message.slice(0, 100)));
  await page.waitForTimeout(2500);
  await page.screenshot({ path: 'before/02-after-skip-gallery.png' });
  const out = await page.evaluate(async () => {
    const res = {};
    for (const [cat, id] of [['fitness-coaches', 'fitness-coaches-001'], ['fitness-coaches', 'fitness-coaches-002'], ['tiktok', 'tiktok-001'], ['automation-consultants', 'automation-consultants-009'], ['ecommerce', 'ecommerce-001']]) {
      try {
        const sc = await fetchScene(cat, id);
        res[id] = { hasV3: !!(sc.v3 && sc.v3.platforms), hasRich: !!sc.richBrief, keys: Object.keys(sc).length, template: (sc.template || '').slice(0, 600), prompt: String(buildPrompt(sc)) };
      } catch (e) { res[id] = { err: String(e) }; }
    }
    return res;
  });
  fs.writeFileSync('before/legacy-prompts.json', JSON.stringify(out, null, 1));
  for (const [k, v] of Object.entries(out)) console.log('\n##', k, JSON.stringify({ hasV3: v.hasV3, hasRich: v.hasRich, keys: v.keys, err: v.err }), '\nTEMPLATE:', (v.template || '').slice(0, 300), '\nPROMPT:', (v.prompt || '').slice(0, 900));
  // open first tile visually
  const tile = await page.$('.tile, .prompt-tile, [data-scene-id]');
  console.log('tile?', !!tile, 'tiles', await page.evaluate(() => document.querySelectorAll('[data-scene-id]').length));
  await page.screenshot({ path: 'before/03-tiles.png', fullPage: false });
  console.log('REQS', [...new Set(reqs)].slice(0, 12)); console.log('ERRS', errs.slice(0, 5));
  await browser.close(); srv.close();
});
