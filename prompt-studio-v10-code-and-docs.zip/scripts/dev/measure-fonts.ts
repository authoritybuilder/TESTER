import { chromium } from 'playwright';
import { loadFontData } from '../../features/prompt-studio/visual-engine/render-worker.ts';
import { FONT_FACES } from '../../features/prompt-studio/visual-engine/artboard-renderer.ts';
const d = loadFontData();
const css = FONT_FACES.map(f => `@font-face{font-family:'${f.family}';font-weight:${f.weight};font-style:${f.italic ? 'italic' : 'normal'};src:url(data:font/woff2;base64,${d[f.file]}) format('woff2')}`).join('');
const b = await chromium.launch(); const p = await b.newPage();
await p.setContent(`<style>${css}</style><body></body>`);
const res = await p.evaluate(async (faces) => {
  await Promise.all(faces.map(f => document.fonts.load(`${f.italic ? 'italic ' : ''}${f.weight} 100px '${f.family}'`)));
  const sample = 'Your headline goes here Book a call with your event name Masthead Workshop programme'; const out: Record<string, number[]> = {};
  for (const f of faces) { const c = document.createElement('canvas').getContext('2d')!; c.font = `${f.italic ? 'italic ' : ''}${f.weight} 100px '${f.family}'`; const lo = c.measureText(sample).width / sample.length / 100; const up = c.measureText(sample.toUpperCase()).width / sample.length / 100; const widest = Math.max(...'MASTHEAD WORKSHOP'.split('').map(ch => c.measureText(ch).width)) / 100; out[`${f.key}-${f.weight}${f.italic ? 'i' : ''}`] = [Math.round(lo * 1000) / 1000, Math.round(up * 1000) / 1000, Math.round(widest * 1000) / 1000]; }
  return out;
}, FONT_FACES);
console.log(JSON.stringify(res)); await b.close();
