/** Dev tool: start the server, drive the real app in Chromium and save screenshots. tsx scripts/dev/shots.ts <outDir> */
import { chromium } from 'playwright';
import { startServer } from '../../server/index.ts';
const out = process.argv[2] ?? 'docs/evidence';
const srv = await startServer({ port: 0, quiet: true, dataDir: '/tmp/ps-shots-ws' });
const b = await chromium.launch(); const url = `http://localhost:${srv.port}/studio/prompt-studio/`;
const errors: string[] = [];
async function page(w: number, h: number) { const c = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 1 }); const p = await c.newPage(); p.on('pageerror', e => errors.push(String(e))); p.on('console', m => { if (m.type() === 'error') errors.push(m.text()); }); return p; }
const p = await page(1440, 900);
await p.goto(url); await p.waitForSelector('.ps-card'); await p.waitForTimeout(900);
console.log('overlay on entry?', await p.evaluate(() => ({ dialogs: document.querySelectorAll('dialog[open]').length, bodyOverflow: getComputedStyle(document.body).overflow, cards: document.querySelectorAll('.ps-card').length, sideHidden: (document.querySelector('.ps-side') as HTMLElement).hidden })));
await p.screenshot({ path: `${out}/after-01-gallery-desktop.png` });
await p.click('[data-open-wizard]'); await p.fill('#wz-businessName', 'Tidewater Strength'); await p.waitForTimeout(300); await p.screenshot({ path: `${out}/after-02-wizard-side-panel.png` });
await p.click('button[aria-label="Close brand panel"]');
await p.fill('#ps-q', 'promote my webinar'); await p.waitForTimeout(500); await p.screenshot({ path: `${out}/after-03-intent-search.png` });
await p.goto(url + '#/scene/fitness-coaches-001'); await p.waitForSelector('.ed-layer'); await p.waitForTimeout(1200); await p.screenshot({ path: `${out}/after-04-editor-desktop.png` });
await p.goto(url + '#/campaign'); await p.waitForSelector('.ps-flow-step'); await p.waitForTimeout(600); await p.screenshot({ path: `${out}/after-05-campaign.png` });
for (const [w, h, name] of [[390, 844, 'mobile-390'], [320, 640, 'mobile-320'], [820, 1180, 'tablet-820']] as const) { const m = await page(w, h); await m.goto(url); await m.waitForSelector('.ps-card'); await m.waitForTimeout(600); await m.screenshot({ path: `${out}/after-06-gallery-${name}.png` }); const ov = await m.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); console.log(name, 'horizontal overflow px', ov); await m.goto(url + '#/scene/tiktok-001'); await m.waitForSelector('.ed-layer'); await m.waitForTimeout(900); await m.screenshot({ path: `${out}/after-07-editor-${name}.png` }); console.log(name, 'editor overflow px', await m.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)); }
console.log('console/page errors:', errors.slice(0, 8));
await b.close(); await srv.close();
