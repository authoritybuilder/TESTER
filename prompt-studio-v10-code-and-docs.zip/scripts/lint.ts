/** Project lint (no external linter dependency): safety and hygiene rules that matter for this module. `npm run lint` */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const files: string[] = []; const walk = (d: string): void => { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) { if (!/node_modules|\.cache|legacy|data|thumbs/.test(f)) walk(p); } else if (/\.(ts|css|html)$/.test(f) && !/public\/app\.js/.test(p)) files.push(p); } };
for (const d of ['features', 'server', 'scripts', 'public']) walk(join(ROOT, d));
const RULES: Array<{ re: RegExp; msg: string; only?: RegExp; except?: RegExp }> = [
  { re: /\.innerHTML\s*=|\.outerHTML\s*=|insertAdjacentHTML|document\.write\(/, msg: 'no HTML string injection into the app DOM', only: /features\/prompt-studio\/(app|gallery|editor)\// },
  { re: /\beval\(|new Function\(/, msg: 'no dynamic code execution' },
  { re: /:\s*any(\[\])?\s*[;,)=\]>|]|\bas any\b|<any>/, msg: 'no `any` in product code', except: /tests\/|scripts\/dev\// },
  { re: /@ts-ignore|@ts-nocheck/, msg: 'no TypeScript suppression' },
  { re: /console\.log\(/, msg: 'no console.log in product modules', only: /features\/prompt-studio\/(?!tests)/ },
  { re: /TODO|FIXME|lorem ipsum/i, msg: 'no placeholder markers' },
  { re: /3,392|Elite AI Image Prompts|#c5a880|#132620|wizard-overlay|completeWizard|professional of business/i, msg: 'stale legacy claim/style/logic', except: /tests\/|scripts\/dev\/|lint\.ts/ },
  { re: /api\.anthropic\.com|ANTHROPIC_API_KEY/, msg: 'Claude API access is server-side only', only: /features\/prompt-studio\/(app|gallery|editor|catalog|compiler|shared)\// },
  { re: /localStorage\.(setItem|getItem)\(/, msg: 'use the guarded store helper', only: /features\/prompt-studio\/app\//, except: /dom\.ts/ },
  { re: /colou?r:\s*#(9BE05A|031816|C9B8F0|E8744F)\b/i, msg: 'superseded palette in app chrome', only: /public\/app\.css/ },
  { re: /--ab-dot|#273A21|#1C2F20|radial-gradient\(#273A21/i, msg: 'dark dot-grid bands are not part of the light Studio theme', only: /public\/(app\.css|index\.html)|scripts\/build-lab\.ts/ },
];
const problems: string[] = [];
for (const f of files) { const rel = relative(ROOT, f); if (rel === 'scripts/lint.ts') continue; const lines = readFileSync(f, 'utf8').split('\n'); lines.forEach((line, i) => { for (const r of RULES) { if (r.only && !r.only.test(rel)) continue; if (r.except && r.except.test(rel)) continue; if (r.re.test(line)) problems.push(`${rel}:${i + 1} ${r.msg}`); } }); }
if (problems.length) { console.error(problems.join('\n')); console.error(`\n${problems.length} lint problem(s)`); process.exit(1); }
console.log(`lint ok — ${files.length} files, ${RULES.length} rules`);
