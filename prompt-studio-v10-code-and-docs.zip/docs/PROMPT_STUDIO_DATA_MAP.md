# Prompt Studio — data map

## Where the data lives

| Path | What it is | Written by |
|---|---|---|
| `PROMPTSTUDIO-v9918-FINAL.zip`, `PROMPTSTUDIO-rebuilt.zip` | The two source archives. Never modified. | — |
| `public/data/index.json` | Gallery index: `version`, `generatedAt`, `totalScenes` (4,437), `categories` (151), `scenes[]` (one compact entry per record) | `npm run import` |
| `public/data/goals.json` | 13 curated goal definitions used by search (10 are shown as pills in the gallery) | `npm run import` |
| `public/data/scenes/<category>/<id>.json` | One canonical record per scene (4,437 files, 124 MB) | `npm run import` |
| `data/manifests/source-checksums.json` | SHA-256 of both archives and of every source record | `npm run import` |
| `data/reports/import-report.json` | Counts, archive differences, source defects, distribution statistics | `npm run import` |
| `data/visual/specs/<cat>/<id>.json` | The VisualSceneSpec planned for each scene | `npm run backfill` |
| `data/visual/html/<cat>/<id>.html` | The self-contained HTML artboard for each scene | `npm run backfill` |
| `data/visual/preview-manifest.json` | Preview ledger: cache key, hashes, QA result per scene | `npm run backfill` |
| `public/thumbs/<cat>/<id>.webp` | Browser-rasterised thumbnail (560 px long side) | `npm run backfill` |
| `data/reports/thumbnail-coverage.json` / `.csv` | Coverage and duplicate report; CSV lists every scene | `npm run backfill` |
| `data/workspaces/` (git-ignored) | Demo host storage: brand kits, saved designs, campaigns | preview server |

The import is atomic: records are written to a staging directory and swapped in only after every record validates. A failed import leaves the previous data in place.

## Canonical scene record

Schema: `features/prompt-studio/catalog/schema.ts` (`CanonicalSceneSchema`, Zod, strict). Example: `public/data/scenes/tiktok/tiktok-001.json`.

| Field | Source | Notes |
|---|---|---|
| `id`, `category`, `source_version` | record id, category folder, `v9.9.18` | |
| `display_title` | `name` | |
| `what_creating` | asset label + niche | Plain language, e.g. "A hook frame for TikTok" |
| `visible_scene` | `tagline`, or derived from scenario/framing/props when the tagline is generic (1,812 records) | Camera and lighting jargon removed |
| `where_used` | `businessMoment` | |
| `benefit` | first sentence of `sub` | |
| `target_audience`, `funnel_stage` | niche and asset type | |
| `subject`, `objects`, `environment`, `wardrobe_if_applicable`, `composition` | structured `v3` fields of the source | |
| `copy_safe_zones` | parsed from the source safe-zone sentence | Percent rectangles with a role |
| `dimensions` | aspect and recommended dimensions | |
| `brand_constraints` | palette (hex from source, colour words, or niche-derived), archetype | `paletteSource` records which |
| `reference_requirements` | derived from subject kind | Says when a real photo of a person or product is needed |
| `negative_constraints`, `best_platforms`, `keywords` | source | |
| `dna` | `compiler/dna.ts` | See below |
| `original_template` | — | Always `null`. The source has no separate template field and one is never invented. |
| `original` | the FINAL archive record, verbatim | 39 keys including all 10 platform prompts |
| `provenance` | importer | Archive names, paths, SHA-256, `alternate_differences`, `source_defects`, `transformations` |

Nothing in `original` is edited. Every derived field can be traced through `provenance.transformations`.

## Creative DNA (`dna`)

Deterministic extraction, no model call: `assetLabel`, `promise`, `subjectKind`, `subject`, `action`, `environment`, `environmentKind`, `props`, `mood`, `framing` (crop, subject side and share, secondary element), `pose`, `zones`, `noOverlay`, `palette`, `paletteSource`, `lightingVariant`, `person`, `anchors` (3–7 phrases that must survive into every prompt and artboard), `width`, `height`.

Distribution across the catalogue (from the import report): subject kind — person 3,556, two people 208, devices 129, texture 129, environment only 129, product 62, print/typographic 62, hands 56, flat-lay 45, group 41, pattern 20. Palette source — source hex 2,503, source colour words 1,473, niche-derived 461. Safe zones — parsed 3,388, explicitly no overlay 148, none stated 901. 31 environment kinds, 119 composition families.

## Gallery index entry

`id`, `cat`, `niche`, `title`, `what`, `see`, `use`, `why`, aspect and pixel size, fidelity label, composition family, thumbnail path and content hash (used for cache-busting). The browser loads only the index and thumbnails until a scene is opened; the full record is then fetched and validated by `catalog/catalog-client.ts`. A missing, corrupt or mismatched record raises a named error (`unknown-id`, `not-found`, `network`, `corrupt`, `integrity`) and the UI shows it. There is no substitute scene.

## Saved design (asset) record — demo host

`AssetRecord` in `integrations/host.ts`: `id`, `workspaceId`, `sceneId`, `title`, `status` (draft or approved), `kind`, `width`, `height`, `format`, `imageBytes`, `imageSha256`, `specHash`, `altText`, `createdAt`, `updatedAt`, `createdBy`, `version`, `campaignIds[]`, `insertedInto[]` and `rights[]` (who supplied each uploaded image and under what confirmation). The editable VisualSceneSpec and the exported HTML are stored beside the record for every version, so a saved design reopens as an editable document, not a flat image. The demo host keeps these per workspace under `data/workspaces/<workspace>/`. In the real Studio these map to the parent app's asset library through `HostAdapter` (see `PROMPT_STUDIO_SAAS_INTEGRATION.md`).

## Rebuilding the data

```
npm run import      # archives → canonical records, index, checksums, report (about 10 s)
npm run backfill    # records → specs, HTML artboards, thumbnails, coverage report (about 28 min cold, 5 s cached)
```
