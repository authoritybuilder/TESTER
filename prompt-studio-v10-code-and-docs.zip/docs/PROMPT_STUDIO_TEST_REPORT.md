# Prompt Studio — test report

Run on 11 November 2026 in a Linux cloud container: Node 22, TypeScript 5.9 (strict), Playwright 1.63.0 with Chromium 153.0.8010.12, sharp 0.35, zod 4. The complete output of the final run is in `docs/evidence/verify-log.txt` (ends with `exit=0`).

## Commands

```
npm ci
npm run import       # archives → canonical data
npm run backfill     # specs, artboards, thumbnails, coverage report
npm run lab          # six full-size lab artboards
npm run verify       # typecheck && lint && test && build && test:e2e
npm start            # preview server on port 4173
```

## Result of `npm run verify`

| Step | Result |
|---|---|
| `tsc --noEmit` (strict, `noUncheckedIndexedAccess`) | Clean |
| Lint (`scripts/lint.ts`) | OK — 49 files, 11 rules |
| Unit and integration tests | 25 passed, 0 failed |
| Build | `public/app.js` 697 KB from 116 modules; build fails if a server-only module is bundled |
| End-to-end tests (real server, real Chromium) | 23 passed, 0 failed |

### Unit and integration (25)

Catalogue (7): exactly 4,437 distinct scenes in 151 categories · every record validates and keeps its verbatim original and all 10 platform prompts · source checksums match · the two archives differ and the difference is preserved · customer copy is plain language · a missing, corrupt, mismatched or gutted record is an explicit error · safe-zone sentences parse to correct rectangles.

Compiler (8): legacy sameness regression · all 4,437 × 10 providers compile with anchors, in budget, no placeholders · 1,540-pair distinctness fixture · two businesses, one scene · platform variants share anchors and differ in syntax · short budgets never cut mid-sentence · reversible edits with a diff and concept lock · a gutted scene cannot compile.

Visual engine (10): every scene plans to a valid, traceable, honestly labelled spec · anchors present in the built artboard · two templates in one niche give different compositions · brand change keeps the scene · four aspect ratios re-compose · schema fails closed · renderer escapes all text for every scene · editor state and undo/redo · intent search and campaign packs · fidelity labels and the Claude tier's "unavailable" state.

### End-to-end (23)

Render and security (8): six lab artboards exist as HTML, spec, PNG and WebP at native size and are mutually different · rendering is deterministic, exact-size, font-complete and makes no network requests · different scenes give different images, brands change colour not structure, sizes re-compose · exact customer text including long names, currency and non-Latin text · transparent PNG and photo composites · sandbox blocks scripts and all external, localhost and `file:` requests · renderer limits · sanitiser.

Server (5): anonymous browsing allowed, actions explained · render API returns real PNG, WebP and JPEG at artboard size and rejects invalid specs with 422 · asset library save, list, reopen, new version, second session, other tenant denied · campaign pack ZIP with images, sources and manifest · honest capability states, rate limit and traversal.

Interface (10): gallery usable on first entry with no overlay, dialog or scroll lock · optional brand panel · intent search, filters and keyboard · editor edits the real artboard · exported PNG matches the artboard on screen; saved design reopens in a second session; other workspace denied · signed-out export in the browser · use my photo with rights confirmation · missing brief shows a distinct error and recovers · campaign flow to ZIP download · accessibility basics, responsive at 320/390/820/1440, theme tokens and computed colours match the Studio reference, no dark bands in the chrome.

## Catalogue-wide results

| Measure | Result | Source |
|---|---|---|
| Source records imported | 4,437 of 4,437, 151 categories | `data/reports/import-report.json` |
| Scene × provider compilations passing | 44,370 of 44,370 | unit test 9 |
| Specs planned and schema-valid | 4,437 | coverage report |
| HTML artboards written | 4,437 | coverage report |
| Thumbnails rasterised by Chromium | 4,437 | coverage report |
| Automated QA pass | 4,437 | coverage report |
| Failed renders / blank frames / missing files / text overflow | 0 / 0 / 0 / 0 | coverage report |
| Pixel-identical thumbnail groups | 0 | coverage report |
| Identical perceptual-hash groups (review candidates) | 68 groups, 163 scenes | coverage report |
| Near pairs inside one composition family (hash distance ≤ 3) | 2,114 | coverage report |
| First full backfill | 1,652 s | run log |
| Identical re-run | 0 rendered, 4,437 cached, 5 s | coverage report |
| Paid API calls | 0 Claude, 0 photo provider | coverage report |

## Checks done outside the test suite

- **Static hosting**: the repository was served by a plain static file server under a `/ThePromptStudio/` sub-path. The gallery loaded with thumbnails; the editor opened `tiktok-001`, accepted a headline edit and exported a 1080×1920 PNG in the browser; no page errors. The only failed request was the expected `api/session` 404.
- **Theme**: token values were sampled from the owner's Studio screenshot with sharp and are asserted in UI test 10.
- **Visual inspection by Claude, not by a person**: about 70 development renders, 96 thumbnails on review sheets 1 and 3 (of 217 stratified samples covering all 151 categories and 119 composition families, `data/reports/review-sample.json`), the six lab artboards at full size, and the application screenshots in `docs/evidence/`.

## Defects found by testing and fixed

Figures too small and copy cards covering them · mid-word masthead wrap (text fitting recalibrated from measured glyph widths) · three safe-zone parser errors · mirrored hands · 12 pixel-identical thumbnail groups (lighting variants) · 695 false overflow warnings (threshold calibrated) · `book` matching "notebook" (487 scenes re-rendered) · "bokeh" in customer copy · missing second chair in two-person scenes · a campaign pack repeating a composition family · identical Flux and Leonardo prompts · label casing · an invented statistic in demo copy · broken asset URLs under the Studio path · a dropped connection after a 413 · a non-atomic import that could leave no data on failure · app chrome themed dark instead of the light Studio theme (corrected twice from owner feedback).

## Not tested

- Any browser other than Chromium (Safari and Firefox untested, including the browser-side export).
- Real assistive technology; a full WCAG 2.2 audit.
- The live Claude API and any photo provider.
- Load, concurrency beyond the backfill, and long-running stability of the render worker.
- The real Authority Builder Studio host.
- Human review of the thumbnails. None has happened yet.
