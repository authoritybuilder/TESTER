# Prompt Studio — interface

Code: `features/prompt-studio/app/` (vanilla TypeScript, bundled by esbuild into `public/app.js`), styles in `public/app.css`. The module mounts with `mountPromptStudio(rootElement, host)` and does not render its own header or sidebar inside the real Studio.

## Theme

The chrome uses the live Authority Builder Studio light theme. Token values were sampled pixel-for-pixel from the Studio home screenshot supplied by the owner on 11 November 2026, cross-checked with the light theme in the animation library the owner supplied.

| Token | Value | Used for |
|---|---|---|
| `--ab-cream` | `#F5F5F0` | Page and top bar background |
| `--ab-white` | `#FFFFFF` | Rail, cards, pills, fields |
| `--ab-border` | `#DDE0D6` | Card and rail hairlines |
| `--ab-pill-border` | `#C9CCC4` | Pills and the search field |
| `--ab-lime` | `#A0CF5D` | Primary buttons, active navigation and selected states |
| `--ab-lime-bright` | `#B8E452` | Logo mark |
| `--ab-lime-pale` | `#D5EAB8` | Headline highlight |
| `--ab-glow` | `#D8ECBC` | Soft glow in the hero card |
| `--ab-ink` | `#141B15` | Text |
| `--ab-green` | `#3E6A1F` | Eyebrows and links |
| `--ab-muted` | `#5F6862` | Secondary text |
| `--ab-banner` / `-border` / `-ink` | `#E6F3E1` / `#B9D9AE` / `#1E4A2B` | Notice banner |
| `--ab-dark` | `#101D15` | Account pill, toasts, fidelity chip only |

Typeface: Plus Jakarta Sans, weight 800 with tight tracking for headings. Shapes: pill buttons, 20 px cards, a 28 px hero card.

An earlier pass used the animation library's dark dot-grid bands for the header and sidebar. That was wrong for the Studio and has been removed; a lint rule and a UI test now fail if dark bands return. The specification's original palette (`#031816`, `#9BE05A`, `#E8744F`, `#C9B8F0`) is also superseded by the owner's reference.

Customer brand colours style the generated assets only. They never change the app chrome, and Authority Builder's colours are never stamped onto customer artwork (unit test "brand change keeps the scene").

## Preview shell

`public/index.html` is a stand-in for the parent app so the module can be run on its own. It mirrors the Studio layout: a 96 px white icon rail (Home, Emails, Photos, Planner, **Prompts**, Designs, Projects, Brand, Connect, Settings), a light top bar with a workspace selector and a lime Create button. Items that belong to other Studio modules are greyed and not clickable. The pill in the top bar says plainly that this is a preview shell. Which rail item Prompt Studio finally lives under is the owner's decision; "Prompts" is highlighted here only because the name matches.

## Screens

| Screen | Route | What it does |
|---|---|---|
| Gallery | `#/` | Opens immediately, no overlay. Hero card with search and 10 goal pills, filters, favourites, recently used, compare (two at a time), paged grid of 4,437 cards, each with its own thumbnail, plain-language "You'll see / Use it for / Why" and a fidelity chip. |
| Brand panel | side panel on the gallery | Optional four-step wizard in the page flow (not a modal): Back, Next, Skip, Save, Close, Edit later, Reset only this draft. Autosaves; survives navigation and refresh; the gallery stays usable beside it. |
| Editor | `#/scene/<id>` | Live preview is the real artboard in a sandboxed iframe. Edit text in place, drag and resize layers, keyboard nudge, hide/lock/reorder/duplicate/delete layers, colour and size controls, undo/redo, size presets, plain-language change box with a diff, concept lock. Tabs: Edit, Creative brief, Exact prompt, Scene details, Sizes, History. |
| Modes in the editor | — | Design it here · Use my photo (rights confirmation dialog, removable) · Generate a photograph (disabled, "Not connected — optional") · Copy prompt |
| Export | editor toolbar | PNG, WebP, JPEG, HTML, design JSON. Server render when signed in; browser render otherwise. |
| My library | `#/library` | Saved designs for the workspace; reopen and edit, new versions, mark where a design is used. |
| Plan my whole launch | `#/campaign` | Pick what you are doing (launch, webinar, lead magnet, newsletter, course, podcast, service, product). Returns a sequence of visuals that each do a different job, never two from the same composition family. Build the set at channel sizes and export one ZIP. |
| Compare | `#/compare/<a>/<b>` | Two scenes side by side. |

## States

- **Missing or invalid scene record**: a named error with the scene id and a retry. No substitute content (UI test 8).
- **Not signed in**: browsing, editing and browser export work; saving explains that sign-in is needed (UI test 6).
- **View-only member**: can open designs, cannot save.
- **No photo provider / no Claude key**: shown as "Not connected — optional", with the reason.

## Accessibility and responsive checks

Automated in UI test 10 at 320, 390, 820 and 1440 px for the gallery and the editor: no horizontal scroll, every image has alt text, every control has an accessible name, no touch target under 32 px, exactly one `h1`, `lang="en-AU"`, no console errors. Token contrast pairs are asserted against WCAG AA (text 4.5:1, large or non-text 3:1). `prefers-reduced-motion` disables transitions. Focus moves into the brand panel when it opens and there is a skip link.

This is automated coverage of the basics, not a full WCAG 2.2 audit. Screen-reader testing with real assistive technology has not been done.

## Screenshots

`docs/evidence/`: `before-01`, `before-02` (legacy), `after-01` gallery, `after-02` brand panel, `after-03` intent search, `after-04` editor, `after-05` campaign, `after-06` gallery at 320/390/820, `after-07` editor at 320/390/820. Regenerate with `npx tsx scripts/dev/shots.ts docs/evidence`.

## Not built

Custom brand font upload, logo image upload (the logo is a text wordmark for now), review links, approvals workflow, analytics, a 24-language interface and the 7-toggle accessibility overlay used in other Authority Builder tools.
