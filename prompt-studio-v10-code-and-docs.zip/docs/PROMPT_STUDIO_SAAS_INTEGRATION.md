# Prompt Studio — integration with Authority Builder Studio

## Honest status

The parent Studio codebase was not available for this build. Prompt Studio is therefore integrated **against a contract**, and proven with a demo host, not wired into the real app. What that means in practice:

| Area | State |
|---|---|
| Module mounts into a host-supplied element and takes theme tokens from the host | Built and tested |
| Auth, entitlements, brand kit, asset library, campaigns, "insert into" | Built against `HostAdapter`; exercised with `DevHost` (file storage, demo tokens) |
| Real Studio login, real brand kit, real asset library | **Not connected** — needs an adapter written inside the Studio codebase |
| "Use in email builder / content planner" | Records a reference on the asset. It does **not** place anything in a real email or planner. |
| Billing, plans, usage metering | Not built. `Entitlements` has the fields; nothing enforces a plan. |

## The contract

`features/prompt-studio/integrations/host.ts`

```ts
interface HostAdapter {
  authenticate(headers): Promise<Principal | null>          // null = anonymous browsing
  entitlements(p): Promise<Entitlements>                    // canRender, canSave, rendersPerMinute, photoProvider, claudeDirection
  brandKit(p): Promise<BrandContext | null>
  saveBrandKit?(p, kit): Promise<void>
  saveAsset(p, { sceneId, title, spec, image, format, html, assetId?, status? }): Promise<AssetRecord>
  listAssets(p): Promise<AssetRecord[]>
  getAsset(p, id): Promise<{ record, spec, versions } | null>
  getAssetImage(p, id): Promise<{ data, format } | null>
  deleteAsset(p, id): Promise<boolean>
  insertAsset(p, id, target, targetId): Promise<AssetRecord | null>   // 'email-builder' | 'content-planner' | 'project' | 'page-builder'
  saveCampaign(p, c): Promise<CampaignRecord>
  listCampaigns(p): Promise<CampaignRecord[]>
}
```

`Principal` carries `userId`, `workspaceId` and `role`. Every adapter call is scoped to the principal's workspace; the server never accepts a workspace id from the request body.

## Front end

```ts
import { mountPromptStudio } from './features/prompt-studio/app/main.ts';
mountPromptStudio(document.getElementById('prompt-studio-root'), {
  getToken: () => studioSession.token,       // sent as a bearer token to the API
  requestSignIn: () => studio.openSignIn(),  // called when an action needs a signed-in user
});
```

Load `public/app.css` (or supply the `--ab-*` tokens from the Studio stylesheet and drop the `.ab-*` shell rules) and serve `public/data`, `public/thumbs` and `public/fonts`. Inside the Studio, do not ship `public/index.html`; it is only the preview shell.

## Server routes (preview server, `server/index.ts`)

All routes are also served under `/studio/prompt-studio/`.

| Route | Purpose | Signed in? |
|---|---|---|
| `GET /api/health` | Liveness, renderer and capability flags | No |
| `GET /api/session` | Principal, entitlements, brand kit | No (returns anonymous) |
| `PUT /api/brand-kit` | Save the workspace brand kit | Yes, not viewer |
| `POST /api/render` | Spec → PNG / WebP / JPEG | Yes |
| `POST /api/export/html` | Spec → self-contained HTML | Yes |
| `POST /api/export/pack` | Several specs → ZIP with images, sources and a manifest | Yes |
| `GET/POST /api/assets`, `GET/DELETE /api/assets/:id`, `GET /api/assets/:id/image`, `POST /api/assets/:id/insert` | Asset library | Yes |
| `GET/POST /api/campaigns` | Saved campaign plans | Yes |
| `POST /api/creative-direction` | Claude tier — 503 without a key | Yes |
| `POST /api/photo/generate` | Photo provider — always 503 (none connected) | Yes |

The render worker needs Node 22 and a Chromium that Playwright can launch. It is a long-running process and will not run on purely static hosting.

## Demo host

`server/dev-host.ts`. Tokens `demo-token-harbour` (owner, workspace Harbour), `demo-token-juniper` (owner, workspace Juniper) and `demo-token-viewer` (viewer, workspace Harbour), overridable with `AB_DEV_TOKENS`. **For local preview only.** Do not deploy the demo host.

## Deployment options

1. **Static preview** (GitHub Pages or any static host). Publish the repository as it is; the root `index.html` redirects to `public/`. Gallery, editor, prompts and browser-side export work. Saving, server rendering, campaign ZIP export and the asset library do not, because there is no API. Checked on 11 November 2026 by serving the repository from a plain static server under a `/ThePromptStudio/` sub-path: the gallery loaded and a 1080×1920 PNG exported from the editor with no page errors.
2. **Full preview**: `npm ci && npm run build && npm start`, then open `http://localhost:4173/studio/prompt-studio/` (set `PORT` to change the port).
3. **Inside the Studio**: write a `HostAdapter` against the Studio's auth, brand kit and asset storage, mount the module at `/studio/prompt-studio`, and run the render worker as a service.

Nothing has been pushed or published. The work is committed locally on the branch `html-first-rebuild-v2`.

## Rollback

The legacy app is intact at `legacy/index.html` with its `legacy/index.json`. To roll back a static deployment, remove the root redirect page and restore those two files to the repository root (`git rm index.html && git mv legacy/index.html index.html && git mv legacy/index.json index.json`) or redeploy the commit before this branch (`273bc6f`). The source archives and spreadsheets were never modified.

## Work needed to finish the integration

1. Decide where Prompt Studio sits in the Studio navigation (Prompts or Designs).
2. Implement `HostAdapter` in the Studio codebase and delete the demo tokens.
3. Map `insertAsset` to the real email builder and planner.
4. Host the render worker and put the rate limit in shared storage.
5. Move generated data (270 MB) to object storage or a CDN rather than the application repository.
