# Prompt Studio — creative engine (prompt compiler)

Code: `features/prompt-studio/compiler/dna.ts` and `pipeline.ts`. There is one compiler; the editor's "Exact prompt" tab, the "Copy prompt" mode and the tests all call it.

## Pipeline

```
loadFullSource(id)                  catalogue client — fails loudly if the record is missing or invalid
  → validate                        Zod schema + source checksum
  → deriveDistinctSceneSpec         creative DNA: subject, framing, zones, props, pose, palette, anchors
  → mergeWorkspaceBrandContext      business name, offer, audience, palette — optional
  → applyUserOverrides              typed edits and plain-language change requests
  → validateSceneInvariants         anchors still present; a gutted record throws SceneInvariantError
  → compileProviderSpecificInstructions
  → length check                    segments shorten, then drop whole, lowest priority first
  → brief + provenance
```

Rules that fix the legacy behaviour:

1. **No fallback scene.** If the full record cannot be loaded the compiler does not run and the UI shows an error naming the scene and the reason.
2. **Anchors are critical segments.** Each record carries 3–7 distinctness anchors taken from its own framing, safe zones, pose and props. Critical segments are never dropped by the length check, and nothing is ever cut mid-sentence.
3. **Brand personalises, it does not replace.** A brand kit changes names, palette and copy. It cannot change the subject, framing or composition family. Test: "same asset, two genuinely different businesses".
4. **Placeholders are resolved or removed.** No compiled prompt contains an unresolved `[placeholder]` or `{NAME}`.

## Provider adapters

Ten adapters build from the same scene spec, each in its own syntax and character budget:

| Provider | Budget | Shape |
|---|---|---|
| Claude | 2,600 | Labelled sections |
| ChatGPT | 1,700 | Natural-language brief |
| Midjourney | 950 | Comma tags, `--ar`, `--style raw`, `--no` |
| Flux | 1,300 | Composition first, "Keep the image free of…" |
| Imagen | 1,400 | Style first, "Do not include…" |
| Firefly | 950 | `Content type:` header |
| Leonardo | 1,300 | `Prompt:` / `Negative prompt:` / `Dimensions:` |
| SDXL | 900 | Tags and `Negative:` |
| Ideogram | 900 | "Text in image: none" |
| Sora | 1,500 | "Video brief." — labelled as video, not an image prompt |

## User control

- **Change requests in plain language** ("remove the plant, add a notebook, more white space") are parsed into typed overrides and returned with a reversible diff.
- **Concept lock** (on by default) refuses changes that would alter the subject kind, framing family or asset type, and says why.
- **Quick actions**: keep the concept and change the colour; switch layout and keep copy; and similar one-step edits.

## Verified behaviour

From `npm test` (`compiler.test.ts`, 8 tests, all passing on 11 November 2026):

| Check | Result |
|---|---|
| All 4,437 scenes × 10 providers compile | 44,370 compilations; anchors intact, within budget, no unresolved placeholders |
| Legacy regression pair (`fitness-coaches-001` / `-002`) | Similarity 0.94 in the originals → 0.63 (ChatGPT), 0.60 (Midjourney) |
| Pairwise fixture (56 scenes, 1,540 pairs, one brand kit) | Highest similarity 0.87, between two Social Background records written for different niches |
| Two businesses, one scene | Names, palette and copy differ; anchors and structure identical |
| Short budgets | Critical detail kept; lower-priority segments shortened or dropped whole |
| Gutted record | Throws a data-integrity error; no generic output |

## Optional Claude creative-director tier

`visual-engine/creative-director.ts` defines three passes (faithfulness check, art direction, critique) that return JSON against a schema using the Messages API structured-output format. It runs only on the server and only when `ANTHROPIC_API_KEY` is set; the model is read from `AB_CLAUDE_MODEL`.

**Status: not exercised against the live API.** No key was available in the build environment. The tier is covered by mock-transport tests only (schema shaping, refusal and `max_tokens` handling, "unavailable" state). Without a key, `POST /api/creative-direction` returns 503 and the UI says the feature is not connected. The deterministic compiler and planner above do not depend on it; all 4,437 previews were produced with zero model calls.

## Known limits

- 1,546 records share their scenario text with at least one other record in the source. Their identity comes from framing, safe zones, pose and business moment, which is why the 0.87 pair above exists. They are distinct, but closer to each other than records with unique scenarios.
- Change-request parsing is rule-based. Requests outside its vocabulary are reported as "not understood" rather than guessed.
