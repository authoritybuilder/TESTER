# Prompt Studio — HTML visual engine

The engine turns a catalogue record into a real image without an image-generation API:

```
canonical scene → planScene() → VisualSceneSpec (JSON) → renderArtboardHtml() → HTML/CSS/SVG artboard → Chromium screenshot → PNG / WebP / JPEG
```

Code: `features/prompt-studio/visual-engine/`.

## VisualSceneSpec — the source of truth

`scene-schema.ts`. A strict Zod schema (`SPEC_VERSION 1.0.0`) with 21 layer types: background, environment, figure, hands, object, shape, path, pattern, texture, image, headline, text, stat, badge, cta, annotation, logo, diagram, chart, frame and group. Positions are percentages of the artboard; sizes are in units of 1% of the short side, so one spec re-composes at any size. Images may only be base64 PNG/JPEG/WebP data URLs or `asset:` references. Validation fails closed: an invalid spec is rejected, never rendered.

The editor edits this spec. The preview, the export and the saved design are all the same document.

## Scene planner

`scene-planner.ts`, deterministic. It chooses a plan by subject kind (person, two people, group, hands, devices, product, flat-lay, environment only, pattern, texture, print), places the subject according to the parsed framing, lays copy into the parsed safe zones, picks the environment (31 kinds) and props (about 100 drawn objects), applies one of 22 distinct lighting/setting treatments, and derives colour roles from the scene palette or the customer's brand kit. `adaptZones()` re-composes for 1:1, 4:5, 9:16 and 16:9 rather than cropping.

Suggested copy is labelled `suggested` until the customer replaces it. No statistics, testimonials or claims are generated.

## Illustration kit

`illustration/` draws everything as procedural SVG: environments, props, 18 figure poses and hands. Figures are faceless and stylised on purpose. They stand in for a photograph; they are not presented as one.

## Honest fidelity labels

Every spec carries one label, shown on the thumbnail and in the editor:

| Stored value | Shown as | Meaning | Scenes |
|---|---|---|---|
| `final-html-asset` | HTML visual | The graphic is the finished asset | 294 |
| `composition-concept` | Composition concept | Layout, type and colour are real; the person, setting and objects are illustration standing in for a photograph | 3,987 |
| `photo-required` | Needs your photo | The asset's value is a real photo; the illustration marks where it goes | 156 |
| `customer-version` | Your version | The customer has placed their own photo | set in the editor |

## Artboard renderer

`artboard-renderer.ts` and `layer-registry.ts`. Output is one self-contained HTML document:

- no `<script>`, no event handlers, no external URLs;
- all text escaped;
- only the font faces a spec uses are embedded (Plus Jakarta Sans, Fraunces, Anton, Caveat — SIL OFL 1.1, see `public/fonts/LICENSES.md`);
- Content-Security-Policy `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:`;
- safe-zone guides exist only in the editor and are never present in exported or stored artboards.

## Render worker

`render-worker.ts`, Playwright 1.63.0 with Chromium 153. JavaScript disabled, service workers blocked, every non-`data:` request aborted and counted, a fresh context per render, timeouts, a 40-megapixel ceiling. After each render it reports text overflow, missing fonts and blocked requests. `asset-pipeline.ts` (sharp) converts to WebP/JPEG, checks the frame is not blank and computes a perceptual hash.

Browser fallback: when no server is available (for example static hosting, or a signed-out visitor) the editor rasterises in the browser through SVG `foreignObject` and canvas. Verified in Chromium only.

## Backfill

`scripts/backfill.ts` (`npm run backfill`). Resumable and idempotent. Cache key = sha256(scene id + source sha256 + spec hash + renderer version). A failed render keeps the last good record. Flags: `--only`, `--limit`, `--concurrency`, `--force`, `--recheck-qa`. The release gate requires 100% coverage, zero failures and zero pixel-identical groups. Results: `PROMPT_STUDIO_THUMBNAIL_COVERAGE.md`.

## Visual lab

`examples/prompt-studio-visual-lab.html` shows six catalogue scenes at full size, each with its spec, HTML artboard, PNG and WebP under `examples/lab/<id>/`:

| Scene | Role | Size | Label |
|---|---|---|---|
| `tiktok-001` | Hook / reel cover | 1080×1920 | Composition concept |
| `brand-consultants-019` | Offer hero | 1920×1080 | Composition concept |
| `linkedin-001` | Real-photo composite | 1080×1350 | HTML visual with an embedded raster (a synthetic test image, not a photo of a person) |
| `executive-coaches-009` | Instructional diagram | 1920×1080 | Composition concept |
| `ecommerce-005` | Flat-lay concept | 1080×1080 | Needs your photo |
| `linkedin-009` | Report cover | 2550×3300 | Composition concept |

Demo brands in the lab ("Northlight Brand Studio", "Marlow Advisory", "Fieldnote Research") are fictional. Rebuild with `npm run lab`.

## Verified behaviour

`visual-engine.test.ts` (10 tests) and `e2e/render-security.e2e.ts` (8 tests), all passing: every one of the 4,437 scenes plans to a valid, traceable spec; rendering is deterministic, exact-size and makes no network requests; different scenes give different images; one scene with two brands keeps its structure and changes colour; four aspect ratios re-compose with subject and headline on the artboard; long names, currency and non-Latin text render without overflow; transparent PNG works when asked.

## Limits

- Illustrations are concepts, not publish-grade photography. 3,987 of 4,437 previews are composition concepts.
- No pure-SVG export and no PDF or print-bleed export. Formats are HTML, PNG, WebP, JPEG, design JSON and a ZIP pack.
- 3,422 distinct layer-geometry signatures across 4,437 scenes; 1,442 scenes share a coarse signature with at least one other scene (same template family written for another niche). They differ in palette, environment, props and copy.
- An expert "custom fragment" path with a DOMPurify-in-Chromium sanitiser exists and is tested, but is not exposed in the UI.
