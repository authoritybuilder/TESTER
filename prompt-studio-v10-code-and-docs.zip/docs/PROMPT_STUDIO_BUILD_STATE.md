# Prompt Studio — build state

As at 11 November 2026. Branch `html-first-rebuild-v2`, committed locally, not pushed.

## Decision

**GO** for owner review and a private preview (static or local).
**NO-GO** for release to customers inside Authority Builder Studio.

The engine, data and interface work and are verified by 48 automated tests and a 100% preview gate. The release blockers are things that cannot be done from this repository: the real Studio connection, human review of the previews, and hosting for the renderer.

## Milestones

| Feature | Real state | Reproducible proof | Remaining blocker | Next repair |
|---|---|---|---|---|
| Source truth: both archives imported, all 4,437 originals preserved | Done | `npm run import`; `data/reports/import-report.json`; catalogue tests 1–4 | None | — |
| Prompt engine repaired: one compiler, no fallback scene, 10 provider adapters | Done | `npm test` (compiler tests); 44,370 compilations pass | 1,546 records share scenario text in the source, so some pairs are close (max 0.87) | Owner decides whether to rewrite those source scenarios |
| VisualSceneSpec, HTML/CSS/SVG artboards, Chromium rendering | Done | `npm run lab`; `examples/prompt-studio-visual-lab.html`; render tests | Illustrations are concepts, not photographs | Connect a photo provider or collect customer photos; optional Claude art-direction pass |
| Real image export (PNG, WebP, JPEG, HTML, JSON, ZIP) | Done | UI test 5, server test 2 and 4 | No pure SVG, PDF or print bleed | Add if print assets matter |
| Thumbnails for every record | Done — 4,437 of 4,437, 0 failed, 0 pixel-identical | `npm run backfill`; `PROMPT_STUDIO_THUMBNAIL_COVERAGE.md` | No human review; 68 identical-hash groups to look at | Owner reviews the five contact sheets, then the flagged groups |
| Gallery, optional brand panel, in-page editor | Done | UI tests 1–8; `docs/evidence/after-*.png` | Chromium only; basic accessibility checks only | Test Safari and Firefox; run a full accessibility review |
| Studio look and feel | Done against the owner's screenshot (light theme) | UI test 10 asserts tokens and computed colours | Built from one screenshot; other Studio screens not seen | Owner confirms, or supplies the Studio stylesheet |
| Campaign packs and channel sizes | Done | UI test 9, server test 4 | Rule-based recommendations | Tune with real usage |
| Asset library, brand kit, tenancy | Done against the demo host | Server test 3, UI test 5 | Demo tokens and file storage | Implement `HostAdapter` in the Studio |
| Native Studio integration | **Not done** — contract and preview shell only | `PROMPT_STUDIO_SAAS_INTEGRATION.md` | Studio codebase not available | Owner provides access or the adapter is written by the Studio developer |
| "Insert into email / planner" | **Reference only** | Server test 3 | Needs the real builders | Map `insertAsset` in the adapter |
| Claude creative-director tier | **Built, never run live** | Mock-transport tests | No API key in the build environment | Set `ANTHROPIC_API_KEY`, run on a small sample, review cost and quality |
| Photo generation | **Not connected** by design | `/api/photo/generate` returns 503 | Not in scope | Optional later |
| Security hardening | Renderer sandbox and tenancy tested | Render and server tests; `PROMPT_STUDIO_SECURITY.md` | Demo auth, in-memory rate limit, no independent review | Listed in the security notes |
| Documentation | Done | `docs/PROMPT_STUDIO_*.md` | — | — |

## Inputs that were not available

The Studio parent codebase, the "SaaS master prompt" file and the original Claude conversation named in the specification were not supplied and were not read. Where the specification depends on them, this build follows the specification text and the owner's two brand references only.

## Things the owner should know before relying on this

1. **Most previews are concepts.** 3,987 of 4,437 are illustrated stand-ins for a photograph, 156 need the customer's own photo, 294 are finished graphics. Each is labelled.
2. **No person has reviewed the thumbnails.** Claude inspected samples. The specification asks for human sign-off across every niche cluster.
3. **The theme was corrected twice** after owner feedback. It now matches the supplied Studio screenshot; it has not been compared with any other Studio screen.
4. **Repository size.** Generated data adds about 270 MB (scene records 124 MB, specs and artboards 96 MB, thumbnails 43 MB). GitHub accepts it, but a CDN or object store is the better home.
5. **Bundle size.** The app script is 697 KB, much of it the validation library.
6. **Nothing was pushed, published or saved to the owner's computer.**

## Next runnable steps

```
git log --oneline -3                 # confirm the local commit
npm ci && npm run verify             # reproduce the results (a few minutes)
npm start                            # http://localhost:4173/studio/prompt-studio/
```

Then, in order: owner looks at the preview and the contact sheets → decide the navigation home and confirm the theme → push the branch and open a pull request → Studio adapter → host the render worker → trial the Claude tier on 50 scenes → browser and accessibility testing → release decision.
