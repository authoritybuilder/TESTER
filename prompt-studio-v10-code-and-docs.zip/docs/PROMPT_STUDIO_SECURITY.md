# Prompt Studio — security notes

Scope: the module and its preview server as they exist in this repository. This is a description of the controls that were built and tested, not a penetration test or a compliance statement.

## Threat model in one paragraph

Customers type text and upload images that end up inside HTML which a headless browser then renders on the server. The main risks are script or network access from inside an artboard (server-side request forgery, data exfiltration), one workspace reading another workspace's designs, oversized inputs exhausting the renderer, and secrets reaching the browser.

## Controls

| Risk | Control | Proof |
|---|---|---|
| Script in an artboard | Artboards are generated from a validated JSON spec by a fixed layer registry. All text is escaped. No `<script>`, no event handlers, no external URLs are ever emitted. | Unit test "renderer escapes all text … for every catalogue scene" (all 4,437) |
| Hostile spec | Strict Zod schema, unknown keys rejected, bounded coordinates and sizes, image sources limited to base64 PNG/JPEG/WebP data URLs or `asset:` references. Invalid specs return 422 and are never rendered. | Unit test "schema validation fails closed"; server test "invalid specs are rejected (422)" |
| Network access from the renderer | Chromium runs with JavaScript disabled, service workers blocked and every non-`data:` request aborted and reported. Artboards carry CSP `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:`. | e2e "SANDBOX: scripts never run; external, localhost, file: and font/CSS requests are blocked and reported" |
| Renderer exhaustion | 40-megapixel ceiling, exactly one artboard per document, per-render timeout, isolated browser context per render, 9 MB request body limit (413, connection closed), 30 renders per minute per workspace. | e2e "RENDERER LIMITS…"; server test "rate limit and traversal are enforced" |
| Cross-tenant access | The workspace comes from the authenticated principal, never from the request. Asset reads, writes and deletes check workspace and role. | Server test "other tenants cannot"; UI test 5 "other workspace is denied" |
| Path traversal in static files and asset ids | Paths are resolved and confined to the public and data directories. | Server test "rate limit and traversal are enforced" |
| Preview in the editor | The live preview is an `<iframe sandbox="">` (no scripts, no same-origin). | UI test 4 "preview iframe is fully sandboxed" |
| Secrets in the browser | The Claude key is read only on the server. The build fails if a server-only module is bundled, and lint forbids the API host or key name in client folders. | `scripts/build.ts`, `scripts/lint.ts` |
| DOM injection in the app | Lint forbids `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `eval` and `new Function` in app code; the UI is built with a DOM helper. | `npm run lint` (11 rules, 49 files) |
| Uploaded images | Only raster data URLs, embedded into the spec; a rights confirmation is required and recorded on the asset. | UI test 7 |
| Custom HTML fragments (expert path, not exposed in the UI) | DOMPurify run inside sandboxed Chromium, size limit, fails closed. | e2e "SANITISER … strips or rejects every active-content vector" |

App pages are served with `x-content-type-options: nosniff`, `referrer-policy: same-origin`, `x-frame-options: SAMEORIGIN`, a restrictive permissions policy and CSP `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; frame-src 'self' about: data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'`.

## Not production-ready

- **Authentication is a demo.** `DevHost` accepts fixed bearer tokens. Real authentication, session handling and CSRF protection must come from the Studio.
- **Rate limiting is in memory**, per process. It resets on restart and is not shared across instances.
- **Storage is local files** with no encryption at rest, backups or retention policy.
- **No virus scanning** of uploads beyond type and size checks.
- **No audit log** of who exported or deleted what.
- **Dependencies** (zod, sharp, playwright, dompurify, esbuild, fontsource fonts) were installed at current versions; no vulnerability scan or licence review beyond the font licences was run.
- **No independent security review** has been carried out.

## Privacy

The preview stores brand kit details, designs and uploaded images on the machine running the server, under `data/workspaces/` (git-ignored). Nothing is sent to a third party: there were zero Claude API calls and zero photo-provider calls in this build. If the Claude tier is switched on, scene and brand text would be sent to Anthropic's API; that should be disclosed to customers before it is enabled.
