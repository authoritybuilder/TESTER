# Prompt Studio — audit of the original app and source archives

Audit date: 11 November 2026. Everything below was observed by running the code or reading the files in this repository. Nothing here is taken from a document or conversation that was not supplied (see "Inputs that were not available").

## Inputs that were available

| Input | Where | Used for |
|---|---|---|
| Legacy single-file app | `legacy/index.html` (709,126 bytes), `legacy/index.json` (5.4 MB) — moved from the repo root with `git mv` | Defect reproduction, before screenshots, regression fixtures |
| Final archive | `PROMPTSTUDIO-v9918-FINAL.zip` — sha256 `f40cfaed…86c68`, 4,589 zip entries, 4,437 scene records | Canonical source of every record |
| Rebuilt archive | `PROMPTSTUDIO-rebuilt.zip` — sha256 `02e3ca84…d70b7`, 4,589 zip entries, 4,437 scene records | Alternate source; differences preserved per record |
| Spreadsheets | `PromptStudioPro-v9-database.xlsx`, `PromptStudioPro-v9918-Enhanced.xlsx` | Left untouched at the repo root |
| Rebuild specification | Uploaded V2 specification (619 lines) | Requirements |
| Brand reference | `animation-mega-library-repo.zip` and a screenshot of the live Studio home screen, both supplied by the owner | App chrome tokens |

## Inputs that were not available

- The Authority Builder Studio parent application code. Integration is therefore built against an adapter contract and a demo host, not the real app (see `PROMPT_STUDIO_SAAS_INTEGRATION.md`).
- The "SaaS master prompt" file and the original Claude conversation referred to by the specification. Neither was supplied or reachable, so neither was read and nothing in this build claims to follow them.
- A Claude API key and any photo-generation provider credentials.

## Defects found in the legacy app

### 1. "Everything comes out the same" — root cause

`legacy/index.html` line 5224, `fetchScene(catKey, sceneId)`, requests the full record from `./prompts/<category>/<id>.json` and then from `raw.githubusercontent.com/.../prompts/...`. The repository has no `prompts/` directory: the per-scene files only exist inside the two zip archives. Both requests fail, the `catch` block silently builds a scene from the search-index entry, and the "self-heal" code that follows fills the gaps with generic text, for example:

> "The {base scene} image for {niche}. Designed to capture attention and drive your specific business outcome."

The scene that reaches `buildPrompt` (line 5382) has no platform prompts, no framing, no safe zones and no pose direction, so every output is assembled from the same boilerplate. There is no error state; the user cannot tell the brief is missing.

Recorded evidence: `features/prompt-studio/tests/fixtures/legacy-as-deployed.json` holds the legacy output for the deployed state, and `legacy-with-prompts-present.json` holds the output when the per-scene files are made available. Even in the second case the legacy compiler drops the framing and safe-zone sentences. Word-set similarity (Jaccard) between the original prompts for `fitness-coaches-001` and `fitness-coaches-002` is 0.94; the new compiler produces 0.63 (ChatGPT adapter) and 0.60 (Midjourney adapter) for the same pair. The regression test is `compiler.test.ts` → "REGRESSION 'everything comes out the same'".

### 2. Forced onboarding overlay

On first entry the legacy app covers the gallery with a full-screen wizard overlay. Screenshots: `docs/evidence/before-01-forced-wizard-overlay.png` and `before-02-gallery-after-skip.png`. The rebuild opens straight on the gallery; the brand wizard is an optional in-page side panel (UI test 1 and 2).

### 3. No scene-specific thumbnails

Legacy tiles are text cards. The rebuild renders one browser-rasterised thumbnail per record (4,437 of 4,437, see `PROMPT_STUDIO_THUMBNAIL_COVERAGE.md`).

### 4. Stale documentation

The previous `README.md` and `CHANGELOG.md` described versions 8.9–9.9 and contained counts that no longer match the data. Both have been rewritten; the lint rule "stale legacy claim/style/logic" keeps the old strings out of product code.

## Defects found in the source data (preserved, not hidden)

Counts from `data/reports/import-report.json`:

| Source defect | Records |
|---|---|
| Mid-sentence truncation in the original platform prompts (lighting clause cut by a character budget) | 4,209 |
| Generic tagline in the source | 1,812 |
| Scenario text shared verbatim with other records | 1,546 |
| Unresolved placeholders in original platform prompts | 1,411 |

Each affected record lists its defects under `provenance.source_defects`. The verbatim original is kept under `original`; the new compiler works from the structured fields (scenario, framing, safe zones, pose, props, palette) rather than from the truncated strings.

66 prop phrases did not match an illustration rule. Most are not objects ("considered editorial styling" ×215, "premium props matching brand register" ×123, "signature prop" ×107). They stay in the written brief and are omitted from the illustration; the full list is in the import report under `stats.unmatchedProps`.

## Comparison of the two nested archives

| Measure | Result |
|---|---|
| Records in FINAL / rebuilt / legacy index | 4,437 / 4,437 / 4,437 |
| Categories | 151 |
| Records byte-identical across the two archives | 0 |
| Legacy `index.json` agrees with | FINAL for 4,437 records, rebuilt for 0 |

Fields that differ, by number of records: `tagline` 4,437 · `promptTitle` 4,437 · `v3.platforms.chatgpt` 3,703 · `sub` 2,172 · `summary` 2,172 · `mj`, `flux`, `imagen`, `sdxl`, `ideogram`, `sora` 1,024 each · `claude` 512.

Decision: FINAL (v9.9.18) is canonical because its tagline and sub-text agree with the shipped index. The rebuilt archive's differing values are stored on every record under `provenance.alternate_differences`, so nothing from either archive is lost. Test: `catalog.test.ts` → "the two nested archives differ and the difference is preserved".

## What the audit could not establish

Whether the live GitHub Pages deployment currently behaves exactly as the repository copy does was not checked against the public URL; the reproduction used the files in this repository served locally.
