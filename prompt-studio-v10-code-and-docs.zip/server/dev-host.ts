/**
 * DEV/PREVIEW host adapter — file-backed, two demo workspaces. Demonstrates the tenancy contract end to end
 * (every read/write is scoped to principal.workspaceId; ids are unguessable; cross-tenant reads return null).
 * It is NOT the production store: Authority Builder Studio replaces this with its own services.
 */
import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { Forbidden, type AssetRecord, type CampaignRecord, type Entitlements, type HostAdapter, type InsertTarget, type Principal } from '../features/prompt-studio/integrations/host.ts';
import { hashHex, stableStringify } from '../features/prompt-studio/shared/util.ts';
import type { BrandContext } from '../features/prompt-studio/visual-engine/copy.ts';
import { validateSpec, type VisualSceneSpec } from '../features/prompt-studio/visual-engine/scene-schema.ts';

const sha = (b: Buffer | string): string => createHash('sha256').update(b).digest('hex');
const ID = /^[a-zA-Z0-9_-]{6,64}$/;
/** Demo tokens (override with AB_DEV_TOKENS='token:user:workspace:role,...'). Never use in production. */
const DEFAULT_TOKENS = 'demo-token-harbour:yaz:ws_harbour:owner,demo-token-juniper:sam:ws_juniper:owner,demo-token-viewer:kim:ws_harbour:viewer';

export class DevHost implements HostAdapter {
  private tokens = new Map<string, Principal>();
  constructor(private root: string, private caps: { claude: boolean }) {
    for (const t of (process.env.AB_DEV_TOKENS ?? DEFAULT_TOKENS).split(',')) { const [tok, userId, workspaceId, role] = t.split(':'); if (tok && userId && workspaceId) this.tokens.set(tok, { userId, workspaceId, role: (role as Principal['role']) ?? 'editor', workspaces: [workspaceId] }); }
    mkdirSync(root, { recursive: true });
  }
  private dir(ws: string, ...p: string[]): string { if (!ID.test(ws)) throw new Forbidden('Bad workspace id'); const d = join(this.root, ws, ...p); mkdirSync(d, { recursive: true }); return d; }
  async authenticate(h: Record<string, string | string[] | undefined>): Promise<Principal | null> {
    const raw = String(h['authorization'] ?? '').replace(/^Bearer\s+/i, ''); if (!raw) return null;
    for (const [tok, p] of this.tokens) { const a = Buffer.from(tok), b = Buffer.from(raw); if (a.length === b.length && timingSafeEqual(a, b)) return p; }
    return null;
  }
  async entitlements(p: Principal | null): Promise<Entitlements> {
    return { canRender: !!p, canSave: !!p && p.role !== 'viewer', rendersPerMinute: 30, photoProvider: { connected: false, reason: 'No photographic image provider is configured for this workspace. HTML design and your own photos work without one.' }, claudeDirection: { connected: this.caps.claude, reason: this.caps.claude ? 'Connected' : 'Claude creative direction is not configured on this server; designs use the built-in planner.' } };
  }
  async brandKit(p: Principal): Promise<BrandContext | null> { const f = join(this.dir(p.workspaceId), 'brand-kit.json'); return existsSync(f) ? (JSON.parse(readFileSync(f, 'utf8')) as BrandContext) : null; }
  async saveBrandKit(p: Principal, kit: BrandContext): Promise<void> { if (p.role === 'viewer') throw new Forbidden(); writeFileSync(join(this.dir(p.workspaceId), 'brand-kit.json'), JSON.stringify({ ...kit, workspaceId: p.workspaceId })); }
  private rec(ws: string, id: string): AssetRecord | null { if (!ID.test(id)) return null; const f = join(this.dir(ws, 'assets', id), 'record.json'); return existsSync(f) ? (JSON.parse(readFileSync(f, 'utf8')) as AssetRecord) : null; }
  async saveAsset(p: Principal, i: { sceneId: string; title: string; spec: VisualSceneSpec; image: Buffer; format: AssetRecord['format']; html: string; assetId?: string; status?: AssetRecord['status'] }): Promise<AssetRecord> {
    if (p.role === 'viewer') throw new Forbidden('Viewers cannot save assets');
    const spec = validateSpec(i.spec);
    const prev = i.assetId ? this.rec(p.workspaceId, i.assetId) : null; // an id from another workspace is simply not found here
    const id = prev?.id ?? 'ast_' + randomBytes(12).toString('base64url');
    const d = this.dir(p.workspaceId, 'assets', id); const version = (prev?.version ?? 0) + 1; const now = new Date().toISOString();
    const rights: AssetRecord['rights'] = []; for (const l of spec.artDirection.layerPlan) if (l.type === 'image') rights.push({ layerId: l.id, source: l.rights.source, note: l.rights.note });
    const rec: AssetRecord = { id, workspaceId: p.workspaceId, sceneId: i.sceneId, title: i.title.slice(0, 120), status: i.status ?? prev?.status ?? 'draft', kind: rights.length ? 'customer-version' : spec.artDirection.previewFidelity === 'final-html-asset' ? 'html-visual' : 'composition-concept', width: spec.output.width, height: spec.output.height, format: i.format, imageBytes: i.image.length, imageSha256: sha(i.image), specHash: hashHex(stableStringify(spec)), altText: spec.output.altText, createdAt: prev?.createdAt ?? now, updatedAt: now, createdBy: prev?.createdBy ?? p.userId, version, campaignIds: prev?.campaignIds ?? [], insertedInto: prev?.insertedInto ?? [], rights };
    writeFileSync(join(d, `v${version}.spec.json`), JSON.stringify(spec)); writeFileSync(join(d, `v${version}.html`), i.html); writeFileSync(join(d, `image.${i.format}`), i.image); writeFileSync(join(d, 'record.json'), JSON.stringify(rec));
    return rec;
  }
  async listAssets(p: Principal): Promise<AssetRecord[]> { const d = this.dir(p.workspaceId, 'assets'); return readdirSync(d).map(id => this.rec(p.workspaceId, id)).filter((r): r is AssetRecord => !!r).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); }
  async getAsset(p: Principal, id: string, version?: number): Promise<{ record: AssetRecord; spec: VisualSceneSpec; versions: number[] } | null> {
    const record = this.rec(p.workspaceId, id); if (!record) return null; const d = this.dir(p.workspaceId, 'assets', id);
    const versions = readdirSync(d).map(f => f.match(/^v(\d+)\.spec\.json$/)?.[1]).filter(Boolean).map(Number).sort((a, b) => a - b);
    const v = version && versions.includes(version) ? version : record.version;
    return { record, spec: validateSpec(JSON.parse(readFileSync(join(d, `v${v}.spec.json`), 'utf8'))), versions };
  }
  async getAssetImage(p: Principal, id: string): Promise<{ data: Buffer; format: string } | null> { const r = this.rec(p.workspaceId, id); if (!r) return null; return { data: readFileSync(join(this.dir(p.workspaceId, 'assets', id), `image.${r.format}`)), format: r.format }; }
  async deleteAsset(p: Principal, id: string): Promise<boolean> { if (p.role === 'viewer') throw new Forbidden(); if (!this.rec(p.workspaceId, id)) return false; rmSync(this.dir(p.workspaceId, 'assets', id), { recursive: true, force: true }); return true; }
  async insertAsset(p: Principal, id: string, target: InsertTarget, targetId: string): Promise<AssetRecord | null> {
    if (p.role === 'viewer') throw new Forbidden(); const r = this.rec(p.workspaceId, id); if (!r) return null;
    r.insertedInto.push({ target, targetId: targetId.slice(0, 80), at: new Date().toISOString() }); writeFileSync(join(this.dir(p.workspaceId, 'assets', id), 'record.json'), JSON.stringify(r)); return r;
  }
  async saveCampaign(p: Principal, c: Omit<CampaignRecord, 'id' | 'workspaceId' | 'createdAt' | 'createdBy'>): Promise<CampaignRecord> {
    if (p.role === 'viewer') throw new Forbidden();
    const own = c.assetIds.filter(id => this.rec(p.workspaceId, id)); if (own.length !== c.assetIds.length) throw new Forbidden('Campaign references assets outside this workspace');
    const rec: CampaignRecord = { ...c, name: c.name.slice(0, 120), id: 'cmp_' + randomBytes(9).toString('base64url'), workspaceId: p.workspaceId, createdAt: new Date().toISOString(), createdBy: p.userId };
    writeFileSync(join(this.dir(p.workspaceId, 'campaigns'), rec.id + '.json'), JSON.stringify(rec));
    for (const id of own) { const r = this.rec(p.workspaceId, id)!; r.campaignIds = [...new Set([...r.campaignIds, rec.id])]; writeFileSync(join(this.dir(p.workspaceId, 'assets', id), 'record.json'), JSON.stringify(r)); }
    return rec;
  }
  async listCampaigns(p: Principal): Promise<CampaignRecord[]> { const d = this.dir(p.workspaceId, 'campaigns'); return readdirSync(d).map(f => JSON.parse(readFileSync(join(d, f), 'utf8')) as CampaignRecord).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); }
}
