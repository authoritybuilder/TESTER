/**
 * Prompt Studio backend (migration-preview server). In Authority Builder Studio these routes mount under the parent
 * API with the parent's auth middleware; here a DevHost adapter stands in (see server/dev-host.ts).
 *
 *   npm start            → http://localhost:4173/studio/prompt-studio
 *
 * Security posture: every body is size-limited and schema-validated; rendering happens only in the isolated worker;
 * all asset/campaign routes are scoped to the authenticated principal's workspace; no secret ever reaches the browser.
 */
import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { dirname, extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Forbidden, type HostAdapter, type InsertTarget, type Principal } from '../features/prompt-studio/integrations/host.ts';
import { zipStore } from '../features/prompt-studio/shared/zip.ts';
import { renderArtboardHtml } from '../features/prompt-studio/visual-engine/artboard-renderer.ts';
import { resizePng, sha256, toJpeg, toWebp } from '../features/prompt-studio/visual-engine/asset-pipeline.ts';
import { CreativeDirector } from '../features/prompt-studio/visual-engine/creative-director.ts';
import { loadFontData, RenderError, RenderWorker } from '../features/prompt-studio/visual-engine/render-worker.ts';
import { SpecValidationError, validateSpec, type VisualSceneSpec } from '../features/prompt-studio/visual-engine/scene-schema.ts';
import { DevHost } from './dev-host.ts';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC = join(ROOT, 'public');
const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.md': 'text/markdown; charset=utf-8', '.map': 'application/json' };
const SECURITY_HEADERS = { 'x-content-type-options': 'nosniff', 'referrer-policy': 'same-origin', 'x-frame-options': 'SAMEORIGIN', 'permissions-policy': 'camera=(), microphone=(), geolocation=()' };
const APP_CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; frame-src 'self' about: data: blob:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'";
const MAX_BODY = 9 * 1024 * 1024;
const FORMATS = ['png', 'webp', 'jpeg'] as const; type Format = (typeof FORMATS)[number];

const MOUNT = '/studio/prompt-studio';
class HttpError extends Error { constructor(public status: number, msg: string, public code = 'error') { super(msg); } }
const send = (res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void => { const data = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body)); res.writeHead(status, { 'content-type': Buffer.isBuffer(body) ? 'application/octet-stream' : 'application/json; charset=utf-8', 'cache-control': 'no-store', ...SECURITY_HEADERS, ...headers, 'content-length': String(data.length) }); res.end(data); };
async function readJson(req: IncomingMessage): Promise<Record<string, unknown>> {
  const declared = Number(req.headers['content-length'] ?? 0); if (declared > MAX_BODY) throw new HttpError(413, 'Request is too large (limit 9MB).', 'too-large');
  const chunks: Buffer[] = []; let size = 0;
  for await (const c of req) { size += (c as Buffer).length; if (size > MAX_BODY) throw new HttpError(413, 'Request is too large (limit 9MB).', 'too-large'); chunks.push(c as Buffer); }
  try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}') as unknown; if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('not an object'); return v as Record<string, unknown>; } catch { throw new HttpError(400, 'Body must be a JSON object.', 'bad-json'); }
}

export interface ServerOptions { port?: number; host?: HostAdapter; dataDir?: string; quiet?: boolean }
export async function startServer(opts: ServerOptions = {}): Promise<{ port: number; close: () => Promise<void> }> {
  const director = new CreativeDirector();
  const host = opts.host ?? new DevHost(opts.dataDir ?? join(ROOT, 'data', 'workspaces'), { claude: director.available });
  let worker: RenderWorker | null = null; const getWorker = async (): Promise<RenderWorker> => (worker ??= await RenderWorker.launch());
  const hits = new Map<string, number[]>();
  const rateLimit = (p: Principal, perMin: number): void => { const now = Date.now(); const a = (hits.get(p.workspaceId) ?? []).filter(t => now - t < 60_000); if (a.length >= perMin) throw new HttpError(429, 'You’re exporting faster than this plan allows. Try again in a minute.', 'rate-limited'); a.push(now); hits.set(p.workspaceId, a); };
  const need = async (req: IncomingMessage): Promise<Principal> => { const p = await host.authenticate(req.headers); if (!p) throw new HttpError(401, 'Sign in to Authority Builder Studio to do this. You can keep browsing and editing without signing in.', 'auth-required'); return p; };

  async function renderSpec(spec: VisualSceneSpec, format: Format, o: { scale?: number; width?: number; lighting?: string; transparent?: boolean; resolveAsset?: (r: string) => string | null }): Promise<{ data: Buffer; html: string; overflow: string[]; width: number; height: number }> {
    const w = await getWorker();
    const scale = Math.min(2, Math.max(0.1, o.scale ?? 1));
    const out = await w.render({ spec, scale, lighting: o.lighting, isolate: true, transparent: o.transparent && format === 'png', resolveAsset: o.resolveAsset });
    if (out.blockedRequests.length) throw new HttpError(422, 'The design referenced an external resource, which is not allowed.', 'external-resource');
    let png = out.png; if (o.width && o.width < out.width) png = await resizePng(png, o.width);
    const data = format === 'png' ? png : format === 'webp' ? await toWebp(png, { quality: 90 }) : await toJpeg(png, 92, spec.artDirection.colourRoles.background);
    return { data, html: out.html, overflow: out.overflow, width: out.width, height: out.height };
  }
  const fmt = (v: unknown): Format => (FORMATS.includes(v as Format) ? (v as Format) : 'png');
  const lightingOf = (v: unknown): string | undefined => (typeof v === 'string' && v.length < 40 ? v : undefined);

  async function api(req: IncomingMessage, res: ServerResponse, path: string, url: URL): Promise<void> {
    const m = req.method ?? 'GET';
    if (path === '/api/health') return send(res, 200, { ok: true });
    if (path === '/api/session' && m === 'GET') { const p = await host.authenticate(req.headers); const ent = await host.entitlements(p); return send(res, 200, { principal: p ? { userId: p.userId, workspaceId: p.workspaceId, role: p.role } : null, entitlements: ent, brandKit: p ? await host.brandKit(p) : null, capabilities: { serverRender: true, formats: FORMATS, customHtmlMode: false } }); }
    if (path === '/api/brand-kit' && m === 'PUT') { const p = await need(req); const b = await readJson(req); if (!host.saveBrandKit) throw new HttpError(501, 'Brand kit is managed in Authority Builder Studio settings.'); await host.saveBrandKit(p, sanitiseBrand(b)); return send(res, 200, { ok: true, brandKit: await host.brandKit(p) }); }

    if (path === '/api/render' && m === 'POST') {
      const p = await need(req); const ent = await host.entitlements(p); if (!ent.canRender) throw new HttpError(403, 'Your plan does not include exports.', 'not-entitled'); rateLimit(p, ent.rendersPerMinute);
      const b = await readJson(req); const spec = validateSpec(b.spec); const format = fmt(b.format);
      const r = await renderSpec(spec, format, { scale: typeof b.scale === 'number' ? b.scale : 1, lighting: lightingOf(b.lighting), transparent: b.transparent === true });
      return send(res, 200, r.data, { 'content-type': 'image/' + format, 'x-ab-width': String(r.width), 'x-ab-height': String(r.height), 'x-ab-text-overflow': r.overflow.join(',').slice(0, 300), 'x-ab-sha256': sha256(r.data), 'content-disposition': `attachment; filename="${spec.sceneId}-${spec.output.width}x${spec.output.height}.${format === 'jpeg' ? 'jpg' : format}"` });
    }
    if (path === '/api/export/html' && m === 'POST') { await need(req); const b = await readJson(req); const spec = validateSpec(b.spec); const { html } = renderArtboardHtml(spec, { fonts: { mode: 'inline', data: loadFontData() }, lighting: lightingOf(b.lighting), title: spec.sceneId }); return send(res, 200, Buffer.from(html), { 'content-type': 'text/html; charset=utf-8', 'content-disposition': `attachment; filename="${spec.sceneId}.html"` }); }
    if (path === '/api/export/pack' && m === 'POST') {
      const p = await need(req); const ent = await host.entitlements(p); rateLimit(p, ent.rendersPerMinute);
      const b = await readJson(req); const items = Array.isArray(b.items) ? b.items.slice(0, 12) : []; if (!items.length) throw new HttpError(400, 'Nothing to export.');
      const files: Array<{ name: string; data: Uint8Array }> = []; const manifest: Record<string, unknown>[] = []; const format = fmt(b.format);
      for (const [i, it] of items.entries()) {
        const item = it as { spec: unknown; name?: string; lighting?: string }; const spec = validateSpec(item.spec);
        const base = `${String(i + 1).padStart(2, '0')}-${String(item.name ?? spec.sceneId).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 50)}-${spec.output.width}x${spec.output.height}`;
        const r = await renderSpec(spec, format, { lighting: lightingOf(item.lighting) });
        files.push({ name: `images/${base}.${format === 'jpeg' ? 'jpg' : format}`, data: r.data }, { name: `source/${base}.html`, data: Buffer.from(r.html) }, { name: `source/${base}.spec.json`, data: Buffer.from(JSON.stringify(spec, null, 1)) });
        manifest.push({ file: `images/${base}.${format === 'jpeg' ? 'jpg' : format}`, sceneId: spec.sceneId, width: spec.output.width, height: spec.output.height, placement: spec.output.intendedPlacement, altText: spec.output.altText, sha256: sha256(r.data), fidelity: spec.artDirection.previewFidelity, source: [`source/${base}.html`, `source/${base}.spec.json`], imageRights: spec.artDirection.layerPlan.filter(l => l.type === 'image').map(l => (l.type === 'image' ? { layer: l.id, ...l.rights } : null)), textOverflow: r.overflow });
      }
      files.push({ name: 'manifest.json', data: Buffer.from(JSON.stringify({ generatedAt: new Date().toISOString(), workspaceId: p.workspaceId, campaign: typeof b.campaign === 'string' ? b.campaign.slice(0, 120) : null, fonts: 'Plus Jakarta Sans, Fraunces, Anton, Caveat — SIL OFL 1.1 (embedded in the HTML sources)', note: 'Illustrated “composition concept” layers are stand-ins for photography and are labelled as such. Confirm claims and permissions before publishing.', assets: manifest }, null, 1)) });
      return send(res, 200, Buffer.from(zipStore(files)), { 'content-type': 'application/zip', 'content-disposition': 'attachment; filename="prompt-studio-pack.zip"' });
    }

    if (path === '/api/assets' && m === 'GET') { const p = await need(req); return send(res, 200, { assets: await host.listAssets(p) }); }
    if (path === '/api/assets' && m === 'POST') {
      const p = await need(req); const ent = await host.entitlements(p); if (!ent.canSave) throw new HttpError(403, 'You have view-only access to this workspace.', 'read-only'); rateLimit(p, ent.rendersPerMinute);
      const b = await readJson(req); const spec = validateSpec(b.spec); const format = fmt(b.format ?? 'png');
      const r = await renderSpec(spec, format, { lighting: lightingOf(b.lighting) });
      const rec = await host.saveAsset(p, { sceneId: spec.sceneId, title: String(b.title ?? spec.sceneId), spec, image: r.data, format, html: r.html, assetId: typeof b.assetId === 'string' ? b.assetId : undefined, status: b.status === 'approved' ? 'approved' : 'draft' });
      return send(res, 201, { asset: rec, textOverflow: r.overflow });
    }
    const am = path.match(/^\/api\/assets\/([a-zA-Z0-9_-]{6,64})(\/image|\/insert)?$/);
    if (am) {
      const p = await need(req); const id = am[1]!;
      if (!am[2] && m === 'GET') { const a = await (host as DevHost).getAsset(p, id, Number(url.searchParams.get('version')) || undefined); if (!a) throw new HttpError(404, 'Asset not found in this workspace.', 'not-found'); return send(res, 200, a); }
      if (!am[2] && m === 'DELETE') { const ok = await host.deleteAsset(p, id); if (!ok) throw new HttpError(404, 'Asset not found in this workspace.', 'not-found'); return send(res, 200, { ok: true }); }
      if (am[2] === '/image' && m === 'GET') { const im = await host.getAssetImage(p, id); if (!im) throw new HttpError(404, 'Asset not found in this workspace.', 'not-found'); return send(res, 200, im.data, { 'content-type': 'image/' + im.format, 'cache-control': 'private, max-age=60' }); }
      if (am[2] === '/insert' && m === 'POST') { const b = await readJson(req); const target = String(b.target) as InsertTarget; if (!['email-builder', 'content-planner', 'project', 'page-builder'].includes(target)) throw new HttpError(400, 'Unknown destination.'); const r = await host.insertAsset(p, id, target, String(b.targetId ?? 'default')); if (!r) throw new HttpError(404, 'Asset not found in this workspace.', 'not-found'); return send(res, 200, { asset: r, note: 'Reference recorded through the host adapter. In the standalone preview this is a recorded link, not a live insert into another module.' }); }
    }
    if (path === '/api/campaigns' && m === 'GET') { const p = await need(req); return send(res, 200, { campaigns: await host.listCampaigns(p) }); }
    if (path === '/api/campaigns' && m === 'POST') { const p = await need(req); const b = await readJson(req); const ids = Array.isArray(b.assetIds) ? b.assetIds.map(String).slice(0, 20) : []; const c = await host.saveCampaign(p, { name: String(b.name ?? 'Untitled campaign'), objective: String(b.objective ?? '').slice(0, 200), flow: String(b.flow ?? '').slice(0, 60), assetIds: ids, hypothesis: String(b.hypothesis ?? '').slice(0, 400) }); return send(res, 201, { campaign: c }); }
    if (path === '/api/creative-direction' && m === 'POST') { await need(req); if (!director.available) throw new HttpError(503, 'Claude creative direction isn’t connected on this server, so the built-in planner is used. Nothing was generated or charged.', 'director-unavailable'); throw new HttpError(501, 'Creative direction is enabled per workspace by the host application.', 'not-enabled'); }
    if (path === '/api/photo/generate') throw new HttpError(503, 'No photographic image provider is connected. Use “Design it here” or “Create with my photos”.', 'photo-provider-unavailable');
    throw new HttpError(404, 'Unknown API route.', 'not-found');
  }

  function serveStatic(req: IncomingMessage, res: ServerResponse, path: string): void {
    let rel = path;
    if (rel === '/') rel = '/index.html';
    let base = PUBLIC;
    if (rel.startsWith('/visual/')) { base = join(ROOT, 'data', 'visual'); rel = rel.slice('/visual'.length); }
    else if (rel.startsWith('/examples/')) { base = join(ROOT, 'examples'); rel = rel.slice('/examples'.length); }
    const file = normalize(join(base, decodeURIComponent(rel)));
    if (!(file === base || file.startsWith(base + sep)) || !existsSync(file) || !statSync(file).isFile()) { send(res, 404, { error: 'Not found' }); return; }
    const ext = extname(file); const st = statSync(file); const etag = `"${st.size}-${Math.round(st.mtimeMs)}"`;
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, SECURITY_HEADERS); res.end(); return; }
    const isArtboard = base !== PUBLIC && ext === '.html';
    res.writeHead(200, { 'content-type': MIME[ext] ?? 'application/octet-stream', 'content-length': String(st.size), etag, 'cache-control': /\/thumbs\/|\/fonts\//.test(rel) ? 'public, max-age=86400' : 'no-cache', ...SECURITY_HEADERS, ...(ext === '.woff2' ? { 'access-control-allow-origin': '*' } : {}), ...(ext === '.html' && !isArtboard ? { 'content-security-policy': APP_CSP } : {}) });
    createReadStream(file).pipe(res);
  }

  const server = createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost'); let path = url.pathname;
    // The module is base-path agnostic: everything is also served under the parent-style route /studio/prompt-studio/.
    if (path === '/' || path === MOUNT) { res.writeHead(302, { location: MOUNT + '/' + (url.search ?? '') }); res.end(); return; }
    if (path.startsWith(MOUNT + '/')) path = path.slice(MOUNT.length);
    if (!path.startsWith('/api/')) { try { serveStatic(req, res, path); } catch { send(res, 500, { error: 'Server error' }); } return; }
    api(req, res, path, url).catch(e => {
      if (e instanceof HttpError) { if (e.status === 413) { res.on('finish', () => req.destroy()); return send(res, 413, { error: e.message, code: e.code }, { connection: 'close' }); } return send(res, e.status, { error: e.message, code: e.code }); }
      if (e instanceof SpecValidationError) return send(res, 422, { error: 'That design could not be validated, so it was not rendered.', code: 'invalid-spec', issues: e.issues.slice(0, 8) });
      if (e instanceof RenderError) return send(res, e.code === 'timeout' ? 504 : 422, { error: `The renderer could not produce this image (${e.code}). Your design is unchanged.`, code: 'render-' + e.code });
      if (e instanceof Forbidden) return send(res, 403, { error: e.message, code: 'forbidden' });
      if (!opts.quiet) console.error('[api]', (e as Error).message);
      send(res, 500, { error: 'Something went wrong on the server. Your design is unchanged.', code: 'server-error' });
    });
  });
  const port = opts.port ?? Number(process.env.PORT ?? 4173);
  await new Promise<void>(r => server.listen(port, r));
  const actual = (server.address() as { port: number }).port;
  if (!opts.quiet) console.log(`Prompt Studio → http://localhost:${actual}/studio/prompt-studio/`);
  return { port: actual, close: async () => { await worker?.close(); await new Promise<void>(r => server.close(() => r())); } };
}

function sanitiseBrand(b: Record<string, unknown>): Record<string, unknown> {
  const s = (v: unknown, n: number): string | undefined => (typeof v === 'string' && v.trim() ? v.trim().slice(0, n) : undefined);
  const hex = (v: unknown): string | undefined => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v.toUpperCase() : undefined);
  const pal = b.palette as Record<string, unknown> | undefined;
  const palette = pal && hex(pal.primary) && hex(pal.secondary) && hex(pal.accent) && hex(pal.light) && hex(pal.dark) ? { primary: hex(pal.primary), secondary: hex(pal.secondary), accent: hex(pal.accent), light: hex(pal.light), dark: hex(pal.dark) } : undefined;
  return JSON.parse(JSON.stringify({ businessName: s(b.businessName, 80), offer: s(b.offer, 160), audience: s(b.audience, 160), painPoint: s(b.painPoint, 200), promise: s(b.promise, 160), cta: s(b.cta, 40), website: s(b.website, 120), palette, headlineFont: ['jakarta', 'fraunces', 'anton'].includes(String(b.headlineFont)) ? b.headlineFont : undefined, logoText: s(b.logoText, 40) })) as Record<string, unknown>;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) startServer().catch(e => { console.error(e); process.exit(1); });
