/**
 * In-page visual editor. The large preview IS the HTML/SVG artboard that gets exported: it is rendered by the same
 * trusted renderer into a sandboxed, script-less iframe. Editing happens on the VisualSceneSpec via editor-state.ts.
 */
import type { CanonicalScene } from '../catalog/schema.ts';
import { SceneLoadError, type Catalogue } from '../catalog/catalog-client.ts';
import { compileScene, parseChangeRequest, PROVIDERS, type ProviderKey, type UserOverrides } from '../compiler/pipeline.ts';
import * as ES from '../editor/editor-state.ts';
import { collectFonts, renderArtboardHtml } from '../visual-engine/artboard-renderer.ts';
import type { BrandContext } from '../visual-engine/copy.ts';
import { hasProp, resolveProp } from '../visual-engine/illustration/props.ts';
import { LAYER_META } from '../visual-engine/layer-registry.ts';
import { planScene } from '../visual-engine/scene-planner.ts';
import { validateSpec, type VisualLayer, type VisualSceneSpec } from '../visual-engine/scene-schema.ts';
import { add, Api, ApiError, clear, download, h, loadFonts, store, toast } from './dom.ts';

export interface EditorDeps {
  api: Api; catalogue: Catalogue; brand: () => BrandContext | undefined; signedIn: () => boolean; workspaceId: () => string;
  photoProvider: () => { connected: boolean; reason: string }; onBack: () => void; openWizard: () => void;
  addToPack: (item: { spec: VisualSceneSpec; name: string; lighting: string }) => void; serverAvailable: () => boolean;
}
export const FIDELITY_LABEL: Record<string, string> = { 'final-html-asset': 'HTML visual', 'composition-concept': 'Composition concept', 'photo-required': 'Needs your photo', 'customer-version': 'Customer version' };
const FIDELITY_NOTE: Record<string, string> = {
  'final-html-asset': 'This is a finished HTML graphic. What you see is what exports.',
  'composition-concept': 'The illustrated person, setting and objects are a layout concept standing in for a photograph. Add your own photo for a finished image — the type, colour and layout are already final.',
  'photo-required': 'This design is built around a real photo (your product, your face or your work). The illustration shows where it goes — add your photo before publishing.',
};

/** Rasterise in this browser (used when no render server is reachable, e.g. static hosting). Real pixels from the same HTML. */
export async function browserRasterise(html: string, width: number, height: number, type: 'image/png' | 'image/webp' | 'image/jpeg'): Promise<Blob> {
  const doc = new DOMParser().parseFromString(html, 'text/html'); const board = doc.querySelector('[data-artboard="true"]'); const style = doc.querySelector('style');
  if (!board) throw new Error('Artboard missing');
  const xhtml = new XMLSerializer().serializeToString(board); const css = (style?.textContent ?? '').replace(/]]>/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml"><style><![CDATA[${css}]]></style>${xhtml}</div></foreignObject></svg>`;
  const img = new Image(); img.decoding = 'sync';
  await new Promise<void>((res, rej) => { img.onload = () => res(); img.onerror = () => rej(new Error('This browser could not rasterise the design')); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); });
  await new Promise(r => setTimeout(r, 120)); // let embedded fonts settle
  const c = document.createElement('canvas'); c.width = width; c.height = height; const g = c.getContext('2d'); if (!g) throw new Error('Canvas unavailable');
  if (type === 'image/jpeg') { g.fillStyle = '#FFFFFF'; g.fillRect(0, 0, width, height); }
  g.drawImage(img, 0, 0, width, height);
  return new Promise<Blob>((res, rej) => c.toBlob(b => (b ? res(b) : rej(new Error('Export failed'))), type, 0.92));
}

export async function mountEditor(root: HTMLElement, sceneId: string, deps: EditorDeps, opts: { assetId?: string } = {}): Promise<() => void> {
  clear(root);
  const shell = h('div', { class: 'ed', 'aria-busy': 'true' }, h('div', { class: 'ps-loading', role: 'status' }, 'Loading the full brief…')); root.append(shell);
  let scene: CanonicalScene;
  try { scene = await deps.catalogue.loadFullSource(sceneId); }
  catch (e) {
    clear(shell); shell.removeAttribute('aria-busy');
    const err = e instanceof SceneLoadError ? e : new SceneLoadError(sceneId, 'integrity', (e as Error).message, false);
    shell.append(h('div', { class: 'ps-error', role: 'alert' }, h('h2', {}, 'We couldn’t open this template'), h('p', {}, err.message), h('p', { class: 'ps-muted' }, 'Nothing has been substituted for the missing brief.'), h('div', { class: 'ps-row' }, err.recoverable ? h('button', { class: 'ps-btn ps-btn--primary', onclick: () => void mountEditor(root, sceneId, deps, opts) }, 'Try again') : null, h('button', { class: 'ps-btn', onclick: deps.onBack }, 'Back to gallery'))));
    return () => undefined;
  }
  const lighting = scene.dna.lightingVariant;
  const draftKey = `ab.ps.draft.${deps.workspaceId()}.${sceneId}`;
  let initial: VisualSceneSpec; let assetId = opts.assetId; let savedVersions: number[] = [];
  const base = planScene(scene, { brand: deps.brand() });
  const original = { medium: base.artDirection.medium, fidelity: base.artDirection.previewFidelity };
  initial = base;
  if (assetId) { try { const a = await deps.api.json<{ spec: VisualSceneSpec; versions: number[] }>('GET', `/api/assets/${assetId}`); initial = validateSpec(a.spec); savedVersions = a.versions; } catch (e) { toast('Couldn’t reopen the saved version: ' + (e as Error).message, 'error'); assetId = undefined; } }
  else { const d = store.get<VisualSceneSpec | null>(draftKey, null); if (d) { try { initial = validateSpec(d); } catch { store.del(draftKey); } } }

  const hist = new ES.History<VisualSceneSpec>(initial);
  let selected: string | null = null; let guides = false; let sizeKey: ES.SizeKey = 'native'; let quickStep = 0; let provider: ProviderKey = 'chatgpt';
  let tab: 'edit' | 'brief' | 'prompt' | 'details' | 'sizes' | 'history' = 'edit'; let conceptLocked = true; let overrides: UserOverrides = {}; let lastDiff: string[] = []; let lastOverflow: string[] = [];
  let scale = 0.4; let saveState = 'Draft autosaves on this device';

  // ---------------------------------------------------------------- skeleton
  clear(shell); shell.removeAttribute('aria-busy');
  const chip = h('span', { class: 'ps-chip' }); const saveNote = h('span', { class: 'ps-muted ed-save', 'aria-live': 'polite' }, saveState);
  const undoBtn = h('button', { class: 'ps-btn ps-btn--ghost', title: 'Undo (Ctrl+Z)', 'aria-label': 'Undo', onclick: () => { hist.undo(); changed(false); } }, '↶ Undo');
  const redoBtn = h('button', { class: 'ps-btn ps-btn--ghost', title: 'Redo (Ctrl+Shift+Z)', 'aria-label': 'Redo', onclick: () => { hist.redo(); changed(false); } }, '↷ Redo');
  const sizeSel = h('select', { class: 'ps-select', 'aria-label': 'Size and placement', onchange: () => switchSize(sizeSel.value as ES.SizeKey) }, ...ES.SIZE_PRESETS.map(p => h('option', { value: p.key }, p.key === 'native' ? `Original · ${scene.dimensions.width}×${scene.dimensions.height}` : p.label)));
  const guideBtn = h('button', { class: 'ps-btn ps-btn--ghost', 'aria-pressed': 'false', onclick: () => { guides = !guides; guideBtn.setAttribute('aria-pressed', String(guides)); render(); } }, 'Safe zones');
  const exportSel = h('select', { class: 'ps-select', 'aria-label': 'Export format' }, h('option', { value: 'png' }, 'PNG image'), h('option', { value: 'webp' }, 'WebP image'), h('option', { value: 'jpeg' }, 'JPEG image'), h('option', { value: 'html' }, 'HTML (editable source)'), h('option', { value: 'json' }, 'Design file (JSON)'));
  const exportBtn = h('button', { class: 'ps-btn ps-btn--primary', onclick: () => void doExport() }, 'Export');
  const saveBtn = h('button', { class: 'ps-btn', onclick: () => void doSave() }, 'Save to library');
  const top = h('header', { class: 'ed-top' },
    h('button', { class: 'ps-btn ps-btn--ghost', onclick: deps.onBack }, '← Gallery'),
    h('div', { class: 'ed-title' }, h('h1', {}, scene.dna.assetLabel), h('p', { class: 'ps-muted' }, scene.what_creating), chip),
    h('div', { class: 'ed-actions' }, undoBtn, redoBtn, sizeSel, guideBtn, exportSel, exportBtn, saveBtn));
  const left = h('aside', { class: 'ed-left', 'aria-label': 'Edit this visual' }); const right = h('aside', { class: 'ed-right', 'aria-label': 'Layers' });
  const frameA = h('iframe', { class: 'ed-frame', sandbox: '', title: 'Live artboard preview', tabindex: '-1' }); const frameB = h('iframe', { class: 'ed-frame', sandbox: '', title: 'Live artboard preview (buffer)', tabindex: '-1', 'aria-hidden': 'true' });
  let front = frameA, back = frameB; back.style.visibility = 'hidden';
  const selBox = h('div', { class: 'ed-sel', hidden: true }, h('div', { class: 'ed-handle', 'data-handle': '1', title: 'Drag to resize' }));
  const overlay = h('div', { class: 'ed-overlay', tabindex: '0', role: 'application', 'aria-label': 'Artboard. Click a layer to select it, drag to move, arrow keys to nudge, Delete to remove.' }, selBox);
  const wrap = h('div', { class: 'ed-wrap' }, frameA, frameB, overlay);
  const note = h('p', { class: 'ed-note' }); const warn = h('div', { class: 'ed-warn', 'aria-live': 'polite' });
  const modes = h('div', { class: 'ed-modes', role: 'group', 'aria-label': 'How to make this image' });
  const stage = h('main', { class: 'ed-stage' }, modes, h('div', { class: 'ed-canvas' }, wrap), note, warn);
  shell.append(top, h('div', { class: 'ed-body' }, left, stage, right));
  const fileIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', hidden: true, 'aria-label': 'Choose a photo', onchange: () => void pickPhoto() }); shell.append(fileIn);

  const spec = (): VisualSceneSpec => hist.value;
  const apply = (next: VisualSceneSpec): void => { hist.push(next); changed(); };
  const tryOp = (f: () => VisualSceneSpec | void): void => { try { const r = f(); if (r) apply(r); } catch (e) { toast((e as Error).message, 'error'); } };

  // ---------------------------------------------------------------- render (double-buffered so the preview never flashes)
  let renderTimer = 0; let liveSpec: VisualSceneSpec | null = null;
  function fit(): void { const s = liveSpec ?? spec(); const availW = Math.max(240, stage.clientWidth - 32), availH = Math.max(280, window.innerHeight - 250); scale = Math.min(availW / s.output.width, availH / s.output.height, 1); wrap.style.width = Math.round(s.output.width * scale) + 'px'; wrap.style.height = Math.round(s.output.height * scale) + 'px'; for (const f of [frameA, frameB]) { f.style.width = s.output.width + 'px'; f.style.height = s.output.height + 'px'; f.style.transform = `scale(${scale})`; } drawSelection(); }
  async function renderNow(): Promise<void> {
    const s = liveSpec ?? spec(); const fonts = await loadFonts(collectFonts(s).map(f => f.file));
    const { html } = renderArtboardHtml(s, { fonts: { mode: 'inline', data: fonts }, guides, lighting });
    const target = back; target.onload = () => { target.style.visibility = 'visible'; front.style.visibility = 'hidden'; const t = front; front = target; back = t; };
    target.srcdoc = html; fit();
  }
  function render(): void { window.clearTimeout(renderTimer); renderTimer = window.setTimeout(() => void renderNow(), 25); }
  function changed(persist = true): void {
    liveSpec = null; const s = spec(); if (selected && !ES.findLayer(s, selected)) selected = null;
    undoBtn.disabled = !hist.canUndo; redoBtn.disabled = !hist.canRedo;
    const fid = s.artDirection.layerPlan.some(l => l.type === 'image' && !l.hidden) ? 'customer-version' : s.artDirection.previewFidelity;
    chip.textContent = FIDELITY_LABEL[fid] ?? fid; chip.dataset.fid = fid;
    note.textContent = fid === 'customer-version' ? 'Your photo is in place. Layout, type and colour are final — check the crop, then export.' : FIDELITY_NOTE[s.artDirection.previewFidelity] ?? '';
    const cw = ES.contrastWarnings(s); clear(warn);
    if (cw.length) warn.append(h('p', {}, `Low contrast on ${cw.map(c => `“${c.name}” (${c.ratio}:1)`).join(', ')} — try another colour.`));
    if (lastOverflow.length) warn.append(h('p', {}, `Text may be clipped in: ${lastOverflow.join(', ')}. Shorten it or enlarge the box.`));
    if (persist) { const ok = store.set(draftKey, s); saveState = ok ? 'Draft saved on this device · ' + new Date().toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' }) : 'Draft too large to autosave — use Save to library'; saveNote.textContent = saveState; }
    render(); drawLeft(); drawLayers(); drawModes();
  }

  // ---------------------------------------------------------------- selection + pointer editing
  const pct = (e: PointerEvent | MouseEvent): { x: number; y: number } => { const r = overlay.getBoundingClientRect(); return { x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100 }; };
  function hit(x: number, y: number): string | null {
    const ls = spec().artDirection.layerPlan; let fallback: string | null = null;
    for (let i = ls.length - 1; i >= 0; i--) { const l = ls[i]!; if (l.hidden) continue; const b = l.box; if (x < b.x || y < b.y || x > b.x + b.w || y > b.y + b.h) continue; const full = b.w >= 99 && b.h >= 99; if (full) { fallback ??= l.id; continue; } return l.id; }
    return fallback;
  }
  function drawSelection(): void { const l = selected ? ES.findLayer(liveSpec ?? spec(), selected) : undefined; if (!l || l.hidden) { selBox.hidden = true; return; } selBox.hidden = false; selBox.style.left = l.box.x + '%'; selBox.style.top = l.box.y + '%'; selBox.style.width = l.box.w + '%'; selBox.style.height = l.box.h + '%'; selBox.dataset.locked = String(!!l.locked); }
  function select(id: string | null): void { selected = id; drawSelection(); drawLayers(); drawLeft(); }
  let drag: { id: string; start: { x: number; y: number }; box: { x: number; y: number; w: number; h: number }; resize: boolean; moved: boolean } | null = null;
  overlay.addEventListener('pointerdown', e => {
    if ((e.target as HTMLElement).tagName === 'TEXTAREA') return; const p = pct(e); const onHandle = (e.target as HTMLElement).dataset.handle === '1'; const id = onHandle ? selected : hit(p.x, p.y);
    select(id); overlay.focus({ preventScroll: true }); const l = id ? ES.findLayer(spec(), id) : undefined; if (!l || l.locked) return;
    drag = { id: l.id, start: p, box: { ...l.box }, resize: onHandle, moved: false }; overlay.setPointerCapture(e.pointerId); e.preventDefault();
  });
  overlay.addEventListener('pointermove', e => {
    if (!drag) return; const p = pct(e); const dx = p.x - drag.start.x, dy = p.y - drag.start.y; if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 0.6) return; drag.moved = true;
    const snap = (v: number): number => { for (const g of [0, 50, 100]) if (Math.abs(v - g) < 0.8) return g; return v; };
    const nb = drag.resize ? { ...drag.box, w: Math.max(2, drag.box.w + dx), h: Math.max(2, drag.box.h + dy) } : { ...drag.box, x: drag.box.x + dx, y: drag.box.y + dy };
    if (!drag.resize) { const cx = snap(nb.x + nb.w / 2); nb.x = cx - nb.w / 2; nb.x = snap(nb.x); nb.y = snap(nb.y); if (Math.abs(nb.x + nb.w - 100) < 0.8) nb.x = 100 - nb.w; if (Math.abs(nb.y + nb.h - 100) < 0.8) nb.y = 100 - nb.h; }
    try { liveSpec = ES.setBox(spec(), drag.id, nb); drawSelection(); render(); } catch { /* ignore invalid intermediate */ }
  });
  const endDrag = (): void => { if (drag?.moved && liveSpec) { const s = liveSpec; liveSpec = null; apply(s); } drag = null; };
  overlay.addEventListener('pointerup', endDrag); overlay.addEventListener('pointercancel', endDrag);
  overlay.addEventListener('dblclick', e => { const p = pct(e); const id = hit(p.x, p.y); const l = id ? ES.findLayer(spec(), id) : undefined; if (l && ES.layerText(l) !== null && !l.locked) inlineEdit(l); });
  function inlineEdit(l: VisualLayer): void {
    const ta = h('textarea', { class: 'ed-inline', 'aria-label': 'Edit text: ' + l.name }); ta.value = ES.layerText(l) ?? '';
    ta.style.left = l.box.x + '%'; ta.style.top = l.box.y + '%'; ta.style.width = Math.max(l.box.w, 24) + '%'; ta.style.height = Math.max(l.box.h, 10) + '%';
    const commit = (): void => { const v = ta.value; ta.remove(); if (v !== ES.layerText(l)) tryOp(() => ES.setText(spec(), l.id, v)); overlay.focus({ preventScroll: true }); };
    ta.addEventListener('blur', commit, { once: true }); ta.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Escape') { ta.value = ES.layerText(l) ?? ''; ta.blur(); } if (ev.key === 'Enter' && (ev.metaKey || ev.ctrlKey)) ta.blur(); });
    overlay.append(ta); ta.focus(); ta.select();
  }
  overlay.addEventListener('keydown', e => {
    const mod = e.metaKey || e.ctrlKey; const step = e.shiftKey ? 5 : 1;
    if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) hist.redo(); else hist.undo(); changed(false); return; }
    if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); hist.redo(); changed(false); return; }
    if (!selected) return;
    const id = selected; const map: Record<string, () => VisualSceneSpec | void> = {
      ArrowLeft: () => ES.moveLayer(spec(), id, -step, 0), ArrowRight: () => ES.moveLayer(spec(), id, step, 0), ArrowUp: () => ES.moveLayer(spec(), id, 0, -step), ArrowDown: () => ES.moveLayer(spec(), id, 0, step),
      Delete: () => ES.removeLayer(spec(), id), Backspace: () => ES.removeLayer(spec(), id), ']': () => ES.reorderLayer(spec(), id, 'up'), '[': () => ES.reorderLayer(spec(), id, 'down'),
      Enter: () => { const l = ES.findLayer(spec(), id); if (l && ES.layerText(l) !== null) inlineEdit(l); }, Escape: () => { select(null); },
    };
    if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); tryOp(() => { const r = ES.duplicateLayer(spec(), id); selected = r.newId; return r.spec; }); return; }
    const f = map[e.key]; if (f) { e.preventDefault(); tryOp(f); }
  });

  // ---------------------------------------------------------------- top modes: four genuinely different paths
  function drawModes(): void {
    clear(modes); const pp = deps.photoProvider(); const hasPhoto = spec().artDirection.layerPlan.some(l => l.id === 'your-photo');
    add(modes,
      h('span', { class: 'ed-mode ed-mode--on', title: 'You are editing the real HTML/SVG design that will be exported' }, 'Design it here'),
      h('button', { class: 'ps-btn ps-btn--small', onclick: () => fileIn.click() }, hasPhoto ? 'Replace my photo' : 'Use my photo'),
      hasPhoto ? h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => tryOp(() => ES.removePhoto(spec(), original)) }, 'Remove photo') : null,
      h('button', { class: 'ps-btn ps-btn--small', disabled: !pp.connected, title: pp.reason, 'aria-describedby': 'photo-why' }, 'Generate a photograph'),
      !pp.connected ? h('span', { class: 'ps-muted ed-why', id: 'photo-why' }, 'Not connected — optional') : null,
      h('button', { class: 'ps-btn ps-btn--small', onclick: () => void copyPrompt() }, 'Copy prompt'));
  }
  async function copyPrompt(): Promise<void> { try { const c = compile(); await navigator.clipboard.writeText(c.prompt); toast(`${PROVIDERS[provider].label} prompt copied (${c.length} characters).`, 'ok'); } catch (e) { tab = 'prompt'; drawLeft(); toast('Copy blocked by the browser — the prompt is shown in the Exact prompt tab.', 'info'); void e; } }
  const compile = (p: ProviderKey = provider): ReturnType<typeof compileScene> => compileScene(scene, p, { brand: deps.brand(), overrides: { ...overrides, conceptLocked, ...(sizeKey !== 'native' ? { channel: { width: spec().output.width, height: spec().output.height, placement: spec().output.intendedPlacement } } : {}) } });

  async function pickPhoto(): Promise<void> {
    const f = fileIn.files?.[0]; fileIn.value = ''; if (!f) return;
    if (!/^image\/(png|jpeg|webp)$/.test(f.type)) { toast('Please choose a PNG, JPEG or WebP image.', 'error'); return; }
    if (f.size > 12 * 1024 * 1024) { toast('That photo is over 12MB. Please choose a smaller file.', 'error'); return; }
    const ok = await confirmDialog('Use this photo?', 'Only use photos you own or have permission to use — including permission from anyone who appears in them. The photo stays in this design and your workspace.', 'I have the right to use this photo');
    if (!ok) return;
    try { // downscale + re-encode in the browser: strips EXIF/GPS and keeps the design file small
      const bmp = await createImageBitmap(f); const max = 2000; const k = Math.min(1, max / Math.max(bmp.width, bmp.height)); const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k); c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
      const src = c.toDataURL('image/jpeg', 0.88); tryOp(() => ES.usePhoto(spec(), src, `Photograph supplied by the customer for ${scene.dna.assetLabel}`, `Uploaded by workspace ${deps.workspaceId()} on ${new Date().toISOString().slice(0, 10)}; customer confirmed usage rights; EXIF removed`));
      toast('Photo added. The illustrated stand-in is hidden — you can bring it back with “Remove photo”.', 'ok');
    } catch { toast('That image couldn’t be read. Try a different file.', 'error'); }
  }
  function confirmDialog(title: string, body: string, checkLabel: string): Promise<boolean> {
    return new Promise(res => {
      const cb = h('input', { type: 'checkbox', id: 'ps-confirm-cb' }); const okB = h('button', { class: 'ps-btn ps-btn--primary', disabled: true, value: 'ok' }, 'Use photo');
      cb.addEventListener('change', () => { okB.disabled = !cb.checked; });
      const d = h('dialog', { class: 'ps-dialog', 'aria-labelledby': 'ps-confirm-t' }, h('form', { method: 'dialog' }, h('h2', { id: 'ps-confirm-t' }, title), h('p', {}, body), h('label', { class: 'ps-check', for: 'ps-confirm-cb' }, cb, ' ' + checkLabel), h('div', { class: 'ps-row ps-row--end' }, h('button', { class: 'ps-btn', value: 'cancel' }, 'Cancel'), okB)));
      d.addEventListener('close', () => { res(d.returnValue === 'ok'); d.remove(); }); shell.append(d); d.showModal();
    });
  }

  // ---------------------------------------------------------------- size / brand / export / save
  function switchSize(k: ES.SizeKey): void { const p = ES.SIZE_PRESETS.find(x => x.key === k)!; sizeKey = k; const size = k === 'native' ? { width: scene.dimensions.width, height: scene.dimensions.height, placement: scene.where_used } : { width: p.width, height: p.height, placement: p.placement }; tryOp(() => ES.replan({ scene, current: spec(), brand: deps.brand(), size, note: `re-composed for ${size.width}×${size.height}` })); }
  async function doExport(): Promise<void> {
    const s = spec(); const f = exportSel.value; const name = `${scene.id}-${s.output.width}x${s.output.height}`;
    if (f === 'json') { download(new Blob([JSON.stringify(s, null, 1)], { type: 'application/json' }), name + '.design.json'); return; }
    exportBtn.disabled = true; exportBtn.textContent = 'Rendering…';
    try {
      if (f === 'html') { const fonts = await loadFonts(collectFonts(s).map(x => x.file)); const { html } = renderArtboardHtml(s, { fonts: { mode: 'inline', data: fonts }, lighting, title: scene.display_title }); download(new Blob([html], { type: 'text/html' }), name + '.html'); toast('HTML source downloaded — it opens in any browser and contains no scripts.', 'ok'); return; }
      const useServer = deps.serverAvailable() && deps.signedIn();
      if (useServer) { const r = await deps.api.blob('/api/render', { spec: s, format: f, lighting }); lastOverflow = (r.headers.get('x-ab-text-overflow') ?? '').split(',').filter(Boolean); download(r.blob, `${name}.${f === 'jpeg' ? 'jpg' : f}`); toast(`Exported ${r.headers.get('x-ab-width')}×${r.headers.get('x-ab-height')} ${f.toUpperCase()} from the render service.`, 'ok'); changed(false); }
      else { const fonts = await loadFonts(collectFonts(s).map(x => x.file)); const { html } = renderArtboardHtml(s, { fonts: { mode: 'inline', data: fonts }, lighting }); const blob = await browserRasterise(html, s.output.width, s.output.height, ('image/' + f) as 'image/png'); download(blob, `${name}.${f === 'jpeg' ? 'jpg' : f}`); toast(deps.serverAvailable() ? 'Exported in your browser. Sign in to use the render service and save to your library.' : 'Exported in your browser (no render service on this host).', 'ok'); }
    } catch (e) { toast(e instanceof ApiError ? e.message : 'Export failed: ' + (e as Error).message, 'error'); }
    finally { exportBtn.disabled = false; exportBtn.textContent = 'Export'; }
  }
  async function doSave(): Promise<void> {
    if (!deps.serverAvailable()) { toast('Saving to a workspace library needs Authority Builder Studio. On this static preview your draft is kept on this device.', 'info'); return; }
    if (!deps.signedIn()) { toast('Sign in to save this to your workspace library. Your draft is safe on this device meanwhile.', 'info'); return; }
    saveBtn.disabled = true; saveBtn.textContent = 'Saving…';
    try { const r = await deps.api.json<{ asset: { id: string; version: number }; textOverflow: string[] }>('POST', '/api/assets', { spec: spec(), title: scene.dna.assetLabel + ' — ' + scene.niche, format: 'png', lighting, assetId }); assetId = r.asset.id; lastOverflow = r.textOverflow; savedVersions = [...new Set([...savedVersions, r.asset.version])]; history.replaceState(null, '', `#/scene/${scene.id}?asset=${assetId}`); saveState = `Saved to library · version ${r.asset.version}`; saveNote.textContent = saveState; toast('Saved to your workspace library with its editable source.', 'ok'); changed(false); }
    catch (e) { toast((e as Error).message, 'error'); } finally { saveBtn.disabled = false; saveBtn.textContent = 'Save to library'; }
  }

  // ---------------------------------------------------------------- natural-language change → real document edits + diff
  function applyChangeRequest(text: string): void {
    const pr = parseChangeRequest(text); const diff: string[] = []; let s = spec(); const ov = pr.overrides;
    try {
      if (pr.conceptChange && conceptLocked) { lastDiff = ['Not applied: that would change the underlying concept. Use “Change concept” (back to the gallery) or untick “Keep the concept locked”.']; drawLeft(); return; }
      for (const rm of ov.scene?.removeProps ?? []) { const m = s.artDirection.layerPlan.filter(l => !l.hidden && (l.type === 'object' || l.type === 'diagram' || l.type === 'chart' || l.type === 'badge' || l.type === 'cta') && (l.name.toLowerCase().includes(rm.toLowerCase()) || (l.type === 'object' && (l.sourcePhrase.toLowerCase().includes(rm.toLowerCase()) || l.kind.includes(rm.toLowerCase().replace(/\s+/g, '-')))))); for (const l of m) { s = ES.toggleHidden(s, l.id); diff.push(`Hid “${l.name}” (restore it from Layers)`); } if (!m.length) diff.push(`Couldn’t find “${rm}” in this design — added to the brief only`); }
      if (ov.scene?.subject && /no person/.test(ov.scene.subject)) { for (const l of s.artDirection.layerPlan.filter(x => x.type === 'figure' && !x.hidden)) { s = ES.toggleHidden(s, l.id); diff.push('Hid the illustrated person'); } }
      for (const add of ov.scene?.addProps ?? []) { const kind = resolveProp(add); if (kind && hasProp(kind)) { const id = ('added-' + kind).slice(0, 34) + (s.artDirection.layerPlan.some(l => l.id === 'added-' + kind) ? '-' + (s.artDirection.layerPlan.length + 1) : ''); const ar = s.output.width / s.output.height; const layer: VisualLayer = { id, name: add.slice(0, 50), type: 'object', kind, sourcePhrase: add.slice(0, 80), variant: 0.5, box: { x: 40, y: 62, w: 20 / (ar > 1 ? ar : 1), h: ar > 1 ? 20 : 20 * ar }, shadow: true }; const next = JSON.parse(JSON.stringify(s)) as VisualSceneSpec; next.artDirection.layerPlan.push(layer); next.provenance.changes = [...next.provenance.changes, `added object: ${add}`.slice(0, 200)].slice(-40); s = validateSpec(next); selected = id; diff.push(`Added “${add}” as a new object layer — drag it into place`); } else diff.push(`No built-in illustration for “${add}” — added to the brief only (use your own photo to show it)`); }
      if (ov.scene?.negativeSpace) { const fig = s.artDirection.layerPlan.find(l => l.type === 'figure' && !l.hidden); if (fig) { const k = ov.scene.negativeSpace === 'more' ? 0.86 : 1.14; s = ES.setBox(s, fig.id, { x: fig.box.x + (fig.box.w * (1 - k)) / 2, y: fig.box.y + fig.box.h * (1 - k), w: fig.box.w * k, h: fig.box.h * k }); diff.push(ov.scene.negativeSpace === 'more' ? 'Made the subject smaller for more open space' : 'Made the subject larger'); } }
      if (ov.direction?.style === 'editorial') { s = ES.quickAction('editorial', scene, s, deps.brand(), quickStep++); diff.push('Applied the editorial type treatment'); }
      if (ov.direction?.style === 'minimal') { for (const l of s.artDirection.layerPlan.filter(x => x.type === 'object' && !x.hidden)) s = ES.toggleHidden(s, l.id); diff.push('Hid the supporting objects for a more minimal look'); }
      if (pr.notes.some(n => /less corporate/i.test(n))) { s = ES.quickAction('relaxed', scene, s, deps.brand(), quickStep++); diff.push('Applied the softer, less corporate treatment'); }
      for (const n of pr.notes.filter(x => !/less corporate/i.test(x))) diff.push(`Brief only: “${n}” — recorded in the creative brief and prompt`);
      overrides = { ...overrides, changeRequest: [overrides.changeRequest, text].filter(Boolean).join('. ') };
      if (s !== spec()) hist.push(s); lastDiff = diff.length ? diff : ['Nothing to change — try “remove the plant”, “add a notebook”, “more white space” or “make it more editorial”.']; changed();
    } catch (e) { toast((e as Error).message, 'error'); }
  }

  // ---------------------------------------------------------------- left panel (tabs)
  function drawLeft(): void {
    clear(left); const s = spec();
    const tabs: Array<[typeof tab, string]> = [['edit', 'Edit'], ['brief', 'Creative brief'], ['prompt', 'Exact prompt'], ['details', 'Scene details'], ['sizes', 'Sizes'], ['history', 'History']];
    left.append(h('div', { class: 'ps-tabs', role: 'tablist' }, ...tabs.map(([k, label]) => h('button', { class: 'ps-tab', role: 'tab', 'aria-selected': String(tab === k), onclick: () => { tab = k; drawLeft(); } }, label))));
    const body = h('div', { class: 'ed-panel', role: 'tabpanel' }); left.append(body);
    if (tab === 'edit') {
      const ta = h('textarea', { class: 'ps-input', rows: 2, id: 'ps-change', placeholder: 'e.g. remove the plant, add a notebook, more white space' });
      body.append(h('label', { class: 'ps-label', for: 'ps-change' }, 'What would you like to change?'), ta,
        h('div', { class: 'ps-row' }, h('button', { class: 'ps-btn ps-btn--primary ps-btn--small', onclick: () => { if (ta.value.trim()) applyChangeRequest(ta.value); } }, 'Apply change'), h('label', { class: 'ps-check' }, h('input', { type: 'checkbox', checked: conceptLocked, onchange: (e: Event) => { conceptLocked = (e.target as HTMLInputElement).checked; } }), ' Keep the concept locked')));
      if (lastDiff.length) body.append(h('div', { class: 'ed-diff', role: 'status' }, h('strong', {}, 'What changed'), h('ul', {}, ...lastDiff.map(d => h('li', {}, d))), h('p', { class: 'ps-muted' }, 'Every change can be undone.')));
      const texts = s.artDirection.layerPlan.filter(l => !l.hidden && ES.layerText(l) !== null);
      if (texts.length) { body.append(h('h3', {}, 'Your words')); for (const l of texts) { const inp = h('input', { class: 'ps-input', type: 'text', value: ES.layerText(l) ?? '', id: 'tx-' + l.id, maxlength: l.type === 'stat' ? 16 : 400, onchange: (e: Event) => tryOp(() => ES.setText(spec(), l.id, (e.target as HTMLInputElement).value)), onfocus: () => { selected = l.id; drawSelection(); } }); body.append(h('label', { class: 'ps-label', for: 'tx-' + l.id }, l.name, 'copyStatus' in l && l.copyStatus === 'suggested' ? h('span', { class: 'ps-tag' }, 'suggested — replace with yours') : null), inp); } }
      else body.append(h('p', { class: 'ps-muted' }, s.scene.mustNotInclude.some(x => /No added text/.test(x)) ? 'This template is designed to carry no text — the original brief says the frame stands alone.' : 'No text layers in this design.'));
      body.append(h('h3', {}, 'Change just this'), h('div', { class: 'ed-quick' }, ...ES.QUICK_ACTIONS.map(q => h('button', { class: 'ps-btn ps-btn--small', onclick: () => { if (q.key === 'header') sizeKey = 'web', sizeSel.value = 'web'; tryOp(() => ES.quickAction(q.key, scene, spec(), deps.brand(), quickStep++)); } }, q.label)),
        h('button', { class: 'ps-btn ps-btn--small', onclick: () => fileIn.click() }, 'Replace the image'),
        h('button', { class: 'ps-btn ps-btn--small', disabled: !selected, onclick: () => selected && tryOp(() => ES.removeLayer(spec(), selected!)) }, 'Remove this object'),
        h('button', { class: 'ps-btn ps-btn--small', onclick: () => { try { const frames = ES.matchingCarousel(scene, spec(), deps.brand()); frames.forEach((f, i) => deps.addToPack({ spec: f, name: `${scene.dna.assetLabel} carousel ${i + 1}`, lighting })); toast('Four-frame carousel added to your pack (cover, idea, steps, call to action).', 'ok'); } catch (e) { toast((e as Error).message, 'error'); } } }, 'Make a matching carousel')));
      body.append(h('h3', {}, 'Brand'), h('p', { class: 'ps-muted' }, deps.brand()?.palette ? 'Your brand kit colours and details are applied to this design.' : 'Using this template’s own palette.'), h('div', { class: 'ps-row' }, h('button', { class: 'ps-btn ps-btn--small', onclick: deps.openWizard }, 'Personalise my brand'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => tryOp(() => ES.replan({ scene, current: spec(), brand: deps.brand(), size: { width: s.output.width, height: s.output.height, placement: s.output.intendedPlacement }, note: 'brand kit re-applied' })) }, 'Re-apply brand')),
        h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { deps.addToPack({ spec: spec(), name: scene.dna.assetLabel, lighting }); toast('Added to your pack.', 'ok'); } }, 'Add this design to my pack'));
    } else if (tab === 'brief') {
      const a = s.artDirection;
      body.append(h('h3', {}, 'What the viewer sees'), h('p', {}, scene.visible_scene), h('ul', {}, ...a.focalHierarchy.map((x, i) => h('li', {}, `${i + 1}. ${x}`))),
        h('h3', {}, 'Why this layout works'), h('p', {}, a.whyThisWorks), h('p', { class: 'ps-muted' }, a.compositionRationale),
        h('h3', {}, 'Where to use it'), h('p', {}, scene.where_used), h('h3', {}, 'The action it encourages'), h('p', {}, s.intent.marketingMechanism + '.'),
        h('h3', {}, 'Must stay recognisable'), h('ul', {}, ...s.scene.distinctnessAnchors.map(x => h('li', {}, x))), h('h3', {}, 'Full creative brief'), h('pre', { class: 'ed-pre' }, compile('claude').creativeBrief));
    } else if (tab === 'prompt') {
      let c: ReturnType<typeof compileScene> | null = null; let err = ''; try { c = compile(); } catch (e) { err = (e as Error).message; }
      const sel = h('select', { class: 'ps-select', id: 'ps-prov', onchange: () => { provider = sel.value as ProviderKey; drawLeft(); } }, ...(Object.keys(PROVIDERS) as ProviderKey[]).map(k => h('option', { value: k, selected: k === provider }, PROVIDERS[k].label)));
      body.append(h('label', { class: 'ps-label', for: 'ps-prov' }, 'Write the prompt for'), sel);
      if (c) { body.append(h('p', { class: 'ps-muted' }, `${c.kind === 'video' ? 'Video brief' : c.kind === 'design-brief' ? 'Design brief' : 'Image prompt'} · ${c.length} of ${c.budget} characters · scene anchors kept: ${c.anchorsPresent.join(', ')}`), h('pre', { class: 'ed-pre', id: 'ps-prompt' }, c.prompt), h('div', { class: 'ps-row' }, h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: () => void copyPrompt() }, 'Copy prompt')), ...c.warnings.map(w => h('p', { class: 'ed-warn-inline' }, w)));
        if (c.changes.length) body.append(h('h3', {}, 'Changed from the original'), h('ul', {}, ...c.changes.map(x => h('li', {}, `${x.field}: ${x.from} → ${x.to}`))));
        body.append(h('details', {}, h('summary', {}, 'Original prompt (verbatim from the v9.9.18 library)'), h('pre', { class: 'ed-pre' }, c.originalPrompt))); }
      else body.append(h('p', { class: 'ps-error', role: 'alert' }, err));
    } else if (tab === 'details') {
      const o = scene.original; const rows: Array<[string, string]> = [['Template ID', scene.id], ['Category', `${scene.niche} (${scene.category})`], ['Asset type', o.asset], ['Business moment', o.businessMoment], ['Scenario', o.scenario], ['Framing', o.framing], ['Safe zones', o.safeZones], ['Pose direction', o.poseDirection || '—'], ['Lighting', o.lightingSpec], ['Wardrobe', scene.wardrobe_if_applicable ?? 'Not applicable — no person in this scene'], ['Palette', o.palette], ['Design principle', o.designPrinciple], ['Conversion intent', o.conversionIntent], ['Render / background', `${o.render} · ${o.bg}`], ['Source', `${scene.provenance.canonical_archive} → ${scene.provenance.canonical_path}`], ['Source SHA-256', scene.provenance.canonical_sha256], ['Design hash', s.originalSceneFingerprint === scene.provenance.canonical_sha256 ? 'linked to source ✓' : 'MISMATCH']];
      body.append(h('dl', { class: 'ed-dl' }, ...rows.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])));
      if (scene.provenance.source_defects.length) body.append(h('details', {}, h('summary', {}, `Known issues in the original record (${scene.provenance.source_defects.length})`), h('ul', {}, ...scene.provenance.source_defects.map(d => h('li', {}, d)))));
      body.append(h('details', {}, h('summary', {}, 'Original rich brief'), h('pre', { class: 'ed-pre' }, o.richBrief)));
    } else if (tab === 'sizes') {
      body.append(h('p', { class: 'ps-muted' }, 'Each size is re-composed from the same scene — not cropped or stretched — so the subject, key objects and copy zones stay readable.'));
      for (const p of ES.SIZE_PRESETS) body.append(h('div', { class: 'ed-size' }, h('button', { class: 'ps-btn ps-btn--small' + (sizeKey === p.key ? ' ps-btn--primary' : ''), onclick: () => { sizeSel.value = p.key; switchSize(p.key); } }, p.key === 'native' ? `Original · ${scene.dimensions.width}×${scene.dimensions.height}` : p.label), h('span', { class: 'ps-muted' }, p.key === 'native' ? scene.where_used : p.placement),
        p.key !== 'native' ? h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', 'aria-label': `Add ${p.label} to pack`, onclick: () => { try { deps.addToPack({ spec: ES.replan({ scene, current: spec(), brand: deps.brand(), size: { width: p.width, height: p.height, placement: p.placement }, note: 'pack size' }), name: `${scene.dna.assetLabel} ${p.key}`, lighting }); toast(`${p.label} added to your pack.`, 'ok'); } catch (e) { toast((e as Error).message, 'error'); } } }, '+ Pack') : null));
    } else {
      body.append(h('p', { class: 'ps-muted' }, `${hist.depth} step(s) can be undone in this session. ${saveState}.`));
      if (savedVersions.length && assetId) body.append(h('h3', {}, 'Saved versions'), h('div', { class: 'ps-row' }, ...savedVersions.map(v => h('button', { class: 'ps-btn ps-btn--small', onclick: async () => { try { const a = await deps.api.json<{ spec: VisualSceneSpec }>('GET', `/api/assets/${assetId}?version=${v}`); apply(validateSpec(a.spec)); toast(`Version ${v} reopened as a new step — undo to go back.`, 'ok'); } catch (e) { toast((e as Error).message, 'error'); } } }, 'Version ' + v))));
      body.append(h('h3', {}, 'Change log'), s.provenance.changes.length ? h('ol', {}, ...s.provenance.changes.map(c => h('li', {}, c))) : h('p', { class: 'ps-muted' }, 'No edits yet — this is the template as generated.'),
        h('button', { class: 'ps-btn ps-btn--small', onclick: () => { store.del(draftKey); overrides = {}; lastDiff = []; sizeKey = 'native'; sizeSel.value = 'native'; apply(planScene(scene, { brand: deps.brand() })); toast('Reset to the original template. Undo brings your edits back.', 'info'); } }, 'Reset to the original template'));
    }
  }

  // ---------------------------------------------------------------- right panel: layers + inspector
  function drawLayers(): void {
    clear(right); const s = spec(); right.append(h('h2', { class: 'ed-h' }, 'Layers'), h('p', { class: 'ps-muted' }, 'Top of the list sits in front.'));
    const list = h('ul', { class: 'ed-layers', role: 'listbox', 'aria-label': 'Layers' });
    [...s.artDirection.layerPlan].reverse().forEach(l => {
      const meta = LAYER_META[l.type]; const b = (label: string, glyph: string, f: () => VisualSceneSpec | void, pressed?: boolean): HTMLButtonElement => h('button', { class: 'ed-ic', title: label, 'aria-label': `${label}: ${l.name}`, 'aria-pressed': pressed === undefined ? undefined : String(pressed), onclick: (e: Event) => { e.stopPropagation(); tryOp(f); } }, glyph);
      list.append(h('li', { class: 'ed-layer' + (selected === l.id ? ' is-sel' : '') + (l.hidden ? ' is-hidden' : ''), role: 'option', 'aria-selected': String(selected === l.id), tabindex: '0', onclick: () => select(l.id), onkeydown: (e: KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(l.id); } } },
        h('span', { class: 'ed-layer-ic', 'aria-hidden': 'true' }, meta.icon), h('span', { class: 'ed-layer-name' }, l.name, h('small', {}, meta.label + (l.role === 'concept' ? ' · concept' : ''))),
        h('span', { class: 'ed-layer-btns' }, b(l.hidden ? 'Show' : 'Hide', l.hidden ? '○' : '●', () => ES.toggleHidden(spec(), l.id), !l.hidden), b(l.locked ? 'Unlock' : 'Lock', l.locked ? '🔒' : '🔓', () => ES.toggleLocked(spec(), l.id), !!l.locked), b('Bring forward', '↑', () => ES.reorderLayer(spec(), l.id, 'up')), b('Send back', '↓', () => ES.reorderLayer(spec(), l.id, 'down')), b('Duplicate', '⧉', () => { const r = ES.duplicateLayer(spec(), l.id); selected = r.newId; return r.spec; }), b('Delete', '✕', () => ES.removeLayer(spec(), l.id)))));
    });
    right.append(list);
    const l = selected ? ES.findLayer(s, selected) : undefined;
    if (l) {
      const numIn = (label: string, k: 'x' | 'y' | 'w' | 'h'): HTMLElement => h('label', { class: 'ed-num' }, label, h('input', { type: 'number', class: 'ps-input', step: '0.5', value: String(l.box[k]), disabled: !!l.locked, onchange: (e: Event) => tryOp(() => ES.setBox(spec(), l.id, { ...l.box, [k]: Number((e.target as HTMLInputElement).value) })) }));
      const insp = h('div', { class: 'ed-insp' }, h('h3', {}, l.name), h('div', { class: 'ed-nums' }, numIn('Left %', 'x'), numIn('Top %', 'y'), numIn('Width %', 'w'), numIn('Height %', 'h')));
      if ('size' in l && typeof l.size === 'number') insp.append(h('label', { class: 'ed-num' }, 'Text size', h('input', { type: 'number', class: 'ps-input', step: '0.2', min: '1', max: '60', value: String(l.size), onchange: (e: Event) => tryOp(() => ES.setTextSize(spec(), l.id, Number((e.target as HTMLInputElement).value))) })));
      const col = 'color' in l ? l.color : l.type === 'shape' && l.fill?.kind === 'solid' ? l.fill.color : l.type === 'background' && l.fill.kind === 'solid' ? l.fill.color : null;
      if (col) { const pal = s.artDirection.colourRoles; insp.append(h('div', { class: 'ed-num' }, 'Colour', h('div', { class: 'ed-swatches' }, ...Object.entries(pal).map(([k, c]) => h('button', { class: 'ed-sw', style: { background: c }, title: `${k} ${c}`, 'aria-label': `Use ${k} colour ${c}`, onclick: () => tryOp(() => ES.setLayerColour(spec(), l.id, c)) })), h('input', { type: 'color', value: col, 'aria-label': 'Custom colour', onchange: (e: Event) => tryOp(() => ES.setLayerColour(spec(), l.id, (e.target as HTMLInputElement).value.toUpperCase())) })))); }
      if (l.type === 'image') insp.append(h('p', { class: 'ps-muted' }, `Rights: ${l.rights.note}`), h('label', { class: 'ed-num' }, 'Crop focus (left–right)', h('input', { type: 'range', min: '0', max: '100', value: String(l.focusX), onchange: (e: Event) => { const v = Number((e.target as HTMLInputElement).value); const next = JSON.parse(JSON.stringify(spec())) as VisualSceneSpec; const il = next.artDirection.layerPlan.find(x => x.id === l.id); if (il?.type === 'image') il.focusX = v; apply(validateSpec(next)); } })), h('label', { class: 'ed-num' }, 'Crop focus (top–bottom)', h('input', { type: 'range', min: '0', max: '100', value: String(l.focusY), onchange: (e: Event) => { const v = Number((e.target as HTMLInputElement).value); const next = JSON.parse(JSON.stringify(spec())) as VisualSceneSpec; const il = next.artDirection.layerPlan.find(x => x.id === l.id); if (il?.type === 'image') il.focusY = v; apply(validateSpec(next)); } })));
      right.append(insp);
    } else right.append(h('p', { class: 'ps-muted ed-insp' }, 'Select a layer to move, resize, recolour or edit it. Double-click text on the artboard to type directly.'));
    right.append(saveNote);
  }

  const onResize = (): void => fit(); window.addEventListener('resize', onResize);
  changed(false);
  return () => { window.removeEventListener('resize', onResize); window.clearTimeout(renderTimer); };
}
