/**
 * Standalone migration-preview host. Stands in for Authority Builder Studio's shell so the module can be run and
 * tested on its own. In the real product the parent app renders the header/sidebar and calls mountPromptStudio().
 */
import { mountPromptStudio } from './main.ts';

const KEY = 'ab.preview.token';
const sel = document.getElementById('ab-workspace') as HTMLSelectElement | null;
const root = document.getElementById('prompt-studio-root') as (HTMLElement & { refreshSession?: () => Promise<void> }) | null;
const read = (): string | null => { try { return sessionStorage.getItem(KEY); } catch { return null; } };
if (sel && root) {
  const avatar = document.getElementById('ab-avatar');
  const badge = (): void => { const i = sel.selectedOptions[0]?.dataset['initials'] ?? ''; if (avatar) { avatar.textContent = i; avatar.hidden = !i; avatar.setAttribute('aria-label', i ? `Signed in to ${sel.selectedOptions[0]?.textContent ?? 'a demo workspace'}` : ''); } };
  sel.value = read() ?? ''; badge();
  sel.addEventListener('change', () => { try { if (sel.value) sessionStorage.setItem(KEY, sel.value); else sessionStorage.removeItem(KEY); } catch { /* ignore */ } badge(); void root.refreshSession?.(); });
  const menu = document.getElementById('ab-menu'); const nav = document.getElementById('ab-nav');
  menu?.addEventListener('click', () => { const open = nav?.classList.toggle('is-open') ?? false; menu.setAttribute('aria-expanded', String(open)); });
  void mountPromptStudio(root, { getToken: read, requestSignIn: () => { sel.focus(); sel.classList.add('is-nudge'); setTimeout(() => sel.classList.remove('is-nudge'), 1600); } });
}
