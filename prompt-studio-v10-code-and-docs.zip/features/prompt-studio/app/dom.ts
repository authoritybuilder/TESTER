/** Tiny DOM + API helpers for the Prompt Studio module. All text goes through textContent — never innerHTML. */
export type Child = Node | string | null | undefined | false;
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Record<string, unknown> = {}, ...kids: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = String(v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v as EventListener);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (v === true) el.setAttribute(k, '');
    else if (k in el && !['list', 'form', 'type', 'role'].includes(k) && typeof v !== 'string') (el as unknown as Record<string, unknown>)[k] = v;
    else el.setAttribute(k, String(v));
  }
  for (const c of kids) if (c) el.append(c);
  return el;
}
/** append() that tolerates null/false children. */
export function add(el: Element, ...kids: Child[]): void { for (const c of kids) if (c) el.append(c); }
export const clear = (el: Element): void => { while (el.firstChild) el.removeChild(el.firstChild); };

let toastHost: HTMLElement | null = null;
export function toast(msg: string, kind: 'ok' | 'error' | 'info' = 'info'): void {
  if (!toastHost) { toastHost = h('div', { class: 'ps-toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(toastHost); }
  const t = h('div', { class: 'ps-toast ps-toast--' + kind }, msg); toastHost.append(t); setTimeout(() => t.remove(), kind === 'error' ? 7000 : 3800);
}

export class ApiError extends Error { constructor(public status: number, public code: string, msg: string) { super(msg); } }
export class Api {
  token: string | null = null; available = true;
  private headers(json = true): Record<string, string> { return { ...(json ? { 'content-type': 'application/json' } : {}), ...(this.token ? { authorization: 'Bearer ' + this.token } : {}) }; }
  async json<T>(method: string, path: string, body?: unknown): Promise<T> {
    let r: Response;
    try { r = await fetch(path, { method, headers: this.headers(), body: body === undefined ? undefined : JSON.stringify(body) }); } catch { throw new ApiError(0, 'network', 'Can’t reach the Prompt Studio server. Check your connection and try again.'); }
    const txt = await r.text(); let data: unknown = null; try { data = txt ? JSON.parse(txt) : null; } catch { /* not JSON */ }
    if (!r.ok) { const d = (data ?? {}) as { error?: string; code?: string }; throw new ApiError(r.status, d.code ?? 'error', d.error ?? `Request failed (${r.status})`); }
    return data as T;
  }
  async blob(path: string, body: unknown): Promise<{ blob: Blob; headers: Headers }> {
    let r: Response;
    try { r = await fetch(path, { method: 'POST', headers: this.headers(), body: JSON.stringify(body) }); } catch { throw new ApiError(0, 'network', 'Can’t reach the Prompt Studio server.'); }
    if (!r.ok) { let d: { error?: string; code?: string } = {}; try { d = (await r.json()) as typeof d; } catch { /* ignore */ } throw new ApiError(r.status, d.code ?? 'error', d.error ?? `Request failed (${r.status})`); }
    return { blob: await r.blob(), headers: r.headers };
  }
}
export function download(blob: Blob, filename: string): void { const a = h('a', { href: URL.createObjectURL(blob), download: filename }); document.body.append(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }

export const store = {
  get<T>(k: string, d: T): T { try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : d; } catch { return d; } },
  set(k: string, v: unknown): boolean { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } },
  del(k: string): void { try { localStorage.removeItem(k); } catch { /* ignore */ } },
};

let fontData: Promise<Record<string, string>> | null = null;
/** Bundled fonts as base64 (fetched once) so editor previews and browser exports are fully self-contained. */
export function loadFonts(files: string[], base = 'fonts/'): Promise<Record<string, string>> {
  fontData ??= Promise.resolve({});
  fontData = fontData.then(async have => {
    for (const f of files) if (!have[f]) { try { const buf = await (await fetch(base + f)).arrayBuffer(); let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); have[f] = btoa(s); } catch { /* font unavailable: renderer falls back to system stack */ } }
    return have;
  });
  return fontData;
}
