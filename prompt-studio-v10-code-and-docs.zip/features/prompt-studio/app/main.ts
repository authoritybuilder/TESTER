/**
 * Prompt Studio module entry. `mountPromptStudio(el, host)` mounts inside the parent Studio shell (its header/sidebar
 * stay untouched); the standalone preview page calls it with a small demo host. One init, explicit state transitions,
 * no timeouts-as-control-flow, no scroll locks, no overlay on entry.
 */
import { Catalogue } from '../catalog/catalog-client.ts';
import type { GalleryEntry } from '../catalog/schema.ts';
import { ASSET_GROUPS, searchScenes, type Query } from '../gallery/search.ts';
import { abPartner, FLOWS, recommendForFlow, type Recommendation } from '../integrations/campaigns.ts';
import * as ES from '../editor/editor-state.ts';
import type { BrandContext } from '../visual-engine/copy.ts';
import { planScene } from '../visual-engine/scene-planner.ts';
import type { VisualSceneSpec } from '../visual-engine/scene-schema.ts';
import { add, Api, clear, download, h, store, toast } from './dom.ts';
import { FIDELITY_LABEL, mountEditor } from './editor-view.ts';

export interface HostContext {
  /** Bearer token from the parent app's session, or null when browsing anonymously. */
  getToken: () => string | null;
  /** Called when the module needs the host's sign-in. */
  requestSignIn?: () => void;
  assetBase?: string;
}
interface Session { principal: { userId: string; workspaceId: string; role: string } | null; entitlements: { canRender: boolean; canSave: boolean; photoProvider: { connected: boolean; reason: string }; claudeDirection: { connected: boolean; reason: string } }; brandKit: BrandContext | null }
interface PackItem { spec: VisualSceneSpec; name: string; lighting: string }
const GOALS: Array<[string, string]> = [['promote-offer', 'Promote an offer'], ['build-trust', 'Build trust'], ['grow-audience', 'Grow my audience'], ['launch', 'Launch something'], ['social-content', 'Create social content'], ['ads', 'Make ads'], ['email', 'Design email visuals'], ['visualise-idea', 'Visualise an idea'], ['website', 'Make my website look better'], ['brand-shoot', 'Create my brand shoot']];
const STAGES: Array<[string, string]> = [['attract', 'Get noticed'], ['engage', 'Start a conversation'], ['nurture', 'Build trust'], ['convert', 'Ask for the sale'], ['retain', 'Look after clients']];
const WIZ_STEPS = ['Your business', 'Who you’re reaching', 'Your visual identity', 'What you’re making'];
const PAGE = 48;
let mounted = false;

export async function mountPromptStudio(root: HTMLElement, host: HostContext): Promise<void> {
  if (mounted) return; mounted = true; // guard against double initialisation
  root.classList.add('ps'); const base = host.assetBase ?? '';
  const api = new Api(); api.token = host.getToken();
  const view = h('div', { class: 'ps-view' }); const side = h('aside', { class: 'ps-side', hidden: true, 'aria-label': 'Personalise my brand' }); const packBar = h('div', { class: 'ps-pack', hidden: true });
  root.append(h('div', { class: 'ps-layout' }, view, side), packBar);
  view.append(h('div', { class: 'ps-loading', role: 'status' }, 'Loading the visual library…'));

  let catalogue: Catalogue;
  try { catalogue = await Catalogue.open(p => fetch(base + p), 'data/'); }
  catch (e) { clear(view); view.append(h('div', { class: 'ps-error', role: 'alert' }, h('h2', {}, 'The visual library didn’t load'), h('p', {}, (e as Error).message), h('button', { class: 'ps-btn ps-btn--primary', onclick: () => location.reload() }, 'Try again'))); return; }
  const all = catalogue.index.scenes;
  let session: Session = { principal: null, entitlements: { canRender: false, canSave: false, photoProvider: { connected: false, reason: 'Not connected' }, claudeDirection: { connected: false, reason: 'Not connected' } }, brandKit: null };
  let serverUp = true;
  async function loadSession(): Promise<void> { api.token = host.getToken(); try { session = await api.json<Session>('GET', base + 'api/session'); serverUp = true; } catch { serverUp = false; } }
  await loadSession();
  const ws = (): string => session.principal?.workspaceId ?? 'guest';

  // ---------------------------------------------------------------- persisted client state (explicit keys; never overwritten on boot)
  const favs = new Set(store.get<string[]>('ab.ps.favs', [])); let recent = store.get<string[]>('ab.ps.recent', []);
  const draftKey = (): string => 'ab.ps.wizard.' + ws();
  let wizDraft: BrandContext & { objective?: string; channel?: string; campaign?: string; constraints?: string; style?: string } = {};
  const loadDraft = (): void => { wizDraft = { ...(session.brandKit ?? {}), ...store.get<typeof wizDraft>(draftKey(), {}) }; };
  loadDraft();
  let wizStep = 0; let wizStatus = '';
  const brand = (): BrandContext | undefined => { const b = { ...(session.brandKit ?? {}), ...wizDraft }; const has = b.businessName || b.offer || b.audience || b.promise || b.cta || b.palette; return has ? { ...b, workspaceId: session.principal?.workspaceId } : undefined; };
  const pack: PackItem[] = [];
  let query: Query = store.get<Query>('ab.ps.query', {}); let shown = PAGE; const compare = new Set<string>(); let disposeEditor: (() => void) | null = null; let filtersOpen = false;

  // ---------------------------------------------------------------- pack bar
  function drawPack(): void {
    clear(packBar); packBar.hidden = pack.length === 0; if (!pack.length) return;
    packBar.append(h('strong', {}, `Pack · ${pack.length} design${pack.length === 1 ? '' : 's'}`), h('span', { class: 'ps-muted ps-pack-names' }, pack.map(p => p.name).join(' · ')),
      h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: () => void exportPack() }, 'Export pack (ZIP)'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { pack.length = 0; drawPack(); } }, 'Clear'));
  }
  async function exportPack(name?: string): Promise<void> {
    if (!serverUp) { toast('Pack export needs the render service. On this static preview, export each design from the editor instead.', 'info'); return; }
    if (!session.principal) { toast('Sign in to export a pack with its manifest and sources. Single designs can be exported from the editor.', 'info'); host.requestSignIn?.(); return; }
    try { toast('Rendering your pack…', 'info'); const r = await api.blob(base + 'api/export/pack', { items: pack.slice(0, 12), format: 'png', campaign: name ?? null }); download(r.blob, 'prompt-studio-pack.zip'); toast('Pack downloaded: images, editable sources and a manifest with alt text.', 'ok'); } catch (e) { toast((e as Error).message, 'error'); }
  }
  const addToPack = (item: PackItem): void => { if (pack.length >= 12) { toast('A pack holds up to 12 designs.', 'info'); return; } pack.push(item); drawPack(); };

  // ---------------------------------------------------------------- optional in-page brand wizard (side panel; never a modal)
  function openWizard(): void { side.hidden = false; root.classList.add('ps--side'); drawWizard(); (side.querySelector('.ps-wiz-body input, .ps-wiz-body textarea, .ps-wiz-body select') as HTMLElement | null ?? side.querySelector('button'))?.focus({ preventScroll: true }); }
  function closeWizard(): void { side.hidden = true; root.classList.remove('ps--side'); (root.querySelector('[data-open-wizard]') as HTMLElement | null)?.focus({ preventScroll: true }); }
  function saveDraft(msg = 'Draft saved on this device'): void { const ok = store.set(draftKey(), wizDraft); wizStatus = ok ? `${msg} · ${new Date().toLocaleTimeString('en-AU', { hour: '2-digit', minute: '2-digit' })}` : 'Couldn’t save the draft on this device'; const s = side.querySelector('.ps-wiz-status'); if (s) s.textContent = wizStatus; }
  function field(label: string, key: keyof typeof wizDraft, opts: { placeholder?: string; area?: boolean; hint?: string } = {}): HTMLElement {
    const id = 'wz-' + String(key); const val = (wizDraft[key] as string | undefined) ?? '';
    const input = opts.area ? h('textarea', { class: 'ps-input', id, rows: 2, placeholder: opts.placeholder ?? '' }) : h('input', { class: 'ps-input', id, type: 'text', placeholder: opts.placeholder ?? '' });
    (input as HTMLInputElement).value = val; input.addEventListener('input', () => { const v = (input as HTMLInputElement).value.trim(); if (v) (wizDraft as Record<string, unknown>)[key] = v; else delete (wizDraft as Record<string, unknown>)[key]; saveDraft(); });
    return h('div', { class: 'ps-field' }, h('label', { class: 'ps-label', for: id }, label, h('span', { class: 'ps-opt' }, 'optional')), input, opts.hint ? h('p', { class: 'ps-hint' }, opts.hint) : null);
  }
  function colour(label: string, key: 'primary' | 'secondary' | 'accent' | 'light' | 'dark', fallback: string): HTMLElement {
    const id = 'wz-c-' + key; const inp = h('input', { type: 'color', id, value: wizDraft.palette?.[key] ?? fallback });
    inp.addEventListener('input', () => { wizDraft.palette = { primary: '#1F5F4A', secondary: '#E8B4B8', accent: '#E8744F', light: '#FBF8F1', dark: '#14211D', ...(wizDraft.palette ?? {}), [key]: inp.value.toUpperCase() }; saveDraft(); });
    return h('label', { class: 'ps-colour', for: id }, inp, label);
  }
  function drawWizard(): void {
    clear(side);
    const body = h('div', { class: 'ps-wiz-body' });
    if (wizStep === 0) body.append(h('p', { class: 'ps-hint' }, session.principal ? `Workspace: ${session.principal.workspaceId}${session.brandKit ? ' — your saved brand kit is filled in below.' : ' — no brand kit saved yet.'}` : 'You’re browsing without signing in. Details stay on this device until you sign in and save.'), field('Business or brand name', 'businessName', { placeholder: 'e.g. Tidewater Strength' }), field('What you’re offering', 'offer', { placeholder: 'e.g. 12-week strength programme' }), field('Website', 'website', { placeholder: 'e.g. tidewater.example' }));
    else if (wizStep === 1) body.append(field('Who it’s for', 'audience', { placeholder: 'e.g. women over 40 returning to training' }), field('The problem they have', 'painPoint', { area: true }), field('Your promise', 'promise', { placeholder: 'One clear line — no numbers you can’t back up', hint: 'Used as the headline where a template has a headline zone.' }), field('What you want them to do', 'cta', { placeholder: 'e.g. Book a call' }));
    else if (wizStep === 2) { const fontSel = h('select', { class: 'ps-select', id: 'wz-font' }, ...[['', 'Let each template choose'], ['jakarta', 'Clean sans (Plus Jakarta Sans)'], ['fraunces', 'Editorial serif (Fraunces)'], ['anton', 'Bold condensed (Anton)']].map(([v, l]) => h('option', { value: v, selected: (wizDraft.headlineFont ?? '') === v }, l))); fontSel.addEventListener('change', () => { if (fontSel.value) wizDraft.headlineFont = fontSel.value as 'jakarta'; else delete wizDraft.headlineFont; saveDraft(); });
      add(body, h('p', { class: 'ps-hint' }, 'These colours style the designs you make — not the Authority Builder app itself.'), h('div', { class: 'ps-colours' }, colour('Main', 'primary', '#1F5F4A'), colour('Second', 'secondary', '#E8B4B8'), colour('Accent', 'accent', '#E8744F'), colour('Light', 'light', '#FBF8F1'), colour('Dark', 'dark', '#14211D')),
        wizDraft.palette ? h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { delete wizDraft.palette; saveDraft(); drawWizard(); } }, 'Use each template’s own colours') : null,
        h('div', { class: 'ps-field' }, h('label', { class: 'ps-label', for: 'wz-font' }, 'Headline typeface', h('span', { class: 'ps-opt' }, 'optional')), fontSel), field('Name to show as your logo', 'logoText', { hint: 'Shown as a text wordmark for now (logo image upload comes from the Studio brand kit). Add your own photos in the editor with “Use my photo” — only images you have the right to use.' })); }
    else body.append(field('What this is for', 'objective', { placeholder: 'e.g. fill my March cohort' }), field('Where it will appear', 'channel', { placeholder: 'e.g. Instagram, email, sales page' }), field('Campaign name', 'campaign'), field('Anything to avoid or include', 'constraints', { area: true }));
    side.append(
      h('div', { class: 'ps-wiz-head' }, h('h2', {}, 'Make these assets look like my brand'), h('button', { class: 'ps-btn ps-btn--ghost ps-btn--small', 'aria-label': 'Close brand panel', onclick: closeWizard }, 'Close')),
      h('ol', { class: 'ps-steps' }, ...WIZ_STEPS.map((s, i) => h('li', { 'aria-current': i === wizStep ? 'step' : undefined }, h('button', { class: 'ps-step', onclick: () => { wizStep = i; drawWizard(); } }, `${i + 1}. ${s}`)))),
      body,
      h('p', { class: 'ps-wiz-status ps-muted', 'aria-live': 'polite' }, wizStatus || 'Everything here is optional. Changes save as you type.'),
      h('div', { class: 'ps-row ps-wiz-nav' }, h('button', { class: 'ps-btn ps-btn--small', disabled: wizStep === 0, onclick: () => { wizStep--; drawWizard(); } }, 'Back'), wizStep < 3 ? h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: () => { wizStep++; drawWizard(); } }, 'Next') : null, h('button', { class: 'ps-btn ps-btn--small', onclick: () => { if (wizStep < 3) { wizStep++; drawWizard(); } else closeWizard(); } }, wizStep < 3 ? 'Skip' : 'Edit later'),
        h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: () => void saveBrand() }, 'Save')),
      h('button', { class: 'ps-link', onclick: () => { store.del(draftKey()); loadDraft(); wizDraft = { ...(session.brandKit ?? {}) }; wizStatus = 'Draft reset. Your saved brand kit is unchanged.'; drawWizard(); } }, 'Reset only this draft'));
  }
  async function saveBrand(): Promise<void> {
    saveDraft();
    if (!serverUp || !session.principal) { wizStatus = 'Saved on this device. Sign in to save it to your workspace brand kit.'; drawWizard(); toast('Brand details saved on this device.', 'ok'); route(); return; }
    try { const r = await api.json<{ brandKit: BrandContext }>('PUT', base + 'api/brand-kit', wizDraft); session.brandKit = r.brandKit; wizStatus = 'Saved to your workspace brand kit'; drawWizard(); toast('Brand kit saved to your workspace.', 'ok'); route(); } catch (e) { toast((e as Error).message, 'error'); }
  }

  // ---------------------------------------------------------------- gallery
  function card(e: GalleryEntry): HTMLElement {
    const img = h('img', { class: 'ps-thumb-img', src: `${base}${e.thumb}?v=${e.hash.slice(0, 10)}`, alt: `${e.title}: ${e.see}`, loading: 'lazy', decoding: 'async', width: e.w, height: e.h, dataset: { sceneId: e.id } });
    const thumb = h('button', { class: 'ps-thumb', style: { aspectRatio: `${e.w} / ${e.h}` }, 'aria-label': `Design this visual: ${e.title} for ${e.niche}`, onclick: () => { location.hash = `#/scene/${e.id}`; } }, img, h('span', { class: 'ps-fid', dataset: { fid: e.fidelity } }, FIDELITY_LABEL[e.fidelity] ?? e.fidelity));
    img.addEventListener('error', () => { thumb.classList.add('is-missing'); img.remove(); thumb.prepend(h('span', { class: 'ps-thumb-missing', role: 'img', 'aria-label': 'Preview not rendered' }, `Preview not rendered for ${e.id}`)); }, { once: true });
    const fav = h('button', { class: 'ps-fav', 'aria-pressed': String(favs.has(e.id)), 'aria-label': `${favs.has(e.id) ? 'Remove from' : 'Add to'} favourites: ${e.title}`, onclick: () => { if (favs.has(e.id)) favs.delete(e.id); else favs.add(e.id); store.set('ab.ps.favs', [...favs]); fav.setAttribute('aria-pressed', String(favs.has(e.id))); fav.textContent = favs.has(e.id) ? '★' : '☆'; } }, favs.has(e.id) ? '★' : '☆');
    const cmp = h('input', { type: 'checkbox', checked: compare.has(e.id), 'aria-label': `Compare ${e.title}`, onchange: () => { if (cmp.checked) { if (compare.size >= 2) { cmp.checked = false; toast('Compare two at a time.', 'info'); return; } compare.add(e.id); } else compare.delete(e.id); drawCompareBar(); } });
    return h('article', { class: 'ps-card', dataset: { sceneId: e.id } }, thumb,
      h('div', { class: 'ps-card-body' }, h('div', { class: 'ps-card-head' }, h('h3', {}, e.title), fav), h('p', { class: 'ps-card-for' }, `${e.niche} · ${e.aspect}`),
        h('dl', { class: 'ps-facts' }, h('dt', {}, 'You’ll see'), h('dd', {}, e.see), h('dt', {}, 'Use it for'), h('dd', {}, e.where), h('dt', {}, 'Why'), h('dd', {}, e.benefit)),
        h('div', { class: 'ps-card-foot' }, h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: () => { location.hash = `#/scene/${e.id}`; } }, 'Design this visual'), h('label', { class: 'ps-check ps-cmp' }, cmp, ' Compare'))));
  }
  const compareBar = h('div', { class: 'ps-cmpbar', hidden: true });
  function drawCompareBar(): void { clear(compareBar); compareBar.hidden = compare.size === 0; if (compare.size) compareBar.append(h('span', {}, `${compare.size} selected to compare`), h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', disabled: compare.size !== 2, onclick: () => { location.hash = `#/compare/${[...compare].join('/')}`; } }, 'Compare side by side'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { compare.clear(); route(); } }, 'Clear')); }

  function drawGallery(): void {
    clear(view); disposeEditor?.(); disposeEditor = null;
    const results = searchScenes(all, query, favs);
    const search = h('input', { class: 'ps-search', type: 'search', id: 'ps-q', placeholder: 'What do you want to make? Try “promote my webinar” or “email header”', value: query.text ?? '', autocomplete: 'off' });
    let t = 0; search.addEventListener('input', () => { window.clearTimeout(t); t = window.setTimeout(() => { query = { ...query, text: search.value }; shown = PAGE; store.set('ab.ps.query', query); drawResults(); }, 140); });
    const sel = (label: string, key: keyof Query, options: Array<[string, string]>): HTMLElement => { const id = 'f-' + key; const s = h('select', { class: 'ps-select', id, onchange: () => { query = { ...query, [key]: s.value || undefined }; shown = PAGE; store.set('ab.ps.query', query); drawResults(); } }, h('option', { value: '' }, 'Any'), ...options.map(([v, l]) => h('option', { value: v, selected: query[key] === v }, l))); return h('div', { class: 'ps-filter' }, h('label', { class: 'ps-label', for: id }, label), s); };
    const cats = Object.entries(catalogue.index.categories).map(([k, c]) => [k, `${c.label} (${c.count})`] as [string, string]).sort((a, b) => a[1].localeCompare(b[1]));
    const platforms = [...new Set(all.flatMap(e => e.platforms))].sort().map(p => [p, p.charAt(0).toUpperCase() + p.slice(1)] as [string, string]);
    const aspects = [...new Set(all.map(e => e.aspect))].sort().map(a => [a, a] as [string, string]);
    const filters = h('div', { class: 'ps-filters', id: 'ps-filters', hidden: !filtersOpen }, sel('Business or niche', 'cat', cats), sel('Type of asset', 'assetGroup', ASSET_GROUPS.map(g => [g.key, g.label])), sel('Where it goes', 'platform', platforms), sel('Stage', 'stage', STAGES), sel('Shape', 'aspect', aspects), sel('Photo needed?', 'needsPhoto', [['no', 'No photo needed'], ['yes', 'Works with my photo']]), sel('Preview type', 'fidelity', [['final-html-asset', 'HTML visual'], ['composition-concept', 'Composition concept'], ['photo-required', 'Needs your photo']]), sel('Style', 'style', [...new Set(all.map(e => e.style))].sort().map(s => [s, s.replace(/-/g, ' ')] as [string, string])),
      h('label', { class: 'ps-check' }, h('input', { type: 'checkbox', checked: !!query.favouritesOnly, onchange: (e: Event) => { query = { ...query, favouritesOnly: (e.target as HTMLInputElement).checked || undefined }; shown = PAGE; drawResults(); } }), ' Favourites only'));
    const filtBtn = h('button', { class: 'ps-btn ps-btn--small', 'aria-expanded': String(filtersOpen), 'aria-controls': 'ps-filters', onclick: () => { filtersOpen = !filtersOpen; filters.hidden = !filtersOpen; filtBtn.setAttribute('aria-expanded', String(filtersOpen)); } }, 'Filters');
    const goals = h('div', { class: 'ps-goals', role: 'group', 'aria-label': 'Start from a goal' }, ...GOALS.map(([k, l]) => h('button', { class: 'ps-goal', 'aria-pressed': String(query.goal === k), onclick: () => { query = { ...query, goal: query.goal === k ? undefined : k }; shown = PAGE; store.set('ab.ps.query', query); drawGallery(); } }, l)));
    const count = h('p', { class: 'ps-count', 'aria-live': 'polite' }); const grid = h('div', { class: 'ps-grid' }); const more = h('div', { class: 'ps-more' });
    const invite = store.get('ab.ps.invite.dismissed', false) || brand() ? null : h('div', { class: 'ps-invite' }, h('span', {}, 'Make these assets look like my brand — add your colours, offer and audience whenever you like.'), h('button', { class: 'ps-btn ps-btn--small ps-btn--primary', onclick: openWizard }, 'Personalise my brand'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', 'aria-label': 'Dismiss', onclick: (e: Event) => { store.set('ab.ps.invite.dismissed', true); (e.target as HTMLElement).parentElement?.remove(); } }, 'Not now'));
    add(view, invite, h('section', { class: 'ps-hero', 'aria-label': 'Start a design' },
      h('div', { class: 'ps-head' }, h('div', {}, h('p', { class: 'ps-eyebrow' }, 'Visual asset studio'), h('h1', {}, 'Prompt ', h('mark', { class: 'ps-hl' }, 'Studio')), h('p', { class: 'ps-muted' }, `${catalogue.count.toLocaleString('en-AU')} editable visual templates across ${Object.keys(catalogue.index.categories).length} niches. Pick one, make it yours, export a real image.`)),
        h('div', { class: 'ps-row' }, h('button', { class: 'ps-btn', 'data-open-wizard': '1', 'aria-expanded': String(!side.hidden), onclick: () => (side.hidden ? openWizard() : closeWizard()) }, 'Personalise my brand'), h('a', { class: 'ps-btn', href: '#/campaign' }, 'Plan my whole launch'), h('a', { class: 'ps-btn', href: '#/library' }, 'My library'))),
      h('div', { class: 'ps-searchrow' }, h('label', { class: 'ps-sr', for: 'ps-q' }, 'Search templates'), search, filtBtn, Object.values(query).some(Boolean) ? h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { query = {}; store.set('ab.ps.query', query); shown = PAGE; drawGallery(); } }, 'Clear all') : null),
      goals), filters, count, compareBar, grid, more);
    if (recent.length && !query.text && !query.goal) { const rec = recent.map(id => catalogue.entry(id)).filter((e): e is GalleryEntry => !!e).slice(0, 6); if (rec.length) grid.before(h('section', { class: 'ps-recent', 'aria-label': 'Recently used' }, h('h2', {}, 'Recently used'), h('div', { class: 'ps-recent-row' }, ...rec.map(e => h('a', { class: 'ps-recent-item', href: `#/scene/${e.id}` }, h('img', { src: `${base}${e.thumb}?v=${e.hash.slice(0, 10)}`, alt: '', loading: 'lazy', width: e.w, height: e.h }), h('span', {}, e.title)))))); }
    let observer: IntersectionObserver | null = null;
    function drawResults(): void {
      const res = searchScenes(all, query, favs); clear(grid); clear(more); observer?.disconnect();
      count.textContent = res.length === all.length ? `Showing all ${all.length.toLocaleString('en-AU')} templates` : `${res.length.toLocaleString('en-AU')} template${res.length === 1 ? '' : 's'} match`;
      if (!res.length) { grid.append(h('div', { class: 'ps-empty' }, h('h2', {}, 'Nothing matches that yet'), h('p', {}, 'Try fewer words — for example “webinar”, “testimonial”, “email header” — or clear the filters.'), h('button', { class: 'ps-btn', onclick: () => { query = {}; shown = PAGE; drawGallery(); } }, 'Show everything'))); return; }
      const frag = document.createDocumentFragment(); for (const e of res.slice(0, shown)) frag.append(card(e)); grid.append(frag);
      if (shown < res.length) { const b = h('button', { class: 'ps-btn', onclick: () => { shown += PAGE; drawResults(); } }, `Show more (${(res.length - shown).toLocaleString('en-AU')} to go)`); more.append(b); observer = new IntersectionObserver(en => { if (en.some(x => x.isIntersecting)) { const y = window.scrollY; shown += PAGE; drawResults(); window.scrollTo({ top: y }); } }, { rootMargin: '600px' }); observer.observe(b); }
    }
    void results; drawResults(); drawCompareBar();
  }

  // ---------------------------------------------------------------- compare
  async function drawCompare(a: string, b: string): Promise<void> {
    clear(view); view.append(h('div', { class: 'ps-loading' }, 'Loading both briefs…'));
    try {
      const [sa, sb] = await Promise.all([catalogue.loadFullSource(a), catalogue.loadFullSource(b)]); clear(view);
      const col = (s: typeof sa): HTMLElement => { const e = catalogue.entry(s.id)!; return h('div', { class: 'ps-cmp-col' }, h('img', { src: `${base}${e.thumb}?v=${e.hash.slice(0, 10)}`, alt: `${e.title}: ${e.see}`, width: e.w, height: e.h }), h('h2', {}, s.dna.assetLabel), h('p', { class: 'ps-muted' }, `${s.niche} · ${s.aspect_ratio}`), h('dl', { class: 'ps-facts' }, ...([['You’ll see', s.visible_scene], ['Subject', s.dna.subject], ['Setting', s.dna.environment || '—'], ['In frame', s.dna.props.join(', ') || '—'], ['Framing', s.framing], ['Copy space', s.original.safeZones], ['Use it for', s.where_used], ['Designed to', s.benefit]] as Array<[string, string]>).flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])), h('a', { class: 'ps-btn ps-btn--primary', href: `#/scene/${s.id}` }, 'Design this visual')); };
      view.append(h('div', { class: 'ps-head' }, h('h1', {}, 'Compare'), h('a', { class: 'ps-btn', href: '#/' }, '← Gallery')), h('div', { class: 'ps-cmp-grid' }, col(sa), col(sb)));
      const ab = abPartner(all, catalogue.entry(a)!); if (ab) view.append(h('section', { class: 'ps-note' }, h('h2', {}, 'A/B idea'), h('p', {}, ab.hypothesis), h('p', { class: 'ps-muted' }, ab.measure), h('a', { class: 'ps-btn ps-btn--small', href: `#/compare/${a}/${ab.scene.id}` }, `Compare with “${ab.scene.title}”`)));
    } catch (e) { clear(view); view.append(h('div', { class: 'ps-error', role: 'alert' }, h('p', {}, (e as Error).message), h('a', { class: 'ps-btn', href: '#/' }, 'Back to gallery'))); }
  }

  // ---------------------------------------------------------------- library
  async function drawLibrary(): Promise<void> {
    clear(view); view.append(h('div', { class: 'ps-head' }, h('h1', {}, 'My library'), h('a', { class: 'ps-btn', href: '#/' }, '← Gallery')));
    if (!serverUp) { view.append(h('div', { class: 'ps-empty' }, h('h2', {}, 'The library lives in Authority Builder Studio'), h('p', {}, 'This static preview has no workspace storage. Your in-progress drafts are kept on this device and reopen from the gallery.'))); return; }
    if (!session.principal) { view.append(h('div', { class: 'ps-empty' }, h('h2', {}, 'Sign in to see your saved designs'), h('p', {}, 'Saved designs, their editable sources and campaigns belong to a workspace.'), h('button', { class: 'ps-btn ps-btn--primary', onclick: () => host.requestSignIn?.() }, 'Sign in'))); return; }
    try {
      const [{ assets }, { campaigns }] = await Promise.all([api.json<{ assets: Array<{ id: string; sceneId: string; title: string; status: string; kind: string; width: number; height: number; version: number; updatedAt: string; altText: string; campaignIds: string[]; insertedInto: Array<{ target: string; targetId: string }> }> }>('GET', base + 'api/assets'), api.json<{ campaigns: Array<{ id: string; name: string; objective: string; assetIds: string[]; hypothesis: string }> }>('GET', base + 'api/campaigns')]);
      if (!assets.length) { view.append(h('div', { class: 'ps-empty' }, h('h2', {}, 'Nothing saved yet'), h('p', {}, 'Open any template, make it yours and choose “Save to library”.'), h('a', { class: 'ps-btn ps-btn--primary', href: '#/' }, 'Browse templates'))); return; }
      const picked = new Set<string>(); const grid = h('div', { class: 'ps-grid' });
      for (const a of assets) {
        const img = h('img', { class: 'ps-thumb-img', alt: a.altText, width: a.width, height: a.height }); void fetch(`${base}api/assets/${a.id}/image`, { headers: { authorization: 'Bearer ' + api.token } }).then(r => (r.ok ? r.blob() : Promise.reject(new Error()))).then(bl => { img.src = URL.createObjectURL(bl); }).catch(() => { img.alt = 'Image unavailable'; });
        const target = h('select', { class: 'ps-select', 'aria-label': `Use ${a.title} in` }, h('option', { value: '' }, 'Use in…'), h('option', { value: 'email-builder' }, 'Email builder'), h('option', { value: 'content-planner' }, 'Content planner'), h('option', { value: 'project' }, 'Project'), h('option', { value: 'page-builder' }, 'Page builder'));
        target.addEventListener('change', async () => { if (!target.value) return; try { const r = await api.json<{ note: string }>('POST', `${base}api/assets/${a.id}/insert`, { target: target.value, targetId: 'default' }); toast(`Linked to ${target.selectedOptions[0]!.textContent}. ${r.note}`, 'ok'); void drawLibrary(); } catch (e) { toast((e as Error).message, 'error'); } });
        grid.append(h('article', { class: 'ps-card' }, h('a', { class: 'ps-thumb', href: `#/scene/${a.sceneId}?asset=${a.id}`, style: { aspectRatio: `${a.width} / ${a.height}` }, 'aria-label': `Reopen ${a.title}` }, img, h('span', { class: 'ps-fid' }, a.kind === 'customer-version' ? 'Customer version' : a.kind === 'html-visual' ? 'HTML visual' : 'Composition concept')),
          h('div', { class: 'ps-card-body' }, h('h3', {}, a.title), h('p', { class: 'ps-card-for' }, `${a.width}×${a.height} · version ${a.version} · ${a.status} · updated ${new Date(a.updatedAt).toLocaleDateString('en-AU')}`), a.insertedInto.length ? h('p', { class: 'ps-muted' }, 'Linked in: ' + [...new Set(a.insertedInto.map(i => i.target))].join(', ')) : null, a.campaignIds.length ? h('p', { class: 'ps-muted' }, `In ${a.campaignIds.length} campaign(s)`) : null,
            h('div', { class: 'ps-card-foot' }, h('a', { class: 'ps-btn ps-btn--small ps-btn--primary', href: `#/scene/${a.sceneId}?asset=${a.id}` }, 'Reopen and edit'), target, h('label', { class: 'ps-check' }, h('input', { type: 'checkbox', 'aria-label': `Add ${a.title} to a campaign`, onchange: (e: Event) => { if ((e.target as HTMLInputElement).checked) picked.add(a.id); else picked.delete(a.id); } }), ' Campaign'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: async () => { const d = h('dialog', { class: 'ps-dialog' }, h('form', { method: 'dialog' }, h('h2', {}, 'Delete this design?'), h('p', {}, `“${a.title}” and its editable source will be removed from your workspace. This can’t be undone.`), h('div', { class: 'ps-row ps-row--end' }, h('button', { class: 'ps-btn', value: 'cancel' }, 'Keep it'), h('button', { class: 'ps-btn ps-btn--danger', value: 'ok' }, 'Delete')))); view.append(d); d.addEventListener('close', async () => { const ok = d.returnValue === 'ok'; d.remove(); if (!ok) return; try { await api.json('DELETE', `${base}api/assets/${a.id}`); toast('Deleted.', 'ok'); void drawLibrary(); } catch (e) { toast((e as Error).message, 'error'); } }); d.showModal(); } }, 'Delete')))));
      }
      const name = h('input', { class: 'ps-input', type: 'text', id: 'cmp-name', placeholder: 'e.g. March cohort launch' });
      view.append(grid, h('section', { class: 'ps-note' }, h('h2', {}, 'Group into a campaign'), h('p', { class: 'ps-muted' }, 'Tick “Campaign” on the designs above, name it, and save. Results aren’t tracked here — record them in your ad or email platform.'), h('div', { class: 'ps-row' }, h('label', { class: 'ps-sr', for: 'cmp-name' }, 'Campaign name'), name, h('button', { class: 'ps-btn ps-btn--primary', onclick: async () => { if (!picked.size) { toast('Tick at least one design.', 'info'); return; } try { await api.json('POST', base + 'api/campaigns', { name: name.value || 'Untitled campaign', objective: wizDraft.objective ?? '', flow: 'manual', assetIds: [...picked], hypothesis: '' }); toast('Campaign saved.', 'ok'); void drawLibrary(); } catch (e) { toast((e as Error).message, 'error'); } } }, 'Save campaign')),
        campaigns.length ? h('ul', {}, ...campaigns.map(c => h('li', {}, `${c.name} — ${c.assetIds.length} design(s)${c.objective ? ' · ' + c.objective : ''}`))) : null));
    } catch (e) { view.append(h('div', { class: 'ps-error', role: 'alert' }, h('p', {}, (e as Error).message))); }
  }

  // ---------------------------------------------------------------- campaign planner (offer → complementary assets → pack)
  let flowKey = FLOWS[0]!.key; let flowCat = ''; let recs: Recommendation[] = [];
  function drawCampaign(): void {
    clear(view); const flow = FLOWS.find(f => f.key === flowKey)!; recs = recommendForFlow(all, flow, { cat: flowCat || undefined });
    const b = brand();
    const cats = Object.entries(catalogue.index.categories).filter(([, c]) => c.channel === 'Profession').map(([k, c]) => [k, c.label] as [string, string]).sort((x, y) => x[1].localeCompare(y[1]));
    const fs = h('select', { class: 'ps-select', id: 'cp-flow', onchange: () => { flowKey = fs.value; drawCampaign(); } }, ...FLOWS.map(f => h('option', { value: f.key, selected: f.key === flowKey }, f.label)));
    const cs = h('select', { class: 'ps-select', id: 'cp-cat', onchange: () => { flowCat = cs.value; drawCampaign(); } }, h('option', { value: '' }, 'Any field'), ...cats.map(([k, l]) => h('option', { value: k, selected: k === flowCat }, l)));
    view.append(h('div', { class: 'ps-head' }, h('div', {}, h('h1', {}, 'Plan my whole launch'), h('p', { class: 'ps-muted' }, 'Pick what you’re doing. You’ll get a set of different visuals that each do a different job — not five versions of one picture.')), h('a', { class: 'ps-btn', href: '#/' }, '← Gallery')),
      h('div', { class: 'ps-filters' }, h('div', { class: 'ps-filter' }, h('label', { class: 'ps-label', for: 'cp-flow' }, 'What are you promoting?'), fs), h('div', { class: 'ps-filter' }, h('label', { class: 'ps-label', for: 'cp-cat' }, 'Your field'), cs),
        h('div', { class: 'ps-filter' }, h('span', { class: 'ps-label' }, 'Your offer and audience'), h('p', { class: 'ps-muted' }, b?.offer || b?.businessName ? `${b.businessName ?? ''}${b.offer ? ' — ' + b.offer : ''}${b.audience ? ' · for ' + b.audience : ''}` : 'Not set yet (optional).'), h('button', { class: 'ps-btn ps-btn--small', onclick: openWizard }, b ? 'Edit' : 'Add my offer'))),
      h('p', { class: 'ps-muted' }, flow.description));
    const grid = h('ol', { class: 'ps-flow' });
    recs.forEach((r, i) => { const e = r.scene; grid.append(h('li', { class: 'ps-flow-step' }, h('a', { class: 'ps-thumb', href: `#/scene/${e.id}`, style: { aspectRatio: `${e.w} / ${e.h}` }, 'aria-label': `Open ${e.title}` }, h('img', { class: 'ps-thumb-img', src: `${base}${e.thumb}?v=${e.hash.slice(0, 10)}`, alt: `${e.title}: ${e.see}`, loading: 'lazy', width: e.w, height: e.h }), h('span', { class: 'ps-fid', dataset: { fid: e.fidelity } }, FIDELITY_LABEL[e.fidelity] ?? e.fidelity)),
      h('div', {}, h('p', { class: 'ps-step-n' }, `Step ${i + 1} · ${r.step.label}`), h('h3', {}, e.title), h('p', { class: 'ps-muted' }, r.step.size ? `${r.step.size.placement} · ${r.step.size.width}×${r.step.size.height}` : e.aspect), h('ul', { class: 'ps-reasons' }, ...r.reasons.map(x => h('li', {}, x))),
        h('div', { class: 'ps-row' }, h('a', { class: 'ps-btn ps-btn--small', href: `#/scene/${e.id}` }, 'Preview and edit'), h('button', { class: 'ps-btn ps-btn--small ps-btn--ghost', onclick: () => { const alt = recommendForFlow(all, { ...flow, steps: [r.step] }, { cat: flowCat || undefined, exclude: recs.map(x => x.scene.id) })[0]; if (alt) { recs[i] = alt; const li = grid.children[i] as HTMLElement; li.replaceWith(h('li', { class: 'ps-flow-step' }, h('p', {}, `Swapped to “${alt.scene.title}”.`), h('a', { class: 'ps-btn ps-btn--small', href: `#/scene/${alt.scene.id}` }, 'Preview and edit'))); } else toast('No other close match for this step.', 'info'); } }, 'Try a different one'))))); });
    const built = h('p', { class: 'ps-muted', 'aria-live': 'polite' });
    view.append(grid, h('section', { class: 'ps-note' }, h('h2', {}, 'Build the pack'), h('p', {}, 'Creates each design in your brand at the right size for its placement, ready to edit or export together. Headlines are placeholders until you add your own words — nothing is invented for you.'),
      h('div', { class: 'ps-row' }, h('button', { class: 'ps-btn ps-btn--primary', onclick: async () => { built.textContent = 'Composing designs…'; let n = 0; for (const r of recs) { try { const sc = await catalogue.loadFullSource(r.scene.id); const first = planScene(sc, { brand: brand() }); const spec = r.step.size ? ES.replan({ scene: sc, current: first, brand: brand(), size: r.step.size, note: `campaign step: ${r.step.label}` }) : first; addToPack({ spec, name: `${r.step.label} — ${r.scene.title}`, lighting: sc.dna.lightingVariant }); n++; } catch (e) { toast(`${r.scene.title}: ${(e as Error).message}`, 'error'); } } built.textContent = `${n} design(s) added to your pack below. Open any step to edit it first, or export the pack now.`; } }, `Build ${recs.length} designs`), built),
      h('h3', {}, 'Before you publish'), h('ul', {}, h('li', {}, 'Replace every “suggested” line with your real words, dates and prices.'), h('li', {}, 'Only use quotes, results and photos you have permission to use.'), h('li', {}, 'Only mention a deadline if it is real.'), h('li', {}, 'Check each design at phone size.'))));
  }

  // ---------------------------------------------------------------- router (single source of truth: location.hash)
  function route(): void {
    const [path, qs] = location.hash.replace(/^#\/?/, '').split('?'); const parts = (path ?? '').split('/').filter(Boolean);
    disposeEditor?.(); disposeEditor = null; root.dataset.view = parts[0] ?? 'gallery';
    if (parts[0] === 'scene' && parts[1]) {
      const id = decodeURIComponent(parts[1]); recent = [id, ...recent.filter(x => x !== id)].slice(0, 12); store.set('ab.ps.recent', recent);
      const assetId = new URLSearchParams(qs ?? '').get('asset') ?? undefined;
      void mountEditor(view, id, { api, catalogue, brand, signedIn: () => !!session.principal, workspaceId: ws, photoProvider: () => session.entitlements.photoProvider, onBack: () => { location.hash = '#/'; }, openWizard, addToPack, serverAvailable: () => serverUp }, { assetId }).then(d => { disposeEditor = d; });
      window.scrollTo({ top: 0 }); return;
    }
    if (parts[0] === 'compare' && parts[1] && parts[2]) { void drawCompare(parts[1], parts[2]); return; }
    if (parts[0] === 'library') { void drawLibrary(); return; }
    if (parts[0] === 'campaign') { drawCampaign(); return; }
    drawGallery();
  }
  window.addEventListener('hashchange', route);
  /** Host calls this after its session changes (sign-in/out, workspace switch). */
  (root as HTMLElement & { refreshSession?: () => Promise<void> }).refreshSession = async () => { await loadSession(); loadDraft(); if (!side.hidden) drawWizard(); route(); };
  route(); drawPack();
}
