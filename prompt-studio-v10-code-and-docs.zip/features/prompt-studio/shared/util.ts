/** Shared, isomorphic helpers (no Node or DOM APIs). */

export function escapeHtml(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export const clamp = (n: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, n));
export const round = (n: number, dp = 2): number => { const f = 10 ** dp; return Math.round(n * f) / f; };

/** cyrb53 — fast deterministic 53-bit string hash (seeds, short fingerprints). */
export function hash53(str: string, seed = 0): number {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
export const hashHex = (str: string): string => hash53(str).toString(16).padStart(14, '0') + hash53(str, 7).toString(16).padStart(14, '0');

/** Deterministic PRNG (mulberry32) seeded from a string. */
export function rng(seedStr: string): () => number {
  let a = hash53(seedStr) >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const pick = <T>(r: () => number, arr: readonly T[]): T => arr[Math.floor(r() * arr.length) % arr.length] as T;
export const between = (r: () => number, lo: number, hi: number): number => lo + r() * (hi - lo);

/** Stable JSON stringify (sorted keys) for content hashing. */
export function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v) ?? 'null';
  if (Array.isArray(v)) return '[' + v.map(stableStringify).join(',') + ']';
  const o = v as Record<string, unknown>;
  return '{' + Object.keys(o).sort().filter(k => o[k] !== undefined).map(k => JSON.stringify(k) + ':' + stableStringify(o[k])).join(',') + '}';
}

// ---------- colour ----------
export type RGB = [number, number, number];
export const HEX_RE = /^#[0-9a-fA-F]{6}$/;
export function isHex(v: unknown): v is string { return typeof v === 'string' && HEX_RE.test(v); }
export function hexToRgb(hex: string): RGB {
  const h = isHex(hex) ? hex.slice(1) : '808080';
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}
export function rgbToHex([r, g, b]: RGB): string {
  return '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('').toUpperCase();
}
export function mix(a: string, b: string, t: number): string {
  const A = hexToRgb(a), B = hexToRgb(b);
  return rgbToHex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]);
}
export const lighten = (c: string, t: number): string => mix(c, '#FFFFFF', t);
export const darken = (c: string, t: number): string => mix(c, '#000000', t);
export function luminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map(v => { const s = v / 255; return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4; }) as RGB;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
export function contrast(a: string, b: string): number {
  const la = luminance(a), lb = luminance(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}
/** Choose the more legible of two inks on a background. */
export function inkOn(bg: string, dark = '#111111', light = '#FFFFFF'): string {
  return contrast(bg, dark) >= contrast(bg, light) ? dark : light;
}
export function saturation(hex: string): number {
  const [r, g, b] = hexToRgb(hex); const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
  return mx === 0 ? 0 : (mx - mn) / mx;
}
export function slugify(s: string): string {
  return s.toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}
export function titleCase(s: string): string { return s.replace(/\b([a-z])/g, m => m.toUpperCase()); }
export function sentence(s: string): string { const t = s.trim(); return t ? t.charAt(0).toUpperCase() + t.slice(1) : t; }
export function truncateWords(s: string, max: number): string {
  if (s.length <= max) return s;
  const cut = s.slice(0, max + 1); const i = cut.lastIndexOf(' ');
  return (i > max * 0.5 ? cut.slice(0, i) : cut.slice(0, max)).replace(/[\s,;:·—-]+$/, '') + '…';
}
