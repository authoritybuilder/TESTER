/**
 * Intent search: people type what they are trying to make or promote ("promote my webinar", "email header"),
 * not taxonomy. Pure, deterministic and fast enough to run on every keystroke across 4,437 entries.
 */
import type { GalleryEntry } from '../catalog/schema.ts';
import { hash53 } from '../shared/util.ts';

export interface Query { text?: string; goal?: string; cat?: string; assetGroup?: string; platform?: string; stage?: string; aspect?: string; needsPhoto?: 'yes' | 'no' | ''; fidelity?: string; style?: string; biz?: string; favouritesOnly?: boolean }

const STOP = new Set(['i', 'need', 'a', 'an', 'the', 'my', 'for', 'to', 'make', 'create', 'want', 'me', 'of', 'and', 'that', 'this', 'with', 'in', 'on', 'our', 'some', 'something', 'graphic', 'image', 'visual', 'picture', 'design', 'promote', 'get', 'is', 'it', 'new', 'up', 'looks', 'look', 'please', 'help', 'can', 'you', 'into', 'turn', 'use', 'using', 'from', 'do']);
/** Intent phrases → what they mean in catalogue terms. */
export const INTENTS: Array<{ re: RegExp; asset?: RegExp; aspect?: RegExp; kw?: RegExp; label: string }> = [
  { re: /sales page|landing page|page hero|website hero|homepage/, asset: /Sales\/Hero|Stock\/Hero|Homepage|Sales\/Programme|Advertising\/Hero|Launch/, label: 'page hero' },
  { re: /webinar|masterclass|live (event|training|session)|registration|online event/, asset: /Sales\/Event|Live Event|Replay|Event\/(Invite|Banner|Speaker|Calendar|Day-of|Keynote)|Enterprise\/Workshop|Cohort|Premium Event|Authority\/Speaker/, label: 'online event promotion' },
  { re: /workshop|\bevent\b|conference|retreat|in person/, asset: /Event|Live Event|Workshop|Premium Event/, label: 'event' },
  { re: /course|lesson|module|curriculum|cohort|programme|program/, asset: /Course|Cohort|Programme|Teachable|Thinkific|Kajabi|Replay|Onboarding/, label: 'course' },
  { re: /launch|announc/, asset: /Launch|Cohort|Sales\/Event|Bundle|Promo|Bonus/, label: 'launch' },
  { re: /product|shop|store|ecommerce|e-commerce|sku/, asset: /E-commerce|Stock\/Product|Bundle/, label: 'product' },
  { re: /podcast|episode|show/, asset: /Podcast|Show|Series/, label: 'podcast' },
  { re: /free guide|lead magnet|guide|checklist|download|opt-?in|freebie|ebook/, asset: /Lead|Workshop\/Materials|Bonus|Course\/Resource/, label: 'lead magnet' },
  { re: /before and after|before\/after|transformation/, asset: /Before After|Case Study|Social Proof|Service\/Showcase/, kw: /transformation|before|after/, label: 'transformation' },
  { re: /testimonial|review|proof|case study|results/, asset: /Social Proof|Case Study|Testimonial|Community\/Spotlight/, label: 'proof' },
  { re: /quote|saying/, asset: /Quote|Stock\/Social Backgrounds/, label: 'quote' },
  { re: /email|newsletter|inbox/, asset: /Email|Newsletter|Editorial\/(Masthead|Letter)/, label: 'email' },
  { re: /header|banner|masthead/, asset: /Masthead|Banner|Header|Email|Channel Branding|Services Page|About Page/, aspect: /16:5|3:1|12:5|8\.2:3/, label: 'header' },
  { re: /story|reel|tiktok|short/, aspect: /9:16/, asset: /Tiktok|Video|Advertising\/Mobile/, label: 'vertical video' },
  { re: /thumbnail|youtube/, asset: /Thumbnail|Video|Series|Tutorial|Channel/, label: 'thumbnail' },
  { re: /linkedin|expert|thought leader|authority/, asset: /LinkedIn|Authority|Headshot|Editorial\/Authority/, label: 'expertise' },
  { re: /instagram|carousel|\big\b/, asset: /Carousel|Social|Stock\/Social/, label: 'social' },
  { re: /pinterest|pin\b/, asset: /Pinterest/, aspect: /2:3/, label: 'pin' },
  { re: /\bad\b|ads|advert|retarget/, asset: /Advertising/, label: 'ads' },
  { re: /about|bio|my story/, asset: /About|Bio|Brand\/|Authenticity/, label: 'about' },
  { re: /book(ing)?|call|consult|discovery/, asset: /Booking|Consulting|Sales\/Service/, label: 'booking' },
  { re: /community|member|skool|group/, asset: /Community|Skool|Circle|Mighty|Sales\/Group/, label: 'community' },
  { re: /speak|keynote|stage|panel/, asset: /Speaker|Keynote|Stage|Panel/, label: 'speaking' },
  { re: /background|texture|backdrop/, asset: /Social Backgrounds|Branding|Texture/, label: 'background' },
  { re: /mock-?up|device|screen/, asset: /Product Mockups/, label: 'mock-up' },
  { re: /menu|invite|invitation|signage|print|card/, asset: /Event\/(Print|Invite|Signage|Hospitality|Follow-up)|Advertising\/Print/, label: 'print' },
  { re: /diagram|framework|method|process|explain|infographic/, asset: /Method|Methodology|Curriculum|Assessment|Strategy|Tutorial/, label: 'idea visual' },
];
export const ASSET_GROUPS: Array<{ key: string; label: string; re: RegExp }> = [
  { key: 'sales', label: 'Sales & offers', re: /^Sales|Bundle|Promo|Conversion|Executive Service|Mentoring|Programme/ }, { key: 'proof', label: 'Proof & trust', re: /Social Proof|Case Study|Authenticity|Testimonial|Spotlight/ },
  { key: 'authority', label: 'Expertise & speaking', re: /^Authority|Headshot|Speaker|Keynote|Panel|Stage|LinkedIn/ }, { key: 'social', label: 'Social posts', re: /^Social|Stock\/Social|Tiktok|Pinterest|Twitter|Creator|Community\/Engagement/ },
  { key: 'video', label: 'Video & podcast', re: /Video|Thumbnail|Podcast|Series|Channel|Show|Tutorial|Replay/ }, { key: 'email', label: 'Email', re: /^Email|Onboarding\/Email|Newsletter/ },
  { key: 'web', label: 'Website', re: /Homepage|About Page|Services Page|Stock\/(Hero|Blog|About)|Content|Generic/ }, { key: 'course', label: 'Courses & community', re: /^Course|Cohort|Teachable|Thinkific|Kajabi|Mighty|Circle|Community|Onboarding|Bonus/ },
  { key: 'event', label: 'Events & print', re: /^Event|Live Event|Premium Event|Workshop|Enterprise/ }, { key: 'editorial', label: 'Editorial', re: /^Editorial|Lifestyle|Fashion/ },
  { key: 'product', label: 'Products', re: /^E-commerce|Stock\/Product|Service\// }, { key: 'brand', label: 'Brand shoot', re: /^Stock\/(Lifestyle|Workspaces|Celebration)|^Brand|Lead/ }, { key: 'ads', label: 'Ads', re: /^Advertising|Marketing/ },
  { key: 'consulting', label: 'Consulting delivery', re: /^Consulting|Enterprise/ },
];

const tokens = (t: string): string[] => t.toLowerCase().replace(/[^a-z0-9:+ ]+/g, ' ').split(/\s+/).filter(w => w && !STOP.has(w));
const stem = (w: string): string => (w.length > 4 ? w.replace(/(ing|es|s)$/, '') : w);

export function matchesFilters(e: GalleryEntry, q: Query, favs?: Set<string>): boolean {
  if (q.goal && !e.goal.includes(q.goal)) return false;
  if (q.cat && e.cat !== q.cat) return false;
  if (q.assetGroup) { const g = ASSET_GROUPS.find(x => x.key === q.assetGroup); if (g && !g.re.test(e.asset)) return false; }
  if (q.platform && !e.platforms.includes(q.platform)) return false;
  if (q.stage && e.stage !== q.stage) return false;
  if (q.aspect && e.aspect !== q.aspect) return false;
  if (q.needsPhoto === 'yes' && !e.needsPhoto) return false;
  if (q.needsPhoto === 'no' && e.needsPhoto) return false;
  if (q.fidelity && e.fidelity !== q.fidelity) return false;
  if (q.style && e.style !== q.style) return false;
  if (q.biz && e.biz !== q.biz) return false;
  if (q.favouritesOnly && !favs?.has(e.id)) return false;
  return true;
}

export function searchScenes(all: GalleryEntry[], q: Query, favs?: Set<string>): GalleryEntry[] {
  const pool = all.filter(e => matchesFilters(e, q, favs));
  const text = (q.text ?? '').trim().toLowerCase();
  if (!text) return pool.slice().sort((a, b) => (hash53(a.id) % 9973) - (hash53(b.id) % 9973)); // stable interleave: varied first screen
  const toks = tokens(text).map(stem); const intents = INTENTS.filter(i => i.re.test(text));
  const scored: Array<{ e: GalleryEntry; s: number }> = [];
  for (const e of pool) {
    let s = 0; const f = { title: e.title.toLowerCase(), what: e.what.toLowerCase(), asset: e.asset.toLowerCase(), niche: e.niche.toLowerCase(), see: e.see.toLowerCase(), where: e.where.toLowerCase(), kw: e.kw, benefit: e.benefit.toLowerCase(), job: e.job.toLowerCase() };
    for (const t of toks) { if (f.title.includes(t)) s += 5; if (f.what.includes(t)) s += 3; if (f.asset.includes(t)) s += 4; if (f.niche.includes(t)) s += 4; if (f.where.includes(t)) s += 3; if (f.see.includes(t)) s += 2; if (f.job.includes(t)) s += 2; if (f.kw.includes(t)) s += 1; if (f.benefit.includes(t)) s += 1; if (e.id.includes(t)) s += 1; }
    for (const i of intents) { if (i.asset?.test(e.asset)) s += 9; if (i.aspect?.test(e.aspect)) s += 5; if (i.kw?.test(e.kw)) s += 3; }
    if (s > 0) scored.push({ e, s });
  }
  return scored.sort((a, b) => b.s - a.s || (hash53(a.e.id) % 997) - (hash53(b.e.id) % 997)).map(x => x.e);
}
