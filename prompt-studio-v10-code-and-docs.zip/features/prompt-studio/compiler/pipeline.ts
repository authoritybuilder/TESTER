/**
 * The ONE prompt/brief compiler. Replaces the legacy chain buildPrompt → v3GetEnhancedPrompt → v94AugmentPrompt →
 * v100CondensePrompt (and its generic one-size-fits-all portrait fallback; see docs/PROMPT_STUDIO_AUDIT.md).
 *
 *   loadFullSource(id) → validate → deriveDistinctSceneSpec → mergeWorkspaceBrandContext → applyUserOverrides
 *   → validateSceneInvariants → compileProviderSpecificInstructions → checkCapability/length
 *   → producePromptAndCreativeBrief → (generate/preview) → recordProvenance
 *
 * Precedence: template identity (immutable unless the customer explicitly changes concept) > the customer's business,
 * audience and purpose > brand kit > explicit optional styling edits > provider syntax/limits (always last).
 * Critical scene detail is emitted first so a shortened prompt stays distinct; segments are dropped whole, never cut mid-sentence.
 */
import type { CanonicalScene, PlatformKey } from '../catalog/schema.ts';
import { sentence, truncateWords } from '../shared/util.ts';
import type { BrandContext } from '../visual-engine/copy.ts';

export const PROVIDERS = {
  claude: { label: 'Claude (design brief)', kind: 'design-brief', budget: 2600, style: 'sections' },
  chatgpt: { label: 'ChatGPT image', kind: 'image', budget: 1700, style: 'prose' },
  mj: { label: 'Midjourney', kind: 'image', budget: 950, style: 'tags' },
  flux: { label: 'Flux', kind: 'image', budget: 1300, style: 'prose' },
  imagen: { label: 'Imagen', kind: 'image', budget: 1400, style: 'prose' },
  firefly: { label: 'Adobe Firefly', kind: 'image', budget: 950, style: 'prose' },
  leonardo: { label: 'Leonardo', kind: 'image', budget: 1300, style: 'prose' },
  sdxl: { label: 'Stable Diffusion XL', kind: 'image', budget: 900, style: 'tags' },
  ideogram: { label: 'Ideogram', kind: 'image', budget: 900, style: 'prose' },
  sora: { label: 'Sora (video)', kind: 'video', budget: 1500, style: 'prose' },
} as const satisfies Record<PlatformKey, { label: string; kind: 'image' | 'video' | 'design-brief'; budget: number; style: 'sections' | 'prose' | 'tags' }>;
export type ProviderKey = keyof typeof PROVIDERS;

export interface UserOverrides {
  purpose?: 'awareness' | 'trust' | 'leads' | 'sales' | 'retention';
  scene?: { subject?: string; environment?: string; addProps?: string[]; removeProps?: string[]; negativeSpace?: 'more' | 'less' };
  channel?: { width: number; height: number; placement?: string };
  direction?: { style?: 'photographic' | 'illustrated' | 'editorial' | 'minimal'; intensity?: 1 | 2 | 3 };
  changeRequest?: string;
  /** default true: brand/style edits may not rewrite the underlying concept. */
  conceptLocked?: boolean;
}
export interface Change { field: string; from: string; to: string; reversible: true; source: 'brand-kit' | 'override' | 'change-request' }
export interface Segment { key: string; label: string; priority: number; full: string; short: string; critical: boolean }
export interface CompiledPrompt {
  sceneId: string; provider: ProviderKey; kind: 'image' | 'video' | 'design-brief'; prompt: string; length: number; budget: number;
  segmentsKept: string[]; segmentsShortened: string[]; segmentsDropped: string[];
  anchorsPresent: string[]; anchorsMissing: string[]; warnings: string[]; changes: Change[];
  creativeBrief: string; originalPrompt: string;
  provenance: { sceneId: string; sourceVersion: string; sourceFingerprint: string; compilerVersion: string; brandApplied: boolean; conceptLocked: boolean; overridesApplied: string[] };
}
export class SceneInvariantError extends Error { constructor(public readonly sceneId: string, public readonly missing: string[]) { super(`Scene invariants violated for ${sceneId}: ${missing.join('; ')}`); this.name = 'SceneInvariantError'; } }

export const PIPELINE_VERSION = 'ab-compiler-10.0.0';

// ---------------------------------------------------------------- step: working scene (immutable identity + mutable optional styling)
export interface WorkingScene {
  base: CanonicalScene; subject: string; action: string; environment: string; props: string[]; framing: string; safeZones: string; noOverlay: boolean;
  palette: string[]; business: string; offer: string; audience: string; purpose: string; style: string; lighting: string; wardrobe: string | null;
  width: number; height: number; aspect: string; placement: string; notes: string[]; changes: Change[]; warnings: string[]; conceptLocked: boolean; applied: string[]; brandApplied: boolean;
}
const INTENT_WORDS: Record<string, string> = {
  trust_builder: 'build trust before the first conversation', aspirational: 'let the viewer picture the outcome', emotional_connection: 'create a real human connection', social_proof: 'make room for verified proof',
  community_belonging: 'signal belonging', curiosity_gap: 'open a curiosity gap', premium_signaling: 'signal premium value through restraint', educational: 'teach one idea at a glance', fomo_urgency: 'convey genuine, factual urgency', pattern_interrupt: 'break the scrolling pattern',
};
const PURPOSE_WORDS: Record<NonNullable<UserOverrides['purpose']>, string> = { awareness: 'earn attention from people who do not know the brand yet', trust: 'build trust and credibility', leads: 'earn an enquiry or sign-up', sales: 'support a buying decision', retention: 'make existing clients feel looked after' };

export function deriveDistinctSceneSpec(scene: CanonicalScene): WorkingScene {
  const d = scene.dna; const person = ['person', 'two-people', 'group', 'hands'].includes(d.subjectKind);
  const photo = /realistic|photo/.test(scene.render_style);
  return {
    base: scene, subject: d.subject, action: d.action, environment: d.environment, props: [...d.props], framing: scene.framing, safeZones: scene.original.safeZones, noOverlay: d.noOverlay,
    palette: [...d.palette], business: '', offer: '', audience: scene.target_audience, purpose: INTENT_WORDS[scene.conversion_intent] ?? scene.conversion_intent.replace(/_/g, ' '),
    style: `${scene.render_style.replace(/-/g, ' ')}, ${scene.background_style.replace(/_/g, ' ')} background, ${scene.design_principle.replace(/_/g, ' ')} composition`,
    lighting: photo ? scene.lighting_spec : '', wardrobe: person ? scene.wardrobe_if_applicable : null,
    width: d.width, height: d.height, aspect: scene.aspect_ratio, placement: scene.where_used, notes: [], changes: [], warnings: [], conceptLocked: true, applied: [], brandApplied: false,
  };
}

// ---------------------------------------------------------------- step: brand merge (colour/voice only — never adds a face, logo or camera)
export function mergeWorkspaceBrandContext(w: WorkingScene, brand?: BrandContext): WorkingScene {
  if (!brand) return w;
  const ch = (field: string, from: string, to: string): void => { if (from !== to) w.changes.push({ field, from, to, reversible: true, source: 'brand-kit' }); };
  if (brand.palette) { const p = [brand.palette.primary, brand.palette.secondary, brand.palette.accent, brand.palette.light, brand.palette.dark].map(c => c.toUpperCase()); ch('palette', w.palette.join(', '), p.join(', ')); w.palette = p; w.brandApplied = true; }
  if (brand.businessName) { ch('business', '(not set)', brand.businessName); w.business = brand.businessName; w.brandApplied = true; }
  if (brand.offer) { ch('offer', '(not set)', brand.offer); w.offer = brand.offer; w.brandApplied = true; }
  if (brand.audience) { ch('audience', w.audience, brand.audience); w.audience = brand.audience; w.brandApplied = true; }
  return w;
}

// ---------------------------------------------------------------- step: explicit user overrides + natural-language change request
const CONCEPT_CHANGE = /\b(instead|different (scene|concept|idea|image)|replace (the )?(whole|entire)|completely different|change the concept|start again)\b/i;

export function parseChangeRequest(text: string): { overrides: UserOverrides; notes: string[]; conceptChange: boolean } {
  const o: UserOverrides = { scene: {} }; const notes: string[] = []; const t = text.trim(); if (!t) return { overrides: {}, notes, conceptChange: false };
  for (const clause of t.split(/[.;\n]+|,\s*(?=(?:and\s+)?(?:remove|add|make|no|less|more|use|change)\b)/i).map(s => s.trim()).filter(Boolean)) {
    let m: RegExpMatchArray | null;
    if ((m = clause.match(/^(?:please\s+)?(?:remove|take out|no|without|delete)\s+(?:the\s+|any\s+)?(.+)$/i))) { if (/people|person|face|model/i.test(m[1]!)) o.scene!.subject = 'no person in frame'; else (o.scene!.removeProps ??= []).push(m[1]!.trim()); }
    else if ((m = clause.match(/^(?:please\s+)?(?:add|include|show)\s+(?:a\s+|an\s+|some\s+|the\s+)?(.+)$/i))) (o.scene!.addProps ??= []).push(m[1]!.trim());
    else if (/more (white ?space|negative space|room|breathing)/i.test(clause)) o.scene!.negativeSpace = 'more';
    else if (/less (white ?space|negative space|empty)/i.test(clause) || /fill the frame/i.test(clause)) o.scene!.negativeSpace = 'less';
    else if (/less corporate|more relaxed|more casual/i.test(clause)) { notes.push('Relaxed, less corporate register: natural posture, softer wardrobe and setting — same scene.'); }
    else if (/more editorial|magazine/i.test(clause)) (o.direction ??= {}).style = 'editorial';
    else if (/minimal|simpler|cleaner/i.test(clause)) (o.direction ??= {}).style = 'minimal';
    else if (/illustrat/i.test(clause)) (o.direction ??= {}).style = 'illustrated';
    else if ((m = clause.match(/(?:set|change|move) (?:it |the scene |the setting )?(?:in|to) (?:a |an |the )?(.+)$/i)) && !/colou?r|font|palette/i.test(clause)) o.scene!.environment = m[1]!.trim();
    else notes.push(sentence(clause) + '.');
  }
  if (o.scene && !Object.keys(o.scene).length) delete o.scene;
  return { overrides: o, notes, conceptChange: CONCEPT_CHANGE.test(t) };
}

export function applyUserOverrides(w: WorkingScene, ov?: UserOverrides): WorkingScene {
  if (!ov) return w;
  const merged: UserOverrides = { ...ov, scene: { ...ov.scene } };
  if (ov.changeRequest) { const pr = parseChangeRequest(ov.changeRequest); merged.scene = { ...pr.overrides.scene, ...merged.scene, addProps: [...(pr.overrides.scene?.addProps ?? []), ...(ov.scene?.addProps ?? [])], removeProps: [...(pr.overrides.scene?.removeProps ?? []), ...(ov.scene?.removeProps ?? [])] }; merged.direction = { ...pr.overrides.direction, ...ov.direction }; w.notes.push(...pr.notes); if (pr.conceptChange) w.warnings.push('This request changes the underlying concept. Use “Change concept” to pick a different template, or unlock the concept to proceed.'); w.applied.push('changeRequest'); }
  w.conceptLocked = ov.conceptLocked ?? true;
  const ch = (field: string, from: string, to: string): void => { w.changes.push({ field, from, to, reversible: true, source: ov.changeRequest ? 'change-request' : 'override' }); w.applied.push(field); };
  if (merged.purpose) { ch('purpose', w.purpose, PURPOSE_WORDS[merged.purpose]); w.purpose = PURPOSE_WORDS[merged.purpose]; }
  const sc = merged.scene ?? {};
  if (sc.subject) { if (w.conceptLocked && w.base.dna.subjectKind !== 'person' && /person|people/.test(sc.subject) && !/no person/.test(sc.subject)) w.warnings.push('Adding a person changes this concept (the source scene has no person). Locked concept kept the original subject.'); else { ch('subject', w.subject, sc.subject); w.subject = sc.subject; if (/no person/.test(sc.subject)) w.wardrobe = null; } }
  if (sc.environment) { if (w.conceptLocked) w.warnings.push(`Changing the setting to “${sc.environment}” alters the concept; applied as a styling note only. Unlock the concept to replace the setting.`), w.notes.push(`Setting flavour requested: ${sc.environment}.`); else { ch('environment', w.environment, sc.environment); w.environment = sc.environment; } }
  for (const rm of sc.removeProps ?? []) { const before = w.props.join(', '); const kept = w.props.filter(p => !p.toLowerCase().includes(rm.toLowerCase()) && !rm.toLowerCase().includes(p.toLowerCase())); if (kept.length !== w.props.length) { w.props = kept; ch('props', before, kept.join(', ') || '(none)'); } else w.notes.push(`Leave out: ${rm}.`); }
  for (const add of sc.addProps ?? []) { const before = w.props.join(', '); w.props.push(add); ch('props', before, w.props.join(', ')); }
  if (sc.negativeSpace) { w.notes.push(sc.negativeSpace === 'more' ? 'Increase negative space around the subject; keep the same subject, setting and copy zones.' : 'Tighter framing with less empty space; keep the same subject, setting and copy zones.'); w.applied.push('negativeSpace'); }
  if (merged.direction?.style) { const st = { photographic: 'photorealistic photography', illustrated: 'editorial illustration', editorial: 'magazine-editorial treatment', minimal: 'minimal, reduced treatment' }[merged.direction.style]; ch('style', w.style, `${st}; ${w.style.split(', ').slice(1).join(', ')}`); w.style = `${st}; ${w.style.split(', ').slice(1).join(', ')}`; if (merged.direction.style === 'illustrated') w.lighting = ''; }
  if (merged.channel) { ch('output', `${w.width}×${w.height}`, `${merged.channel.width}×${merged.channel.height}`); w.width = merged.channel.width; w.height = merged.channel.height; w.aspect = ratio(w.width, w.height); if (merged.channel.placement) w.placement = merged.channel.placement; w.notes.push('Re-compose for this format (do not crop or stretch): keep the subject, key props and copy zones readable.'); }
  return w;
}
const gcd = (a: number, b: number): number => (b ? gcd(b, a % b) : a);
function ratio(w: number, h: number): string { const g = gcd(w, h); const a = w / g, b = h / g; return a <= 32 && b <= 32 ? `${a}:${b}` : `${Math.round((w / h) * 100) / 100}:1`; }

// ---------------------------------------------------------------- step: invariants
const norm = (s: string): string => s.toLowerCase().replace(/[^a-z0-9% ]+/g, ' ').replace(/\s+/g, ' ').trim();
/** The source facts that must survive compilation for this scene to still be this scene. */
export function sceneAnchors(w: WorkingScene): Array<{ name: string; needle: string }> {
  const d = w.base.dna; const a: Array<{ name: string; needle: string }> = [{ name: 'asset', needle: d.assetLabel }];
  a.push({ name: 'framing', needle: w.framing.split(',')[0]!.slice(0, 60) });
  if (w.environment && w.conceptLocked) a.push({ name: 'environment', needle: w.environment.split(',')[0]!.slice(0, 50) });
  if (w.props[0]) a.push({ name: 'prop', needle: w.props[0].slice(0, 40) });
  if (!w.noOverlay && d.zones[0]) a.push({ name: 'copy-zone', needle: w.safeZones.split(';')[0]!.slice(0, 50) });
  if (w.noOverlay) a.push({ name: 'no-overlay', needle: 'no text' });
  return a.filter(x => norm(x.needle).length > 2);
}
export function validateSceneInvariants(w: WorkingScene): WorkingScene {
  const missing: string[] = [];
  if (!w.base.original?.richBrief) missing.push('original rich brief missing');
  if (!w.framing) missing.push('framing missing');
  if (!w.base.dna.anchors || w.base.dna.anchors.length < 3) missing.push('fewer than 3 distinctness anchors');
  if (w.conceptLocked && w.base.dna.subjectKind !== 'person' && w.wardrobe && !['two-people', 'group', 'hands', 'print-typographic'].includes(w.base.dna.subjectKind)) missing.push('wardrobe applied to a scene with no person');
  if (missing.length) throw new SceneInvariantError(w.base.id, missing);
  return w;
}

// ---------------------------------------------------------------- step: segments (shared canonical content, ordered by priority)
export function buildSegments(w: WorkingScene, kind: 'image' | 'video' | 'design-brief'): Segment[] {
  const s = w.base, d = s.dna; const seg: Segment[] = [];
  const add = (key: string, label: string, priority: number, full: string, short = full, critical = false): void => { if (full.trim()) seg.push({ key, label, priority, full: full.trim(), short: short.trim(), critical }); };
  const forWhom = s.original.channelType === 'Platform' ? s.niche : s.niche.toLowerCase();
  const biz = w.business ? ` for ${w.business}${w.offer ? ' (' + w.offer + ')' : ''}` : '';
  add('asset', 'Asset', 1, `${d.assetLabel} for ${forWhom}${biz}. Use: ${truncateWords(w.placement, 150)}.`, `${d.assetLabel} for ${forWhom}${biz}.`, true);
  const subj = d.subjectKind === 'person' || d.subjectKind === 'two-people' ? `${sentence(w.subject)}${w.action ? ' — ' + w.action : ''}. Use the customer’s own reference photo for identity; do not invent a likeness.` : `${sentence(w.subject)}${w.action && !/^N\/A/.test(w.action) ? ' — ' + w.action : ''}.`;
  add('subject', 'Subject', 2, subj, `${sentence(w.subject)}${w.action ? ' — ' + truncateWords(w.action, 70) : ''}.`, true);
  add('framing', 'Framing', 3, `Framing: ${w.framing}.`, `Framing: ${w.framing}.`, true);
  const propTxt = w.props.length ? ` Visible in frame: ${w.props.join(', ')}.` : '';
  add('setting', 'Setting and props', 4, `${w.environment ? 'Setting: ' + w.environment + '.' : ''}${propTxt}`, `${w.environment ? 'Setting: ' + w.environment.split(',')[0] + '.' : ''}${w.props.length ? ' Props: ' + w.props.slice(0, 3).join(', ') + '.' : ''}`, true);
  add('copy', 'Copy space', 5, w.noOverlay ? 'No text, logos or graphics in the image — the frame stands alone.' : `Leave clean space for copy: ${w.safeZones}. Do not render any lettering in the image; copy is added afterwards as live text.`, w.noOverlay ? 'No text or graphics in the image.' : `Copy space: ${w.safeZones.split(';')[0]}. No lettering in the image.`, true);
  add('job', 'Marketing job', 6, `The image should ${w.purpose}; viewer: ${w.audience}.`, `Goal: ${w.purpose}.`);
  for (const [i, n] of w.notes.entries()) add('note' + i, 'Customer direction', 6, n, n, true);
  add('palette', 'Brand palette', 7, `Palette: ${w.palette.join(', ')}${w.brandApplied ? ' (customer brand kit)' : ''}; use as dominant/secondary/accent, not as a tint over everything.`, `Palette: ${w.palette.slice(0, 3).join(', ')}.`);
  if (d.mood) add('mood', 'Mood', 8, `Mood: ${d.mood}.`, `Mood: ${truncateWords(d.mood, 60)}.`);
  add('style', 'Style', 9, `Style: ${w.style}.`, `Style: ${w.style.split(/[,;]/)[0]}.`);
  if (w.lighting && kind !== 'design-brief') add('lighting', 'Lighting', 10, `Lighting: ${w.lighting}`, `Lighting: ${truncateWords(w.lighting.split(/[.,]/)[0]!, 90)}.`);
  if (w.wardrobe) add('wardrobe', 'Wardrobe', 11, `Wardrobe (only if a person appears): ${w.wardrobe}.`, `Wardrobe: ${truncateWords(w.wardrobe, 70)}.`);
  if (kind === 'video') add('motion', 'Motion', 4, `Motion: a single continuous 5–8 second take; ${d.pose === 'none' ? 'slow push-in on the arrangement, natural light shift' : 'subtle natural movement — ' + (w.action || 'a breath, a glance, a small gesture')}; camera steady or gentle push-in; no cuts, no on-screen text.`, 'Motion: one steady 5–8 s take, subtle natural movement, no cuts.', true);
  add('negatives', 'Avoid', 12, `Avoid: ${s.negative_constraints.join('; ')}.`, `Avoid: ${s.negative_constraints.slice(0, 2).join('; ')}.`);
  add('output', 'Output', 13, `Output: ${w.width}×${w.height} (${w.aspect}).`, `${w.aspect}.`, true);
  return seg.sort((a, b) => a.priority - b.priority);
}

// ---------------------------------------------------------------- step: provider adapters (syntax + limits LAST)
function render(provider: ProviderKey, parts: Array<{ s: Segment; text: string }>, w: WorkingScene): string {
  const cfg = PROVIDERS[provider]; const body = parts.filter(p => p.s.key !== 'output' && p.s.key !== 'negatives');
  const neg = parts.find(p => p.s.key === 'negatives')?.text.replace(/^Avoid:\s*/, '').replace(/\.$/, '') ?? '';
  switch (provider) {
    case 'claude': return `Design this visual as an editable HTML/CSS/SVG artboard.\n` + parts.map(p => `${p.s.label.toUpperCase()}: ${p.text.replace(/^[A-Za-z ()’]+:\s*/, m => (p.s.key === 'asset' || p.s.key === 'subject' ? m : ''))}`).join('\n');
    case 'mj': return body.map(p => p.text.replace(/^(Framing|Setting|Style|Mood|Palette|Lighting|Wardrobe[^:]*|Goal|Props|Copy space|Motion):\s*/i, '').replace(/\.\s*$/, '').replace(/\.\s+/g, ', ')).join(', ') + ` --ar ${w.aspect.replace(/[^0-9:.]/g, '')} --style raw` + (neg ? ` --no ${neg.split(';').slice(0, 3).map(x => x.trim().replace(/^no\s+/i, '').toLowerCase()).join(', ')}` : '');
    case 'sdxl': return body.map(p => p.text.replace(/\.\s*$/, '').replace(/\.\s+/g, ', ')).join(', ') + `, ${w.aspect} aspect ratio.` + (neg ? ` Negative: ${neg.toLowerCase()}.` : '');
    case 'sora': return `Video brief. ` + body.map(p => p.text).join(' ') + (neg ? ` Avoid: ${neg}.` : '') + ` ${w.aspect}, ${w.width}×${w.height}.`;
    case 'ideogram': return body.map(p => p.text).join(' ') + ` Text in image: none (copy is added afterwards). Aspect ratio ${w.aspect}.` + (neg ? ` Avoid: ${neg}.` : '');
    case 'firefly': return `Content type: ${/realistic|photo/.test(w.base.render_style) ? 'Photo' : 'Graphic'}. ` + body.map(p => p.text).join(' ') + ` Aspect ratio ${w.aspect}.` + (neg ? ` Avoid: ${neg}.` : '');
    case 'flux': { // composition-first prose; avoidances folded into the description rather than a separate negative field
      const order = ['framing', 'subject', 'setting']; const first = order.map(k => body.find(p => p.s.key === k)).filter((x): x is { s: Segment; text: string } => !!x); const rest = body.filter(p => !order.includes(p.s.key));
      return [...first, ...rest].map(p => p.text).join(' ') + (neg ? ` Keep the image free of: ${neg.toLowerCase()}.` : '') + ` ${w.aspect} composition, ${w.width}×${w.height}.`; }
    case 'imagen': { const style = body.find(p => p.s.key === 'style'); return (style ? style.text.replace(/^Style:\s*/, 'A ').replace(/\.$/, '') + ' image. ' : '') + body.filter(p => p.s.key !== 'style').map(p => p.text).join(' ') + (neg ? ` Do not include: ${neg.toLowerCase()}.` : '') + ` Aspect ratio: ${w.aspect}.`; }
    case 'leonardo': return `Prompt: ${body.map(p => p.text).join(' ')}` + (neg ? `\nNegative prompt: ${neg.toLowerCase()}` : '') + `\nDimensions: ${w.width}×${w.height} (${w.aspect})`;
    default: return (cfg.kind === 'image' && provider === 'chatgpt' ? 'Create an image. ' : '') + body.map(p => p.text).join(' ') + (neg ? ` Avoid: ${neg}.` : '') + ` Output ${w.width}×${w.height} (${w.aspect}).`;
  }
}

export function compileProviderSpecificInstructions(w: WorkingScene, provider: ProviderKey): { prompt: string; kept: string[]; shortened: string[]; dropped: string[] } {
  const cfg = PROVIDERS[provider]; const segs = buildSegments(w, cfg.kind);
  const state = segs.map(s => ({ s, mode: 'full' as 'full' | 'short' | 'drop' }));
  const build = (): string => render(provider, state.filter(x => x.mode !== 'drop').map(x => ({ s: x.s, text: x.mode === 'full' ? x.s.full : x.s.short })), w);
  let out = build();
  // 1) shorten from the least important upward; 2) drop non-critical from the least important upward; critical segments only ever shorten.
  for (const phase of ['short', 'drop'] as const) {
    for (let i = state.length - 1; i >= 0 && out.length > cfg.budget; i--) {
      const st = state[i]!; if (phase === 'drop' && st.s.critical) continue; if (st.mode === 'drop') continue;
      st.mode = phase; out = build();
    }
  }
  return { prompt: out, kept: state.filter(x => x.mode === 'full').map(x => x.s.key), shortened: state.filter(x => x.mode === 'short').map(x => x.s.key), dropped: state.filter(x => x.mode === 'drop').map(x => x.s.key) };
}

// ---------------------------------------------------------------- step: capability + length + brief + provenance
export function compileScene(scene: CanonicalScene, provider: ProviderKey, ctx: { brand?: BrandContext; overrides?: UserOverrides } = {}): CompiledPrompt {
  if (!(provider in PROVIDERS)) throw new Error(`Unknown provider “${provider}”`);
  let w = deriveDistinctSceneSpec(scene);
  w = mergeWorkspaceBrandContext(w, ctx.brand);
  w = applyUserOverrides(w, ctx.overrides);
  w = validateSceneInvariants(w);
  const cfg = PROVIDERS[provider];
  const { prompt, kept, shortened, dropped } = compileProviderSpecificInstructions(w, provider);
  const warnings = [...w.warnings];
  if (prompt.length > cfg.budget) warnings.push(`Prompt is ${prompt.length} characters; ${cfg.label} works best under ${cfg.budget}. All scene-critical detail was kept.`);
  if (cfg.kind === 'video') warnings.push('This is a video brief. Prompt Studio does not generate video; paste it into a video tool you are licensed to use.');
  if (/\{[a-zA-Z_]+\}/.test(prompt)) warnings.push('Unresolved placeholder detected in compiled prompt.');
  const hay = norm(prompt); const anchors = sceneAnchors(w);
  const present = anchors.filter(a => hay.includes(norm(a.needle))).map(a => a.name), missing = anchors.filter(a => !hay.includes(norm(a.needle))).map(a => a.name);
  if (missing.length) throw new SceneInvariantError(scene.id, missing.map(m => `anchor “${m}” lost during compilation for ${provider}`));
  const brief = buildSegments(w, 'design-brief').map(s => `${s.label}: ${s.full.replace(/^[A-Za-z ()’]+:\s*/, '')}`).join('\n') + `\nOriginal design principle: ${scene.design_principle.replace(/_/g, ' ')}\nOriginal conversion intent: ${scene.conversion_intent.replace(/_/g, ' ')}`;
  return {
    sceneId: scene.id, provider, kind: cfg.kind, prompt, length: prompt.length, budget: cfg.budget, segmentsKept: kept, segmentsShortened: shortened, segmentsDropped: dropped,
    anchorsPresent: present, anchorsMissing: missing, warnings, changes: w.changes, creativeBrief: brief, originalPrompt: scene.original_platform_prompts[provider],
    provenance: { sceneId: scene.id, sourceVersion: scene.source_version, sourceFingerprint: scene.provenance.canonical_sha256, compilerVersion: PIPELINE_VERSION, brandApplied: w.brandApplied, conceptLocked: w.conceptLocked, overridesApplied: [...new Set(w.applied)] },
  };
}

/** Word-set Jaccard similarity — a cheap *signal* used by tests; never the sole proof of distinctness. */
export function jaccard(a: string, b: string): number {
  const A = new Set(norm(a).split(' ').filter(x => x.length > 2)), B = new Set(norm(b).split(' ').filter(x => x.length > 2));
  let inter = 0; for (const x of A) if (B.has(x)) inter++;
  return inter / Math.max(1, A.size + B.size - inter);
}
