/**
 * Creative-DNA extraction: turns one verbatim source record into typed scene facts.
 * Pure + deterministic. Every output traces to named source fields (documented inline),
 * so the same DNA drives the prompt compiler, the VisualSceneSpec planner and the QA ledger.
 */
import type { OriginalScene, SceneDNA, SubjectKind, Zone } from '../catalog/schema.ts';
import { clamp, hash53, rng, round } from '../shared/util.ts';

// ---------------------------------------------------------------- colour words (source palettes without hex)
const COLOUR_WORDS: Array<[RegExp, string]> = [
  [/tiktok (red|pink)/, '#FE2C55'], [/tiktok (cyan|aqua)/, '#25F4EE'], [/youtube red/, '#FF0000'], [/linkedin blue/, '#0A66C2'],
  [/instagram|ig[- ]gradient/, '#DD2A7B'], [/pinterest red/, '#E60023'], [/facebook blue/, '#1877F2'], [/twitter|x[- ]black/, '#14171A'],
  [/automation orange|bright orange|orange/, '#F2742B'], [/navy/, '#1B2A49'], [/crisp white|pure white|white/, '#FFFFFF'],
  [/tomato/, '#E4572E'], [/fresh greens?|leaf green|herb green/, '#6BA547'], [/sage/, '#A8B5A0'], [/forest|deep green|emerald/, '#1F5F4A'],
  [/olive/, '#7A7B3C'], [/mint/, '#A8E0C4'], [/teal/, '#1E8F8B'], [/turquoise|aqua/, '#3CC4C0'], [/sky blue|light blue/, '#8EC5E8'],
  [/cobalt|electric blue|royal blue/, '#2450D8'], [/blue/, '#2F6FB5'], [/indigo/, '#3A3F8F'], [/violet|purple|amethyst/, '#7B4FB5'],
  [/lavender|lilac/, '#C7B8E6'], [/plum|aubergine/, '#5B2A4E'], [/magenta|fuchsia/, '#C8327D'], [/hot pink/, '#F0478C'],
  [/blush|soft pink|rose[- ]?pink|dusty rose|rose/, '#E8B4B8'], [/pink/, '#F29CB4'], [/coral/, '#E8744F'], [/peach|apricot/, '#F7C59F'],
  [/terracotta|clay|rust/, '#C4633E'], [/burgundy|wine|oxblood|maroon/, '#6E1F2B'], [/crimson|scarlet|red/, '#D8343A'],
  [/mustard|ochre/, '#D9A520'], [/gold|brass|honey|amber/, '#C9A14A'], [/yellow|lemon|sunshine/, '#F5CF47'],
  [/champagne/, '#EAD9B5'], [/cream|ivory|ecru|off[- ]white|paper/, '#F4EDE0'], [/sand|beige|oat|linen|stone|taupe/, '#D8C9B0'],
  [/camel|tan|caramel/, '#B88B5A'], [/chocolate|espresso|walnut|brown|wood/, '#5A3E2B'], [/copper|bronze/, '#B26B3F'],
  [/charcoal|graphite|slate|ink/, '#2B2F36'], [/silver|steel|chrome/, '#B8BEC6'], [/grey|gray|concrete/, '#8C9097'],
  [/jet|midnight|deep contrast|black/, '#111111'], [/lime|neon green/, '#9BE05A'], [/green/, '#3E9B5F'],
  [/signature accent|brand accent|accent/, '#E0A030'],
];
const NICHE_HUES = [8, 22, 36, 48, 86, 140, 162, 178, 196, 212, 232, 258, 284, 318, 340];

function hslToHex(h: number, s: number, l: number): string {
  const a = s * Math.min(l, 1 - l);
  const f = (n: number): string => { const k = (n + h / 30) % 12; const c = l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); return Math.round(255 * c).toString(16).padStart(2, '0'); };
  return ('#' + f(0) + f(8) + f(4)).toUpperCase();
}

export function extractPalette(o: OriginalScene): { palette: string[]; source: SceneDNA['paletteSource'] } {
  const hexes = [...new Set((o.palette.match(/#[0-9A-Fa-f]{6}/g) ?? []).map(h => h.toUpperCase()))];
  if (hexes.length >= 3) return { palette: hexes.slice(0, 5), source: 'source-hex' };
  // colour words: prefer the niche bias clause, then the whole palette text
  const text = o.palette.toLowerCase();
  const bias = text.split('niche palette bias:')[1] ?? '';
  const out = [...hexes];
  for (const chunk of [bias, text]) {
    for (const part of chunk.split(/\+|,|;| and /)) {
      const p = part.trim(); if (!p) continue;
      const hit = COLOUR_WORDS.find(([re]) => re.test(p));
      if (hit && !out.includes(hit[1])) out.push(hit[1]);
    }
  }
  if (out.length >= 3) return { palette: out.slice(0, 5), source: hexes.length ? 'source-hex' : 'source-colour-words' };
  // niche-derived (deterministic, documented): a calm triad seeded by the niche name
  const hue = NICHE_HUES[hash53(o.niche) % NICHE_HUES.length] as number;
  const derived = [hslToHex(hue, 0.42, 0.34), hslToHex((hue + 28) % 360, 0.55, 0.62), '#F4EFE6', hslToHex((hue + 180) % 360, 0.5, 0.55)];
  for (const d of derived) if (out.length < 4 && !out.includes(d)) out.push(d);
  return { palette: out, source: out.length > derived.length - 1 && hexes.length + 0 === 0 && out.length === derived.length ? 'niche-derived' : 'source-colour-words' };
}

// ---------------------------------------------------------------- environment / props / mood
const ENV_RULES: Array<[string, RegExp]> = [
  ['event-prep-table', /event-prep|letterpress|stationery/],
  ['product-studio', /product photography studio|seamless backdrop, lighting modifiers/],
  ['photo-studio', /photo studio|seamless paper|strobe|softbox/],
  ['salon', /nail|salon|manicure/],
  ['stage', /stage|keynote|conference|auditorium|podium/],
  ['podcast-studio', /podcast|acoustic|recording booth/],
  ['music-studio', /music studio|instruments|recording equipment/],
  ['youtube-studio', /youtube studio|camera \+ lights|course studio|ready-to-record|video call setup/],
  ['creator-studio', /creator|ring[- ]light|phone-on-tripod|tiktok|ig-grade|member/],
  ['fitness-studio', /fitness|gym|training space|dumbbell|performance training|sports/],
  ['yoga-studio', /yoga|meditation|breath|wellness studio|health studio/],
  ['kitchen', /kitchen|cooking|produce|recipe|food/],
  ['bedroom', /bedroom|bedside|sleep|boudoir/],
  ['sacred-space', /sacred|altar|tarot|crystals|candle|contemplative/],
  ['coaching-room', /two chairs|two armchairs|armchair|couples|counselling|therapy|mediation|1:1 session|breakthrough chair|conversation-friendly|intimate/],
  ['living-room', /living room|family home|cosy|cozy|home interior|luxury home|luxe interior|calm uncluttered|restorative interior|warm welcoming interior/],
  ['library-study', /library|study with|stacked books|writer's desk|writing desk|reading space|study desk/],
  ['boardroom', /boardroom|leadership-grade|executive office|strategy room|review session|review meeting|round table/],
  ['design-studio', /brand studio|designer studio|mood-?board|creative agency|ad-agency|artist|workshop|art /],
  ['artist-studio', /paint|canvas|artist studio/],
  ['rehearsal-studio', /rehearsal|mirror wall|full-length mirror|mirror-implied|mirror/],
  ['tech-office', /multi-monitor|developer|code|tech|no-code|automation flows|ai dashboards|trading/],
  ['marketing-workspace', /marketing workspace|analytics|funnel|seo|email-platform|launch war-room|campaign|content workspace|sales office|dashboard/],
  ['workshop-room', /whiteboard|training room|workshop floor|collaborative|kanban|sticky|accountability board|vision-board|habit-tracker|process/],
  ['financial-office', /financial|wealth|advisor|bills|budget|spreadsheet|debt/],
  ['cafe', /caf[ée]|rooftop|bar|restaurant/],
  ['outdoor', /outdoor|park|garden|beach|nature|trail|retreat|destination|travel/],
  ['magazine-backdrop', /magazine|editorial-feature|considered backdrop|branded backdrop/],
  ['home-office', /home office|telehealth|minimal(ist)? (modern )?desk|planner spread/],
  ['open-window-space', /open-window|high-ceiling|light streaming|threshold/],
  ['office', /office|co-working|workspace|studio|branded environment|professional/],
];
/** Source "lighting variants" that are really *setting* variants (e.g. “· Garden Setting”) move the scene, so they pick the environment. */
export const SETTING_VARIANTS: Record<string, string> = { 'Garden Setting': 'outdoor', 'City Skyline': 'boardroom', 'Library Backdrop': 'library-study', 'Coastal Edge': 'outdoor', 'Mountain Light': 'outdoor', Boardroom: 'boardroom', 'Hotel Lobby': 'living-room', Atelier: 'artist-studio', 'Studio Backdrop': 'photo-studio', 'Wood-Panelled Office': 'financial-office' };
export function classifyEnvironment(text: string): string {
  const t = text.toLowerCase();
  for (const [kind, re] of ENV_RULES) if (re.test(t)) return kind;
  return 'office';
}

const first = (...ms: Array<RegExpMatchArray | null>): string => { for (const m of ms) if (m?.[1]) return m[1].trim(); return ''; };

function extractEnvironment(o: OriginalScene): string {
  const c = o.v3.platforms.chatgpt, s = o.scenario;
  return first(
    c.match(/Setting: (.+?)\. (?:Visible props|[A-Z])/),
    s.match(/environment is (.+?); props/),
    s.match(/Captured in (.+?)\. /),
    s.match(/ in (.+?), engaging/),
    s.match(/within (.+?), engaged/),
    s.match(/Background treatment: (.+?)\. /),
    o.industryContext.match(/Use context: (.+?)\. /),
  ).replace(/\{[a-zA-Z_]+\}/g, '').replace(/\s{2,}/g, ' ').trim();
}
function extractProps(o: OriginalScene): string[] {
  const c = o.v3.platforms.chatgpt, s = o.scenario;
  const raw = first(
    c.match(/Visible props: (.+?)\. /),
    s.match(/props in frame include (.+?); the mood/),
    s.match(/ground the scene: (.+?), (?:soft|warm|golden|bright|cool|natural|moody|crisp|gentle)/),
    s.match(/interacting with (.+?) naturally present/),
    s.match(/Visible [A-Za-z /-]+-native elements: (.+?)\. /),
    o.industryContext.match(/Native props\/elements that should appear: (.+?)\. /),
  );
  const out: string[] = [];
  for (const p of raw.split(/,\s*(?![^()]*\))/)) {
    const t = p.replace(/\{[a-zA-Z_]+\}/g, '').trim();
    if (t && !out.some(x => x.toLowerCase() === t.toLowerCase())) out.push(t);
  }
  return out.slice(0, 6);
}
function extractMood(o: OriginalScene): string {
  const s = o.scenario;
  return first(
    s.match(/mood register is (.+?)\.?$/),
    s.match(/Subject demonstrates (.+?) through/),
    s.match(/Aesthetic register: (.+?)\. /),
    s.match(/, (.+?) mood register/),
    o.industryContext.match(/Aesthetic register: (.+?)\. /),
  ).slice(0, 140);
}

// ---------------------------------------------------------------- subject kind, framing, pose
function classifySubject(o: OriginalScene): SubjectKind {
  const f = o.framing.toLowerCase(), p = o.poseDirection.toLowerCase(), a = o.asset, sz = o.safeZones.toLowerCase(), sc = o.scenario.toLowerCase();
  if (/backdrop only|no subject, repeating brand pattern/.test(p + ' ' + f)) return 'pattern';
  if (a === 'Stock/Social Backgrounds' || /texture shot|no focal point/.test(sc + sz)) return 'texture';
  if (a === 'Stock/Product Mockups') return 'devices';
  if (a === 'Stock/Workspaces' || /no subject visible/.test(sz)) return 'environment-only';
  if (/menu card|table-card|thank-you card/.test(f)) return 'print-typographic';
  if (/flat-lay|top-down/.test(f) && !/or subject|subject holding/.test(f) || /flat-lay arrangement|food-led/.test(p)) return 'flat-lay';
  if (/n\/a — product|collection arrangement/.test(p) || /product detail 80%|product centred/.test(f)) return 'product';
  if (/hands sharp|hands-only|hands mid-lift|hand mid-action|natural product use/.test(p) || /hand 60%|hands \+ packaging/.test(f)) return 'hands';
  if (/wide group|all faces|group arrangement/.test(f + p)) return 'group';
  if (/fellow panellists|panel context/.test(f)) return 'group';
  if (/two chairs|second chair|both implied seats|both chair/.test(f)) return 'two-people';
  return 'person';
}

const SECONDARY: Array<[string, RegExp]> = [
  ['framework', /framework/], ['library', /library/], ['toolkit', /toolkit/], ['documents', /document/], ['second chair', /second chair|two chairs|both chair/],
  ['whiteboard', /whiteboard|board/], ['audience', /audience/], ['programme element', /programme element|programme materials/],
  ['retreat venue', /retreat venue|venue/], ['bundle stack', /bundle/], ['bonus stack', /bonus/], ['curriculum', /curriculum/],
  ['monitors and sticky notes', /monitors/], ['data visualisation', /data visualisation/], ['audit tool', /audit tool/], ['result', /result/],
  ['gear', /gear/], ['camera', /subject \+ camera|behind-camera/], ['tutorial subject', /tutorial-subject/], ['module cue object', /module-cue|single object/],
  ['lesson cue object', /lesson-cue/], ['book and tea', /book \+ tea/], ['boardroom', /boardroom/], ['mission imagery', /mission imagery/],
  ['event details', /event details|event name|date \+ venue/], ['quote zone', /quote/], ['cta zone', /cta-zone|cta zone/], ['copy zone', /copy zone|body copy/],
  ['headline space', /headline/], ['masthead', /masthead/], ['title', /title/], ['show name', /show name/], ['packaging', /packaging/],
  ['product', /product|item/], ['destination', /destination/], ['food', /food/], ['community mark', /community-mark|community-feel/],
  ['brand element', /brand-element|brand mark|brand pattern/], ['mug or laptop', /mug or laptop|laptop edge/], ['client environment', /client environment/],
  ['signature object', /signature object/], ['number', /large number/], ['course list', /course list/], ['environment', /environment/],
];

function parseFraming(o: OriginalScene, kind: SubjectKind): SceneDNA['framing'] {
  const f = o.framing.toLowerCase();
  const [aw, ah] = o.aspect.split(':').map(Number) as [number, number];
  const ratio = (aw || 16) / (ah || 9);
  let crop: SceneDNA['framing']['crop'] =
    /top-down|flat-lay/.test(f) ? 'top-down'
    : /tight|80% of frame|reaction crop|detail crop/.test(f) ? 'tight'
    : /full or three-quarter body/.test(f) ? 'full-body'
    : /head-and-shoulders|head and shoulders|close-medium|medium[- ]close|intimate close/.test(f) ? 'close'
    : /medium-wide/.test(f) ? 'medium-wide'
    : /\bwide\b|environmental|16:5|banner|spread/.test(f) ? 'wide'
    : /medium|portrait/.test(f) ? 'medium'
    : ratio >= 1.7 ? 'wide' : 'medium';
  if (kind === 'flat-lay') crop = 'top-down';
  const shareM = f.match(/(?:subject|face|hand|member|product detail|product)\s*(?:\+ [a-z ]+?)?\s*(\d{2})(?:-(\d{2}))?%/) ?? f.match(/(\d{2})(?:-(\d{2}))?% of frame/);
  const defaults: Record<SceneDNA['framing']['crop'], number> = { tight: 0.8, close: 0.65, medium: 0.52, 'medium-wide': 0.46, wide: 0.36, 'top-down': 0.6, 'full-body': 0.72 };
  let share = shareM ? (Number(shareM[1]) + Number(shareM[2] ?? shareM[1])) / 200 : defaults[crop];
  if (/50\/50/.test(f)) share = 0.5;
  const r = rng('side:' + o.id);
  let side: SceneDNA['framing']['subjectSide'] =
    /occupies edges/.test(f) ? 'edges'
    : /subject right|right third|on right|40% right|right two-fifths|subject \d+% right/.test(f) ? 'right'
    : /subject left|left third|left page|subject \d+% left|40% left/.test(f) ? 'left'
    : /subject upper|upper two-thirds|upper third/.test(f) ? 'top'
    : /cent(re|er)(d|ed)?\b|symmetr/.test(f) ? 'centre'
    : 'none';
  if (side === 'none') {
    const dp = o.designPrinciple;
    side = dp === 'centered_focal' || dp === 'symmetric_balanced' || dp === 'tight_crop' ? 'centre' : r() < 0.5 ? 'left' : 'right';
    // respect explicit copy-space direction in the safe zones
    const sz = o.safeZones.toLowerCase();
    if (/copy space on the right|right (one-)?third|right two-thirds|right half|camera-right for headline/.test(sz + f)) side = 'left';
    else if (/left (one-)?third|left two-fifths|left 40%|left two-thirds|left negative space/.test(sz + f)) side = 'right';
  }
  if (kind === 'pattern' || kind === 'texture' || kind === 'environment-only' || kind === 'devices') side = 'none';
  let secondary = '', secondaryShare = 0;
  const afterSubject = f.replace(/^[^,]*subject[^,]*,?/, ' ');
  for (const [label, re] of SECONDARY) {
    if (re.test(afterSubject) || (label !== 'environment' && label !== 'title' && re.test(f) && !/subject/.test(label))) {
      secondary = label;
      const m = f.match(new RegExp('(?:' + re.source + ')[a-z +-]*?(\\d{2})%')) ?? f.match(new RegExp('(\\d{2})% (?:' + re.source + ')'));
      secondaryShare = m ? Number(m[1]) / 100 : 0;
      break;
    }
  }
  return { raw: o.framing, crop, subjectShare: round(clamp(share, 0.2, 0.9)), subjectSide: side, secondary, secondaryShare: round(secondaryShare) };
}

function classifyPose(o: OriginalScene, kind: SubjectKind): string {
  const p = (o.poseDirection + ' | ' + o.framing).toLowerCase();
  if (kind === 'hands') return 'hands';
  if (kind === 'group') return 'group';
  if (kind !== 'person' && kind !== 'two-people' && kind !== 'print-typographic') return 'none';
  if (/behind mic|headphones on/.test(p)) return 'behind-mic';
  if (/viewfinder|behind-camera/.test(p)) return 'behind-camera';
  if (/mic in hand|stage register|keynote|implied audience/.test(p)) return 'stage-mic';
  if (/marker in hand|at whiteboard|gesturing at board/.test(p)) return 'board-marker';
  if (/hand at framework|presenting curriculum|toward result|presenting findings|presenting case-study/.test(p)) return 'framework-point';
  if (/open-arm|welcome|wave|open-palm|palm-open|announcement-gesture|generous/.test(p)) return 'welcome-open';
  if (/laugh|celebrat|joy|mid-celebration/.test(p)) return 'celebrate';
  if (/toolkit|toward bonus|toward bundle|toward recommendation|toward cta|hand on shelf|on or near gear|holding signature|demonstration gesture/.test(p)) return 'presenting-item';
  if (/seated|knees angled|leaned forward toward implied client|hot-seat|two chairs/.test(p)) return 'seated-client';
  if (/mug in hand|leaned slightly toward camera|leaning toward camera/.test(p)) return 'lean-mug';
  if (/reading|book \+ tea/.test(p)) return 'reading';
  if (/settled at desk|hand at keyboard|mid-annotation|leaned on forearm|at desk|laptop edge/.test(p)) return 'desk-settled';
  if (/eyes lifted|off-camera|horizon|contemplative|profile/.test(p)) return 'contemplative';
  if (/fashion|on-model|outfit/.test(p)) return 'fashion';
  if (/mid-statement|hook-energy|mouth open|animated|unusual pose|single committed expression/.test(p)) return 'hook-energy';
  if (/unposed|mid-action|natural activity|documentary/.test(p)) return 'mid-action';
  if (/direct|head-and-shoulders|jaw set|chin|gaze steady|authority|portrait/.test(p)) return 'portrait-direct';
  return 'standing-relaxed';
}

// ---------------------------------------------------------------- safe zones
function zoneRole(purpose: string): string {
  const p = purpose.toLowerCase();
  if (/play-button|ui\b|username|caption preview|duration overlay|subscribe|watch-next|platform ui|time stamp|end-screen/.test(p)) return 'ui';
  if (/masthead/.test(p)) return 'masthead';
  if (/quote|testimonial/.test(p)) return 'quote';
  if (/number\b/.test(p) && !/episode|module|cohort|slide/.test(p)) return 'number';
  if (/cta|button|rsvp|booking|download/.test(p) && !/headline/.test(p)) return 'cta';
  if (/gratitude|welcome message|mission statement|message/.test(p)) return 'message';
  if (/statement|headline/.test(p)) return 'headline';
  if (/courses|course list|curriculum/.test(p)) return 'list';
  if (/body copy/.test(p)) return 'body';
  if (/brand mark|logo|foil mark|event mark|sponsor/.test(p)) return 'logo';
  if (/signature/.test(p)) return 'signature';
  if (/subject|materials|food|standing area|image|environmental/.test(p) && !/name|title|headline/.test(p)) return 'visual';
  if (/credential|author|editor|byline|organisation|caption|credit|details|date|venue|price|sizes|duration|difficulty|outcomes|reason|tips|year/.test(p) && !/name \+|title|headline/.test(p)) return 'details';
  return 'headline';
}

/** Parse the source `safeZones` sentence into artboard-relative rectangles (percent). */
export function parseZones(safeZones: string, W: number, H: number): { zones: Zone[]; noOverlay: boolean } {
  const zones: Zone[] = [];
  let noOverlay = false;
  const add = (x: number, y: number, w: number, h: number, purpose: string): void => {
    const pz = purpose.replace(/^(clean|clear|reserved|kept legible)\s*/i, '').replace(/^(for|is|:)\s+/i, '').replace(/\s*(overlay|in elegant typography)\s*$/i, '').trim() || 'copy';
    zones.push({ x: round(clamp(x, 0, 100)), y: round(clamp(y, 0, 100)), width: round(clamp(w, 2, 100)), height: round(clamp(h, 2, 100)), purpose: pz.slice(0, 160), role: zoneRole(pz) });
  };
  const frac = (t: string): number | null =>
    /two-thirds/.test(t) ? 66.7 : /two-fifths/.test(t) ? 40 : /(one-)?third/.test(t) ? 33.3 : /half/.test(t) ? 50 : /quarter/.test(t) ? 25 : null;

  for (const clauseRaw of safeZones.split(/;\s*/)) {
    const clause = clauseRaw.trim(); const c = clause.toLowerCase();
    if (!c) continue;
    if (/no (specific )?overlay|caption-driven|stands alone|overlay optional|print-safe margins|blank screens|per platform ui overlap/.test(c)) { if (/no (specific )?overlay|stands alone/.test(c)) noOverlay = true; continue; }
    const purposeOf = (re: RegExp): string => { const m = clause.match(re); return (m?.[1] ?? clause).trim(); };

    // exact corner boxes e.g. "Bottom-right 200x80px for YouTube duration overlay"
    let m = c.match(/(top|bottom)-(left|right) (\d+)x(\d+)(?:px)?/);
    if (m) { const w = Number(m[3]) / W * 100, h = Number(m[4]) / H * 100; add(m[2] === 'right' ? 100 - w - 2 : 2, m[1] === 'bottom' ? 100 - h - 3 : 3, w, h, purposeOf(/(?:px|\d) (?:for )?(.+)$/i)); continue; }
    if (/top \+ bottom/.test(c)) { add(0, 0, 100, 16, 'before label'); add(0, 80, 100, 20, 'after label + transformation copy'); continue; }
    if (/subject middle-third only/.test(c)) { add(0, 20, 30, 60, 'YouTube watch-next card'); add(70, 20, 30, 60, 'YouTube subscribe card'); continue; }
    if (/edges (\d+)px/.test(c)) continue; // platform UI margin, enforced by guides
    if (/copy space on the right half/.test(c)) { add(50, 12, 46, 76, 'headline copy space'); continue; }
    if (/negative space for overlaid blog title/.test(c)) { add(6, 22, 52, 56, 'blog title'); continue; }
    if (/designed for overlaid typography/.test(c)) { add(14, 26, 72, 48, 'overlaid quote typography'); continue; }
    if (/corner/.test(c)) { add(68, 80, 28, 15, purposeOf(/corner (?:for )?(.+)$/i).replace(/^treatment.*$/, 'brand mark')); continue; }
    if (/centre vertical zone \(gutter\)/.test(c)) continue;
    if (/right page two-thirds/.test(c)) { add(56, 12, 38, 76, 'body copy'); continue; }

    // generic "<region> <size> <purpose>" — several may appear in one clause ("Top 20% for X; ...")
    const re = /(?:reserve |reserved )?(top|bottom|left|right or bottom|right|centre|center|middle)\s*(\d+)?\s*(px|%)?\s*((?:one-)?third|two-thirds|two-fifths|half|quarter)?/g;
    let hit = false; let mm: RegExpExecArray | null;
    while ((mm = re.exec(c))) {
      let region = mm[1] as string; const num = mm[2] ? Number(mm[2]) : null; const unit = mm[3]; const fr = mm[4] ? frac(mm[4]) : null;
      if (num === null && fr === null && !/^(centre|center|middle)$/.test(region)) continue;
      if (num === null && fr === null && !/^\s*(clear|reserved)\b/.test(c.slice(mm.index + mm[0].length))) continue;
      if (/subject\s*$/.test(c.slice(0, mm.index)) || /^\s*(subject|image|environmental)\b/.test(c.slice(mm.index + mm[0].length)) && !/name|title|headline/.test(c.slice(mm.index + mm[0].length, mm.index + mm[0].length + 40))) { if (/^\s*(subject|image|environmental)\b/.test(c.slice(mm.index + mm[0].length))) { /* a visual band, recorded as such */ } else continue; }
      if (region === 'right or bottom') region = W >= H ? 'right' : 'bottom';
      const rest = clause.slice(mm.index + mm[0].length);
      const purpose = (rest.match(/^\s*(?:OR bottom \d+% )?(?:\([^)]*\)\s*)?(?:clean |clear |reserved |kept )?(?:for\s+)?([^;,]+?)(?:;|,| — |$)/i)?.[1] ?? '').trim();
      const sizeV = num !== null ? (unit === 'px' ? num / H * 100 : num) : fr;
      const sizeH = num !== null ? (unit === 'px' ? num / W * 100 : num) : fr;
      if (region === 'top') add(0, 0, 100, sizeV ?? 20, purpose);
      else if (region === 'bottom') add(0, 100 - (sizeV ?? 20), 100, sizeV ?? 20, purpose);
      else if (region === 'left') add(0, 0, sizeH ?? 33.3, 100, purpose);
      else if (region === 'right') add(100 - (sizeH ?? 33.3), 0, sizeH ?? 33.3, 100, purpose);
      else if (region === 'middle') add(0, (100 - (sizeV ?? 50)) / 2, 100, sizeV ?? 50, purpose);
      else { const s = sizeH ?? 60; add((100 - s) / 2, s >= 80 ? 8 : 28, s, s >= 80 ? 70 : 44, purpose); }
      hit = true;
      if (/ OR /.test(clause)) break;
    }
    if (!hit && /thumbnail|legible|readable|sharp|crop/.test(c)) continue; // legibility constraints, not zones
  }
  // de-duplicate identical rects, keep at most 4
  const seen = new Set<string>();
  const uniq = zones.filter(z => { const k = `${z.x}|${z.y}|${z.width}|${z.height}`; if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 4);
  return { zones: uniq, noOverlay: noOverlay && uniq.length === 0 };
}

// ---------------------------------------------------------------- main
export function parseDimensions(dim: string): { width: number; height: number } {
  const m = dim.match(/(\d+)\s*[×x]\s*(\d+)/);
  if (!m) throw new Error(`Unparseable dimensions "${dim}"`);
  return { width: Number(m[1]), height: Number(m[2]) };
}

export function splitName(o: OriginalScene): { assetLabel: string; promise: string } {
  const nicheRe = new RegExp('\\s+for\\s+' + o.niche.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&') + '\\s*$', 'i');
  const base = o.name.replace(nicheRe, '');
  const i = base.indexOf(':');
  const assetLabel = (i > 0 ? base.slice(0, i) : base).trim();
  const promise = (i > 0 ? base.slice(i + 1) : '').replace(/\s*·\s*[^·]+$/, m => m).trim();
  return { assetLabel, promise };
}

export function extractDNA(o: OriginalScene, idx: { baseScene: string; lighting: string }): SceneDNA {
  const { width, height } = parseDimensions(o.dimensions);
  const { assetLabel, promise } = splitName(o);
  const kind = classifySubject(o);
  const environment = extractEnvironment(o);
  const props = extractProps(o);
  const mood = extractMood(o);
  const framing = parseFraming(o, kind);
  const pose = classifyPose(o, kind);
  const { zones, noOverlay } = parseZones(o.safeZones, width, height);
  const { palette, source } = extractPalette(o);
  const sc = o.scenario;
  const pres = /\b(a|the) woman\b/i.test(sc) ? 'woman' : /\b(a|the) man\b/i.test(sc) ? 'man' : 'unspecified';
  const age = sc.match(/in their ((?:early|mid|late) [a-z]+)/i)?.[1] ?? '';
  const lightingMood = o.lightingSpec.match(/mood ([^.]+)\./)?.[1]?.trim() ?? '';

  const subject =
    kind === 'pattern' ? 'repeating brand pattern backdrop, no person'
    : kind === 'texture' ? 'textural surface with no focal point'
    : kind === 'devices' ? 'device mock-ups with blank screens'
    : kind === 'environment-only' ? 'the workspace itself, no person'
    : kind === 'flat-lay' ? 'top-down arrangement of objects'
    : kind === 'product' ? 'the product as hero'
    : kind === 'hands' ? 'hands in action'
    : kind === 'group' ? 'a group, every face readable'
    : kind === 'print-typographic' ? 'typography-led printed piece'
    : kind === 'two-people' ? 'the expert with a second seat for the client' : 'the expert, on-brand and present';
  const action = o.poseDirection && !/^Subject framed per|^N\/A/.test(o.poseDirection) ? o.poseDirection : (sc.match(/engag(?:ed|ing) [^—,.]+/)?.[0] ?? '');

  // distinctness anchors (3–7): genuine, visible, source-derived
  const anchors: string[] = [];
  const push = (s: string): void => { const t = s.trim(); if (t && !anchors.some(a => a.toLowerCase() === t.toLowerCase()) && anchors.length < 7) anchors.push(t.slice(0, 110)); };
  push(assetLabel);
  if (framing.secondary) push(framing.secondary + (framing.secondaryShare ? ` filling ~${Math.round(framing.secondaryShare * 100)}% of the frame` : ' visible in frame'));
  push(o.framing.split(',')[0] ?? '');
  for (const p of props.slice(0, 2)) push(p);
  if (environment) push(environment.split(',')[0] ?? '');
  if (zones[0]) push(`${zones[0].role} zone: ${zones[0].purpose}`);
  if (action) push(action.split(',')[0] ?? '');
  while (anchors.length < 3) push([o.asset, o.businessMoment.split(',')[0] ?? '', o.bg.replace(/_/g, ' ')][anchors.length] ?? o.id);

  return {
    assetLabel, promise, baseScene: idx.baseScene, subjectKind: kind, subject, action, environment,
    environmentKind: SETTING_VARIANTS[o.v3.lighting_variant] ?? classifyEnvironment(environment + ' ' + o.niche + ' ' + props.join(' ')),
    props, mood, framing, pose, poseRaw: o.poseDirection, zones, noOverlay, palette, paletteSource: source,
    lightingVariant: o.v3.lighting_variant || idx.lighting || 'Editorial', lightingMood,
    person: { presentation: pres, age, wardrobe: o.wardrobe },
    anchors, width, height,
  };
}
