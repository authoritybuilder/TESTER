/**
 * Asset pipeline: raw browser PNG → validated, optimised derivatives + QA metrics.
 * Node-only (sharp). Never fabricates output: every function works on real pixel buffers.
 */
import { createHash } from 'node:crypto';
import sharp from 'sharp';

export const sha256 = (b: Buffer | string): string => createHash('sha256').update(b).digest('hex');

export interface RasterStats { width: number; height: number; meanLuma: number; stdevLuma: number; distinctColours: number; blank: boolean; dhash: string; edgeDensity: number }

/** Decode a raster and measure it (proves the file decodes; flags blank frames; perceptual hash for duplicate signals). */
export async function measureRaster(buf: Buffer): Promise<RasterStats> {
  const img = sharp(buf); const meta = await img.metadata();
  if (!meta.width || !meta.height) throw new Error('Raster did not decode');
  const st = await img.clone().greyscale().stats(); const ch = st.channels[0]!;
  const small = await img.clone().resize(32, 32, { fit: 'fill' }).removeAlpha().raw().toBuffer();
  const colours = new Set<number>(); for (let i = 0; i < small.length; i += 3) colours.add(((small[i]! >> 3) << 10) | ((small[i + 1]! >> 3) << 5) | (small[i + 2]! >> 3));
  // dHash 9×8 greyscale
  const g = await img.clone().greyscale().resize(9, 8, { fit: 'fill' }).raw().toBuffer(); let bits = '';
  for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) bits += g[y * 9 + x]! > g[y * 9 + x + 1]! ? '1' : '0';
  const dhash = BigInt('0b' + bits).toString(16).padStart(16, '0');
  // edge density on 64×64 (how much structure the image has)
  const e = await img.clone().greyscale().resize(64, 64, { fit: 'fill' }).raw().toBuffer(); let edges = 0;
  for (let y = 0; y < 63; y++) for (let x = 0; x < 63; x++) if (Math.abs(e[y * 64 + x]! - e[y * 64 + x + 1]!) + Math.abs(e[y * 64 + x]! - e[(y + 1) * 64 + x]!) > 24) edges++;
  return { width: meta.width, height: meta.height, meanLuma: ch.mean, stdevLuma: ch.stdev, distinctColours: colours.size, blank: ch.stdev < 2.5 || colours.size < 3, dhash, edgeDensity: edges / (63 * 63) };
}
export function hamming(a: string, b: string): number { let x = BigInt('0x' + a) ^ BigInt('0x' + b); let c = 0; while (x) { c += Number(x & 1n); x >>= 1n; } return c; }

export async function toWebp(png: Buffer, opts: { width?: number; quality?: number } = {}): Promise<Buffer> {
  let p = sharp(png); if (opts.width) p = p.resize({ width: opts.width, withoutEnlargement: true });
  return p.webp({ quality: opts.quality ?? 82, effort: 4 }).toBuffer();
}
export async function toJpeg(png: Buffer, quality = 90, background = '#FFFFFF'): Promise<Buffer> { return sharp(png).flatten({ background }).jpeg({ quality, mozjpeg: true }).toBuffer(); }
export async function resizePng(png: Buffer, width: number): Promise<Buffer> { return sharp(png).resize({ width, withoutEnlargement: true }).png({ compressionLevel: 9 }).toBuffer(); }
/** Mean absolute pixel difference (0–255) between two rasters at a common small size — a similarity *signal*, not proof. */
export async function meanDiff(a: Buffer, b: Buffer): Promise<number> {
  const [x, y] = await Promise.all([a, b].map(v => sharp(v).resize(64, 64, { fit: 'fill' }).removeAlpha().raw().toBuffer()));
  let s = 0; for (let i = 0; i < x!.length; i++) s += Math.abs(x![i]! - y![i]!); return s / x!.length;
}
