/**
 * Artboard renderer: validated VisualSceneSpec → one isolated, script-free HTML document.
 * The exact same markup is (a) shown live in the editor inside a sandboxed iframe and
 * (b) rasterised by the Playwright render worker — so what the customer edits is what exports.
 */
import { escapeHtml } from '../shared/util.ts';
import { buildTone, renderLayer, type RenderCtx } from './layer-registry.ts';
import type { FontKey, VisualLayer, VisualSceneSpec } from './scene-schema.ts';

export interface FontFace { family: string; key: FontKey; weight: number; italic: boolean; file: string }
/** Bundled, licensed (SIL OFL 1.1) fonts — see public/fonts/LICENSES.md. */
export const FONT_FACES: FontFace[] = [
  ...[400, 500, 600, 700, 800].map(w => ({ family: 'Plus Jakarta Sans', key: 'jakarta' as const, weight: w, italic: false, file: `plus-jakarta-sans-latin-${w}-normal.woff2` })),
  ...[400, 600, 700, 900].map(w => ({ family: 'Fraunces', key: 'fraunces' as const, weight: w, italic: false, file: `fraunces-latin-${w}-normal.woff2` })),
  ...[400, 600].map(w => ({ family: 'Fraunces', key: 'fraunces' as const, weight: w, italic: true, file: `fraunces-latin-${w}-italic.woff2` })),
  { family: 'Anton', key: 'anton', weight: 400, italic: false, file: 'anton-latin-400-normal.woff2' },
  { family: 'Caveat', key: 'caveat', weight: 700, italic: false, file: 'caveat-latin-700-normal.woff2' },
];

export type FontMode =
  | { mode: 'inline'; data: Record<string, string> }   // file -> base64 woff2 (self-contained export / sandboxed render)
  | { mode: 'linked'; base: string }                    // same-origin URL prefix, e.g. "/fonts/"
  | { mode: 'none' };

export interface RenderOptions {
  fonts: FontMode;
  guides?: boolean;                 // editor-only safe-zone overlays (never exported)
  resolveAsset?: (ref: string) => string | null;
  lighting?: string;                // source lighting variant, drives illustration tone
  title?: string;
}

function nearestWeight(key: FontKey, weight: number, italic: boolean): FontFace | undefined {
  const c = FONT_FACES.filter(f => f.key === key && f.italic === italic);
  const pool = c.length ? c : FONT_FACES.filter(f => f.key === key);
  return pool.slice().sort((a, b) => Math.abs(a.weight - weight) - Math.abs(b.weight - weight))[0];
}
/** Only the faces a spec actually uses are embedded. */
export function collectFonts(spec: VisualSceneSpec): FontFace[] {
  const used = new Map<string, FontFace>();
  const add = (key: FontKey, weight: number, italic = false): void => { const f = nearestWeight(key, weight, italic); if (f) used.set(f.file, f); };
  const walk = (ls: VisualLayer[]): void => {
    for (const l of ls) {
      if (l.hidden) continue;
      switch (l.type) {
        case 'headline': case 'text': add(l.font, l.weight, !!l.italic); break;
        case 'stat': add(l.font, 800); add('jakarta', 600); break;
        case 'badge': case 'cta': case 'logo': add(l.font, 700); break;
        case 'annotation': add('caveat', 700); break;
        case 'diagram': add(l.font, 600); add(l.font, 800); add(l.font, 700); break;
        case 'pattern': if (l.kind === 'monogram') add('fraunces', 600); break;
        case 'image': add('jakarta', 600); break;
        case 'group': walk(l.children); break;
      }
    }
  };
  walk(spec.artDirection.layerPlan);
  return [...used.values()];
}

function fontCss(spec: VisualSceneSpec, fonts: FontMode): string {
  if (fonts.mode === 'none') return '';
  return collectFonts(spec).map(f => {
    const src = fonts.mode === 'inline'
      ? (fonts.data[f.file] ? `url(data:font/woff2;base64,${fonts.data[f.file]})` : null)
      : `url(${fonts.base}${f.file})`;
    return src ? `@font-face{font-family:'${f.family}';font-weight:${f.weight};font-style:${f.italic ? 'italic' : 'normal'};font-display:block;src:${src} format('woff2')}` : '';
  }).join('');
}

const BASE_CSS = `*{margin:0;padding:0}html,body{background:transparent}body{-webkit-font-smoothing:antialiased;text-rendering:geometricPrecision}` +
  `[data-artboard]{position:relative;overflow:hidden;isolation:isolate}` +
  `.l{position:absolute;box-sizing:border-box}.l svg{display:block;position:absolute;inset:0}` +
  `*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}`;

/** Editor-only safe-zone guide styles (never present in exported or stored artboards). */
const GUIDE_CSS =
  `.gz{position:absolute;box-sizing:border-box;border:2px dashed rgba(160,207,93,.95);background:rgba(160,207,93,.10);color:#141B15;font:600 13px 'Plus Jakarta Sans',system-ui,sans-serif;z-index:9999;pointer-events:none}` +
  `.gz span{position:absolute;left:0;top:0;background:#A0CF5D;padding:2px 6px;border-radius:0 0 6px 0;max-width:100%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}`;

export interface RenderResult { html: string; body: string; problems: string[]; width: number; height: number }

/** Render the artboard element only (used for in-app thumbnails of unsaved drafts and tests). */
export function renderArtboardBody(spec: VisualSceneSpec, opts: RenderOptions): { body: string; problems: string[] } {
  const { width: W, height: H } = spec.output;
  const roles = spec.artDirection.colourRoles;
  const ctx: RenderCtx = { W, H, U: Math.min(W, H) / 100, roles, tone: buildTone(roles, opts.lighting ?? 'Editorial', false), lighting: opts.lighting ?? 'Editorial', resolveAsset: opts.resolveAsset, problems: [] };
  const layers = spec.artDirection.layerPlan.map((l, i) => renderLayer(l, ctx, i + 1)).join('');
  const guides = opts.guides ? spec.output.safeZones.map(z => `<div class="gz" style="left:${z.x}%;top:${z.y}%;width:${z.width}%;height:${z.height}%"><span>${escapeHtml(z.purpose)}</span></div>`).join('') : '';
  const body = `<div data-artboard="true" data-scene-id="${escapeHtml(spec.sceneId)}" data-fidelity="${spec.artDirection.previewFidelity}" role="img" aria-label="${escapeHtml(spec.output.altText)}" style="width:${W}px;height:${H}px;background:${roles.background}">${layers}${guides}</div>`;
  return { body, problems: ctx.problems };
}

/** Render a complete, self-contained, script-free HTML document for one artboard. */
export function renderArtboardHtml(spec: VisualSceneSpec, opts: RenderOptions): RenderResult {
  const { body, problems } = renderArtboardBody(spec, opts);
  const fontSrc = opts.fonts.mode === 'linked' ? ` 'self'` : '';
  // CSP: no script, no network. Only inline styles, data: images/fonts (plus same-origin fonts when linked).
  const csp = `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:${fontSrc}; base-uri 'none'; form-action 'none'`;
  const html = `<!doctype html><html lang="en-AU"><head><meta charset="utf-8"/><meta http-equiv="Content-Security-Policy" content="${csp}"/>` +
    `<meta name="viewport" content="width=${spec.output.width}"/><meta name="generator" content="Authority Builder Prompt Studio ${spec.provenance.rendererVersion}"/>` +
    `<title>${escapeHtml(opts.title ?? spec.sceneId)}</title><style>${fontCss(spec, opts.fonts)}${BASE_CSS}${opts.guides ? GUIDE_CSS : ''}</style></head><body>${body}</body></html>`;
  return { html, body, problems, width: spec.output.width, height: spec.output.height };
}
