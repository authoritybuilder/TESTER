/**
 * Resumable, idempotent catalogue preview queue.
 * Cache key = sha256(sceneId + sourceVersion/sourceSha + visualSpecHash + rendererVersion): re-running an identical job
 * renders nothing; changing a source record, the planner or the renderer invalidates exactly the affected scenes.
 * Progress is checkpointed to a manifest so an interrupted backfill resumes where it stopped.
 */
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { sha256 } from './asset-pipeline.ts';

export interface PreviewRecord {
  sceneId: string; category: string; cacheKey: string; sourceSha256: string; visualSpecHash: string; rendererVersion: string;
  status: 'rendered' | 'failed'; error?: string;
  spec: string; html: string; thumb: string; htmlSha256: string; thumbSha256: string; thumbBytes: number;
  width: number; height: number; thumbWidth: number; thumbHeight: number; aspect: string;
  fidelity: string; medium: string; family: string; layers: number; conceptLayers: number;
  qa: { decoded: boolean; blank: boolean; stdevLuma: number; distinctColours: number; edgeDensity: number; dhash: string; textOverflow: string[]; missingFonts: string[]; blockedRequests: number; problems: string[]; pass: boolean };
  renderMs: number; renderedAt: string;
}
export interface PreviewManifest { rendererVersion: string; browser: string; updatedAt: string; records: Record<string, PreviewRecord> }

export const cacheKey = (sceneId: string, sourceSha: string, specHash: string, rendererVersion: string): string => sha256([sceneId, sourceSha, specHash, rendererVersion].join('|'));

export class PreviewLedger {
  manifest: PreviewManifest;
  constructor(private path: string, rendererVersion: string, browser: string) {
    this.manifest = existsSync(path) ? (JSON.parse(readFileSync(path, 'utf8')) as PreviewManifest) : { rendererVersion, browser, updatedAt: '', records: {} };
    this.manifest.rendererVersion = rendererVersion; this.manifest.browser = browser;
  }
  isFresh(sceneId: string, key: string, files: string[]): boolean { const r = this.manifest.records[sceneId]; return !!r && r.status === 'rendered' && r.cacheKey === key && files.every(f => existsSync(f)); }
  put(r: PreviewRecord): void { this.manifest.records[r.sceneId] = r; }
  save(): void { this.manifest.updatedAt = new Date().toISOString(); mkdirSync(dirname(this.path), { recursive: true }); const tmp = this.path + '.tmp'; writeFileSync(tmp, JSON.stringify(this.manifest)); renameSync(tmp, this.path); }
}

/** Minimal bounded-concurrency runner with per-job error capture (one bad scene never stops the backfill). */
export async function runQueue<T>(items: T[], concurrency: number, job: (item: T, i: number) => Promise<void>, onError: (item: T, e: unknown) => void, onProgress?: (done: number) => void): Promise<void> {
  let next = 0, done = 0;
  const worker = async (): Promise<void> => { for (;;) { const i = next++; if (i >= items.length) return; try { await job(items[i]!, i); } catch (e) { onError(items[i]!, e); } done++; onProgress?.(done); } };
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
}
