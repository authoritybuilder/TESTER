/**
 * VisualSceneSpec — the typed, validated, declarative visual-design language.
 * This (not HTML) is the source of truth for a design. The trusted renderer (artboard-renderer.ts)
 * turns a validated spec into an HTML/CSS/SVG artboard; nothing model- or user-authored is executed.
 *
 * Coordinates: every layer box is in percent of the artboard (0–100, bleed allowed −60…160).
 * Sizes for type/strokes are in "units" = percent of the artboard's short side, so a spec re-lays-out
 * across aspect ratios without pixel maths.
 */
import { z } from 'zod';
import { ENV_KINDS } from './illustration/environments.ts';
import { FIGURE_POSES, TOP_KINDS } from './illustration/figures.ts';
import { PROP_KINDS } from './illustration/props.ts';

export const SPEC_VERSION = '1.0.0';
export const RENDERER_VERSION = 'ab-artboard-1.0.0';
export const COMPILER_VERSION = 'ab-compiler-10.0.0';

export const Hex = z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'must be a #RRGGBB colour');
const pct = z.number().min(-60).max(160);
const size = z.number().min(0).max(100);
export const Box = z.object({ x: pct, y: pct, w: z.number().min(0.5).max(220), h: z.number().min(0.5).max(220) }).strict();
export type Box = z.infer<typeof Box>;

export const FONT_KEYS = ['jakarta', 'fraunces', 'anton', 'caveat'] as const;
export type FontKey = (typeof FONT_KEYS)[number];

const Stop = z.object({ color: Hex, at: z.number().min(0).max(100), alpha: z.number().min(0).max(1).optional() }).strict();
export const Paint = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('solid'), color: Hex, alpha: z.number().min(0).max(1).optional() }).strict(),
  z.object({ kind: z.literal('linear'), angle: z.number().min(0).max(360), stops: z.array(Stop).min(2).max(5) }).strict(),
  z.object({ kind: z.literal('radial'), cx: z.number().min(0).max(100), cy: z.number().min(0).max(100), stops: z.array(Stop).min(2).max(5) }).strict(),
]);
export type Paint = z.infer<typeof Paint>;

/** data: URLs for raster images only (validated type + bounded size) or a workspace asset reference resolved server-side. */
export const SafeImageSrc = z.string().max(6_000_000).refine(
  v => /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v) || /^asset:[a-zA-Z0-9_-]{6,64}$/.test(v),
  'image src must be a base64 PNG/JPEG/WebP data URL or an asset: reference',
);

const base = {
  id: z.string().regex(/^[a-z0-9][a-z0-9-]{0,39}$/), name: z.string().min(1).max(60), box: Box,
  hidden: z.boolean().optional(), locked: z.boolean().optional(),
  opacity: z.number().min(0).max(1).optional(), rotation: z.number().min(-180).max(180).optional(),
  blend: z.enum(['normal', 'multiply', 'screen', 'overlay', 'soft-light']).optional(),
  /** 'concept' layers illustrate what a photograph would show; they hide when the customer supplies a real photo. */
  role: z.enum(['design', 'concept']).optional(),
};
const text = {
  text: z.string().max(400), font: z.enum(FONT_KEYS), weight: z.number().int().min(300).max(900), size, color: Hex,
  align: z.enum(['left', 'center', 'right']), valign: z.enum(['top', 'middle', 'bottom']).optional(),
  lineHeight: z.number().min(0.8).max(2), tracking: z.number().min(-0.1).max(0.5).optional(),
  uppercase: z.boolean().optional(), italic: z.boolean().optional(),
  /** provenance of the words: never invented claims. */
  copyStatus: z.enum(['suggested', 'user', 'brand-kit', 'source']),
};

export const LAYER_TYPES = ['background', 'environment', 'figure', 'hands', 'object', 'shape', 'path', 'pattern', 'texture', 'image', 'headline', 'text', 'stat', 'badge', 'cta', 'annotation', 'logo', 'diagram', 'chart', 'frame', 'group'] as const;

const Background = z.object({ ...base, type: z.literal('background'), fill: Paint }).strict();
const Environment = z.object({ ...base, type: z.literal('environment'), kind: z.enum(ENV_KINDS as [string, ...string[]]), seed: z.string().max(80), horizon: z.number().min(0.2).max(0.95), busy: z.enum(['left', 'right', 'both']), blur: z.number().min(0).max(40) }).strict();
const Figure = z.object({ ...base, type: z.literal('figure'), pose: z.enum(FIGURE_POSES), facing: z.enum(['left', 'right']), look: z.object({ skin: Hex, hair: Hex, hairStyle: z.number().int().min(0).max(5), top: Hex, topKind: z.enum(TOP_KINDS), bottom: Hex, accent: Hex, beard: z.boolean() }).strict(), blur: z.number().min(0).max(40).optional() }).strict();
const Hands = z.object({ ...base, type: z.literal('hands'), mode: z.enum(['present', 'reveal', 'detail']), look: Figure.shape.look, seed: z.string().max(80) }).strict();
const ObjectLayer = z.object({ ...base, type: z.literal('object'), kind: z.enum(PROP_KINDS as [string, ...string[]]), sourcePhrase: z.string().max(80), variant: z.number().min(0).max(1), blur: z.number().min(0).max(40).optional(), shadow: z.boolean().optional() }).strict();
const Shape = z.object({ ...base, type: z.literal('shape'), shape: z.enum(['rect', 'ellipse', 'line', 'triangle', 'arch', 'blob', 'ring']), fill: Paint.optional(), stroke: Hex.optional(), strokeWidth: size.optional(), radius: size.optional(), shadow: z.boolean().optional() }).strict();
const PathLayer = z.object({ ...base, type: z.literal('path'), d: z.string().max(4000).regex(/^[MmLlHhVvCcSsQqTtAaZz0-9\s,.\-eE]+$/, 'path data may only contain SVG path commands and numbers'), viewBox: z.tuple([z.number().positive().max(4000), z.number().positive().max(4000)]), fill: Hex.optional(), stroke: Hex.optional(), strokeWidth: size.optional() }).strict();
const Pattern = z.object({ ...base, type: z.literal('pattern'), kind: z.enum(['dots', 'grid', 'stripes', 'monogram', 'waves', 'confetti', 'checks', 'rays', 'arches']), color: Hex, color2: Hex.optional(), scale: z.number().min(1).max(40), text: z.string().max(24).optional() }).strict();
const Texture = z.object({ ...base, type: z.literal('texture'), kind: z.enum(['grain', 'paper', 'marble', 'linen', 'concrete', 'wood', 'vignette', 'light-leak', 'halftone', 'plaster']), color: Hex, intensity: z.number().min(0).max(1), seed: z.string().max(80).optional() }).strict();
const ImageLayer = z.object({ ...base, type: z.literal('image'), src: SafeImageSrc, fit: z.enum(['cover', 'contain']), focusX: z.number().min(0).max(100), focusY: z.number().min(0).max(100), mask: z.enum(['none', 'circle', 'rounded', 'arch', 'blob']), alt: z.string().max(200), rights: z.object({ source: z.enum(['user-upload', 'licensed', 'provider-generated']), note: z.string().max(200), confirmedByUser: z.boolean() }).strict(), tint: Hex.optional(), tintAmount: z.number().min(0).max(1).optional() }).strict();
const Headline = z.object({ ...base, type: z.literal('headline'), ...text }).strict();
const Text = z.object({ ...base, type: z.literal('text'), ...text }).strict();
const Stat = z.object({ ...base, type: z.literal('stat'), value: z.string().max(16), label: z.string().max(80), font: z.enum(FONT_KEYS), color: Hex, labelColor: Hex, size, align: z.enum(['left', 'center', 'right']), verified: z.boolean(), copyStatus: text.copyStatus }).strict();
const Badge = z.object({ ...base, type: z.literal('badge'), text: z.string().max(40), shape: z.enum(['pill', 'circle', 'ribbon', 'stamp', 'tag']), fill: Hex, color: Hex, font: z.enum(FONT_KEYS), size, copyStatus: text.copyStatus }).strict();
const Cta = z.object({ ...base, type: z.literal('cta'), text: z.string().max(40), fill: Hex, color: Hex, font: z.enum(FONT_KEYS), size, radius: size, icon: z.enum(['none', 'arrow', 'play', 'download']), style: z.enum(['solid', 'outline', 'bar']), copyStatus: text.copyStatus }).strict();
const Annotation = z.object({ ...base, type: z.literal('annotation'), text: z.string().max(80), color: Hex, size, arrow: z.enum(['none', 'left', 'right', 'up', 'down']), copyStatus: text.copyStatus }).strict();
const Logo = z.object({ ...base, type: z.literal('logo'), text: z.string().max(40), src: SafeImageSrc.optional(), color: Hex, font: z.enum(FONT_KEYS), size, mark: z.enum(['none', 'dot', 'square', 'ring']), copyStatus: text.copyStatus }).strict();
const Diagram = z.object({ ...base, type: z.literal('diagram'), kind: z.enum(['steps', 'cycle', 'pillars', 'funnel', 'matrix', 'timeline', 'venn', 'ladder', 'list']), nodes: z.array(z.object({ label: z.string().max(40) }).strict()).min(2).max(7), color: Hex, color2: Hex, ink: Hex, surface: Hex.optional(), font: z.enum(FONT_KEYS), size, copyStatus: text.copyStatus }).strict();
const Chart = z.object({ ...base, type: z.literal('chart'), kind: z.enum(['bars', 'line', 'donut']), values: z.array(z.number().min(0).max(100)).min(2).max(8), color: Hex, color2: Hex, ink: Hex, surface: Hex.optional(), illustrative: z.literal(true) }).strict();
const Frame = z.object({ ...base, type: z.literal('frame'), kind: z.enum(['phone', 'laptop', 'tablet', 'browser', 'polaroid', 'card', 'book', 'page']), color: Hex, screen: Paint, shadow: z.boolean().optional() }).strict();

const Leaf = z.discriminatedUnion('type', [Background, Environment, Figure, Hands, ObjectLayer, Shape, PathLayer, Pattern, Texture, ImageLayer, Headline, Text, Stat, Badge, Cta, Annotation, Logo, Diagram, Chart, Frame]);
const Group = z.object({ ...base, type: z.literal('group'), children: z.array(Leaf).min(1).max(24) }).strict();
export const VisualLayer = z.union([Leaf, Group]);
export type VisualLayer = z.infer<typeof VisualLayer>;
export type LeafLayer = z.infer<typeof Leaf>;
export type LayerOf<T extends VisualLayer['type']> = Extract<VisualLayer, { type: T }>;

export const ColourRoles = z.object({ background: Hex, surface: Hex, ink: Hex, primary: Hex, secondary: Hex, accent: Hex, light: Hex, dark: Hex }).strict();
export type ColourRoles = z.infer<typeof ColourRoles>;

export const SafeZone = z.object({ x: z.number().min(0).max(100), y: z.number().min(0).max(100), width: z.number().min(0).max(100), height: z.number().min(0).max(100), purpose: z.string().max(160) }).strict();

const s = (max: number) => z.string().max(max);
export const VisualSceneSpecSchema = z.object({
  specVersion: z.literal(SPEC_VERSION),
  sceneId: z.string().regex(/^[a-z0-9][a-z0-9-]{1,80}$/),
  sourceVersion: s(40),
  originalSceneFingerprint: z.string().regex(/^[0-9a-f]{64}$/),
  visualArchetype: s(80),
  intent: z.object({
    funnelStage: z.enum(['attract', 'engage', 'nurture', 'convert', 'retain']),
    outcome: s(240), intendedAudience: s(160), marketingMechanism: s(160), useCase: s(300),
  }).strict(),
  scene: z.object({
    subject: s(200), action: s(240), environment: s(240), props: z.array(s(80)).max(8), narrative: s(700),
    distinctnessAnchors: z.array(s(120)).min(3).max(7), mustInclude: z.array(s(120)).max(8), mustNotInclude: z.array(s(120)).max(8),
  }).strict(),
  artDirection: z.object({
    medium: z.enum(['html-graphic', 'html-illustration', 'diagram', 'photo-composite', 'photographic']),
    visualLanguage: s(200), compositionFamily: s(60), compositionRationale: s(500), whyThisWorks: s(400),
    focalPoint: s(160), focalHierarchy: z.array(s(120)).min(1).max(6), shapesAndMotifs: z.array(s(80)).max(8),
    layerPlan: z.array(VisualLayer).min(1).max(60),
    typography: z.object({ headline: z.enum(FONT_KEYS), body: z.enum(FONT_KEYS), accent: z.enum(FONT_KEYS), scale: z.number().min(0.5).max(2) }).strict(),
    colourRoles: ColourRoles,
    lightAndTexture: s(240), whitespacePlan: s(240), accessibilityNotes: z.array(s(200)).max(6),
    previewFidelity: z.enum(['final-html-asset', 'composition-concept', 'photo-required']),
  }).strict(),
  output: z.object({
    width: z.number().int().min(200).max(6000), height: z.number().int().min(200).max(6000), aspect: s(12),
    safeZones: z.array(SafeZone).max(8), formats: z.array(z.enum(['html', 'svg', 'png', 'webp', 'jpeg', 'pdf'])).min(1),
    intendedPlacement: s(240), altText: s(300),
  }).strict(),
  brand: z.object({
    workspaceId: z.string().regex(/^[a-zA-Z0-9_-]{1,64}$/).optional(), tokenReferences: z.array(s(60)).max(12), logoAssetId: s(64).optional(),
    typefaceRefs: z.array(s(60)).max(4), approvedCopy: z.array(s(200)).max(12), sourceImages: z.array(s(80)).max(8),
  }).strict(),
  provenance: z.object({
    originalTemplateId: s(80), compilerVersion: s(40), rendererVersion: s(40), creativeModel: s(80).optional(),
    approvalStatus: z.enum(['auto-generated', 'art-directed', 'human-reviewed', 'customer-edited', 'approved']),
    planner: z.enum(['deterministic', 'claude-structured-output', 'claude-in-session']), conceptLocked: z.boolean(),
    changes: z.array(s(200)).max(40),
  }).strict(),
}).strict();
export type VisualSceneSpec = z.infer<typeof VisualSceneSpecSchema>;

export class SpecValidationError extends Error {
  constructor(public readonly issues: string[]) { super('VisualSceneSpec failed validation: ' + issues.slice(0, 6).join('; ')); this.name = 'SpecValidationError'; }
}
/** Validate untrusted spec data (model output, API input, stored drafts). Fails closed. */
export function validateSpec(data: unknown): VisualSceneSpec {
  const r = VisualSceneSpecSchema.safeParse(data);
  if (!r.success) throw new SpecValidationError(r.error.issues.map(i => `${i.path.join('.')}: ${i.message}`));
  const ids = new Set<string>();
  const walk = (ls: VisualLayer[]): void => { for (const l of ls) { if (ids.has(l.id)) throw new SpecValidationError([`duplicate layer id "${l.id}"`]); ids.add(l.id); if (l.type === 'group') walk(l.children); } };
  walk(r.data.artDirection.layerPlan);
  return r.data;
}
/** JSON Schema for Claude structured outputs (`output_config.format`). */
export function specJsonSchema(): unknown { return z.toJSONSchema(VisualSceneSpecSchema, { target: 'draft-2020-12' }); }
