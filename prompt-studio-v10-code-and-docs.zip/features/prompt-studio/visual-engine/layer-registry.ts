/**
 * Layer registry — the ONLY place layer data becomes markup.
 * Every primitive is a trusted template: numbers are formatted, colours are schema-validated hex,
 * and all text is HTML-escaped. No layer can emit script, event handlers, external URLs or raw markup.
 */
import { escapeHtml, hash53, rng } from '../shared/util.ts';
import { drawEnvironment } from './illustration/environments.ts';
import { drawFigure, drawHands } from './illustration/figures.ts';
import { drawProp } from './illustration/props.ts';
import { buildTone, darken, lighten, mix, n, type Tone } from './illustration/svg.ts';
import type { ColourRoles, FontKey, LayerOf, Paint, VisualLayer } from './scene-schema.ts';

export interface RenderCtx {
  W: number; H: number; U: number; roles: ColourRoles; tone: Tone; lighting: string;
  /** resolves `asset:` references to data URLs (server-side, tenant-checked). */
  resolveAsset?: (ref: string) => string | null;
  problems: string[];
}
export const FONT_STACK: Record<FontKey, string> = {
  jakarta: `'Plus Jakarta Sans','Inter',system-ui,sans-serif`,
  fraunces: `'Fraunces','Georgia',serif`,
  anton: `'Anton','Impact','Arial Narrow',sans-serif`,
  caveat: `'Caveat','Comic Sans MS',cursive`,
};
const e = escapeHtml;
const uid = (id: string, k: string): string => `${k}-${id}`;

export function paintCss(p: Paint): string {
  const rgba = (c: string, a?: number): string => (a === undefined || a >= 1 ? c : `rgba(${parseInt(c.slice(1, 3), 16)},${parseInt(c.slice(3, 5), 16)},${parseInt(c.slice(5, 7), 16)},${a})`);
  if (p.kind === 'solid') return rgba(p.color, p.alpha);
  const stops = p.stops.map(s => `${rgba(s.color, s.alpha)} ${n(s.at)}%`).join(',');
  return p.kind === 'linear' ? `linear-gradient(${n(p.angle)}deg,${stops})` : `radial-gradient(circle at ${n(p.cx)}% ${n(p.cy)}%,${stops})`;
}
const svg = (vbW: number, vbH: number, inner: string, par = 'xMidYMid meet', extra = ''): string =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n(vbW)} ${n(vbH)}" preserveAspectRatio="${par}" width="100%" height="100%" overflow="visible" aria-hidden="true"${extra}>${inner}</svg>`;
const px = (ctx: RenderCtx, units: number): string => n(units * ctx.U) + 'px';

function textCss(ctx: RenderCtx, l: { font: FontKey; weight: number; size: number; color: string; align: string; valign?: string; lineHeight: number; tracking?: number; uppercase?: boolean; italic?: boolean }): string {
  const j = l.valign === 'middle' ? 'center' : l.valign === 'bottom' ? 'flex-end' : 'flex-start';
  return `display:flex;flex-direction:column;justify-content:${j};font-family:${FONT_STACK[l.font]};font-weight:${l.weight};font-size:${px(ctx, l.size)};color:${l.color};text-align:${l.align};line-height:${l.lineHeight};letter-spacing:${l.tracking ?? 0}em;${l.uppercase ? 'text-transform:uppercase;' : ''}${l.italic ? 'font-style:italic;' : ''}`;
}
const textHtml = (t: string): string => e(t).replace(/\n/g, '<br/>');

type Renderers = { [K in VisualLayer['type']]: (l: LayerOf<K>, ctx: RenderCtx) => string };

function patternSvg(l: LayerOf<'pattern'>, ctx: RenderCtx): string {
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H, s = l.scale * ctx.U, c = l.color, c2 = l.color2 ?? c, id = uid(l.id, 'pt');
  let def = '';
  switch (l.kind) {
    case 'dots': def = `<pattern id="${id}" width="${n(s)}" height="${n(s)}" patternUnits="userSpaceOnUse"><circle cx="${n(s / 2)}" cy="${n(s / 2)}" r="${n(s * 0.14)}" fill="${c}"/></pattern>`; break;
    case 'grid': def = `<pattern id="${id}" width="${n(s)}" height="${n(s)}" patternUnits="userSpaceOnUse"><path d="M${n(s)} 0H0V${n(s)}" fill="none" stroke="${c}" stroke-width="${n(Math.max(1, s * 0.03))}"/></pattern>`; break;
    case 'stripes': def = `<pattern id="${id}" width="${n(s)}" height="${n(s)}" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="${n(s / 2)}" height="${n(s)}" fill="${c}"/></pattern>`; break;
    case 'checks': def = `<pattern id="${id}" width="${n(s * 2)}" height="${n(s * 2)}" patternUnits="userSpaceOnUse"><rect width="${n(s)}" height="${n(s)}" fill="${c}"/><rect x="${n(s)}" y="${n(s)}" width="${n(s)}" height="${n(s)}" fill="${c2}"/></pattern>`; break;
    case 'waves': def = `<pattern id="${id}" width="${n(s * 2)}" height="${n(s)}" patternUnits="userSpaceOnUse"><path d="M0 ${n(s / 2)}Q${n(s / 2)} 0 ${n(s)} ${n(s / 2)}T${n(s * 2)} ${n(s / 2)}" fill="none" stroke="${c}" stroke-width="${n(s * 0.08)}"/></pattern>`; break;
    case 'arches': def = `<pattern id="${id}" width="${n(s)}" height="${n(s)}" patternUnits="userSpaceOnUse"><path d="M${n(s * 0.15)} ${n(s)}V${n(s * 0.5)}A${n(s * 0.35)} ${n(s * 0.35)} 0 0 1 ${n(s * 0.85)} ${n(s * 0.5)}V${n(s)}" fill="none" stroke="${c}" stroke-width="${n(s * 0.06)}"/></pattern>`; break;
    case 'monogram': {
      const t = e((l.text ?? 'AB').slice(0, 24)); const fs = s * 0.34;
      def = `<pattern id="${id}" width="${n(s * 2.4)}" height="${n(s * 1.6)}" patternUnits="userSpaceOnUse"><text x="${n(s * 0.6)}" y="${n(s * 0.55)}" font-family="${FONT_STACK.fraunces}" font-weight="600" font-size="${n(fs)}" text-anchor="middle" fill="${c}">${t}</text><circle cx="${n(s * 1.8)}" cy="${n(s * 0.42)}" r="${n(s * 0.16)}" fill="none" stroke="${c2}" stroke-width="${n(s * 0.03)}"/><text x="${n(s * 1.8)}" y="${n(s * 1.35)}" font-family="${FONT_STACK.fraunces}" font-weight="600" font-size="${n(fs)}" text-anchor="middle" fill="${c}">${t}</text><circle cx="${n(s * 0.6)}" cy="${n(s * 1.22)}" r="${n(s * 0.16)}" fill="none" stroke="${c2}" stroke-width="${n(s * 0.03)}"/></pattern>`;
      break;
    }
    case 'confetti': {
      const r = rng('confetti:' + l.id); let o = '';
      for (let i = 0; i < 70; i++) { const x = r() * w, y = r() * h * (0.3 + r() * 0.7), sz = (0.4 + r() * 0.9) * s * 0.3; o += r() < 0.5 ? `<rect x="${n(x)}" y="${n(y)}" width="${n(sz)}" height="${n(sz * 0.5)}" fill="${r() < 0.5 ? c : c2}" transform="rotate(${n(r() * 180)} ${n(x)} ${n(y)})"/>` : `<circle cx="${n(x)}" cy="${n(y)}" r="${n(sz * 0.35)}" fill="${r() < 0.5 ? c : c2}"/>`; }
      return svg(w, h, o, 'none');
    }
    case 'rays': {
      let o = ''; const cx = w / 2, cy = h * 0.55, R = Math.hypot(w, h);
      for (let i = 0; i < 24; i += 2) { const a1 = (i / 24) * Math.PI * 2, a2 = ((i + 1) / 24) * Math.PI * 2; o += `<polygon points="${n(cx)},${n(cy)} ${n(cx + Math.cos(a1) * R)},${n(cy + Math.sin(a1) * R)} ${n(cx + Math.cos(a2) * R)},${n(cy + Math.sin(a2) * R)}" fill="${c}"/>`; }
      return svg(w, h, o, 'none');
    }
  }
  return svg(w, h, `<defs>${def}</defs><rect width="${n(w)}" height="${n(h)}" fill="url(#${id})"/>`, 'none');
}

function textureSvg(l: LayerOf<'texture'>, ctx: RenderCtx): string {
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H, id = uid(l.id, 'tx'), seed = hash53(l.seed ?? l.id) % 997, a = l.intensity;
  const turb = (bf: string, oct: number, type = 'fractalNoise'): string => `<feTurbulence type="${type}" baseFrequency="${bf}" numOctaves="${oct}" seed="${seed}" result="n"/>`;
  const k = 1000 / Math.max(w, h); // keep texture scale consistent across sizes
  const f = (v: number): string => (v * k).toFixed(5);
  const mono = (slope: number, icpt: number): string => `<feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  ${slope} 0 0 0 ${icpt}" result="a"/><feFlood flood-color="${l.color}"/><feComposite in2="a" operator="in"/>`;
  let filter = '', extra = '';
  switch (l.kind) {
    case 'vignette': return `<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 46%,rgba(0,0,0,0) 46%,${l.color} 130%);opacity:${a}"></div>`;
    case 'light-leak': return `<div style="position:absolute;inset:0;background:radial-gradient(circle at 86% 8%,${l.color} 0%,rgba(255,255,255,0) 55%);opacity:${a};mix-blend-mode:screen"></div>`;
    case 'halftone': { const s = ctx.U * 1.6; return svg(w, h, `<defs><pattern id="${id}" width="${n(s)}" height="${n(s)}" patternUnits="userSpaceOnUse" patternTransform="rotate(30)"><circle cx="${n(s / 2)}" cy="${n(s / 2)}" r="${n(s * 0.22)}" fill="${l.color}"/></pattern></defs><rect width="${n(w)}" height="${n(h)}" fill="url(#${id})" opacity="${a}"/>`, 'none'); }
    case 'grain': filter = turb(f(0.9), 2) + mono(1.6, -0.55); break;
    case 'paper': filter = turb(`${f(0.035)} ${f(0.05)}`, 4) + mono(1.3, -0.35); break;
    case 'plaster': filter = turb(f(0.012), 5) + mono(1.5, -0.42); break;
    case 'linen': filter = turb(`${f(0.9)} ${f(0.02)}`, 2) + mono(1.4, -0.4); extra = `<filter id="${id}b" x="0" y="0" width="100%" height="100%">${turb(`${f(0.02)} ${f(0.9)}`, 2)}${mono(1.4, -0.4)}</filter><rect width="${n(w)}" height="${n(h)}" filter="url(#${id}b)" opacity="${a * 0.8}"/>`; break;
    case 'concrete': filter = turb(f(0.02), 5) + mono(1.2, -0.3); extra = `<filter id="${id}b" x="0" y="0" width="100%" height="100%">${turb(f(0.8), 1)}${mono(1.2, -0.5)}</filter><rect width="${n(w)}" height="${n(h)}" filter="url(#${id}b)" opacity="${a * 0.6}"/>`; break;
    case 'marble': filter = `<feTurbulence type="turbulence" baseFrequency="${f(0.006)} ${f(0.011)}" numOctaves="5" seed="${seed}" result="n"/><feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -9 0 0 0 1.25" result="a"/><feGaussianBlur in="a" stdDeviation="${n(ctx.U * 0.12)}" result="b"/><feFlood flood-color="${l.color}"/><feComposite in2="b" operator="in"/>`; break;
    case 'wood': filter = turb(`${f(0.004)} ${f(0.09)}`, 3) + mono(1.6, -0.5); break;
  }
  return svg(w, h, `<defs><filter id="${id}" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">${filter}</filter></defs><rect width="${n(w)}" height="${n(h)}" filter="url(#${id})" opacity="${a}"/>${extra}`, 'none');
}

function shapeHtml(l: LayerOf<'shape'>, ctx: RenderCtx): string {
  const fill = l.fill ? `background:${paintCss(l.fill)};` : '';
  const strokeCss = l.stroke ? `border:${px(ctx, l.strokeWidth ?? 0.4)} solid ${l.stroke};` : '';
  const sh = l.shadow ? `box-shadow:0 ${px(ctx, 1.2)} ${px(ctx, 4)} rgba(0,0,0,.18);` : '';
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H;
  switch (l.shape) {
    case 'rect': return `<div style="position:absolute;inset:0;box-sizing:border-box;${fill}${strokeCss}${sh}border-radius:${px(ctx, l.radius ?? 0)}"></div>`;
    case 'ellipse': return `<div style="position:absolute;inset:0;box-sizing:border-box;${fill}${strokeCss}${sh}border-radius:50%"></div>`;
    case 'ring': return `<div style="position:absolute;inset:0;box-sizing:border-box;border:${px(ctx, l.strokeWidth ?? 1)} solid ${l.stroke ?? ctx.roles.accent};border-radius:50%"></div>`;
    case 'arch': return `<div style="position:absolute;inset:0;box-sizing:border-box;${fill}${strokeCss}border-radius:${n(w / 2)}px ${n(w / 2)}px 0 0"></div>`;
    case 'line': return `<div style="position:absolute;left:0;right:0;top:50%;height:${px(ctx, l.strokeWidth ?? 0.4)};transform:translateY(-50%);background:${l.stroke ?? (l.fill ? paintCss(l.fill) : ctx.roles.ink)};border-radius:${px(ctx, 1)}"></div>`;
    case 'triangle': return svg(w, h, `<polygon points="${n(w / 2)},0 ${n(w)},${n(h)} 0,${n(h)}" fill="${l.fill?.kind === 'solid' ? l.fill.color : ctx.roles.accent}"/>`, 'none');
    case 'blob': { const r = rng('blob:' + l.id); const pts: string[] = []; const k = 8; for (let i = 0; i < k; i++) { const a = (i / k) * Math.PI * 2, rad = 0.38 + r() * 0.12; pts.push(`${n(50 + Math.cos(a) * rad * 100)}% ${n(50 + Math.sin(a) * rad * 100)}%`); } return `<div style="position:absolute;inset:0;${fill}clip-path:polygon(${pts.join(',')});border-radius:42% 58% 55% 45% / 50% 42% 58% 50%"></div>`; }
  }
}

function diagramSvg(l: LayerOf<'diagram'>, ctx: RenderCtx): string {
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H, N = l.nodes.length, fs = l.size * ctx.U, ff = FONT_STACK[l.font];
  const label = (x: number, y: number, t: string, anchor = 'middle', col = l.ink, sz = fs, wt = 600): string => `<text x="${n(x)}" y="${n(y)}" font-family="${ff}" font-weight="${wt}" font-size="${n(sz)}" text-anchor="${anchor}" fill="${col}">${e(t)}</text>`;
  const onC = (c: string): string => (lum(c) > 0.6 ? '#111111' : '#FFFFFF');
  let o = l.surface ? `<rect width="${n(w)}" height="${n(h)}" rx="${n(ctx.U * 1.2)}" fill="${l.surface}"/>` : '';
  const pad = Math.min(w, h) * 0.08, iw = w - pad * 2, ih = h - pad * 2;
  switch (l.kind) {
    case 'steps': { const r = Math.min(iw / (N * 2.6), ih * 0.24); for (let i = 0; i < N; i++) { const cx = pad + (iw / N) * (i + 0.5), cy = pad + ih * 0.38; if (i < N - 1) o += `<line x1="${n(cx + r)}" y1="${n(cy)}" x2="${n(cx + iw / N - r)}" y2="${n(cy)}" stroke="${l.ink}" stroke-width="${n(r * 0.08)}" stroke-dasharray="${n(r * 0.18)} ${n(r * 0.18)}" opacity="0.5"/>`; o += `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(r)}" fill="${i % 2 ? l.color2 : l.color}"/>` + label(cx, cy + r * 0.34, String(i + 1), 'middle', onC(i % 2 ? l.color2 : l.color), r * 0.95, 800) + label(cx, cy + r + fs * 1.5, l.nodes[i]!.label); } break; }
    case 'cycle': { const R = Math.min(iw, ih) * 0.34, cx = w / 2, cy = h / 2, r = R * 0.34; o += `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(R)}" fill="none" stroke="${l.ink}" stroke-width="${n(r * 0.08)}" stroke-dasharray="${n(r * 0.2)} ${n(r * 0.2)}" opacity="0.45"/>`; for (let i = 0; i < N; i++) { const a = -Math.PI / 2 + (i / N) * Math.PI * 2, x = cx + Math.cos(a) * R, y = cy + Math.sin(a) * R; o += `<circle cx="${n(x)}" cy="${n(y)}" r="${n(r)}" fill="${i % 2 ? l.color2 : l.color}"/>` + label(x, y + fs * 0.35, l.nodes[i]!.label, 'middle', onC(i % 2 ? l.color2 : l.color), Math.min(fs, r * 0.42)); } break; }
    case 'pillars': { const bw = iw / N; o += `<polygon points="${n(pad)},${n(pad + ih * 0.2)} ${n(w / 2)},${n(pad)} ${n(w - pad)},${n(pad + ih * 0.2)}" fill="${l.ink}" opacity="0.85"/><rect x="${n(pad)}" y="${n(h - pad - ih * 0.08)}" width="${n(iw)}" height="${n(ih * 0.08)}" fill="${l.ink}" opacity="0.85"/>`; for (let i = 0; i < N; i++) { const x = pad + bw * i + bw * 0.12; o += `<rect x="${n(x)}" y="${n(pad + ih * 0.24)}" width="${n(bw * 0.76)}" height="${n(ih * 0.64)}" rx="${n(bw * 0.06)}" fill="${i % 2 ? l.color2 : l.color}"/>` + `<text transform="translate(${n(x + bw * 0.38 + fs * 0.35)} ${n(pad + ih * 0.56)}) rotate(-90)" font-family="${ff}" font-weight="700" font-size="${n(Math.min(fs, bw * 0.3))}" text-anchor="middle" fill="${onC(i % 2 ? l.color2 : l.color)}">${e(l.nodes[i]!.label)}</text>`; } break; }
    case 'funnel': { for (let i = 0; i < N; i++) { const y = pad + (ih / N) * i, t1 = iw * (1 - (i / N) * 0.62), t2 = iw * (1 - ((i + 1) / N) * 0.62), hh = ih / N - ih * 0.02; const c = i % 2 ? l.color2 : l.color; o += `<polygon points="${n(w / 2 - t1 / 2)},${n(y)} ${n(w / 2 + t1 / 2)},${n(y)} ${n(w / 2 + t2 / 2)},${n(y + hh)} ${n(w / 2 - t2 / 2)},${n(y + hh)}" fill="${c}"/>` + label(w / 2, y + hh / 2 + fs * 0.35, l.nodes[i]!.label, 'middle', onC(c)); } break; }
    case 'matrix': { const cw = iw / 2, ch = ih / 2; for (let i = 0; i < 4; i++) { const x = pad + (i % 2) * cw, y = pad + Math.floor(i / 2) * ch, c = [l.color, lighten(l.color, 0.5), lighten(l.color2, 0.5), l.color2][i] as string; o += `<rect x="${n(x + cw * 0.03)}" y="${n(y + ch * 0.04)}" width="${n(cw * 0.94)}" height="${n(ch * 0.92)}" rx="${n(ctx.U)}" fill="${c}"/>` + label(x + cw / 2, y + ch / 2 + fs * 0.35, l.nodes[i % N]!.label, 'middle', onC(c)); } break; }
    case 'timeline': { const y = h / 2; o += `<line x1="${n(pad)}" y1="${n(y)}" x2="${n(w - pad)}" y2="${n(y)}" stroke="${l.ink}" stroke-width="${n(ctx.U * 0.4)}" stroke-linecap="round"/>`; for (let i = 0; i < N; i++) { const x = pad + (iw / (N - 1)) * i; o += `<circle cx="${n(x)}" cy="${n(y)}" r="${n(ctx.U * 1.5)}" fill="${i % 2 ? l.color2 : l.color}" stroke="${l.surface ?? '#FFFFFF'}" stroke-width="${n(ctx.U * 0.4)}"/>` + label(x, i % 2 ? y + fs * 2.4 : y - fs * 1.5, l.nodes[i]!.label, i === 0 ? 'start' : i === N - 1 ? 'end' : 'middle'); } break; }
    case 'venn': { const R = Math.min(iw / (1.2 + N * 0.6), ih * 0.42); for (let i = 0; i < Math.min(N, 3); i++) { const cx = w / 2 + (i - (Math.min(N, 3) - 1) / 2) * R * 1.15, cy = N >= 3 && i === 1 ? h / 2 - R * 0.3 : h / 2 + (N >= 3 ? R * 0.2 : 0); const c = [l.color, l.color2, mix(l.color, l.color2, 0.5)][i] as string; o += `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(R)}" fill="${c}" opacity="0.72"/>` + label(cx + (i - (Math.min(N, 3) - 1) / 2) * R * 0.28, cy + fs * 0.35, l.nodes[i]!.label, 'middle', onC(c)); } break; }
    case 'ladder': { const sw = iw / N; for (let i = 0; i < N; i++) { const hh = (ih * (i + 1)) / N, x = pad + sw * i, c = i % 2 ? l.color2 : l.color; o += `<rect x="${n(x)}" y="${n(h - pad - hh)}" width="${n(sw * 0.94)}" height="${n(hh)}" rx="${n(ctx.U * 0.6)}" fill="${c}"/>` + label(x + sw * 0.47, h - pad - hh + fs * 1.5, l.nodes[i]!.label, 'middle', onC(c), Math.min(fs, sw * 0.2)); } break; }
    case 'list': { const rh = ih / N; for (let i = 0; i < N; i++) { const y = pad + rh * i + rh / 2; o += `<circle cx="${n(pad + rh * 0.3)}" cy="${n(y)}" r="${n(Math.min(rh * 0.26, fs * 0.8))}" fill="${i % 2 ? l.color2 : l.color}"/>` + label(pad + rh * 0.3, y + fs * 0.3, String(i + 1), 'middle', onC(i % 2 ? l.color2 : l.color), fs * 0.8, 800) + label(pad + rh * 0.3 + Math.min(rh * 0.5, fs * 1.6), y + fs * 0.35, l.nodes[i]!.label, 'start') + (i < N - 1 ? `<line x1="${n(pad)}" y1="${n(y + rh / 2)}" x2="${n(w - pad)}" y2="${n(y + rh / 2)}" stroke="${l.ink}" stroke-width="${n(ctx.U * 0.1)}" opacity="0.25"/>` : ''); } break; }
  }
  return svg(w, h, o, 'none');
}
function lum(hex: string): number { const v = parseInt(hex.slice(1), 16); return (0.299 * ((v >> 16) & 255) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; }

function chartSvg(l: LayerOf<'chart'>, ctx: RenderCtx): string {
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H, pad = Math.min(w, h) * 0.1, iw = w - pad * 2, ih = h - pad * 2, N = l.values.length, mx = Math.max(...l.values, 1);
  let o = l.surface ? `<rect width="${n(w)}" height="${n(h)}" rx="${n(ctx.U * 1.2)}" fill="${l.surface}"/>` : '';
  if (l.kind === 'bars') { const bw = iw / N; l.values.forEach((v, i) => { const bh = (v / mx) * ih * 0.9; o += `<rect x="${n(pad + bw * i + bw * 0.16)}" y="${n(h - pad - bh)}" width="${n(bw * 0.68)}" height="${n(bh)}" rx="${n(bw * 0.08)}" fill="${i === N - 1 ? l.color : l.color2}"/>`; }); o += `<line x1="${n(pad)}" y1="${n(h - pad)}" x2="${n(w - pad)}" y2="${n(h - pad)}" stroke="${l.ink}" stroke-width="${n(ctx.U * 0.2)}" opacity="0.5"/>`; }
  else if (l.kind === 'line') { const pts = l.values.map((v, i) => `${n(pad + (iw / (N - 1)) * i)},${n(h - pad - (v / mx) * ih * 0.9)}`); o += `<polygon points="${n(pad)},${n(h - pad)} ${pts.join(' ')} ${n(w - pad)},${n(h - pad)}" fill="${l.color2}" opacity="0.3"/><polyline points="${pts.join(' ')}" fill="none" stroke="${l.color}" stroke-width="${n(ctx.U * 0.7)}" stroke-linecap="round" stroke-linejoin="round"/>` + pts.map(p => `<circle cx="${p.split(',')[0]}" cy="${p.split(',')[1]}" r="${n(ctx.U * 0.9)}" fill="${l.color}"/>`).join(''); }
  else { const R = Math.min(iw, ih) / 2, cx = w / 2, cy = h / 2, tot = l.values.reduce((a, b) => a + b, 0) || 1; let a0 = -Math.PI / 2; l.values.forEach((v, i) => { const a1 = a0 + (v / tot) * Math.PI * 2, lg = a1 - a0 > Math.PI ? 1 : 0; o += `<path d="M${n(cx + Math.cos(a0) * R)} ${n(cy + Math.sin(a0) * R)}A${n(R)} ${n(R)} 0 ${lg} 1 ${n(cx + Math.cos(a1) * R)} ${n(cy + Math.sin(a1) * R)}L${n(cx)} ${n(cy)}Z" fill="${i === 0 ? l.color : i % 2 ? l.color2 : mix(l.color, l.color2, 0.5)}"/>`; a0 = a1; }); o += `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(R * 0.56)}" fill="${l.surface ?? ctx.roles.surface}"/>`; }
  return svg(w, h, o, 'none');
}

function frameSvg(l: LayerOf<'frame'>, ctx: RenderCtx): string {
  const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H, c = l.color, scr = paintCss(l.screen), U = ctx.U;
  const sh = l.shadow ? `filter:drop-shadow(0 ${n(U * 1.4)}px ${n(U * 3)}px rgba(0,0,0,.22));` : '';
  const div = (st: string, inner = ''): string => `<div style="position:absolute;box-sizing:border-box;${st}">${inner}</div>`;
  switch (l.kind) {
    case 'phone': return div(`inset:0;background:${c};border-radius:${n(w * 0.14)}px;${sh}`, div(`left:5%;right:5%;top:2.6%;bottom:2.6%;background:${scr};border-radius:${n(w * 0.1)}px`) + div(`left:36%;width:28%;top:4%;height:2.2%;background:${c};border-radius:${n(U)}px`));
    case 'tablet': return div(`inset:0;background:${c};border-radius:${n(Math.min(w, h) * 0.07)}px;${sh}`, div(`left:4%;right:4%;top:4%;bottom:4%;background:${scr};border-radius:${n(Math.min(w, h) * 0.03)}px`));
    case 'laptop': return div(`left:9%;right:9%;top:0;height:86%;background:${c};border-radius:${n(w * 0.025)}px ${n(w * 0.025)}px 0 0;${sh}`, div(`left:2.4%;right:2.4%;top:3.4%;bottom:3.4%;background:${scr};border-radius:${n(w * 0.008)}px`)) + div(`left:0;right:0;top:86%;height:9%;background:${lighten(c, 0.55)};border-radius:0 0 ${n(w * 0.03)}px ${n(w * 0.03)}px`) + div(`left:42%;width:16%;top:86%;height:2.4%;background:${lighten(c, 0.3)};border-radius:0 0 ${n(U)}px ${n(U)}px`);
    case 'browser': return div(`inset:0;background:${scr};border-radius:${n(U * 1.2)}px;overflow:hidden;border:${n(U * 0.2)}px solid ${c};${sh}`, div(`left:0;right:0;top:0;height:${n(Math.max(U * 3.4, h * 0.07))}px;background:${c}`, [0, 1, 2].map(i => div(`left:${n(U * (1.4 + i * 1.8))}px;top:50%;width:${n(U * 1.1)}px;height:${n(U * 1.1)}px;margin-top:-${n(U * 0.55)}px;border-radius:50%;background:${['#FF5F57', '#FEBC2E', '#28C840'][i]}`)).join('')));
    case 'polaroid': return div(`inset:0;background:#FFFFFF;${sh}`, div(`left:6%;right:6%;top:5%;bottom:22%;background:${scr}`));
    case 'card': return div(`inset:0;background:${scr};border-radius:${n(U * 1.6)}px;border:${n(U * 0.16)}px solid ${c};${sh}`);
    case 'page': return div(`inset:0;background:${scr};${sh}`) + div(`left:0;top:0;bottom:0;width:1.2%;background:${darken(c, 0.1)};opacity:.5`);
    case 'book': return div(`inset:0;background:${c};border-radius:${n(U * 0.5)}px ${n(U * 1.2)}px ${n(U * 1.2)}px ${n(U * 0.5)}px;${sh}`, div(`left:0;top:0;bottom:0;width:6%;background:${darken(c, 0.25)}`) + div(`left:12%;right:8%;top:8%;bottom:8%;background:${scr};border-radius:${n(U * 0.4)}px`));
  }
}

export const RENDERERS: Renderers = {
  background: l => `<div style="position:absolute;inset:0;background:${paintCss(l.fill)}"></div>`,
  environment: (l, ctx) => {
    const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H;
    return `<div style="position:absolute;inset:0;overflow:hidden${l.blur ? `;filter:blur(${px(ctx, l.blur / 10)})` : ''}">${svg(w, h, drawEnvironment(l.kind, w, h, ctx.tone, { seed: l.seed, horizon: l.horizon, busy: l.busy, lighting: ctx.lighting }), 'none')}</div>`;
  },
  figure: (l, ctx) => `<div style="position:absolute;inset:0${l.blur ? `;filter:blur(${px(ctx, l.blur / 10)})` : ''}">${svg(600, 1000, drawFigure(l.pose, l.look, ctx.tone, l.facing), 'xMidYMin meet')}</div>`,
  hands: (l, ctx) => svg(1000, 600, drawHands(l.look, ctx.tone, l.mode, l.seed), 'xMidYMax meet'),
  object: (l, ctx) => {
    const w = (l.box.w / 100) * ctx.W, h = (l.box.h / 100) * ctx.H;
    return `<div style="position:absolute;inset:0${l.blur ? `;filter:blur(${px(ctx, l.blur / 10)})` : ''}">${svg(w, h, drawProp(l.kind, ctx.tone, w, h, l.variant))}</div>`;
  },
  shape: shapeHtml,
  path: (l, ctx) => svg(l.viewBox[0], l.viewBox[1], `<path d="${e(l.d)}" fill="${l.fill ?? 'none'}"${l.stroke ? ` stroke="${l.stroke}" stroke-width="${n((l.strokeWidth ?? 0.5) * ctx.U * (l.viewBox[0] / ((l.box.w / 100) * ctx.W)))}" stroke-linecap="round" stroke-linejoin="round"` : ''}/>`, 'none'),
  pattern: patternSvg,
  texture: textureSvg,
  image: (l, ctx) => {
    let src = l.src;
    if (src.startsWith('asset:')) { const r = ctx.resolveAsset?.(src) ?? null; if (!r) { ctx.problems.push(`unresolved asset ${src}`); return `<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:${ctx.roles.surface};color:${ctx.roles.ink};font:600 ${px(ctx, 2)} ${FONT_STACK.jakarta};border:${px(ctx, 0.2)} dashed ${ctx.roles.ink}">Image unavailable</div>`; } src = r; }
    const w = (l.box.w / 100) * ctx.W;
    const mask = l.mask === 'circle' ? 'border-radius:50%;' : l.mask === 'rounded' ? `border-radius:${px(ctx, 2.4)};` : l.mask === 'arch' ? `border-radius:${n(w / 2)}px ${n(w / 2)}px 0 0;` : l.mask === 'blob' ? 'border-radius:42% 58% 55% 45% / 50% 42% 58% 50%;' : '';
    const tint = l.tint && l.tintAmount ? `<div style="position:absolute;inset:0;background:${l.tint};opacity:${l.tintAmount};mix-blend-mode:multiply"></div>` : '';
    return `<div style="position:absolute;inset:0;overflow:hidden;${mask}"><img src="${e(src)}" alt="${e(l.alt)}" style="width:100%;height:100%;display:block;object-fit:${l.fit};object-position:${n(l.focusX)}% ${n(l.focusY)}%"/>${tint}</div>`;
  },
  headline: (l, ctx) => `<div data-text="1" style="position:absolute;inset:0;${textCss(ctx, l)}overflow-wrap:break-word;text-wrap:balance">${textHtml(l.text)}</div>`,
  text: (l, ctx) => `<div data-text="1" style="position:absolute;inset:0;${textCss(ctx, l)}overflow-wrap:break-word">${textHtml(l.text)}</div>`,
  stat: (l, ctx) => `<div data-text="1" style="position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;text-align:${l.align};font-family:${FONT_STACK[l.font]}"><div style="font-size:${px(ctx, l.size)};font-weight:800;line-height:1;color:${l.color};letter-spacing:-0.02em">${e(l.value)}</div><div style="font-size:${px(ctx, Math.max(1.6, l.size * 0.2))};font-weight:600;line-height:1.25;margin-top:${px(ctx, l.size * 0.1)};color:${l.labelColor};font-family:${FONT_STACK.jakarta}">${e(l.label)}</div></div>`,
  badge: (l, ctx) => {
    const common = `position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;font-family:${FONT_STACK[l.font]};font-weight:700;font-size:${px(ctx, l.size)};color:${l.color};line-height:1.05;letter-spacing:.04em;text-transform:uppercase;box-sizing:border-box;padding:0 ${px(ctx, l.size * 0.6)};`;
    if (l.shape === 'circle') return `<div data-text="1" style="${common}background:${l.fill};border-radius:50%">${textHtml(l.text)}</div>`;
    if (l.shape === 'stamp') return `<div data-text="1" style="${common}border:${px(ctx, 0.35)} solid ${l.fill};color:${l.fill};border-radius:${px(ctx, 0.8)};transform:rotate(-6deg)">${textHtml(l.text)}</div>`;
    if (l.shape === 'ribbon') return `<div data-text="1" style="${common}background:${l.fill};clip-path:polygon(0 0,100% 0,94% 50%,100% 100%,0 100%,6% 50%)">${textHtml(l.text)}</div>`;
    if (l.shape === 'tag') return `<div data-text="1" style="${common}background:${l.fill};border-radius:${px(ctx, 0.6)}">${textHtml(l.text)}</div>`;
    return `<div data-text="1" style="${common}background:${l.fill};border-radius:999px">${textHtml(l.text)}</div>`;
  },
  cta: (l, ctx) => {
    const icon = l.icon === 'arrow' ? ' →' : l.icon === 'download' ? ' ↓' : '';
    const play = l.icon === 'play' ? `<span style="display:inline-block;width:0;height:0;border-left:${px(ctx, l.size * 0.7)} solid ${l.color};border-top:${px(ctx, l.size * 0.42)} solid transparent;border-bottom:${px(ctx, l.size * 0.42)} solid transparent;margin-right:${px(ctx, l.size * 0.5)}"></span>` : '';
    const st = l.style === 'outline' ? `border:${px(ctx, 0.3)} solid ${l.fill};color:${l.fill};` : `background:${l.fill};color:${l.color};`;
    return `<div data-text="1" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;box-sizing:border-box;${st}border-radius:${l.style === 'bar' ? '0' : px(ctx, l.radius)};font-family:${FONT_STACK[l.font]};font-weight:700;font-size:${px(ctx, l.size)};letter-spacing:.01em;white-space:nowrap">${play}${e(l.text)}${icon}</div>`;
  },
  annotation: (l, ctx) => {
    const arrows: Record<string, string> = { left: 'M90 30 Q50 10 12 44 M12 44 l16 -2 M12 44 l6 -15', right: 'M10 30 Q50 10 88 44 M88 44 l-16 -2 M88 44 l-6 -15', up: 'M50 90 Q30 50 52 12 M52 12 l-12 10 M52 12 l8 14', down: 'M50 10 Q30 50 52 88 M52 88 l-12 -10 M52 88 l8 -14' };
    const arrow = l.arrow !== 'none' ? `<svg viewBox="0 0 100 100" style="width:${px(ctx, l.size * 1.6)};height:${px(ctx, l.size * 1.6)};flex:none" aria-hidden="true"><path d="${arrows[l.arrow]}" fill="none" stroke="${l.color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>` : '';
    return `<div data-text="1" style="position:absolute;inset:0;display:flex;align-items:center;gap:${px(ctx, l.size * 0.2)};flex-direction:${l.arrow === 'left' ? 'row' : l.arrow === 'right' ? 'row-reverse' : l.arrow === 'up' ? 'column' : 'column-reverse'};font-family:${FONT_STACK.caveat};font-weight:700;font-size:${px(ctx, l.size)};color:${l.color};line-height:1;text-align:center;transform:rotate(-3deg)">${arrow}<span>${textHtml(l.text)}</span></div>`;
  },
  logo: (l, ctx) => {
    if (l.src) { const src = l.src.startsWith('asset:') ? ctx.resolveAsset?.(l.src) ?? '' : l.src; if (src) return `<img src="${e(src)}" alt="${e(l.text)} logo" style="position:absolute;inset:0;width:100%;height:100%;object-fit:contain"/>`; ctx.problems.push(`unresolved logo ${l.src}`); }
    const m = l.mark === 'dot' ? `<span style="width:.62em;height:.62em;border-radius:50%;background:${l.color};display:inline-block"></span>` : l.mark === 'square' ? `<span style="width:.62em;height:.62em;border-radius:.12em;background:${l.color};display:inline-block"></span>` : l.mark === 'ring' ? `<span style="width:.62em;height:.62em;border-radius:50%;border:.12em solid ${l.color};box-sizing:border-box;display:inline-block"></span>` : '';
    return `<div data-text="1" style="position:absolute;inset:0;display:flex;align-items:center;gap:.4em;font-family:${FONT_STACK[l.font]};font-weight:700;font-size:${px(ctx, l.size)};color:${l.color};letter-spacing:.02em;white-space:nowrap">${m}<span>${e(l.text)}</span></div>`;
  },
  diagram: diagramSvg,
  chart: chartSvg,
  frame: frameSvg,
  group: (l, ctx) => l.children.map(c => renderLayer(c, ctx)).join(''),
};

export function renderLayer(l: VisualLayer, ctx: RenderCtx, z = 0): string {
  if (l.hidden) return '';
  const inner = (RENDERERS[l.type] as (x: VisualLayer, c: RenderCtx) => string)(l, ctx);
  const st = `left:${n(l.box.x)}%;top:${n(l.box.y)}%;width:${n(l.box.w)}%;height:${n(l.box.h)}%;${l.opacity !== undefined && l.opacity < 1 ? `opacity:${l.opacity};` : ''}${l.rotation ? `transform:rotate(${n(l.rotation)}deg);` : ''}${l.blend && l.blend !== 'normal' ? `mix-blend-mode:${l.blend};` : ''}${z ? `z-index:${z};` : ''}`;
  return `<div class="l" data-layer="${e(l.id)}" data-type="${l.type}"${l.role === 'concept' ? ' data-role="concept"' : ''} style="${st}">${inner}</div>`;
}

/** Editor metadata: which layer types carry editable text, and human labels. */
export const LAYER_META: Record<VisualLayer['type'], { label: string; text: boolean; icon: string }> = {
  background: { label: 'Background', text: false, icon: '▧' }, environment: { label: 'Illustrated setting', text: false, icon: '⌂' },
  figure: { label: 'Person (illustrated)', text: false, icon: '☺' }, hands: { label: 'Hands (illustrated)', text: false, icon: '✋' },
  object: { label: 'Object', text: false, icon: '◆' }, shape: { label: 'Shape', text: false, icon: '■' }, path: { label: 'Vector path', text: false, icon: '〰' },
  pattern: { label: 'Pattern', text: false, icon: '▦' }, texture: { label: 'Texture', text: false, icon: '░' }, image: { label: 'Photo', text: false, icon: '▣' },
  headline: { label: 'Headline', text: true, icon: 'H' }, text: { label: 'Text', text: true, icon: 'T' }, stat: { label: 'Number', text: true, icon: '#' },
  badge: { label: 'Badge', text: true, icon: '◉' }, cta: { label: 'Button', text: true, icon: '▭' }, annotation: { label: 'Handwritten note', text: true, icon: '✎' },
  logo: { label: 'Logo', text: true, icon: '◎' }, diagram: { label: 'Diagram', text: false, icon: '⬡' }, chart: { label: 'Chart (illustrative)', text: false, icon: '▁' },
  frame: { label: 'Frame', text: false, icon: '▢' }, group: { label: 'Group', text: false, icon: '❏' },
};
export { buildTone };
