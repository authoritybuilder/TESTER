/**
 * Scene planner (deterministic tier): CanonicalScene (+ brand + overrides) → VisualSceneSpec.
 *
 * It composes from the scene's own creative DNA — subject kind, parsed framing geometry, parsed safe zones,
 * environment, source props, pose, lighting variant, design principle, conversion intent, palette — so two
 * scenes only share a composition when their source briefs genuinely share those facts.
 * Ambiguous / high-value scenes can be upgraded by the Claude creative-director tier (creative-director.ts),
 * which must return the same schema.
 */
import type { CanonicalScene, Zone } from '../catalog/schema.ts';
import { clamp, contrast, darken, hash53, inkOn, lighten, luminance, mix, pick, rng, round, saturation, truncateWords } from '../shared/util.ts';
import { fitText, slotCopy, textWidth, type BrandContext } from './copy.ts';
import { buildLook, type FigurePose } from './illustration/figures.ts';
import { hasProp, resolveProp } from './illustration/props.ts';
import { COMPILER_VERSION, RENDERER_VERSION, SPEC_VERSION, validateSpec, type Box, type ColourRoles, type FontKey, type Paint, type VisualLayer, type VisualSceneSpec } from './scene-schema.ts';

export interface PlanOptions {
  brand?: BrandContext;
  target?: { width: number; height: number; placement?: string };
  direction?: 'source' | 'editorial' | 'minimal' | 'bold';
  photo?: { src: string; alt: string; note: string };
  copy?: Record<string, string>;
}

// ------------------------------------------------------------------ colour roles
export function deriveRoles(palette: string[], bg: string, brand?: BrandContext): ColourRoles {
  const bp = brand?.palette;
  const pal = (bp ? [bp.primary, bp.secondary, bp.accent, bp.light, bp.dark] : palette).map(c => c.toUpperCase());
  const byLum = [...pal].sort((a, b) => luminance(a) - luminance(b));
  let dark = bp?.dark ?? byLum[0]!; let light = bp?.light ?? byLum[byLum.length - 1]!;
  if (luminance(dark) > 0.12) dark = darken(dark, 0.72);
  if (luminance(light) < 0.78) light = lighten(light, 0.86);
  const mids = pal.filter(c => c !== byLum[0] || luminance(c) > 0.12).filter(c => luminance(c) < 0.9).sort((a, b) => saturation(b) * (1 - Math.abs(luminance(b) - 0.4)) - saturation(a) * (1 - Math.abs(luminance(a) - 0.4)));
  const primary = bp?.primary ?? mids[0] ?? byLum[Math.floor(byLum.length / 2)]!;
  const secondary = bp?.secondary ?? mids.find(c => c !== primary) ?? mix(primary, light, 0.5);
  let accent = bp?.accent ?? mids.find(c => c !== primary && c !== secondary) ?? mix(primary, '#F0A030', 0.6);
  if (contrast(accent, primary) < 1.25) accent = luminance(primary) > 0.4 ? darken(accent, 0.35) : lighten(accent, 0.4);
  const background = bg === 'solid_color_brand' ? primary : bg === 'studio_white' ? mix('#F8F7F4', light, 0.3) : /texture_paper/.test(bg) ? mix('#F3EDE2', light, 0.4) : /gradient_bold|cinematic/.test(bg) ? dark : light;
  return { background, surface: luminance(background) > 0.5 ? '#FFFFFF' : lighten(background, 0.1), ink: inkOn(background, dark, light), primary, secondary, accent, light, dark };
}

// ------------------------------------------------------------------ builder
class B {
  layers: VisualLayer[] = []; private seen = new Map<string, number>();
  constructor(readonly W: number, readonly H: number, readonly roles: ColourRoles) {}
  get U(): number { return Math.min(this.W, this.H) / 100; }
  id(base: string): string { const k = base.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 34) || 'layer'; const c = (this.seen.get(k) ?? 0) + 1; this.seen.set(k, c); return c === 1 ? k : `${k}-${c}`; }
  add<T extends VisualLayer>(l: T): T { this.layers.push(l); return l; }
}
const box = (x: number, y: number, w: number, h: number): Box => ({ x: round(clamp(x, -60, 160)), y: round(clamp(y, -60, 160)), w: round(clamp(w, 0.5, 220)), h: round(clamp(h, 0.5, 220)) });
const solid = (color: string, alpha?: number): Paint => (alpha === undefined ? { kind: 'solid', color } : { kind: 'solid', color, alpha });

interface P { s: CanonicalScene; o: PlanOptions; b: B; r: () => number; zones: Zone[]; fonts: { headline: FontKey; body: FontKey; accent: FontKey }; envBehind: boolean; motifs: string[]; hierarchy: string[] }

// ------------------------------------------------------------------ zones across aspect ratios
export function adaptZones(zones: Zone[], nw: number, nh: number, W: number, H: number): Zone[] {
  const a0 = nw / nh, a1 = W / H;
  if (Math.abs(Math.log(a0 / a1)) < 0.2) return zones.map(z => ({ ...z }));
  const out: Zone[] = [];
  for (const z of zones) {
    const side = z.height >= 80 && z.width <= 70, band = z.width >= 80 && z.height <= 60;
    if (a1 < a0 && side) { const h = clamp(z.width * 0.95, 26, 44); out.push({ ...z, x: 0, width: 100, y: 100 - h, height: h }); }
    else if (a1 > a0 * 1.25 && band && z.height >= 22) { const w = clamp(z.height * 1.5, 34, 50); out.push({ ...z, y: 0, height: 100, x: 100 - w, width: w }); }
    else if (band && a1 < a0) out.push({ ...z, height: clamp(z.height * (a0 / a1) * 0.6, z.height * 0.6, z.height) , y: z.y > 50 ? 100 - clamp(z.height * (a0 / a1) * 0.6, z.height * 0.6, z.height) : z.y });
    else out.push({ ...z });
  }
  // stack colliding bottom bands
  let bottom = 100;
  for (const z of out.filter(q => q.width >= 80 && q.y + q.height > 60).sort((p, q) => q.y + q.height - (p.y + p.height))) { if (z.y + z.height > bottom) z.y = bottom - z.height; bottom = z.y; }
  return out;
}

// ------------------------------------------------------------------ text overlays for zones
function headlineFont(p: P): FontKey {
  if (p.o.brand?.headlineFont) return p.o.brand.headlineFont;
  const { s } = p; const a = s.asset_type;
  if (p.o.direction === 'editorial') return 'fraunces';
  if (p.o.direction === 'bold') return 'anton';
  if (/Video|Tiktok|Thumbnail|Advertising\/Disruption|Hook|Youtube|Series/.test(a) || s.conversion_intent === 'pattern_interrupt') return 'anton';
  if (/Editorial|Event|Brand\/|Premium|Mentoring|High-ticket|Bonus|Email\/Newsletter|Programme|Lifestyle|Fashion|Pinterest/.test(a) || /magazine|editorial/.test(s.background_style + s.render_style) || s.conversion_intent === 'premium_signaling') return 'fraunces';
  return 'jakarta';
}

function zoneOverlay(p: P, z: Zone, index: number): void {
  const { b, s } = p; const R = b.roles; const U = b.U, W = b.W, H = b.H;
  if (z.role === 'ui' || z.role === 'visual') return;
  const copy = slotCopy(z.purpose, z.role, p.o.brand);
  const key = `${z.role}-${index}`;
  const headText = p.o.copy?.[key] ?? copy.headline;
  const status = p.o.copy?.[key] ? 'user' as const : copy.status;
  const zw = (z.width / 100) * W, zh = (z.height / 100) * H;
  const isSide = z.height >= 80 && z.width < 80, isBand = z.width >= 80 && z.height < 70, isCorner = z.width < 40 && z.height < 30;
  const hf = p.fonts.headline;

  // --- surface behind the copy (only when an illustrated/photographic scene sits behind it)
  let ink = R.ink; let padX = isSide ? 9 : 6, padY = isBand ? 14 : 8;
  if (p.envBehind && !isCorner) {
    const premium = s.conversion_intent === 'premium_signaling' || s.conversion_intent === 'fomo_urgency' || /cinematic|gradient_bold/.test(s.background_style);
    const mode = z.role === 'quote' || (!isSide && !isBand) ? 'card' : s.design_principle === 'negative_space' || s.conversion_intent === 'aspirational' ? 'scrim' : 'panel';
    const fill = premium ? R.dark : mode === 'scrim' ? (isBand && z.y > 40 ? R.dark : hash53(s.id + 'scrim') % 2 ? R.dark : R.light) : mode === 'card' ? (hash53(s.id) % 4 === 0 ? R.dark : '#FFFFFF') : hash53(s.id) % 3 === 0 ? R.primary : hash53(s.id) % 3 === 1 ? R.dark : R.surface;
    ink = inkOn(fill, R.dark, '#FFFFFF');
    if (mode === 'panel') b.add({ id: b.id('panel-' + z.role), name: 'Copy panel', type: 'shape', shape: 'rect', box: box(z.x, z.y, z.width, z.height), fill: solid(fill, 0.94) });
    else if (mode === 'scrim') {
      const angle = isSide ? (z.x < 30 ? 90 : 270) : z.y < 30 ? 180 : 0;
      b.add({ id: b.id('scrim-' + z.role), name: 'Legibility scrim', type: 'shape', shape: 'rect', box: box(isSide ? z.x - (z.x < 30 ? 0 : 14) : z.x, isBand ? z.y - (z.y < 30 ? 0 : 10) : z.y, z.width + (isSide ? 14 : 0), z.height + (isBand ? 10 : 0)), fill: { kind: 'linear', angle, stops: [{ color: fill, at: 0, alpha: 0.94 }, { color: fill, at: 55, alpha: 0.78 }, { color: fill, at: 100, alpha: 0 }] } });
    } else { b.add({ id: b.id('card-' + z.role), name: 'Copy card', type: 'shape', shape: 'rect', box: box(z.x, z.y, z.width, z.height), fill: solid(fill, 0.93), radius: 2.2, shadow: true }); padX = 8; padY = 10; }
  } else if (isCorner && p.envBehind) ink = '#FFFFFF';

  const ix = z.x + (z.width * padX) / 100, iy = z.y + (z.height * padY) / 100, iw = z.width * (1 - (2 * padX) / 100), ih = z.height * (1 - (2 * padY) / 100);
  const iwPx = (iw / 100) * W, ihPx = (ih / 100) * H;
  const align = isSide ? 'left' as const : (z.role === 'details' && isCorner) ? 'right' as const : (isBand && hash53(s.id + 'al') % 2 === 0) || z.role === 'quote' || z.role === 'number' || z.role === 'message' || !isBand ? (isSide ? 'left' as const : 'center' as const) : 'left' as const;

  switch (z.role) {
    case 'cta': {
      if (isBand && z.height <= 13) { b.add({ id: b.id('cta-bar'), name: 'Call-to-action bar', type: 'cta', box: box(z.x, z.y, z.width, z.height), text: headText, fill: R.accent, color: inkOn(R.accent, R.dark, '#FFFFFF'), font: 'jakarta', size: round(clamp((zh / U) * 0.36, 1.8, 4.2)), radius: 0, icon: 'arrow', style: 'bar', copyStatus: status }); }
      else { const bw = clamp(headText.length * 1.9 + 10, 18, isSide ? iw : 46) * (U * 100 / W) ; const bh = clamp(7, 4, 9) * (U * 100 / H);
        if (!isCorner) headlineBlock(p, { ...z, height: z.height * 0.62 }, 'Your headline goes here', 'suggested', ink, align, false);
        b.add({ id: b.id('cta'), name: 'Call-to-action button', type: 'cta', box: box(align === 'center' ? z.x + (z.width - bw) / 2 : ix, z.y + z.height * (isCorner ? 0.2 : 0.7), bw, bh), text: headText, fill: R.accent, color: inkOn(R.accent, R.dark, '#FFFFFF'), font: 'jakarta', size: 2.6, radius: 4, icon: 'arrow', style: 'solid', copyStatus: status }); }
      p.hierarchy.push('call to action: ' + headText); return;
    }
    case 'quote': {
      const qs = fitText(headText, iwPx, ihPx * 0.6, 'fraunces', U, isSide ? 5.2 : 6, 2.2, 1.22, false, 400);
      b.add({ id: b.id('quote-mark'), name: 'Quote mark', type: 'headline', box: box(ix, iy - ih * 0.04, iw, ih * 0.2), text: '“', font: 'fraunces', weight: 700, size: round(Math.min(18, (ihPx * 0.34) / U)), color: R.accent, align, lineHeight: 0.9, copyStatus: 'suggested' });
      b.add({ id: b.id('quote'), name: 'Client quote (add a real one)', type: 'text', box: box(ix, iy + ih * 0.2, iw, ih * 0.56), text: headText.replace(/[“”]/g, ''), font: 'fraunces', weight: 400, italic: true, size: qs, color: ink, align, valign: 'top', lineHeight: 1.22, copyStatus: status });
      b.add({ id: b.id('quote-credit'), name: 'Quote attribution', type: 'text', box: box(ix, iy + ih * 0.8, iw, ih * 0.2), text: copy.details, font: 'jakarta', weight: 600, size: round(clamp(qs * 0.44, 1.5, 2.4)), color: ink, align, valign: 'bottom', lineHeight: 1.2, tracking: 0.04, uppercase: true, copyStatus: 'suggested' });
      p.hierarchy.push('proof placeholder: client quote'); return;
    }
    case 'masthead': {
      const ms = fitText(headText, iwPx, ihPx * 0.72, hf === 'jakarta' ? 'fraunces' : hf, U, 26, 4, 1, true, 900);
      b.add({ id: b.id('masthead'), name: 'Masthead', type: 'headline', box: box(ix, iy, iw, ih * 0.74), text: headText, font: hf === 'jakarta' ? 'fraunces' : hf, weight: 900, size: ms, color: ink, align: isBand ? 'center' : 'left', valign: 'middle', lineHeight: 1, tracking: 0.02, uppercase: true, copyStatus: status });
      b.add({ id: b.id('masthead-line'), name: 'Issue line', type: 'text', box: box(ix, iy + ih * 0.78, iw, ih * 0.2), text: copy.details, font: 'jakarta', weight: 600, size: round(clamp(ms * 0.16, 1.4, 2.4)), color: ink, align: isBand ? 'center' : 'left', lineHeight: 1.2, tracking: 0.18, uppercase: true, copyStatus: 'suggested' });
      p.hierarchy.push('masthead'); return;
    }
    case 'number': {
      b.add({ id: b.id('number'), name: 'Large number', type: 'stat', box: box(ix, iy, iw, ih), value: headText, label: copy.details, font: p.fonts.headline === 'jakarta' ? 'fraunces' : p.fonts.headline, color: ink, labelColor: R.accent, size: round(clamp((Math.min(iwPx, ihPx) / U) * 0.62, 8, 60)), align: 'center', verified: true, copyStatus: status });
      p.hierarchy.push('table number'); return;
    }
    case 'logo': {
      const lz = isCorner || z.height < 30 ? z : { ...z, y: z.y + z.height * 0.3, height: z.height * 0.4 };
      b.add({ id: b.id('logo'), name: 'Brand mark', type: 'logo', box: box(lz.x + lz.width * 0.1, lz.y + lz.height * 0.2, lz.width * 0.8, lz.height * 0.6), text: headText, ...(p.o.brand?.logoSrc ? { src: p.o.brand.logoSrc } : {}), color: p.envBehind ? '#FFFFFF' : R.ink, font: hf, size: round(clamp(Math.min(((lz.height / 100) * H / U) * 0.3, (((lz.width * 0.8) / 100) * W * 0.9) / ((textWidth(headText, hf, false, 700) + 1.1) * U)), 1.4, 5)), mark: 'ring', copyStatus: status });
      return;
    }
    case 'signature': { b.add({ id: b.id('signature'), name: 'Signature', type: 'annotation', box: box(ix, iy, iw, ih), text: headText, color: ink, size: round(clamp((ihPx / U) * 0.4, 3, 9)), arrow: 'none', copyStatus: status }); return; }
    case 'message': { const fs = fitText(headText, iwPx, ihPx, 'fraunces', U, 7, 2.4, 1.2, false, 400); b.add({ id: b.id('message'), name: 'Message', type: 'headline', box: box(ix, iy, iw, ih), text: headText, font: 'fraunces', weight: 400, italic: true, size: fs, color: ink, align: 'center', valign: 'middle', lineHeight: 1.2, copyStatus: status }); p.hierarchy.push('message'); return; }
    case 'list': { b.add({ id: b.id('list'), name: 'List', type: 'diagram', kind: 'list', box: box(ix, iy, iw, ih), nodes: [{ label: 'First course' }, { label: 'Second course' }, { label: 'Third course' }, { label: 'To finish' }], color: R.accent, color2: R.primary, ink, font: 'fraunces', size: round(clamp((ihPx / U) * 0.07, 1.8, 3.6)), copyStatus: 'suggested' }); p.hierarchy.push('course list'); return; }
    case 'body': { for (let i = 0; i < 7; i++) b.add({ id: b.id('body-line'), name: 'Body copy (implied)', type: 'shape', shape: 'rect', box: box(ix, iy + ih * (0.12 + i * 0.115), iw * (i === 6 ? 0.55 : i % 3 === 2 ? 0.9 : 1), Math.max(0.6, ih * 0.035)), fill: solid(ink, 0.22), radius: 0.4 }); return; }
    case 'details': { const fs = fitText(headText, iwPx, ihPx, 'jakarta', U, isCorner ? 2.6 : 3.4, 1.3, 1.25, true, 600); b.add({ id: b.id('details'), name: 'Details line', type: 'text', box: box(ix, iy, iw, ih), text: headText, font: 'jakarta', weight: 600, size: fs, color: ink, align: isCorner ? 'right' : align, valign: 'middle', lineHeight: 1.25, tracking: 0.08, uppercase: true, copyStatus: status }); p.hierarchy.push('details: ' + headText); return; }
  }
  headlineBlock(p, z, headText, status, ink, align, true, copy.details);
}

function headlineBlock(p: P, z: Zone, text: string, status: 'suggested' | 'brand-kit' | 'user', ink: string, align: 'left' | 'center' | 'right', withDetails: boolean, details = ''): void {
  const { b } = p; const U = b.U, W = b.W, H = b.H; const hf = p.fonts.headline;
  const isSide = z.height >= 80 && z.width < 80, isBand = z.width >= 80 && z.height < 70;
  const padX = isSide ? 10 : 6, padY = isBand ? 14 : 9;
  const ix = z.x + (z.width * padX) / 100, iw = z.width * (1 - (2 * padX) / 100);
  let iy = z.y + (z.height * padY) / 100, ih = z.height * (1 - (2 * padY) / 100);
  if (isSide) { iy = z.y + z.height * 0.24; ih = z.height * 0.52; }
  const hasD = withDetails && !!details;
  const hH = hasD ? ih * 0.66 : ih;
  const upper = hf === 'anton';
  const geo = (Math.sqrt(((iw / 100) * W) * ((ih / 100) * H)) / U) * 0.16;
  const max = clamp(geo, 4.5, hf === 'anton' ? 17 : hf === 'fraunces' ? 12 : 11);
  const wantsCta = /\bcta\b|button/i.test(z.purpose) && z.height > 30 && !p.zones.some(q => q.role === 'cta');
  if (wantsCta) ih *= 0.74;
  const fs = fitText(text, (iw / 100) * W, (hH / 100) * H, hf, U, isBand && z.height < 22 ? Math.min(max, ((z.height / 100) * H / U) * 0.42) : max, 1.6, hf === 'anton' ? 1.02 : 1.1, upper, hf === 'jakarta' ? 800 : 700);
  if (isSide) b.add({ id: b.id('rule'), name: 'Accent rule', type: 'shape', shape: 'rect', box: box(ix, iy - 3.2, Math.min(iw * 0.22, 9), 0.9 * (U * 100 / H) * 0.6), fill: solid(b.roles.accent), radius: 0.3 });
  b.add({ id: b.id('headline'), name: 'Headline', type: 'headline', box: box(ix, iy, iw, hH), text, font: hf, weight: hf === 'jakarta' ? 800 : hf === 'fraunces' ? 600 : 400, size: fs, color: ink, align, valign: isSide ? 'top' : 'middle', lineHeight: hf === 'anton' ? 1.02 : 1.1, tracking: hf === 'jakarta' ? -0.02 : hf === 'anton' ? 0.01 : -0.01, uppercase: upper, copyStatus: status });
  if (hasD) b.add({ id: b.id('subline'), name: 'Supporting line', type: 'text', box: box(ix, iy + hH + ih * 0.04, iw, ih * 0.3), text: details, font: 'jakarta', weight: 600, size: round(clamp(fs * 0.36, 1.5, 3)), color: ink, align, valign: 'top', lineHeight: 1.3, tracking: 0.06, uppercase: true, copyStatus: 'suggested' });
  if (wantsCta) { const c = slotCopy(z.purpose, 'cta', p.o.brand); const bw = clamp(c.headline.length * 1.7 + 9, 16, iw) * (W >= H ? H / W : 1) , bh = 6.4 * (W >= H ? 1 : W / H); b.add({ id: b.id('cta'), name: 'Call-to-action button', type: 'cta', box: box(align === 'center' ? ix + (iw - bw) / 2 : ix, iy + ih + (isSide ? 4 : 2), bw, bh), text: c.headline, fill: b.roles.accent, color: inkOn(b.roles.accent, b.roles.dark, '#FFFFFF'), font: 'jakarta', size: 2.4, radius: 4, icon: 'arrow', style: 'solid', copyStatus: c.status }); p.hierarchy.push('call to action: ' + c.headline); }
  p.hierarchy.push('headline: ' + truncateWords(text, 40));
}

// ------------------------------------------------------------------ shared scene pieces
function lightingFinish(p: P, subjectX = 50, subjectY = 40): void {
  const { b, s } = p; const lv = s.dna.lightingVariant.toLowerCase(); const photo = /realistic|photo/.test(s.render_style);
  if (/golden/.test(lv)) b.add({ id: b.id('golden-hour'), name: 'Golden-hour light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 200, stops: [{ color: '#FFB45A', at: 0, alpha: 0.34 }, { color: '#FF8A3D', at: 55, alpha: 0.08 }, { color: '#3B1E08', at: 100, alpha: 0.14 }] }, blend: 'soft-light', role: 'concept' });
  else if (/blue hour/.test(lv)) b.add({ id: b.id('blue-hour'), name: 'Blue-hour light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 180, stops: [{ color: '#22306B', at: 0, alpha: 0.4 }, { color: '#F2A65A', at: 100, alpha: 0.16 }] }, blend: 'multiply', role: 'concept' });
  else if (/tungsten/.test(lv)) b.add({ id: b.id('tungsten'), name: 'Warm tungsten light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'radial', cx: subjectX, cy: subjectY, stops: [{ color: '#FFC27A', at: 0, alpha: 0.3 }, { color: '#5A2E0A', at: 100, alpha: 0.3 }] }, blend: 'soft-light', role: 'concept' });
  else if (/backlit/.test(lv)) b.add({ id: b.id('backlight-halo'), name: 'Backlit halo', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'radial', cx: subjectX, cy: subjectY, stops: [{ color: '#FFF2D0', at: 0, alpha: 0.75 }, { color: '#FFF2D0', at: 34, alpha: 0.12 }, { color: '#FFF2D0', at: 60, alpha: 0 }] }, blend: 'screen', role: 'concept' });
  else if (/overcast/.test(lv)) b.add({ id: b.id('overcast'), name: 'Overcast soft light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: solid('#C7CED6', 0.16), role: 'concept' });
  else if (/window/.test(lv)) b.add({ id: b.id('window-light'), name: 'Window light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 115, stops: [{ color: '#FFF6E0', at: 0, alpha: 0.4 }, { color: '#FFF6E0', at: 50, alpha: 0 }] }, blend: 'screen', role: 'concept' });
  else {
    // remaining source variants: each gets its own light direction + colour temperature so variants of one base scene stay distinct
    const full = box(0, 0, 100, 100); const L = (id: string, name: string, fill: Paint, blend?: 'multiply' | 'screen' | 'soft-light'): void => { b.add({ id: b.id(id), name, type: 'shape', shape: 'rect', box: full, fill, role: 'concept', ...(blend ? { blend } : {}) }); };
    if (/studio light/.test(lv)) L('studio-light', 'Studio key light', { kind: 'radial', cx: 50, cy: 8, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.36 }, { color: '#FFFFFF', at: 55, alpha: 0 }, { color: '#1B2A3A', at: 100, alpha: 0.14 }] });
    else if (/side-lit/.test(lv)) L('side-light', 'Dramatic side light', { kind: 'linear', angle: 90, stops: [{ color: '#0B0F14', at: 0, alpha: 0.56 }, { color: '#0B0F14', at: 48, alpha: 0.08 }, { color: '#FFE7C2', at: 100, alpha: 0.22 }] });
    else if (/top-down/.test(lv)) L('top-light', 'Top-down daylight', { kind: 'radial', cx: 50, cy: 0, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.5 }, { color: '#FFFFFF', at: 60, alpha: 0.04 }, { color: '#2B3440', at: 100, alpha: 0.12 }] });
    else if (/cinematic rim/.test(lv)) { L('rim-grade', 'Cinematic rim grade', { kind: 'linear', angle: 100, stops: [{ color: '#0E2A3A', at: 0, alpha: 0.46 }, { color: '#0E2A3A', at: 50, alpha: 0.1 }, { color: '#F2994A', at: 100, alpha: 0.26 }] }); b.add({ id: b.id('rim-vignette'), name: 'Rim vignette', type: 'texture', kind: 'vignette', box: full, color: '#000000', intensity: 0.5, role: 'concept' }); }
    else if (/garden/.test(lv)) L('garden-light', 'Dappled garden light', { kind: 'radial', cx: 22, cy: 12, stops: [{ color: '#E9F7C9', at: 0, alpha: 0.5 }, { color: '#BFE08A', at: 45, alpha: 0.12 }, { color: '#1F3A1C', at: 100, alpha: 0.16 }] });
    else if (/city skyline/.test(lv)) L('skyline-light', 'City dusk light', { kind: 'linear', angle: 180, stops: [{ color: '#27406B', at: 0, alpha: 0.34 }, { color: '#27406B', at: 55, alpha: 0.04 }, { color: '#F2A65A', at: 100, alpha: 0.2 }] });
    else if (/library/.test(lv)) L('library-light', 'Library lamp light', { kind: 'radial', cx: 78, cy: 30, stops: [{ color: '#FFD28A', at: 0, alpha: 0.42 }, { color: '#6A3F16', at: 100, alpha: 0.3 }] }, 'soft-light');
    else if (/coastal/.test(lv)) L('coastal-light', 'Coastal light', { kind: 'linear', angle: 180, stops: [{ color: '#CDEFFA', at: 0, alpha: 0.48 }, { color: '#FFFFFF', at: 50, alpha: 0.06 }, { color: '#E8D2A6', at: 100, alpha: 0.26 }] });
    else if (/mountain/.test(lv)) L('mountain-light', 'Mountain light', { kind: 'linear', angle: 135, stops: [{ color: '#EAF2FB', at: 0, alpha: 0.44 }, { color: '#EAF2FB', at: 45, alpha: 0.02 }, { color: '#2A3B52', at: 100, alpha: 0.26 }] });
    else if (/boardroom/.test(lv)) L('boardroom-light', 'Boardroom light', { kind: 'linear', angle: 180, stops: [{ color: '#DDE6EE', at: 0, alpha: 0.3 }, { color: '#1F2A36', at: 100, alpha: 0.2 }] });
    else if (/hotel lobby/.test(lv)) L('lobby-light', 'Hotel-lobby glow', { kind: 'radial', cx: 76, cy: 18, stops: [{ color: '#FFD9A0', at: 0, alpha: 0.5 }, { color: '#FFD9A0', at: 40, alpha: 0.08 }, { color: '#3A2412', at: 100, alpha: 0.2 }] });
    else if (/atelier/.test(lv)) L('atelier-light', 'Atelier north light', { kind: 'linear', angle: 90, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.4 }, { color: '#FFFFFF', at: 50, alpha: 0 }, { color: '#C9B79C', at: 100, alpha: 0.16 }] });
    else if (/studio backdrop/.test(lv)) b.add({ id: b.id('backdrop-falloff'), name: 'Studio backdrop fall-off', type: 'texture', kind: 'vignette', box: full, color: '#3B3F45', intensity: 0.42, role: 'concept' });
    else if (/wood-panelled/.test(lv)) L('wood-light', 'Wood-panelled warmth', { kind: 'linear', angle: 180, stops: [{ color: '#8A5A2B', at: 0, alpha: 0.3 }, { color: '#8A5A2B', at: 100, alpha: 0.1 }] }, 'multiply');
    else if (/marble/.test(lv)) L('marble-light', 'Cool tabletop light', { kind: 'radial', cx: 50, cy: 30, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.5 }, { color: '#C8D2DC', at: 100, alpha: 0.2 }] });
  }
  if (/cinematic/.test(s.background_style)) b.add({ id: b.id('vignette'), name: 'Cinematic vignette', type: 'texture', kind: 'vignette', box: box(0, 0, 100, 100), color: '#000000', intensity: 0.6, role: 'concept' });
  if (photo && p.envBehind) b.add({ id: b.id('grain'), name: 'Film grain', type: 'texture', kind: 'grain', box: box(0, 0, 100, 100), color: '#000000', intensity: 0.06, seed: s.id, blend: 'multiply', role: 'concept' });
  if (/illustration/.test(s.render_style)) b.add({ id: b.id('halftone'), name: 'Halftone print texture', type: 'texture', kind: 'halftone', box: box(0, 0, 100, 100), color: p.b.roles.dark, intensity: 0.07 });
  if (/collage/.test(s.render_style)) b.add({ id: b.id('paper'), name: 'Paper collage texture', type: 'texture', kind: 'paper', box: box(0, 0, 100, 100), color: '#5A4630', intensity: 0.3, seed: s.id });
}

function backgroundLayers(p: P, opts: { horizon: number; busy: 'left' | 'right' | 'both'; zoom: number; blur: number }): void {
  const { b, s } = p; const R = b.roles; const bg = s.background_style; const dna = s.dna;
  const env = (): void => { const zx = (opts.zoom - 1) * 50; b.add({ id: b.id('setting'), name: 'Setting: ' + truncateWords(dna.environment || dna.environmentKind, 40), type: 'environment', kind: dna.environmentKind, seed: s.id, horizon: opts.horizon, busy: opts.busy, blur: opts.blur, box: box(opts.busy === 'left' ? -zx * 2 : 0, -(opts.zoom - 1) * 30, 100 * opts.zoom, 100 * opts.zoom), role: 'concept' }); p.envBehind = true; };
  switch (bg) {
    case 'studio_white': b.add({ id: b.id('studio-sweep'), name: 'Studio backdrop', type: 'background', box: box(0, 0, 100, 100), fill: { kind: 'radial', cx: 50, cy: 38, stops: [{ color: '#FFFFFF', at: 0 }, { color: R.background, at: 60 }, { color: darken(R.background, 0.08), at: 100 }] } }); b.add({ id: b.id('floor-shadow'), name: 'Floor', type: 'shape', shape: 'rect', box: box(0, opts.horizon * 100 + 6, 100, 100 - opts.horizon * 100), fill: { kind: 'linear', angle: 180, stops: [{ color: darken(R.background, 0.1), at: 0, alpha: 0.5 }, { color: darken(R.background, 0.04), at: 100, alpha: 0.2 }] } }); break;
    case 'solid_color_brand': b.add({ id: b.id('brand-colour'), name: 'Brand colour field', type: 'background', box: box(0, 0, 100, 100), fill: solid(R.background) }); break;
    case 'gradient_subtle': b.add({ id: b.id('gradient'), name: 'Soft gradient', type: 'background', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 135 + (hash53(s.id) % 4) * 15, stops: [{ color: lighten(R.secondary, 0.7), at: 0 }, { color: R.light, at: 55 }, { color: lighten(R.primary, 0.72), at: 100 }] } }); break;
    case 'gradient_bold': b.add({ id: b.id('gradient'), name: 'Bold gradient', type: 'background', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 120 + (hash53(s.id) % 5) * 20, stops: [{ color: R.primary, at: 0 }, { color: mix(R.primary, R.accent, 0.5), at: 60 }, { color: R.accent, at: 100 }] } }); break;
    case 'texture_paper': b.add({ id: b.id('paper-base'), name: 'Paper', type: 'background', box: box(0, 0, 100, 100), fill: solid(R.background) }); b.add({ id: b.id('paper-texture'), name: 'Paper grain', type: 'texture', kind: 'paper', box: box(0, 0, 100, 100), color: '#6B5A40', intensity: 0.28, seed: s.id }); break;
    case 'transparent_overlay': b.add({ id: b.id('overlay-base'), name: 'Overlay field', type: 'background', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 160, stops: [{ color: R.light, at: 0 }, { color: lighten(R.accent, 0.6), at: 100 }] } }); break;
    default: b.add({ id: b.id('base'), name: 'Base', type: 'background', box: box(0, 0, 100, 100), fill: solid(R.light) }); env();
  }
}

function accentShapes(p: P, cx: number, cy: number, size: number): void {
  const { b, s } = p; const R = b.roles; const dp = s.design_principle; const ar = b.W / b.H;
  const w = size, h = size * ar;
  if (!p.envBehind) {
    if (dp === 'centered_focal' || dp === 'symmetric_balanced') { b.add({ id: b.id('focal-disc'), name: 'Focal disc', type: 'shape', shape: 'ellipse', box: box(cx - w / 2, cy - h / 2, w, h), fill: solid(mix(R.secondary, R.background, 0.35)) }); p.motifs.push('centred disc behind the subject'); }
    else if (dp === 'asymmetric_dynamic' || dp === 'high_contrast') { b.add({ id: b.id('diagonal-block'), name: 'Diagonal colour block', type: 'shape', shape: 'rect', box: box(cx - w * 0.3, -20, w * 0.9, 150), fill: solid(R.accent, 0.92), rotation: 14 }); p.motifs.push('diagonal colour block'); }
    else if (dp === 'negative_space') { b.add({ id: b.id('arch'), name: 'Arch', type: 'shape', shape: 'arch', box: box(cx - w * 0.36, cy - h * 0.34, w * 0.72, 120), fill: solid(mix(R.secondary, R.background, 0.5)) }); p.motifs.push('single arch'); }
    else { b.add({ id: b.id('blob'), name: 'Organic shape', type: 'shape', shape: 'blob', box: box(cx - w / 2, cy - h * 0.46, w, h), fill: solid(mix(R.secondary, R.background, 0.3)) }); p.motifs.push('organic brand shape'); }
  }
  if (dp === 'grid_aligned') { b.add({ id: b.id('grid'), name: 'Alignment grid', type: 'pattern', kind: 'grid', box: box(0, 0, 100, 100), color: p.envBehind ? '#FFFFFF' : R.ink, scale: 8, opacity: 0.1 }); p.motifs.push('visible alignment grid'); }
  if (dp === 's_curve_flow') { b.add({ id: b.id('s-curve'), name: 'S-curve flow line', type: 'path', box: box(0, 0, 100, 100), viewBox: [100, 100], d: 'M-5 82 C 30 96 34 52 55 50 S 78 14 106 22', stroke: R.accent, strokeWidth: 0.7, opacity: 0.85 }); p.motifs.push('S-curve flow line'); }
  if (dp === 'leading_lines') { for (let i = 0; i < 4; i++) b.add({ id: b.id('lead-line'), name: 'Leading line', type: 'path', box: box(0, 0, 100, 100), viewBox: [100, 100], d: `M${i * 34 - 10} 104 L ${round(cx)} ${round(cy)}`, stroke: p.envBehind ? '#FFFFFF' : R.accent, strokeWidth: 0.35, opacity: 0.5 }); p.motifs.push('lines converging on the subject'); }
}

interface Placed { cx: number; top: number; h: number; w: number }
function placeFigure(p: P, pose: FigurePose, cx: number, opts: { crop: CanonicalScene['dna']['framing']['crop']; share: number; topLimit: number; floor: number; seedKey?: string; blur?: number; scale?: number }): Placed {
  const { b, s } = p; const dna = s.dna; const ar = b.W / b.H;
  const seated = pose === 'seated-client' || pose === 'desk-settled' || pose === 'behind-mic';
  const banner = ar >= 2.4;
  const table: Record<string, [number, number]> = { tight: [0.2, 0.94], close: [0.33, 0.88], medium: [0.5, 0.86], 'medium-wide': [0.64, 0.86], wide: [0.82, 0.9], 'full-body': [1, 0.9], 'top-down': [0.5, 0.8] };
  let [v, vis] = table[opts.crop] ?? [0.5, 0.84];
  if (banner && v > 0.5) { v = 0.5; vis = 0.92; }
  if (pose === 'seated-client') { v = opts.crop === 'close' ? 0.4 : opts.crop === 'medium' ? 0.66 : 1; vis = v >= 1 ? 0.8 : 0.86; }
  if (pose === 'desk-settled' || pose === 'behind-mic') { v = opts.crop === 'close' ? 0.5 : 0.74; vis = 0.82; }
  let visible = vis * 100 * clamp(0.94 + (opts.share - 0.4) * 0.3, 0.9, 1.06) * (opts.scale ?? 1);
  const availTop = opts.topLimit + 2;
  let h: number, top: number;
  if (v >= 1) { h = Math.min(visible, opts.floor - availTop); top = opts.floor - h; }
  else { if (100 - visible < availTop) visible = 100 - availTop; h = visible / v; top = 100 - visible; }
  void seated;
  const w = (h * 0.6) / ar;
  const facing = cx <= 50 ? 'right' as const : 'left' as const;
  const pal = b.roles;
  const look = buildLook(s.id + (opts.seedKey ?? ''), dna.person.wardrobe, opts.seedKey ? 'unspecified' : dna.person.presentation, dna.person.age, { primary: pal.primary, secondary: pal.secondary, accent: pal.accent, dark: pal.dark, background: p.envBehind ? mix(pal.light, pal.secondary, 0.16) : pal.background });
  b.add({ id: b.id(opts.seedKey ? 'person' + opts.seedKey : 'person'), name: opts.seedKey ? 'Person (illustrated)' : 'Subject (illustrated stand-in)', type: 'figure', pose, facing, look, box: box(cx - w / 2, top, w, h), role: 'concept', ...(opts.blur ? { blur: opts.blur } : {}) });
  return { cx, top, h, w };
}

function placeProps(p: P, kinds: Array<{ kind: string; phrase: string }>, region: { x0: number; x1: number; base: number }, size: number, max: number): void {
  const { b, s } = p; const ar = b.W / b.H; const list = kinds.slice(0, max); if (!list.length) return;
  const span = region.x1 - region.x0; const step = span / list.length;
  list.forEach((k, i) => {
    const sz = size * (0.82 + ((hash53(s.id + k.kind) % 40) / 100)); const w = sz / (ar > 1 ? ar : 1), h = ar > 1 ? sz : sz * ar;
    const x = region.x0 + step * (i + 0.5) - w / 2 + ((hash53(s.id + i) % 9) - 4) * 0.3;
    b.add({ id: b.id(k.kind), name: truncateWords(k.phrase || k.kind, 50), type: 'object', kind: k.kind, sourcePhrase: k.phrase.slice(0, 80), variant: (hash53(s.id + k.kind) % 100) / 100, box: box(x, region.base - h, w, h), shadow: true, role: 'concept' });
  });
}
function resolveSceneProps(s: CanonicalScene): Array<{ kind: string; phrase: string }> {
  const out: Array<{ kind: string; phrase: string }> = [];
  for (const ph of s.dna.props) { const k = resolveProp(ph); if (k && hasProp(k) && !out.some(o => o.kind === k)) out.push({ kind: k, phrase: ph }); }
  return out;
}

function secondaryElement(p: P, region: { x: number; y: number; w: number; h: number }, floor: number, props: Array<{ kind: string; phrase: string }>): boolean {
  const { b, s } = p; const R = b.roles; const sec = s.dna.framing.secondary; const ar = b.W / b.H; const U = b.U;
  const sq = (size: number): { w: number; h: number } => ({ w: size / (ar > 1 ? ar : 1), h: ar > 1 ? size : size * ar });
  const obj = (kind: string, name: string, x: number, y: number, size: number, blur = 0): void => { const d = sq(size); b.add({ id: b.id(kind), name, type: 'object', kind, sourcePhrase: sec, variant: (hash53(s.id + kind) % 100) / 100, box: box(x - d.w / 2, y - d.h, d.w, d.h), shadow: true, role: 'concept', ...(blur ? { blur } : {}) }); };
  const cx = region.x + region.w / 2;
  const board = (kind: 'steps' | 'cycle' | 'pillars' | 'funnel' | 'matrix' | 'timeline' | 'venn' | 'ladder' | 'list', label: string, prefix: string, count: number): void => {
    const bw = Math.min(region.w * 0.86, 62), bh = Math.min(region.h * 0.6, 52), bx = cx - bw / 2, by = region.y + region.h * 0.12;
    b.add({ id: b.id('board'), name: label, type: 'diagram', kind, box: box(bx, by, bw, bh), nodes: Array.from({ length: count }, (_, i) => ({ label: `${prefix} ${i + 1}` })), color: R.primary, color2: R.accent, ink: R.dark, surface: '#FFFFFF', font: 'jakarta', size: round(clamp(((bh / 100) * b.H / U) * 0.075, 1.5, 3.2)), copyStatus: 'suggested' });
    p.hierarchy.push(label);
  };
  const kinds = ['steps', 'pillars', 'cycle', 'matrix', 'funnel', 'ladder', 'venn', 'timeline'] as const;
  const dk = kinds[hash53(s.dna.baseScene + s.niche) % kinds.length]!;
  const prefix = dk === 'pillars' ? 'Pillar' : dk === 'cycle' ? 'Phase' : dk === 'matrix' ? 'Quadrant' : dk === 'funnel' || dk === 'ladder' ? 'Stage' : dk === 'venn' ? 'Area' : 'Step';
  switch (sec) {
    case 'framework': board(dk, 'Your framework (editable diagram)', prefix, dk === 'matrix' ? 4 : dk === 'venn' ? 3 : 3 + (hash53(s.id) % 2)); return true;
    case 'curriculum': board('list', 'Curriculum (editable list)', 'Module', 4); return true;
    case 'whiteboard': board(pick(p.r, ['steps', 'funnel', 'timeline', 'matrix'] as const), 'Strategy whiteboard (editable)', 'Stage', 4); return true;
    case 'data visualisation': { const bw = Math.min(region.w * 0.8, 50), bh = Math.min(region.h * 0.5, 44); b.add({ id: b.id('chart'), name: 'Findings chart (illustrative — replace with real data)', type: 'chart', kind: pick(p.r, ['bars', 'line', 'donut'] as const), box: box(cx - bw / 2, region.y + region.h * 0.16, bw, bh), values: [28, 44, 39, 61, 74], color: R.accent, color2: R.primary, ink: R.dark, surface: '#FFFFFF', illustrative: true }); p.hierarchy.push('data visual (illustrative)'); return true; }
    case 'library': obj('bookshelf', 'Library of resources', cx, floor + 2, Math.min(region.w * 1.1, 70)); return true;
    case 'second chair': obj('armchair', 'Second chair for the client', cx, floor + 4, 44); return true;
    case 'audience': b.add({ id: b.id('audience'), name: 'Audience (implied)', type: 'object', kind: 'audience', sourcePhrase: 'audience implied bottom edge', variant: 0.5, box: box(-4, region.h - 22, 108, 30), role: 'concept' }); return true;
    case 'documents': obj('documents', 'Documents on the table', cx - region.w * 0.14, 98, 30); obj('worksheet', 'Client worksheet', cx + region.w * 0.16, 99, 24); return true;
    case 'toolkit': { const d = sq(Math.min(region.w * 0.8, 64)); b.add({ id: b.id('toolkit-tray'), name: 'Toolkit surface', type: 'shape', shape: 'rect', box: box(cx - d.w * 0.62, region.y + region.h - d.h * 0.62, d.w * 1.24, d.h * 0.6), fill: solid('#FFFFFF', 0.92), radius: 2, shadow: true, role: 'concept' }); const set = (props.length ? props : [{ kind: 'worksheet', phrase: 'toolkit' }, { kind: 'checklist', phrase: 'toolkit' }, { kind: 'planner', phrase: 'toolkit' }]).slice(0, 3); placeProps(p, set, { x0: cx - d.w * 0.56, x1: cx + d.w * 0.56, base: region.y + region.h - d.h * 0.06 }, 22, 3); p.hierarchy.push('toolkit items'); return true; }
    case 'bundle stack': case 'bonus stack': { obj('tablet', 'Bundle item', cx - region.w * 0.2, floor + 6, 30); obj('book-stack', 'Bundle item', cx + region.w * 0.04, floor + 8, 30); obj('gift-box', sec === 'bonus stack' ? 'Bonus' : 'Bundle item', cx + region.w * 0.26, floor + 9, 24); p.hierarchy.push(sec); return true; }
    case 'monitors and sticky notes': obj('monitor', 'Monitors', cx - region.w * 0.16, floor - 2, 34); obj('sticky-notes', 'Sticky notes', cx + region.w * 0.2, floor - 14, 26); return true;
    case 'audit tool': obj('laptop-dashboard', 'Audit tool', cx - region.w * 0.1, floor + 6, 34); obj('checklist', 'Audit checklist', cx + region.w * 0.24, floor + 8, 22); return true;
    case 'result': { b.add({ id: b.id('result'), name: 'Result (add a verified figure)', type: 'stat', box: box(cx - 14, region.y + region.h * 0.3, 28, 24), value: '00%', label: 'Add a verified client result', font: p.fonts.headline, color: p.envBehind ? '#FFFFFF' : R.ink, labelColor: p.envBehind ? '#FFFFFF' : R.ink, size: 11, align: 'center', verified: false, copyStatus: 'suggested' }); p.hierarchy.push('proof placeholder: verified result'); return true; }
    case 'gear': obj('camera', 'Camera gear', cx - region.w * 0.2, floor + 4, 26); obj('softbox', 'Lighting', cx + region.w * 0.2, floor + 2, 44); return true;
    case 'camera': obj('tripod', 'Camera on tripod', cx, floor + 6, 46); return true;
    case 'book and tea': obj('book-stack', 'Books', cx - region.w * 0.14, floor + 6, 24); obj('mug', 'Tea', cx + region.w * 0.16, floor + 7, 18); return true;
    case 'module cue object': case 'lesson cue object': case 'signature object': case 'programme element': case 'brand element': { const k = props[0] ?? { kind: 'notebook', phrase: sec }; obj(k.kind, truncateWords(k.phrase, 40), region.x + region.w * 0.78, 97, 30); p.hierarchy.push(sec + ': ' + k.phrase); return true; }
    case 'product': case 'packaging': obj(sec === 'packaging' ? 'packaging' : 'product-bottle', 'Product', cx, floor + 8, 34); return true;
    case 'tutorial subject': obj(props[0]?.kind ?? 'laptop', 'Tutorial subject', cx, floor + 4, 46); return true;
    default: return false;
  }
}

// ------------------------------------------------------------------ plans by subject kind
function planPersonScene(p: P): string {
  const { b, s, zones } = p; const dna = s.dna; const f = dna.framing; const R = b.roles;
  const sideZ = zones.filter(z => z.width < 80 && z.role !== 'ui' && z.role !== 'visual' && !(z.width < 40 && z.height < 30));
  const leftZ = sideZ.find(z => z.x + z.width / 2 < 42), rightZ = sideZ.find(z => z.x + z.width / 2 > 58);
  const topZ = zones.filter(z => z.width >= 80 && z.y < 20 && z.role !== 'visual').reduce((m, z) => Math.max(m, z.y + z.height), 0);
  const botZ = zones.filter(z => z.width >= 80 && z.y + z.height > 80 && z.role !== 'visual').reduce((m, z) => Math.max(m, 100 - z.y), 0);
  const centreZ = sideZ.find(z => z !== leftZ && z !== rightZ);
  const x0 = leftZ ? leftZ.x + leftZ.width : 0, x1 = rightZ ? rightZ.x : 100;
  let side = f.subjectSide; if (leftZ && side === 'left') side = 'right'; if (rightZ && side === 'right') side = 'left';
  if (leftZ && rightZ) side = 'centre';
  if (centreZ && side !== 'edges') side = 'edges';
  const hasSecondary = !!f.secondary && !/zone|space|masthead|title|show name|event details|copy/.test(f.secondary);
  const free = x1 - x0;
  let cx = side === 'left' ? x0 + free * (hasSecondary ? 0.26 : 0.34) : side === 'right' ? x0 + free * (hasSecondary ? 0.74 : 0.66) : side === 'edges' ? (hash53(s.id) % 2 ? 11 : 89) : x0 + free * 0.5;
  if (free < 60 && side !== 'edges') cx = x0 + free * 0.5;
  const wide = f.crop === 'wide' || f.crop === 'full-body';
  const horizon = wide ? 0.66 : f.crop === 'medium-wide' ? 0.7 : f.crop === 'medium' ? 0.74 : 0.86;
  const floor = f.crop === 'full-body' ? 97 : 100;
  const busy: 'left' | 'right' | 'both' = leftZ ? 'right' : rightZ ? 'left' : cx > 55 ? 'left' : cx < 45 ? 'right' : 'both';
  const zoom = f.crop === 'tight' ? 1.9 : f.crop === 'close' ? 1.5 : f.crop === 'medium' ? 1.2 : 1;
  const blur = s.background_style === 'blurred_environment' ? 16 : f.crop === 'tight' ? 12 : f.crop === 'close' ? 7 : 0;
  backgroundLayers(p, { horizon, busy, zoom, blur });
  const figH = wide ? 70 : 84;
  accentShapes(p, cx, 46, wide ? 42 : 56);

  const props = resolveSceneProps(s);
  // secondary element in the complementary region
  const compX0 = cx > 50 ? x0 : cx + 12, compX1 = cx > 50 ? cx - 12 : x1;
  let usedSecondary = false;
  if (hasSecondary && compX1 - compX0 > 14) usedSecondary = secondaryElement(p, { x: compX0, y: topZ + 4, w: compX1 - compX0, h: 100 - topZ - botZ - 8 }, floor, props);
  else if (f.secondary === 'audience') usedSecondary = secondaryElement(p, { x: 0, y: 0, w: 100, h: 100 - botZ }, floor, props);

  const pose = (dna.pose === 'none' || dna.pose === 'hands' || dna.pose === 'group' ? 'standing-relaxed' : dna.pose) as FigurePose;
  const scale = s.design_principle === 'tight_crop' ? 1.08 : s.design_principle === 'negative_space' ? 0.92 : 1;
  if (dna.subjectKind === 'group') {
    const n = 3 + (hash53(s.id) % 3); const span = Math.min(free * 0.84, 78); const start = x0 + (free - span) / 2;
    for (let i = 0; i < n; i++) placeFigure(p, (['standing-relaxed', 'welcome-open', 'contemplative', 'presenting-item', 'celebrate'] as const)[(i + hash53(s.id)) % 5]!, start + (span / (n - 1)) * i, { crop: 'medium-wide', share: 0.5 + (i % 2) * 0.05, topLimit: topZ, floor, seedKey: '-' + (i + 1) });
    p.hierarchy.unshift('a group, every face readable');
  } else {
    const fig = placeFigure(p, pose, cx, { crop: f.crop, share: f.subjectShare, topLimit: topZ, floor, scale });
    if (dna.subjectKind === 'two-people' && f.secondary !== 'second chair') { /* the client’s seat is a source anchor even when documents or a board are also in frame */ const d = { w: 44 / (b.W / b.H > 1 ? b.W / b.H : 1), h: b.W / b.H > 1 ? 44 : 44 * (b.W / b.H) }; const ox = cx > 50 ? cx - Math.max(22, fig.w * 0.9) : cx + Math.max(22, fig.w * 0.9); b.add({ id: b.id('second-chair'), name: 'Second chair (the client’s seat)', type: 'object', kind: 'armchair', sourcePhrase: 'second chair', variant: 0.5, box: box(ox - d.w / 2, 100 - d.h * 0.92, d.w, d.h), shadow: true, role: 'concept' }); }
    p.hierarchy.unshift(dna.subject);
    void figH;
  }
  // props: on the surface near the subject, away from copy
  const maxProps = s.design_principle === 'negative_space' ? 1 : usedSecondary ? 2 : 3;
  const base = 99;
  const px0 = cx > 50 ? Math.max(x0 + 2, cx - 40) : Math.min(cx + 10, x1 - 30), px1 = cx > 50 ? cx - 9 : Math.min(cx + 46, x1 - 2);
  const propList = f.secondary === 'toolkit' ? [] : props.filter(k => !(usedSecondary && /bookshelf|armchair/.test(k.kind))).slice(0, maxProps);
  if (propList.length && pose !== 'desk-settled' && pose !== 'behind-mic') {
    const sx0 = Math.min(px0, px1 - 12) - 4, sx1 = px1 + 4; const tone = mix('#B98A5E', R.secondary, 0.25);
    b.add({ id: b.id('surface'), name: 'Table edge in the foreground', type: 'shape', shape: 'rect', box: box(sx0, 92, sx1 - sx0, 12), fill: { kind: 'linear', angle: 180, stops: [{ color: lighten(tone, 0.12), at: 0 }, { color: darken(tone, 0.18), at: 100 }] }, radius: 0.8, role: 'concept' });
  }
  placeProps(p, propList, { x0: Math.min(px0, px1 - 12), x1: px1, base: propList.length && pose !== 'desk-settled' && pose !== 'behind-mic' ? 95 : base }, wide ? 16 : 20, maxProps);
  if (s.design_principle === 'depth_layered' && props[0]) { const k = props[props.length - 1]!; const ar = b.W / b.H; const sz = 46; b.add({ id: b.id('foreground-' + k.kind), name: 'Foreground: ' + truncateWords(k.phrase, 30), type: 'object', kind: k.kind, sourcePhrase: k.phrase.slice(0, 80), variant: 0.3, box: box(cx > 50 ? -8 : 108 - sz / (ar > 1 ? ar : 1), 100 - (ar > 1 ? sz : sz * ar) * 0.72, sz / (ar > 1 ? ar : 1), ar > 1 ? sz : sz * ar), blur: 9, role: 'concept' }); p.motifs.push('blurred foreground object for depth'); }
  if (s.design_principle === 'symmetric_balanced' && props[0] && !leftZ && !rightZ) { const k = props[0]; placeProps(p, [k], { x0: 100 - px1, x1: 100 - Math.min(px0, px1 - 12), base }, wide ? 17 : 22, 1); p.motifs.push('mirrored props for symmetry'); }
  lightingFinish(p, cx, 36);
  return `person/${f.crop}/${side}${hasSecondary ? '+' + f.secondary.replace(/\s+/g, '-') : ''}`;
}

function planPattern(p: P): string {
  const { b, s } = p; const R = b.roles; const init = (p.o.brand?.businessName ?? 'Your Brand').split(/\s+/).map(w => w[0]).join('').slice(0, 3).toUpperCase();
  b.add({ id: b.id('backdrop'), name: 'Backdrop colour', type: 'background', box: box(0, 0, 100, 100), fill: solid(R.primary) });
  const kinds = ['monogram', 'arches', 'dots', 'waves', 'checks', 'monogram', 'grid', 'stripes'] as const; const kind = kinds[hash53(s.id + s.dna.lightingVariant) % kinds.length]!;
  b.add({ id: b.id('repeat'), name: 'Step-and-repeat pattern', type: 'pattern', kind, box: box(0, 0, 100, 100), color: inkOn(R.primary, darken(R.primary, 0.35), lighten(R.primary, 0.45)), color2: R.accent, scale: (kind === 'monogram' ? 14 : 8) + (hash53(s.id + 'sc') % 5), text: init, opacity: 0.9 });
  b.add({ id: b.id('standing-area'), name: 'Guest standing area (pattern-light)', type: 'shape', shape: 'rect', box: box(20, 0, 60, 100), fill: { kind: 'linear', angle: 90, stops: [{ color: R.primary, at: 0, alpha: 0 }, { color: R.primary, at: 30, alpha: 0.78 }, { color: R.primary, at: 70, alpha: 0.78 }, { color: R.primary, at: 100, alpha: 0 }] } });
  lightingFinish(p, 50, 40);
  p.motifs.push('step-and-repeat brand pattern'); p.hierarchy.push('repeating brand pattern', 'clear standing area');
  void s; return 'pattern/step-and-repeat/' + kind;
}

function planTexture(p: P): string {
  const { b, s } = p; const R = b.roles; const sc = s.scenario.toLowerCase();
  const kind = /marble/.test(sc) ? 'marble' : /linen|fabric|cotton|silk/.test(sc) ? 'linen' : /concrete|stone|plaster/.test(sc) ? (/plaster/.test(sc) ? 'plaster' : 'concrete') : /wood|timber/.test(sc) ? 'wood' : /paper|card/.test(sc) ? 'paper' : pick(p.r, ['plaster', 'linen', 'paper', 'marble'] as const);
  const toned = sc.match(/#([0-9a-f]{6})-toned/)?.[0]?.slice(0, 7).toUpperCase() ?? R.secondary;
  const base = kind === 'marble' ? mix('#F6F3EE', toned, 0.16) : mix(lighten(toned, 0.55), R.light, 0.3);
  b.add({ id: b.id('surface'), name: 'Surface colour', type: 'background', box: box(0, 0, 100, 100), fill: solid(base) });
  b.add({ id: b.id('texture'), name: kind[0]!.toUpperCase() + kind.slice(1) + ' texture', type: 'texture', kind, box: box(0, 0, 100, 100), color: kind === 'marble' ? mix(toned, '#6B6258', 0.5) : darken(toned, 0.45), intensity: kind === 'marble' ? 0.55 : 0.42, seed: s.id });
  b.add({ id: b.id('soft-light'), name: 'Soft window light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 100 + (hash53(s.id) % 5) * 22, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.5 }, { color: '#FFFFFF', at: 45, alpha: 0 }, { color: '#3A2E20', at: 100, alpha: 0.16 }] } });
  p.envBehind = false; lightingFinish(p, 50, 40); p.motifs.push(kind + ' texture, even and focal-point-free'); p.hierarchy.push('texture surface');
  return 'texture/' + kind;
}

function planDevices(p: P): string {
  const { b, s } = p; const R = b.roles; const ar = b.W / b.H; const v = hash53(s.id) % 4; const props = resolveSceneProps(s);
  b.add({ id: b.id('surface'), name: 'Desk surface', type: 'background', box: box(0, 0, 100, 100), fill: { kind: 'linear', angle: 170, stops: [{ color: mix(R.light, R.secondary, 0.14), at: 0 }, { color: mix(R.light, R.secondary, 0.3), at: 100 }] } });
  b.add({ id: b.id('surface-grain'), name: 'Surface texture', type: 'texture', kind: v % 2 ? 'linen' : 'plaster', box: box(0, 0, 100, 100), color: darken(R.secondary, 0.4), intensity: 0.2, seed: s.id, role: 'concept' });
  const white: Paint = solid('#FFFFFF'); const dk = R.dark;
  const lw = ar > 1 ? 46 : 70, lh = (lw * 0.62) * ar;
  const lx = v === 0 ? 27 : v === 1 ? 12 : v === 2 ? 40 : 22, ly = 50 - lh / 2 + (v % 2 ? 4 : -2);
  b.add({ id: b.id('laptop'), name: 'Laptop — blank screen for your design', type: 'frame', kind: 'laptop', box: box(lx, ly, lw, lh), color: dk, screen: white, shadow: true });
  const pw = ar > 1 ? 10 : 20, ph = pw * 2.02 * ar;
  b.add({ id: b.id('phone'), name: 'Phone — blank screen', type: 'frame', kind: 'phone', box: box(v === 2 ? 22 : lx + lw + 3, ly + lh - ph + 4, pw, ph), color: dk, screen: white, shadow: true, rotation: v === 1 ? 6 : v === 3 ? -5 : 0 });
  if (v !== 3) { const tw = ar > 1 ? 18 : 32, th = tw * 1.32 * ar; b.add({ id: b.id('tablet'), name: 'Tablet — blank screen', type: 'frame', kind: 'tablet', box: box(v === 2 ? lx + lw + 4 : lx - tw - 3 < 2 ? lx + lw + pw + 6 : lx - tw - 3, ly + lh - th + 2, tw, th), color: dk, screen: white, shadow: true, rotation: v === 0 ? -4 : 3 }); }
  placeProps(p, props.filter(k => !/laptop|phone|tablet|monitor/.test(k.kind)), { x0: 62, x1: 98, base: 96 }, 16, 2);
  lightingFinish(p, 50, 30);
  p.motifs.push('blank device screens ready for the customer’s own design'); p.hierarchy.push('device screens', 'supporting desk props');
  return 'devices/arrangement-' + v;
}

function planEnvironmentOnly(p: P): string {
  const { b, s } = p; const R = b.roles; const props = resolveSceneProps(s); const flip = hash53(s.id) % 2 === 0;
  backgroundLayers(p, { horizon: 0.6, busy: 'both', zoom: 1, blur: 0 });
  b.add({ id: b.id('desk-top'), name: 'Desk in the foreground', type: 'shape', shape: 'rect', box: box(flip ? -4 : 30, 78, 74, 30), fill: { kind: 'linear', angle: 180, stops: [{ color: mix('#C59A6C', R.secondary, 0.25), at: 0 }, { color: mix('#8C6642', R.dark, 0.2), at: 100 }] }, radius: 0.8, role: 'concept' });
  placeProps(p, props.length ? props : [{ kind: 'laptop', phrase: 'laptop' }, { kind: 'mug', phrase: 'coffee' }, { kind: 'plant', phrase: 'plant' }], { x0: flip ? 2 : 34, x1: flip ? 66 : 98, base: 84 }, 26, 3);
  lightingFinish(p, flip ? 70 : 30, 30);
  p.hierarchy.push('the workspace itself', 'props that say who works here'); p.motifs.push('no person — the environment is the hero');
  void R; return 'environment/desk-foreground/' + (flip ? 'left' : 'right');
}

function arrange(p: P, items: Array<{ kind: string; phrase: string }>, area: { x: number; y: number; w: number; h: number }, size: number): void {
  const { b, s } = p; const ar = b.W / b.H; const n = items.length; const mode = s.design_principle === 'grid_aligned' ? 'grid' : s.design_principle === 'symmetric_balanced' || s.design_principle === 'centered_focal' ? 'ring' : s.design_principle === 'asymmetric_dynamic' || s.design_principle === 's_curve_flow' ? 'diagonal' : 'scatter';
  const SCATTER: Array<[number, number]> = [[0.42, 0.46], [0.78, 0.26], [0.2, 0.8], [0.8, 0.74], [0.16, 0.22], [0.56, 0.86]];
  const flip = hash53(s.id + 'flip') % 2 === 0;
  items.forEach((k, i) => {
    let x: number, y: number; const t = n > 1 ? i / (n - 1) : 0.5;
    if (mode === 'grid') { const cols = Math.ceil(Math.sqrt(n)); x = area.x + (area.w / cols) * ((i % cols) + 0.5); y = area.y + (area.h / Math.ceil(n / cols)) * (Math.floor(i / cols) + 0.5); }
    else if (mode === 'ring') { if (i === 0) { x = area.x + area.w / 2; y = area.y + area.h / 2; } else { const a = ((i - 1) / Math.max(1, n - 1)) * Math.PI * 2 - Math.PI / 4; x = area.x + area.w / 2 + Math.cos(a) * area.w * 0.34; y = area.y + area.h / 2 + Math.sin(a) * area.h * 0.34; } }
    else if (mode === 'diagonal') { x = area.x + area.w * (0.16 + t * 0.68); y = area.y + area.h * (flip ? 0.2 + t * 0.6 : 0.8 - t * 0.6); }
    else { const sl = SCATTER[i % SCATTER.length]!; x = area.x + area.w * (flip ? 1 - sl[0] : sl[0]); y = area.y + area.h * sl[1]; }
    const sz = size * (i === 0 ? 1.45 : mode === 'grid' ? 1 : 0.78 + (hash53(s.id + k.kind) % 30) / 100); const w = sz / (ar > 1 ? ar : 1), h = ar > 1 ? sz : sz * ar;
    b.add({ id: b.id(k.kind), name: truncateWords(k.phrase || k.kind, 50), type: 'object', kind: k.kind, sourcePhrase: k.phrase.slice(0, 80), variant: (hash53(s.id + k.kind) % 100) / 100, box: box(x - w / 2, y - h / 2, w, h), rotation: mode === 'grid' ? 0 : ((hash53(s.id + 'r' + i) % 36) - 18), shadow: true, role: 'concept' });
  });
  p.motifs.push(mode + ' object arrangement');
}

function productSet(s: CanonicalScene): Array<{ kind: string; phrase: string }> {
  const t = (s.scenario + ' ' + s.display_title + ' ' + s.niche).toLowerCase();
  const pool = /nail|polish|manicure/.test(t) ? ['nail-polish', 'nail-tools', 'uv-lamp'] : /recipe|food|kitchen/.test(t) ? ['produce', 'cutting-board', 'herbs', 'citrus'] : /unbox|packag/.test(t) ? ['packaging', 'product-jar', 'shopping-bag'] : /book|journal|planner/.test(t) ? ['book', 'journal', 'planner'] : ['product-bottle', 'product-jar', 'product-box', 'shopping-bag', 'gift-box'];
  const r = rng('prod:' + s.id); const first = pick(r, pool);
  return [first, ...pool.filter(k => k !== first)].map(k => ({ kind: k, phrase: 'the product' }));
}

function planProductLike(p: P): string {
  const { b, s, zones } = p; const dna = s.dna; const R = b.roles; const kind = dna.subjectKind; const f = dna.framing;
  const topZ = zones.filter(z => z.width >= 80 && z.y < 20).reduce((m, z) => Math.max(m, z.y + z.height), 0);
  const botZ = zones.filter(z => z.width >= 80 && z.y + z.height > 80).reduce((m, z) => Math.max(m, 100 - z.y), 0);
  const rightZ = zones.find(z => z.height >= 80 && z.width < 80 && z.x >= 20), leftZ = zones.find(z => z.height >= 80 && z.width < 80 && z.x < 20);
  const area = { x: leftZ ? leftZ.width + 3 : 6, y: topZ + 5, w: (rightZ ? rightZ.x : 100) - (leftZ ? leftZ.width : 0) - 12, h: 100 - topZ - botZ - 10 };
  const sceneProps = resolveSceneProps(s); const products = productSet(s); const ar = b.W / b.H;
  const isFlat = kind === 'flat-lay';
  // surface
  if (isFlat || kind === 'hands') {
    const tex = pick(p.r, ['linen', 'marble', 'plaster', 'wood', 'paper'] as const);
    b.add({ id: b.id('surface'), name: 'Surface', type: 'background', box: box(0, 0, 100, 100), fill: solid(s.background_style === 'solid_color_brand' ? R.primary : mix(R.light, R.secondary, tex === 'wood' ? 0.4 : 0.18)) });
    b.add({ id: b.id('surface-texture'), name: tex + ' surface texture', type: 'texture', kind: tex, box: box(0, 0, 100, 100), color: darken(R.secondary, 0.45), intensity: 0.3, seed: s.id, role: 'concept' });
    b.add({ id: b.id('overhead-light'), name: 'Soft overhead light', type: 'shape', shape: 'rect', box: box(0, 0, 100, 100), fill: { kind: 'radial', cx: 40, cy: 34, stops: [{ color: '#FFFFFF', at: 0, alpha: 0.4 }, { color: '#FFFFFF', at: 60, alpha: 0 }] }, role: 'concept' });
  } else backgroundLayers(p, { horizon: 0.66, busy: 'right', zoom: 1, blur: s.background_style === 'lifestyle_environment' ? 10 : 0 });
  if (!isFlat && kind !== 'hands') accentShapes(p, area.x + area.w / 2, area.y + area.h * 0.5, Math.min(area.w, 60));

  if (isFlat) { const items = [...(sceneProps.length >= 3 ? sceneProps : [...products.slice(0, 2), ...sceneProps, { kind: 'pen', phrase: 'pen' }, { kind: 'flower', phrase: 'single fresh flower' }, { kind: 'mug', phrase: 'coffee' }])].slice(0, 5); arrange(p, items, area, ar > 1 ? 34 : 36); p.hierarchy.push('top-down arrangement: ' + items.map(i => i.phrase).slice(0, 3).join(', ')); }
  else if (kind === 'hands') {
    const main = /nail/.test((s.niche + s.scenario).toLowerCase()) ? products[0]! : /unbox|packag|reveal/.test(f.raw + dna.poseRaw) ? { kind: 'packaging', phrase: 'packaging mid-reveal' } : sceneProps[0] ?? products[0]!;
    const sz = Math.min(area.w, area.h * (ar > 1 ? 1 : 1 / ar)) * 0.62; const w = sz / (ar > 1 ? ar : 1), h = ar > 1 ? sz : sz * ar;
    b.add({ id: b.id('hands'), name: 'Hands (illustrated stand-in)', type: 'hands', mode: /detail|sharp/.test(f.raw + dna.poseRaw) ? 'detail' : /reveal|lift|unbox/.test(f.raw + dna.poseRaw) ? 'reveal' : 'present', look: buildLook(s.id, dna.person.wardrobe, dna.person.presentation, dna.person.age, { primary: R.primary, secondary: R.secondary, accent: R.accent, dark: R.dark, background: R.light }), seed: s.id, box: box(area.x + area.w * 0.5 - Math.min(78, 60 * ar) / (0.6 * ar) / 2, 100 - Math.min(78, 60 * ar), Math.min(78, 60 * ar) / (0.6 * ar), Math.min(78, 60 * ar)), role: 'concept' });
    b.add({ id: b.id(main.kind), name: truncateWords(main.phrase, 40), type: 'object', kind: main.kind, sourcePhrase: main.phrase.slice(0, 80), variant: 0.5, box: box(area.x + area.w / 2 - w / 2, area.y + area.h * 0.46 - h / 2, w, h), shadow: true, role: 'concept' });
    placeProps(p, sceneProps.filter(k => k.kind !== main.kind), { x0: area.x, x1: area.x + area.w * 0.4, base: area.y + area.h * 0.36 }, 14, 2);
    p.hierarchy.push('hands in action', main.phrase); p.envBehind = true; // copy sits on a panel so it stays legible over sleeves and hands
  } else {
    const collection = /collection|all products/.test(f.raw + dna.poseRaw); const detail = /detail|80%|tactile|texture/.test(f.raw + s.asset_type.toLowerCase());
    if (collection) { const n = 4 + (hash53(s.id) % 2); const set = Array.from({ length: n }, (_, i) => products[i % products.length]!); const base = area.y + area.h * 0.86; const step = area.w / n; set.forEach((k, i) => { const sz = (ar > 1 ? 46 : 26) * (0.8 + ((i * 37) % 30) / 100); const w = sz / (ar > 1 ? ar : 1), h = ar > 1 ? sz : sz * ar; b.add({ id: b.id(k.kind), name: 'Product ' + (i + 1), type: 'object', kind: k.kind, sourcePhrase: 'collection', variant: (i * 0.23) % 1, box: box(area.x + step * (i + 0.5) - w / 2, base - h, w, h), shadow: true, role: 'concept' }); }); p.hierarchy.push('the whole collection in one considered row'); }
    else { const main = products[0]!; const sz = Math.min(area.w * (ar > 1 ? ar : 1), area.h) * (detail ? 1.5 : 0.78); const w = sz / (ar > 1 ? ar : 1), h = ar > 1 ? sz : sz * ar; const cx = s.design_principle === 'rule_of_thirds' ? area.x + area.w * (hash53(s.id) % 2 ? 0.36 : 0.64) : area.x + area.w / 2;
      b.add({ id: b.id(main.kind), name: 'Product (illustrated stand-in)', type: 'object', kind: main.kind, sourcePhrase: 'the product itself', variant: (hash53(s.id) % 100) / 100, box: box(cx - w / 2, area.y + area.h * (detail ? 0.62 : 0.92) - h * (detail ? 0.5 : 1), w, h), shadow: true, role: 'concept' });
      if (!detail) placeProps(p, sceneProps.filter(k => !/product/.test(k.kind)).slice(0, 2), { x0: cx > 50 ? area.x : cx + w * 0.4, x1: cx > 50 ? cx - w * 0.4 : area.x + area.w, base: area.y + area.h * 0.94 }, 15, 2);
      if (/Texture|Tactile/.test(s.asset_type)) { const tex = (['linen', 'paper', 'plaster', 'wood'] as const)[hash53(s.id + 'mat') % 4]!; b.add({ id: b.id('material-texture'), name: 'Material texture close-up (' + tex + ')', type: 'texture', kind: tex, box: box(0, 0, 100, 100), color: darken(R.primary, 0.3), intensity: 0.55, seed: s.id, blend: 'multiply', role: 'concept' }); p.motifs.push('macro material texture across the frame'); p.hierarchy.push('surface texture and craft detail'); }
      p.hierarchy.push(detail ? 'product detail filling the frame' : 'the product as hero'); }
  }
  lightingFinish(p, 50, 40);
  return `${kind}/${f.crop}/${s.design_principle}`;
}

function planPrint(p: P): string {
  const { b, s, zones } = p; const R = b.roles; const f = s.dna.framing.raw.toLowerCase();
  b.add({ id: b.id('card-stock'), name: 'Card stock', type: 'background', box: box(0, 0, 100, 100), fill: solid(mix('#FBF8F1', R.light, 0.4)) });
  b.add({ id: b.id('stock-texture'), name: 'Paper texture', type: 'texture', kind: 'paper', box: box(0, 0, 100, 100), color: '#7A6A52', intensity: 0.2, seed: s.id });
  const frameStyle = hash53(s.id) % 3;
  if (frameStyle === 0) b.add({ id: b.id('border'), name: 'Printed border', type: 'shape', shape: 'rect', box: box(4, 4 * (b.W / b.H) > 8 ? 3 : 4, 92, 100 - 2 * (4 * (b.W / b.H) > 8 ? 3 : 4)), stroke: R.accent, strokeWidth: 0.3 });
  else if (frameStyle === 1) { b.add({ id: b.id('rule-top'), name: 'Top rule', type: 'shape', shape: 'rect', box: box(12, 6, 76, 0.4), fill: solid(R.ink) }); b.add({ id: b.id('rule-bottom'), name: 'Bottom rule', type: 'shape', shape: 'rect', box: box(12, 93.6, 76, 0.4), fill: solid(R.ink) }); }
  else b.add({ id: b.id('colour-band'), name: 'Colour band', type: 'shape', shape: 'rect', box: box(0, 0, 100, 7), fill: solid(R.primary) });
  if (/thank-you/.test(f)) { const z = zones.find(q => q.role === 'visual'); const d = Math.min(26, (z?.height ?? 26) * 0.9); const ar = b.W / b.H; b.add({ id: b.id('portrait-disc'), name: 'Portrait disc', type: 'shape', shape: 'ellipse', box: box(50 - d / 2 / (ar > 1 ? ar : 1) * (ar > 1 ? 1 : 1) , 7, d / (ar > 1 ? ar : 1), ar > 1 ? d : d * ar), fill: solid(mix(R.secondary, R.light, 0.4)) }); p.motifs.push('small portrait vignette above a handwritten-feel message'); }
  lightingFinish(p, 50, 30);
  p.motifs.push(['fine printed border', 'paired hairline rules', 'solid colour band'][frameStyle]!); p.hierarchy.push('typography-led printed piece');
  p.envBehind = false;
  return 'print/' + (/menu/.test(f) ? 'menu' : /table/.test(f) ? 'table-number' : 'card') + '/frame-' + frameStyle;
}

// ------------------------------------------------------------------ fidelity + metadata
export function classifyFidelity(s: CanonicalScene, hasPhoto: boolean): { fidelity: VisualSceneSpec['artDirection']['previewFidelity']; medium: VisualSceneSpec['artDirection']['medium'] } {
  const k = s.dna.subjectKind; const illustrated = /flat-vector|minimalist-line|editorial-illustration|collage/.test(s.render_style);
  if (hasPhoto) return { fidelity: 'final-html-asset', medium: 'photo-composite' };
  if (k === 'pattern' || k === 'texture' || k === 'print-typographic') return { fidelity: 'final-html-asset', medium: 'html-graphic' };
  if (illustrated) return { fidelity: 'final-html-asset', medium: 'html-illustration' };
  const photoIsTheAsset = (k === 'product' || k === 'flat-lay' || k === 'hands') && /E-commerce|Service\/|Marketing\/|Pinterest\/Recipe|Fashion/.test(s.asset_type) || /Headshot|Before After|E-commerce\/Model|Fashion\/Lookbook/.test(s.asset_type);
  return { fidelity: photoIsTheAsset ? 'photo-required' : 'composition-concept', medium: 'html-illustration' };
}
const MECHANISM: Record<string, string> = {
  trust_builder: 'trust — shows the real person and process behind the offer', aspirational: 'aspiration — lets the viewer picture the outcome', emotional_connection: 'emotional connection — a human, unposed moment',
  social_proof: 'proof — makes room for verified client evidence', community_belonging: 'belonging — signals “people like me are here”', curiosity_gap: 'curiosity — withholds just enough to earn the click',
  premium_signaling: 'premium signalling — restraint and finish imply value', educational: 'education — teaches one idea visibly', fomo_urgency: 'urgency — only when a genuine deadline exists', pattern_interrupt: 'pattern break — looks unlike the posts around it',
};

export function planScene(s: CanonicalScene, o: PlanOptions = {}): VisualSceneSpec {
  const dna = s.dna; const W = o.target?.width ?? dna.width, H = o.target?.height ?? dna.height;
  const roles = deriveRoles(dna.palette, s.background_style, o.brand);
  const b = new B(W, H, roles);
  const zones = adaptZones(dna.zones, dna.width, dna.height, W, H);
  const p: P = { s, o, b, r: rng('plan:' + s.id), zones, fonts: { headline: 'jakarta', body: o.brand?.bodyFont ?? 'jakarta', accent: 'caveat' }, envBehind: false, motifs: [], hierarchy: [] };
  p.fonts.headline = headlineFont(p);
  let family: string;
  switch (dna.subjectKind) {
    case 'pattern': family = planPattern(p); break;
    case 'texture': family = planTexture(p); break;
    case 'devices': family = planDevices(p); break;
    case 'environment-only': family = planEnvironmentOnly(p); break;
    case 'product': case 'flat-lay': case 'hands': family = planProductLike(p); break;
    case 'print-typographic': family = planPrint(p); break;
    default: family = planPersonScene(p);
  }
  // customer photo replaces the illustrated concept (reversible: concept layers are hidden, not deleted)
  if (o.photo) {
    for (const l of b.layers) if (l.role === 'concept') l.hidden = true;
    const firstDesign = b.layers.findIndex(l => l.role !== 'concept' && l.type !== 'background');
    const img: VisualLayer = { id: b.id('your-photo'), name: 'Your photo', type: 'image', box: box(0, 0, 100, 100), src: o.photo.src, fit: 'cover', focusX: 50, focusY: 35, mask: 'none', alt: o.photo.alt.slice(0, 200), rights: { source: 'user-upload', note: o.photo.note.slice(0, 200), confirmedByUser: true } };
    b.layers.splice(firstDesign < 0 ? b.layers.length : Math.max(1, firstDesign), 0, img); p.envBehind = true;
  }
  if (!dna.noOverlay) p.zones.forEach((z, i) => zoneOverlay(p, z, i));
  // intent motif (never a fabricated claim)
  if (s.conversion_intent === 'premium_signaling' && dna.subjectKind !== 'pattern') { b.add({ id: b.id('fine-frame'), name: 'Fine inset frame', type: 'shape', shape: 'rect', box: box(2.2, 2.2 * (W / H), 95.6, 100 - 4.4 * (W / H)), stroke: p.envBehind ? '#FFFFFF' : roles.accent, strokeWidth: 0.18, opacity: 0.7 }); p.motifs.push('fine inset frame'); }

  const { fidelity, medium } = classifyFidelity(s, !!o.photo);
  const photoSource = /realistic|photo/.test(s.render_style);
  const anchors = dna.anchors.slice(0, 7);
  const firstZone = p.zones.find(z => z.role !== 'ui' && z.role !== 'visual');
  const spec: VisualSceneSpec = {
    specVersion: SPEC_VERSION, sceneId: s.id, sourceVersion: s.source_version, originalSceneFingerprint: s.provenance.canonical_sha256,
    visualArchetype: truncateWords(`${dna.assetLabel} — ${family}`, 78),
    intent: { funnelStage: s.funnel_stage, outcome: truncateWords(s.benefit, 236), intendedAudience: truncateWords(o.brand?.audience ?? s.target_audience, 156), marketingMechanism: truncateWords(MECHANISM[s.conversion_intent] ?? s.conversion_intent.replace(/_/g, ' '), 156), useCase: truncateWords(s.where_used, 296) },
    scene: { subject: truncateWords(dna.subject, 196), action: truncateWords(dna.action, 236), environment: truncateWords(dna.environment, 236), props: dna.props.map(x => truncateWords(x, 78)).slice(0, 8), narrative: truncateWords(s.scenario, 696), distinctnessAnchors: anchors.map(a => truncateWords(a, 118)), mustInclude: anchors.slice(0, 4).map(a => truncateWords(a, 118)), mustNotInclude: s.negative_constraints.slice(0, 8).map(a => truncateWords(a, 118)) },
    artDirection: {
      medium, visualLanguage: truncateWords(`${photoSource ? 'Art-directed illustration standing in for a ' + s.render_style.replace(/-/g, ' ') + ' photograph' : s.render_style.replace(/-/g, ' ')}; ${dna.mood || 'on-brand'}`, 196),
      compositionFamily: family.slice(0, 60),
      compositionRationale: truncateWords(`Built from the source framing (“${dna.framing.raw}”) and safe zones (“${s.original.safeZones}”) with a ${s.design_principle.replace(/_/g, ' ')} structure.`, 496),
      whyThisWorks: truncateWords(`${sentenceCase(MECHANISM[s.conversion_intent] ?? 'clarity')}. Suited to: ${s.where_used}. Treat as a creative hypothesis to test — no performance is implied.`, 396),
      focalPoint: truncateWords(p.hierarchy[0] ?? dna.subject, 156), focalHierarchy: (p.hierarchy.length ? p.hierarchy : [dna.subject]).slice(0, 6).map(h => truncateWords(h, 118)),
      shapesAndMotifs: p.motifs.slice(0, 8).map(m => truncateWords(m, 78)), layerPlan: b.layers,
      typography: { headline: p.fonts.headline, body: p.fonts.body, accent: 'caveat', scale: 1 }, colourRoles: roles,
      lightAndTexture: truncateWords(`${dna.lightingVariant} lighting${dna.lightingMood ? ' — ' + dna.lightingMood : ''}; ${s.background_style.replace(/_/g, ' ')} background`, 236),
      whitespacePlan: truncateWords(firstZone ? `Copy space: ${firstZone.purpose} (${Math.round(firstZone.width)}% × ${Math.round(firstZone.height)}% of the artboard)` : dna.noOverlay ? 'No overlay — the frame stands alone, as the source specifies' : 'Open space around the subject per the source framing', 236),
      accessibilityNotes: ['Text is live HTML at export size; check contrast after changing brand colours.', 'Alt text describes what is visibly present.'],
      previewFidelity: fidelity,
    },
    output: { width: W, height: H, aspect: aspectLabel(W, H), safeZones: p.zones.map(z => ({ x: z.x, y: z.y, width: z.width, height: z.height, purpose: z.purpose })), formats: ['html', 'png', 'webp', 'jpeg'], intendedPlacement: truncateWords(o.target?.placement ?? s.where_used, 236), altText: truncateWords(altText(s, fidelity), 296) },
    brand: { ...(o.brand?.workspaceId ? { workspaceId: o.brand.workspaceId } : {}), tokenReferences: o.brand?.palette ? ['brand.palette.primary', 'brand.palette.secondary', 'brand.palette.accent', 'brand.palette.light', 'brand.palette.dark'] : ['scene.palette'], typefaceRefs: [p.fonts.headline, p.fonts.body], approvedCopy: (o.brand?.approvedCopy ?? []).slice(0, 12), sourceImages: o.photo ? ['user-upload'] : [] },
    provenance: { originalTemplateId: s.id, compilerVersion: COMPILER_VERSION, rendererVersion: RENDERER_VERSION, approvalStatus: 'auto-generated', planner: 'deterministic', conceptLocked: true, changes: [] },
  };
  return validateSpec(spec);
}
function sentenceCase(t: string): string { return t.charAt(0).toUpperCase() + t.slice(1); }
export function aspectLabel(w: number, h: number): string {
  const r = w / h; const known: Array<[number, string]> = [[1, '1:1'], [0.8, '4:5'], [0.5625, '9:16'], [1.7778, '16:9'], [1.91, '1.91:1'], [3.2, '16:5'], [0.6667, '2:3'], [1.5, '3:2'], [0.7727, '8.5:11'], [0.7143, '5:7'], [3, '3:1'], [2, '2:1']];
  const hit = known.find(([v]) => Math.abs(v - r) < 0.012); return hit ? hit[1] : `${round(r, 2)}:1`;
}
function altText(s: CanonicalScene, fidelity: string): string {
  const d = s.dna; const kind = fidelity === 'final-html-asset' ? 'Graphic' : 'Illustrated composition concept';
  const bits = [d.subject, d.environment ? 'in ' + d.environment.split(',')[0] : '', d.props.length ? 'with ' + d.props.slice(0, 2).join(' and ') : ''].filter(Boolean).join(' ');
  return `${kind} for “${s.dna.assetLabel}”: ${bits}.`;
}
