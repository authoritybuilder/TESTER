/**
 * Render worker: HTML artboard → real pixels, in a locked-down headless Chromium.
 *
 * Isolation (defence in depth — the renderer only ever emits trusted markup, but we assume it could be wrong):
 *  - JavaScript disabled in the page; service workers blocked; every network request aborted (data: only);
 *  - a fresh, cookie-less context per customer render; strict timeouts; bounded artboard dimensions;
 *  - CSP in the document itself forbids script and any non-data resource;
 *  - the screenshot is of the single [data-artboard] element — never of app chrome.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium, type Browser, type BrowserContext } from 'playwright';
import { renderArtboardHtml } from './artboard-renderer.ts';
import { validateSpec, type VisualSceneSpec } from './scene-schema.ts';

const HERE = dirname(fileURLToPath(import.meta.url));
export const FONT_DIR = resolve(HERE, '../../../public/fonts');
let fontCache: Record<string, string> | null = null;
export function loadFontData(): Record<string, string> {
  if (!fontCache) { fontCache = {}; for (const f of readdirSync(FONT_DIR)) if (f.endsWith('.woff2')) fontCache[f] = readFileSync(join(FONT_DIR, f)).toString('base64'); }
  return fontCache;
}

export const MAX_PIXELS = 40_000_000; // refuse artboards × scale² beyond this (memory guard)
export class RenderError extends Error { constructor(public readonly code: string, message: string) { super(message); this.name = 'RenderError'; } }

export interface RenderRequest { spec: VisualSceneSpec; scale?: number; lighting?: string; resolveAsset?: (ref: string) => string | null; isolate?: boolean; timeoutMs?: number; transparent?: boolean }
export interface RenderOutput { png: Buffer; html: string; width: number; height: number; overflow: string[]; missingFonts: string[]; blockedRequests: string[]; problems: string[]; ms: number }

export class RenderWorker {
  private contexts = new Map<string, BrowserContext>();
  private constructor(private browser: Browser) {}
  static async launch(): Promise<RenderWorker> {
    const browser = await chromium.launch({ headless: true, args: ['--disable-gpu', '--font-render-hinting=none', '--disable-lcd-text', '--force-color-profile=srgb', '--disable-background-networking', '--disable-extensions'] });
    return new RenderWorker(browser);
  }
  async close(): Promise<void> { for (const c of this.contexts.values()) await c.close().catch(() => undefined); this.contexts.clear(); await this.browser.close(); }
  browserVersion(): string { return this.browser.version(); }

  private async context(width: number, height: number, scale: number, isolate: boolean): Promise<{ ctx: BrowserContext; dispose: boolean }> {
    const make = async (): Promise<BrowserContext> => {
      const ctx = await this.browser.newContext({ viewport: { width, height }, deviceScaleFactor: scale, javaScriptEnabled: false, serviceWorkers: 'block', locale: 'en-AU', timezoneId: 'Australia/Brisbane', reducedMotion: 'reduce', colorScheme: 'light', offline: false });
      return ctx;
    };
    if (isolate) return { ctx: await make(), dispose: true };
    const key = `${width}x${height}@${scale}`;
    let ctx = this.contexts.get(key);
    if (!ctx) { if (this.contexts.size > 24) { const [k, old] = this.contexts.entries().next().value as [string, BrowserContext]; await old.close(); this.contexts.delete(k); } ctx = await make(); this.contexts.set(key, ctx); }
    return { ctx, dispose: false };
  }

  /** Render raw artboard HTML (already produced by the trusted renderer or the sanitiser). */
  async renderHtml(html: string, width: number, height: number, opts: { scale?: number; isolate?: boolean; timeoutMs?: number; transparent?: boolean } = {}): Promise<Omit<RenderOutput, 'html' | 'problems'>> {
    const scale = opts.scale ?? 1; const t0 = Date.now(); const timeout = opts.timeoutMs ?? 20_000;
    if (!Number.isFinite(width) || !Number.isFinite(height) || width < 16 || height < 16 || width > 6000 || height > 6000) throw new RenderError('bad-dimensions', `Artboard ${width}×${height} is outside the supported range`);
    if (width * height * scale * scale > MAX_PIXELS) throw new RenderError('too-large', `Requested raster ${Math.round(width * scale)}×${Math.round(height * scale)} exceeds the ${MAX_PIXELS / 1e6}MP limit`);
    if (html.length > 12_000_000) throw new RenderError('too-large', 'Artboard markup exceeds 12MB');
    const { ctx, dispose } = await this.context(width, height, scale, opts.isolate ?? false);
    const page = await ctx.newPage(); const blocked: string[] = [];
    try {
      page.setDefaultTimeout(timeout);
      await page.route('**/*', route => { const u = route.request().url(); if (u.startsWith('data:') || u === 'about:blank') return route.continue(); blocked.push(u.slice(0, 200)); return route.abort('blockedbyclient'); });
      await page.setContent(html, { waitUntil: 'load', timeout });
      const info = await page.evaluate(async () => {
        await document.fonts.ready;
        await Promise.all([...document.images].map(img => (img.complete ? img.decode().catch(() => undefined) : new Promise<void>(res => { img.addEventListener('load', () => res(), { once: true }); img.addEventListener('error', () => res(), { once: true }); }))));
        const boards = document.querySelectorAll('[data-artboard="true"]');
        const overflow: string[] = [];
        // real overflow only: text spilling more than ~12% beyond its box (single decorative glyphs such as a quote mark are exempt)
        document.querySelectorAll<HTMLElement>('[data-text="1"]').forEach(el => { if ((el.textContent ?? '').trim().length <= 2) return; if (el.scrollHeight > el.clientHeight * 1.12 + 3 || el.scrollWidth > el.clientWidth * 1.04 + 3) overflow.push(el.closest('[data-layer]')?.getAttribute('data-layer') ?? '?'); });
        const failedFonts = [...document.fonts].filter(f => f.status === 'error').map(f => `${f.family} ${f.weight}`);
        const brokenImages = [...document.images].filter(i => !i.naturalWidth).length;
        return { boards: boards.length, overflow, failedFonts, brokenImages, scripts: document.scripts.length };
      });
      if (info.boards !== 1) throw new RenderError('artboard-count', `Expected exactly one artboard, found ${info.boards}`);
      if (info.brokenImages) throw new RenderError('broken-image', `${info.brokenImages} image(s) failed to decode`);
      const png = await page.locator('[data-artboard="true"]').screenshot({ type: 'png', animations: 'disabled', caret: 'hide', scale: 'device', omitBackground: !!opts.transparent, timeout });
      return { png, width: Math.round(width * scale), height: Math.round(height * scale), overflow: info.overflow, missingFonts: info.failedFonts, blockedRequests: blocked, ms: Date.now() - t0 };
    } catch (e) {
      if (e instanceof RenderError) throw e;
      const msg = e instanceof Error ? e.message : String(e);
      throw new RenderError(/Timeout/i.test(msg) ? 'timeout' : 'render-failed', msg.split('\n')[0]!.slice(0, 300));
    } finally { await page.close().catch(() => undefined); if (dispose) await ctx.close().catch(() => undefined); }
  }

  /** Validate a spec (fail closed), compile it with the trusted renderer and rasterise it. */
  async render(req: RenderRequest): Promise<RenderOutput> {
    const spec = validateSpec(req.spec);
    const { html, problems } = renderArtboardHtml(spec, { fonts: { mode: 'inline', data: loadFontData() }, lighting: req.lighting, resolveAsset: req.resolveAsset });
    const out = await this.renderHtml(html, spec.output.width, spec.output.height, { scale: req.scale, isolate: req.isolate, timeoutMs: req.timeoutMs, transparent: req.transparent });
    return { ...out, html, problems };
  }
}

/** Convenience one-shot (the shape sketched in the product spec §7D). */
export async function renderArtboard(html: string, width: number, height: number): Promise<Buffer> {
  const w = await RenderWorker.launch();
  try { return (await w.renderHtml(html, width, height, { isolate: true })).png; } finally { await w.close(); }
}
