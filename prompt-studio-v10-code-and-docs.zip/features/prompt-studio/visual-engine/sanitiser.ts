/**
 * Expert "custom fragment" sanitiser (NOT the default path — normal designs never contain model-authored markup).
 * Uses the vetted DOMPurify library running inside a real, network-less Chromium DOM, then a second independent
 * deny-list pass. Fails CLOSED: any residual active content rejects the whole fragment.
 */
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import type { Browser } from 'playwright';

const require = createRequire(import.meta.url);
let purifySrc: string | null = null;
const purify = (): string => (purifySrc ??= readFileSync(require.resolve('dompurify/dist/purify.min.js'), 'utf8'));

export class SanitiseError extends Error { constructor(public readonly reasons: string[]) { super('Fragment rejected: ' + reasons.join('; ')); this.name = 'SanitiseError'; } }
export const MAX_FRAGMENT_BYTES = 400_000;

const ALLOWED_TAGS = ['div', 'span', 'p', 'h1', 'h2', 'h3', 'strong', 'em', 'b', 'i', 'br', 'ul', 'ol', 'li', 'svg', 'g', 'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'defs', 'linearGradient', 'radialGradient', 'stop', 'clipPath', 'mask', 'pattern', 'text', 'tspan', 'title', 'desc'];
const ALLOWED_ATTR = ['style', 'class', 'id', 'viewBox', 'xmlns', 'd', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'width', 'height', 'points', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray', 'opacity', 'fill-opacity', 'stroke-opacity', 'transform', 'offset', 'stop-color', 'stop-opacity', 'gradientUnits', 'gradientTransform', 'patternUnits', 'preserveAspectRatio', 'font-family', 'font-size', 'font-weight', 'text-anchor', 'clip-path', 'mask', 'role', 'aria-label', 'aria-hidden', 'data-layer'];
const DENY: Array<[RegExp, string]> = [
  [/<\s*\/?\s*(script|iframe|object|embed|link|meta|base|form|input|button|textarea|select|audio|video|source|img|image|use|foreignObject|animate|animateTransform|animateMotion|set|style|a)\b/i, 'forbidden element'],
  [/\son[a-z]+\s*=/i, 'event handler attribute'], [/javascript\s*:|vbscript\s*:|data\s*:\s*text\/html/i, 'active URL scheme'],
  [/url\s*\(/i, 'CSS url() reference'], [/@import|expression\s*\(|behavior\s*:|-moz-binding/i, 'active CSS'], [/(xlink:)?href\s*=/i, 'href attribute'], [/position\s*:\s*fixed/i, 'fixed positioning'],
];

/** Sanitise an untrusted HTML/SVG fragment. Returns clean markup or throws SanitiseError. */
export async function sanitiseFragment(browser: Browser, fragment: string): Promise<string> {
  if (typeof fragment !== 'string') throw new SanitiseError(['fragment must be a string']);
  if (Buffer.byteLength(fragment) > MAX_FRAGMENT_BYTES) throw new SanitiseError([`fragment exceeds ${MAX_FRAGMENT_BYTES} bytes`]);
  const ctx = await browser.newContext({ javaScriptEnabled: true, serviceWorkers: 'block', offline: true });
  try {
    const page = await ctx.newPage(); page.setDefaultTimeout(5000);
    await page.route('**/*', r => r.abort('blockedbyclient'));
    await page.setContent('<!doctype html><html><head></head><body></body></html>');
    await page.addScriptTag({ content: purify() });
    const clean = await page.evaluate(([html, tags, attrs]) => {
      const P = (window as unknown as { DOMPurify: { sanitize: (h: string, c: object) => string; addHook: (n: string, f: (node: Element, d: { attrName: string; attrValue: string; keepAttr: boolean }) => void) => void } }).DOMPurify;
      P.addHook('uponSanitizeAttribute', (_n, d) => { if (d.attrName === 'style' && /url\s*\(|expression|@import|position\s*:\s*fixed|behavior|-moz-binding/i.test(d.attrValue)) d.keepAttr = false; });
      return P.sanitize(html as string, { ALLOWED_TAGS: tags as string[], ALLOWED_ATTR: attrs as string[], ALLOW_DATA_ATTR: false, ALLOW_UNKNOWN_PROTOCOLS: false, USE_PROFILES: { html: true, svg: true }, FORBID_TAGS: ['style', 'foreignObject', 'use', 'image', 'a', 'img'], KEEP_CONTENT: false, RETURN_TRUSTED_TYPE: false });
    }, [fragment, ALLOWED_TAGS, ALLOWED_ATTR] as const);
    const reasons = DENY.filter(([re]) => re.test(clean)).map(([, why]) => why);
    if (reasons.length) throw new SanitiseError(reasons);
    return clean;
  } catch (e) { if (e instanceof SanitiseError) throw e; throw new SanitiseError(['sanitiser failed: ' + (e as Error).message.split('\n')[0]]); }
  finally { await ctx.close(); }
}

/** Wrap a sanitised fragment in the same locked-down artboard document the trusted renderer produces. */
export function wrapFragment(clean: string, width: number, height: number): string {
  return `<!doctype html><html lang="en-AU"><head><meta charset="utf-8"/><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; base-uri 'none'; form-action 'none'"/><style>*{margin:0;padding:0}[data-artboard]{position:relative;overflow:hidden;width:${Math.round(width)}px;height:${Math.round(height)}px;contain:strict}</style></head><body><div data-artboard="true">${clean}</div></body></html>`;
}
