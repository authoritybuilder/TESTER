/**
 * Suggested, clearly-editable slot copy. Derived from the source safe-zone purpose (e.g. "event-name +
 * speaker-credentials") and the customer's own brand kit. Never invents offers, prices, results or testimonials:
 * proof slots are explicit placeholders, flagged `copyStatus: 'suggested'`.
 */
import { sentence } from '../shared/util.ts';

export interface BrandContext {
  workspaceId?: string; businessName?: string; offer?: string; audience?: string; painPoint?: string; promise?: string; cta?: string; website?: string;
  palette?: { primary: string; secondary: string; accent: string; light: string; dark: string };
  headlineFont?: 'jakarta' | 'fraunces' | 'anton'; bodyFont?: 'jakarta' | 'fraunces';
  logoText?: string; logoSrc?: string; approvedCopy?: string[];
}
export interface SlotCopy { headline: string; details: string; status: 'suggested' | 'brand-kit' }

const clean = (p: string): string => p.replace(/\boverlay\b|\bcopy\b|\bzone\b|\(.*?\)/gi, '').replace(/-/g, ' ').replace(/\s{2,}/g, ' ').trim();
const cap = (s: string): string => sentence(s.toLowerCase());

export function slotCopy(purpose: string, role: string, brand?: BrandContext): SlotCopy {
  const p = purpose.toLowerCase();
  const b = brand ?? {};
  const name = b.businessName?.trim();
  switch (role) {
    case 'cta': return b.cta ? { headline: b.cta, details: '', status: 'brand-kit' } : { headline: /rsvp/.test(p) ? 'RSVP' : /download/.test(p) ? 'Download' : /book|booking|audit/.test(p) ? 'Book a call' : /resource/.test(p) ? 'Browse resources' : /survey/.test(p) ? 'Take the survey' : 'Find out more', details: '', status: 'suggested' };
    case 'quote': return { headline: /expert/.test(p) ? '“Add your expert quote here.”' : '“Add a real client quote here.”', details: /expert/.test(p) ? (name ?? 'Your name') + ' · Credential' : 'Client name · shared with permission', status: 'suggested' };
    case 'masthead': return name ? { headline: name, details: 'Issue · Date', status: 'brand-kit' } : { headline: 'Masthead', details: 'Issue · Date', status: 'suggested' };
    case 'number': return { headline: '12', details: 'Table', status: 'suggested' };
    case 'message': return { headline: /gratitude/.test(p) ? 'Thank you for being here.' : /mission/.test(p) ? (b.promise ?? 'Your mission statement, in one sentence.') : 'Welcome. We’re glad you’re here.', details: '', status: /mission/.test(p) && b.promise ? 'brand-kit' : 'suggested' };
    case 'logo': return name ? { headline: b.logoText ?? name, details: '', status: 'brand-kit' } : { headline: 'Your brand', details: '', status: 'suggested' };
    case 'signature': return { headline: name ?? 'Your signature', details: '', status: name ? 'brand-kit' : 'suggested' };
  }
  // headline / details: split "a + b + c" into a headline slot and a details line
  const parts = clean(purpose).split(/\s*\+\s*|\s+and\s+/).map(s => s.trim()).filter(Boolean).filter(s => !/^(cta|cta button|booking cta|rsvp cta|download cta)$/i.test(s)).map(s => (/^sub ?head$/i.test(s) ? 'One supporting line about the result' : s));
  const head = parts[0] ?? 'headline';
  const rest = parts.slice(1).map(cap);
  if (role === 'details') return { headline: [cap(head), ...rest].join(' · '), details: '', status: 'suggested' };
  const h = head.toLowerCase();
  const restB = rest.map(r => (/^One supporting line/.test(r) && b.offer ? b.offer : r));
  if (b.promise && /headline|offer/.test(h)) return { headline: b.promise, details: restB.join(' · ') || (b.offer ?? ''), status: 'brand-kit' };
  if (name && /newsletter name|show name|community name|brand|services name|programme name|group name/.test(h)) return { headline: /services/.test(h) && b.offer ? b.offer : name, details: rest.join(' · '), status: 'brand-kit' };
  if (b.offer && /event name|workshop title|programme|cohort name|retreat name|bundle name|launch name|product name|bonus name|trailer name|module|report title/.test(h)) return { headline: b.offer, details: rest.join(' · '), status: 'brand-kit' };
  const special: Array<[RegExp, string]> = [
    [/module number/, 'Module 01'], [/episode title|episode number/, 'Ep. 00 — Episode title'], [/lesson title/, 'Your lesson title'], [/slide specific|slide 1/, 'Your key point for this slide'],
    [/headline/, 'Your headline goes here'], [/hook text/, 'Your hook, in five words'], [/blog title|article title|article headline/, 'Your article title'], [/quarter/, 'Q0 · Year'],
    [/time stamp/, '00:00'], [/collection name/, 'Collection name'], [/recipe name/, 'Recipe name'], [/destination name/, 'Destination'], [/method name/, 'Your Method Name'],
  ];
  for (const [re, txt] of special) if (re.test(h)) return { headline: txt, details: rest.join(' · '), status: 'suggested' };
  return { headline: 'Your ' + h.replace(/^your\s+/, ''), details: rest.join(' · '), status: 'suggested' };
}

/**
 * Deterministic text fitting from measured glyph metrics (scripts/dev/measure-fonts.ts), verified afterwards by the
 * render worker's real-browser overflow check. Returns a font size in artboard units.
 */
const METRICS: Record<string, [number, number]> = { jakarta: [0.53, 0.63], fraunces: [0.545, 0.69], anton: [0.44, 0.45], caveat: [0.38, 0.49] };
function charWidth(ch: string, font: string, upper: boolean, weight: number): number {
  const m = METRICS[font] ?? METRICS.jakarta!; const isUp = upper || (ch >= 'A' && ch <= 'Z');
  const base = (isUp ? m[1] : m[0]) * (1 + (weight - 600) / 9000);
  if (ch === ' ') return base * 0.5;
  if ('mwMW@—%'.includes(ch)) return base * (isUp ? 1.42 : 1.5);
  if ("iltjfI.,:;!'|1·-()".includes(ch) && !(upper && /[a-z]/.test(ch) && !'ij'.includes(ch))) return base * (upper && /[a-z]/.test(ch) ? 0.62 : 0.56);
  return base * 1.06;
}
export function textWidth(text: string, font: string, upper: boolean, weight: number): number { let w = 0; for (const ch of text) w += charWidth(ch, font, upper, weight); return w; }
export function fitText(text: string, boxWpx: number, boxHpx: number, font: string, U: number, maxUnits: number, minUnits: number, lineHeight: number, uppercase = false, weight = 700): number {
  const paras = text.split('\n').map(p => p.split(/\s+/).filter(Boolean));
  const words = paras.flat(); const wW = words.map(w => textWidth(w, font, uppercase, weight));
  const longest = wW.reduce((m, w) => Math.max(m, w), 0.3); const space = charWidth(' ', font, uppercase, weight);
  const avail = boxWpx * 0.95;
  for (let s = maxUnits; s >= minUnits; s -= 0.2) {
    const fs = s * U;
    if (longest * fs > avail) continue;
    let lines = 0;
    for (const para of paras) { let cur = 0; lines++; for (const w of para) { const ww = textWidth(w, font, uppercase, weight) * fs; if (cur && cur + space * fs + ww > avail) { lines++; cur = ww; } else cur += (cur ? space * fs : 0) + ww; } }
    if (lines * fs * lineHeight <= boxHpx * 0.98) return Math.round(s * 100) / 100;
  }
  return minUnits;
}
