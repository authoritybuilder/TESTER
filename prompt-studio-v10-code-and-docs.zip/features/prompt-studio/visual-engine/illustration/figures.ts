/**
 * Stylised, deliberately faceless figure illustrations (trusted inline SVG, viewBox 600×1000).
 * They stand in for the photographed subject in *composition concepts* — never presented as a photo.
 * Pose comes from the source `poseDirection`/`framing` (compiler/dna.ts classifyPose).
 */
import { between, pick, rng } from '../../shared/util.ts';
import { C, L, M, Q, Z, circ, darken, ell, g, lighten, line, mix, path, poly, rect, stroke, tr, type Tone } from './svg.ts';

export const FIGURE_POSES = ['standing-relaxed', 'welcome-open', 'stage-mic', 'board-marker', 'framework-point', 'presenting-item', 'celebrate', 'contemplative', 'lean-mug', 'reading', 'hook-energy', 'mid-action', 'portrait-direct', 'fashion', 'behind-camera', 'behind-mic', 'desk-settled', 'seated-client'] as const;
export type FigurePose = (typeof FIGURE_POSES)[number];
export const TOP_KINDS = ['blazer', 'knit', 'athletic', 'flow', 'shirt'] as const;
export interface FigureLook { skin: string; hair: string; hairStyle: number; top: string; topKind: (typeof TOP_KINDS)[number]; bottom: string; accent: string; beard: boolean }

const SKINS = ['#F3D3B8', '#E9BE9A', '#D9A57E', '#B97F56', '#8D5A3B', '#6A4028'];
const HAIRS = ['#22180F', '#3B2A1E', '#5A3B25', '#8A5A33', '#B98B4A', '#1B1B22'];
const WARDROBE_COLOURS: Array<[RegExp, string]> = [
  [/cream|ivory|oat|ecru/, '#EDE3D0'], [/white/, '#F7F5F0'], [/black/, '#1D1D21'], [/navy/, '#1F2D4D'], [/charcoal|graphite/, '#33363D'],
  [/camel|tan|beige/, '#C19A6B'], [/sage/, '#9BAA8E'], [/blush|pink/, '#E3B3B3'], [/denim|blue/, '#4F6F98'], [/olive|khaki/, '#77784A'],
  [/burgundy|wine/, '#6E1F2B'], [/grey|gray/, '#8B8E94'], [/emerald|green/, '#2C6B55'], [/rust|terracotta/, '#B5603C'], [/linen/, '#DDD2BF'],
];

/** Derive a figure look from the scene's own wardrobe text + palette, seeded by scene id. */
export function buildLook(seed: string, wardrobe: string, presentation: string, age: string, palette: { primary: string; secondary: string; accent: string; dark: string; background: string }): FigureLook {
  const r = rng('look:' + seed); const w = wardrobe.toLowerCase();
  const hit = WARDROBE_COLOURS.find(([re]) => re.test(w));
  let top = hit ? hit[1] : pick(r, [palette.primary, palette.secondary, mix(palette.primary, '#FFFFFF', 0.2), palette.dark]);
  const topKind: FigureLook['topKind'] = /blazer|suit|tailored|jacket|executive/.test(w) ? 'blazer' : /athletic|training|performance|activewear|fitted/.test(w) ? 'athletic' : /flowing|linen|dress|kaftan|layers|apron|robe/.test(w) ? 'flow' : /knit|cardigan|sweater|jumper|cashmere/.test(w) ? 'knit' : /shirt|button|oxford/.test(w) ? 'shirt' : pick(r, ['knit', 'shirt', 'blazer', 'flow'] as const);
  const older = /fifties|sixties|seventies/.test(age);
  const hairStyle = presentation === 'man' ? pick(r, [0, 0, 5, 4]) : presentation === 'woman' ? pick(r, [1, 2, 3, 4, 5]) : Math.floor(r() * 6);
  // keep clothing distinguishable from the wall behind it
  if (Math.abs(lum(top) - lum(palette.background)) < 0.12) top = lum(palette.background) > 0.5 ? darken(top, 0.4) : lighten(top, 0.5);
  return {
    skin: pick(r, SKINS), hair: older && r() < 0.7 ? '#B9B6B0' : pick(r, HAIRS), hairStyle, top, topKind,
    bottom: pick(r, ['#2B2F38', '#3A3F4A', mix(palette.dark, '#3A3F4A', 0.5), '#5B4A3A', '#D8CFC0']), accent: palette.accent,
    beard: presentation === 'man' && r() < 0.4,
  };
}
function lum(hex: string): number { const v = parseInt(hex.slice(1), 16); return (0.299 * ((v >> 16) & 255) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; }

type Pt = [number, number];
interface Arms { le: Pt; lh: Pt; re: Pt; rh: Pt; tilt: number; legs: 'stand' | 'stance' | 'none' }
const ARMS: Record<string, Arms> = {
  'standing-relaxed': { le: [168, 360], lh: [182, 500], re: [432, 360], rh: [418, 500], tilt: 0, legs: 'stand' },
  'welcome-open': { le: [130, 340], lh: [52, 262], re: [470, 340], rh: [548, 262], tilt: 0, legs: 'stand' },
  'stage-mic': { le: [140, 330], lh: [66, 270], re: [440, 350], rh: [352, 268], tilt: -3, legs: 'stance' },
  'board-marker': { le: [170, 360], lh: [196, 480], re: [470, 250], rh: [560, 150], tilt: 6, legs: 'stand' },
  'framework-point': { le: [168, 360], lh: [220, 440], re: [478, 290], rh: [572, 232], tilt: 5, legs: 'stand' },
  'presenting-item': { le: [168, 360], lh: [190, 490], re: [476, 350], rh: [566, 330], tilt: 3, legs: 'stand' },
  celebrate: { le: [128, 170], lh: [92, 36], re: [472, 170], rh: [508, 36], tilt: 0, legs: 'stance' },
  contemplative: { le: [166, 360], lh: [184, 500], re: [436, 370], rh: [318, 300], tilt: -7, legs: 'stand' },
  'lean-mug': { le: [176, 372], lh: [276, 332], re: [424, 372], rh: [324, 332], tilt: 4, legs: 'stand' },
  reading: { le: [170, 380], lh: [240, 400], re: [430, 380], rh: [360, 400], tilt: 0, legs: 'stand' },
  'hook-energy': { le: [132, 356], lh: [214, 446], re: [462, 262], rh: [470, 120], tilt: 8, legs: 'stance' },
  'mid-action': { le: [170, 366], lh: [212, 470], re: [452, 372], rh: [470, 470], tilt: 5, legs: 'stand' },
  'portrait-direct': { le: [176, 372], lh: [392, 356], re: [424, 372], rh: [208, 368], tilt: 0, legs: 'stand' },
  fashion: { le: [118, 352], lh: [214, 452], re: [436, 362], rh: [424, 506], tilt: -5, legs: 'stance' },
  'behind-camera': { le: [176, 300], lh: [246, 150], re: [424, 300], rh: [354, 150], tilt: 0, legs: 'stand' },
  'behind-mic': { le: [170, 366], lh: [220, 470], re: [430, 366], rh: [380, 470], tilt: 0, legs: 'none' },
  'desk-settled': { le: [164, 372], lh: [232, 474], re: [436, 372], rh: [330, 452], tilt: -3, legs: 'none' },
  'seated-client': { le: [170, 366], lh: [226, 512], re: [430, 366], rh: [392, 470], tilt: 4, legs: 'none' },
};

function hairBack(l: FigureLook): string {
  switch (l.hairStyle) {
    case 2: return path(M(238, 80) + C(220, 200, 214, 280, 232, 330) + L(368, 330) + C(386, 280, 380, 200, 362, 80) + Z, l.hair);
    case 4: return circ(300, 78, 82, l.hair) + circ(236, 110, 40, l.hair) + circ(364, 110, 40, l.hair);
    case 1: return path(M(240, 70) + C(226, 130, 230, 170, 244, 186) + L(356, 186) + C(370, 170, 374, 130, 360, 70) + Z, l.hair);
    case 5: return path(M(242, 70) + C(232, 130, 236, 160, 250, 172) + L(350, 172) + C(364, 160, 368, 130, 358, 70) + Z, l.hair);
    default: return '';
  }
}
function hairFront(l: FigureLook): string {
  switch (l.hairStyle) {
    case 0: return path(M(248, 78) + C(246, 28, 354, 28, 352, 78) + C(336, 56, 264, 56, 248, 78) + Z, l.hair);
    case 1: return path(M(246, 96) + C(238, 22, 362, 22, 354, 96) + C(346, 58, 300, 50, 268, 64) + C(256, 72, 250, 84, 246, 96) + Z, l.hair);
    case 2: return path(M(244, 100) + C(236, 20, 364, 20, 356, 100) + C(350, 60, 320, 50, 300, 58) + C(280, 50, 250, 60, 244, 100) + Z, l.hair);
    case 3: return circ(300, 18, 26, l.hair) + path(M(248, 86) + C(244, 26, 356, 26, 352, 86) + C(338, 54, 262, 54, 248, 86) + Z, l.hair);
    case 4: return path(M(246, 88) + C(244, 40, 356, 40, 354, 88) + C(340, 60, 260, 60, 246, 88) + Z, l.hair);
    default: return path(M(246, 96) + C(240, 24, 360, 24, 354, 92) + C(330, 48, 282, 46, 262, 70) + C(254, 78, 250, 86, 246, 96) + Z, l.hair);
  }
}
function head(l: FigureLook, tilt: number): string {
  const beard = l.beard ? path(M(256, 108) + C(258, 160, 342, 160, 344, 108) + C(330, 128, 270, 128, 256, 108) + Z, l.hair, 0.92) : '';
  return g(hairBack(l) + rect(280, 136, 40, 58, darken(l.skin, 0.1), 10) + ell(300, 95, 50, 60, l.skin) + ell(249, 100, 8, 13, l.skin) + ell(351, 100, 8, 13, l.skin) + beard + hairFront(l), `rotate(${tilt} 300 150)`);
}
function torso(l: FigureLook, hem = 540): string {
  const t = l.top;
  const body = l.topKind === 'flow'
    ? path(M(196, 200) + Q(300, 178, 404, 200) + L(420, 440) + L(436, hem + 30) + L(164, hem + 30) + L(180, 440) + Z, t)
    : l.topKind === 'athletic'
      ? path(M(222, 196) + Q(300, 214, 378, 196) + L(392, 300) + L(380, hem) + L(220, hem) + L(208, 300) + Z, t)
      : path(M(196, 200) + Q(300, 178, 404, 200) + L(412, 330) + L(396, hem) + L(204, hem) + L(188, 330) + Z, t);
  let detail = '';
  if (l.topKind === 'blazer') detail = poly([[272, 190], [328, 190], [300, 330]], '#F4F1EA') + stroke(M(272, 190) + L(300, 334) + L(328, 190), darken(t, 0.22), 6) + stroke(M(300, 334) + L(300, hem), darken(t, 0.22), 4) + circ(300, 400, 6, darken(t, 0.3));
  else if (l.topKind === 'knit') detail = stroke(M(268, 192) + Q(300, 222, 332, 192), darken(t, 0.14), 10) + [0, 1, 2, 3, 4, 5].map(i => line(222 + i * 31, hem - 26, 222 + i * 31, hem - 4, darken(t, 0.1), 4, 0.7)).join('');
  else if (l.topKind === 'shirt') detail = poly([[270, 190], [300, 232], [286, 250]], lighten(t, 0.18)) + poly([[330, 190], [300, 232], [314, 250]], lighten(t, 0.18)) + line(300, 236, 300, hem, darken(t, 0.16), 4) + [0, 1, 2].map(i => circ(300, 286 + i * 70, 5, darken(t, 0.25))).join('');
  else if (l.topKind === 'athletic') detail = stroke(M(252, 198) + Q(300, 236, 348, 198), l.skin, 26) + line(222, 330, 378, 330, l.accent, 8, 0.9);
  else detail = stroke(M(262, 192) + Q(300, 240, 338, 192), darken(t, 0.12), 8) + path(M(180, 440) + Q(300, 470, 420, 440), 'none');
  return body + detail;
}
function arm(l: FigureLook, s: Pt, e: Pt, hnd: Pt): string {
  const sleeve = l.topKind === 'athletic' ? l.skin : l.top;
  return stroke(M(s[0], s[1]) + L(e[0], e[1]) + L(hnd[0], hnd[1]), darken(sleeve, l.topKind === 'athletic' ? 0.04 : 0.08), 46) + circ(hnd[0], hnd[1], 26, l.skin);
}
function legs(l: FigureLook, mode: Arms['legs']): string {
  if (mode === 'none') return '';
  const spread = mode === 'stance' ? 34 : 14; const b = l.bottom;
  return ell(300, 972, 150, 14, '#000000', 0.14) + stroke(M(262, 520) + L(262 - spread, 930), b, 74, 1, 'butt') + stroke(M(338, 520) + L(338 + spread, 930), b, 74, 1, 'butt') + rect(222, 500, 156, 60, b, 16) +
    rect(212 - spread, 926, 92, 34, '#22242A', 14) + rect(296 + spread, 926, 92, 34, '#22242A', 14);
}

/** Draw a figure. Faces right by default (the "active" arm is the right arm); `facing:'left'` mirrors it. */
export function drawFigure(pose: FigurePose, l: FigureLook, t: Tone, facing: 'left' | 'right' = 'right'): string {
  const a = ARMS[pose] ?? ARMS['standing-relaxed']!;
  const LS: Pt = [208, 222], RS: Pt = [392, 222];
  let back = '', front = '', body = '';
  const upper = (dy = 0): string => g(arm(l, LS, a.le, a.lh) + torso(l) + head(l, a.tilt) + arm(l, RS, a.re, a.rh), dy ? tr(0, dy) : '');

  switch (pose) {
    case 'seated-client': {
      back = ell(300, 972, 250, 18, '#000000', 0.14) + rect(96, 330, 408, 420, t.soft, 80) + rect(40, 560, 110, 330, t.softShade, 46) + rect(450, 560, 110, 330, t.softShade, 46) + rect(120, 700, 360, 150, lighten(t.soft, 0.1), 30);
      const lower = stroke(M(250, 690) + L(206, 760) + L(214, 930), l.bottom, 78, 1, 'butt') + stroke(M(350, 690) + L(394, 760) + L(386, 930), l.bottom, 78, 1, 'butt') + rect(168, 924, 96, 36, '#22242A', 14) + rect(336, 924, 96, 36, '#22242A', 14);
      body = g(arm(l, LS, a.le, a.lh) + torso(l, 520) + head(l, a.tilt) + arm(l, RS, a.re, a.rh), tr(0, 170)) + lower;
      break;
    }
    case 'desk-settled': {
      body = upper(120);
      front = rect(-260, 600, 1120, 46, t.wood, 10) + rect(-260, 646, 1120, 400, t.woodDark) + g(rect(-110, -150, 220, 150, t.dark, 12) + rect(-98, -138, 196, 126, lighten(t.screen, 0.7), 6) + rect(-140, 0, 280, 16, t.metal, 8), tr(120, 600, 1, 0)) + g(path(M(-34, -70) + L(34, -70) + L(28, 0) + L(-28, 0) + Z, t.paper) + stroke(M(34, -52) + Q(62, -40, 30, -18), t.paper, 10), tr(486, 600));
      break;
    }
    case 'behind-mic': {
      body = upper(110) + g(stroke(M(236, 78) + C(236, 0, 364, 0, 364, 78), t.dark, 14) + rect(222, 70, 30, 60, t.dark, 12) + rect(348, 70, 30, 60, t.dark, 12), tr(0, 110));
      front = rect(-260, 610, 1120, 40, t.wood, 10) + rect(-260, 650, 1120, 400, t.woodDark) + stroke(M(520, 610) + L(470, 380) + L(360, 330), t.dark, 12) + rect(318, 286, 64, 120, t.dark, 30) + rect(318, 372, 64, 14, t.accent) + [0, 1, 2].map(i => line(326, 306 + i * 18, 374, 306 + i * 18, t.metal, 4)).join('');
      break;
    }
    default: body = legs(l, a.legs) + upper();
  }
  // pose props held in hand
  if (pose === 'stage-mic') front += g(rect(-11, -52, 22, 70, t.dark, 8) + circ(0, -60, 20, t.metal) + circ(0, -60, 14, darken(t.metal, 0.2)), tr(a.rh[0] - 2, a.rh[1] - 6, 1, -14));
  if (pose === 'board-marker') front += g(rect(-7, -44, 14, 50, t.accent, 6) + rect(-5, -54, 10, 12, t.dark, 3), tr(a.rh[0], a.rh[1], 1, 28));
  if (pose === 'lean-mug') front += g(path(M(-34, -44) + L(34, -44) + L(28, 30) + L(-28, 30) + Z, t.paper) + ell(0, -44, 34, 8, darken(t.paper, 0.14)) + stroke(M(-12, -62) + Q(-22, -84, -8, -100), t.light, 6, 0.7), tr(300, 322));
  if (pose === 'reading') front += path(M(300, 366) + Q(240, 340, 176, 356) + L(176, 452) + Q(240, 436, 300, 462) + Z, t.paper) + path(M(300, 366) + Q(360, 340, 424, 356) + L(424, 452) + Q(360, 436, 300, 462) + Z, darken(t.paper, 0.05)) + line(300, 366, 300, 462, t.metal, 4) + circ(a.lh[0] - 50, a.lh[1] + 10, 24, l.skin) + circ(a.rh[0] + 50, a.rh[1] + 10, 24, l.skin);
  if (pose === 'behind-camera') front += rect(226, 96, 148, 96, t.dark, 16) + circ(300, 146, 40, t.metal) + circ(300, 146, 27, t.screen) + circ(290, 136, 8, lighten(t.screen, 0.6)) + rect(250, 80, 50, 22, t.dark, 6) + circ(a.lh[0] - 14, a.lh[1] + 6, 24, l.skin) + circ(a.rh[0] + 14, a.rh[1] + 6, 24, l.skin);
  if (pose === 'mid-action') front += g(rect(-5, -46, 10, 56, t.dark, 4), tr(a.rh[0] + 8, a.rh[1] - 4, 1, 30));
  if (pose === 'hook-energy') front += stroke(M(a.rh[0], a.rh[1] - 20) + L(a.rh[0] + 4, a.rh[1] - 62), l.skin, 16);
  if (pose === 'presenting-item') front += ell(a.rh[0] + 6, a.rh[1] + 2, 30, 16, l.skin);

  const all = back + body + front;
  return facing === 'left' ? g(all, 'translate(600 0) scale(-1 1)') : all;
}

/** Top-down hands entering the frame (flat-lay / unboxing / detail scenes). viewBox 1000×600, wrists at the bottom edge. */
export function drawHands(l: FigureLook, t: Tone, mode: 'present' | 'reveal' | 'detail', seed: string): string {
  const r = rng('hands:' + seed); const sleeve = l.topKind === 'athletic' ? l.skin : l.top; const spread = between(r, 0, 40);
  const hand = (cx: number, cy: number, rot: number): string => g(ell(0, 0, 56, 68, l.skin) + [-36, -14, 8, 30].map((dx, i) => rect(dx - 10, -128 + Math.abs(i - 1.5) * 12, 22, 86, l.skin, 11)).join('') + g(rect(-12, -40, 24, 78, l.skin, 12), tr(50, 0, 1, 48)), tr(cx, cy, 1, rot));
  const foreL = stroke(M(60 - spread, 640) + L(250, 380), sleeve, 124) + hand(292, 318, mode === 'reveal' ? 38 : 26);
  const foreR = stroke(M(940 + spread, 640) + L(750, 380), sleeve, 124) + g(hand(292, 318, mode === 'reveal' ? 38 : 26), 'translate(1000 0) scale(-1 1)');
  if (mode === 'detail') return stroke(M(120, 640) + L(420, 330), sleeve, 130) + hand(470, 268, 34) + (t ? '' : '');
  return foreL + foreR;
}
void [Q, ell, poly];
