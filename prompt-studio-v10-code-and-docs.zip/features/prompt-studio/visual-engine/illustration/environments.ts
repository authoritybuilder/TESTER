/**
 * Illustrated environments — trusted inline SVG composed from furniture primitives.
 * The environment kind is classified from the scene's own source text (compiler/dna.ts ENV_RULES);
 * the seed (scene id) varies arrangement so two scenes in the same niche are still different rooms.
 */
import { between, pick, rng } from '../../shared/util.ts';
import { C, L, M, Q, Z, circ, darken, ell, g, lighten, line, mix, n, path, poly, rect, stroke, tr, type Tone } from './svg.ts';

export interface EnvOptions { seed: string; horizon: number; busy: 'left' | 'right' | 'both'; lighting: string }
interface Ctx { w: number; h: number; u: number; t: Tone; r: () => number; hz: number; night: boolean; warm: boolean }

// ---------- primitives (x, y in px; s scales with u) ----------
const windowTall = (c: Ctx, x: number, top: number, ww: number, wh: number, panes = 2): string => {
  const { t, u } = c; let s = rect(x - u, top - u, ww + 2 * u, wh + 2 * u, t.light, u * 0.6) + rect(x, top, ww, wh, t.glass);
  s += rect(x, top + wh * 0.62, ww, wh * 0.38, mix(t.glass, c.night ? '#1B2440' : '#BFD8C4', 0.35), 0, 0.8);
  for (let i = 1; i < panes; i++) s += rect(x + (ww / panes) * i - u * 0.4, top, u * 0.8, wh, t.light);
  s += rect(x, top + wh * 0.5 - u * 0.4, ww, u * 0.8, t.light);
  return s;
};
const lightBeam = (c: Ctx, x: number, top: number, ww: number, wh: number, dir = 1): string =>
  poly([[x, top + wh], [x + ww, top + wh], [x + ww + dir * c.u * 26, c.h], [x + dir * c.u * 10, c.h]], c.t.glow, c.warm ? 0.22 : 0.12);
const plantFloor = (c: Ctx, x: number, base: number, s = 1): string => {
  const { t, u } = c; const k = u * s; let o = ell(x, base, 7 * k, 1.2 * k, t.dark, 0.12) + path(M(x - 5 * k, base - 12 * k) + L(x + 5 * k, base - 12 * k) + L(x + 4 * k, base) + L(x - 4 * k, base) + Z, t.soft);
  for (const [a, len, wd, col] of [[-38, 22, 4, t.plantDark], [-16, 30, 4.6, t.plant], [6, 34, 5, t.plantDark], [26, 26, 4.4, t.plant], [44, 18, 3.6, t.plantDark]] as Array<[number, number, number, string]>)
    o += g(ell(0, -len * k * 0.5, wd * k, len * k * 0.5, col), tr(x, base - 12 * k, 1, a));
  return o;
};
const shelf = (c: Ctx, x: number, top: number, sw: number, rows: number, rowH: number): string => {
  const { t, u, r } = c; let o = '';
  for (let i = 0; i < rows; i++) {
    const y = top + i * rowH; o += rect(x, y + rowH - u, sw, u, t.woodDark);
    let bx = x + u; const end = x + sw - u * 2;
    while (bx < end) {
      const kind = r();
      if (kind < 0.7) { const bw = between(r, 1.2, 2.6) * u, bh = between(r, 0.55, 0.85) * (rowH - u); o += rect(bx, y + rowH - u - bh, bw, bh, pick(r, [t.accent, t.paper, t.accent2, t.furniture, t.soft, t.softShade]), u * 0.2); bx += bw + u * 0.3; }
      else if (kind < 0.85) { o += circ(bx + 2.4 * u, y + rowH - u - 2.4 * u, 2.4 * u, pick(r, [t.accent2, t.soft, t.metal])); bx += 6 * u; }
      else bx += 4 * u;
    }
  }
  return o;
};
const art = (c: Ctx, x: number, y: number, aw: number, ah: number, v = 0): string => {
  const { t } = c; const inset = c.u * 0.8;
  return rect(x, y, aw, ah, t.woodDark, c.u * 0.3) + rect(x + inset, y + inset, aw - 2 * inset, ah - 2 * inset, t.paper) +
    (v % 3 === 0 ? circ(x + aw * 0.5, y + ah * 0.55, Math.min(aw, ah) * 0.22, t.accent) + rect(x + aw * 0.2, y + ah * 0.7, aw * 0.6, ah * 0.08, t.accent2)
      : v % 3 === 1 ? path(M(x + inset, y + ah - inset) + L(x + aw * 0.4, y + ah * 0.4) + L(x + aw * 0.6, y + ah * 0.62) + L(x + aw * 0.8, y + ah * 0.34) + L(x + aw - inset, y + ah - inset) + Z, t.accent2)
        : rect(x + aw * 0.25, y + ah * 0.22, aw * 0.5, ah * 0.5, t.accent, aw * 0.25));
};
const desk = (c: Ctx, x: number, base: number, dw: number, dh: number): string =>
  rect(x, base - dh, dw, c.u * 1.6, c.t.wood, c.u * 0.4) + rect(x + c.u * 1.5, base - dh + c.u * 1.6, c.u * 1.2, dh - c.u * 1.6, c.t.woodDark) + rect(x + dw - c.u * 2.7, base - dh + c.u * 1.6, c.u * 1.2, dh - c.u * 1.6, c.t.woodDark);
const armchair = (c: Ctx, x: number, base: number, s = 1, col?: string): string => {
  const k = c.u * s, f = col ?? c.t.soft;
  return ell(x, base, 13 * k, 1.6 * k, c.t.dark, 0.14) + rect(x - 9 * k, base - 30 * k, 18 * k, 22 * k, f, 6 * k) + rect(x - 13 * k, base - 18 * k, 6 * k, 15 * k, darken(f, 0.12), 3 * k) + rect(x + 7 * k, base - 18 * k, 6 * k, 15 * k, darken(f, 0.12), 3 * k) + rect(x - 9 * k, base - 13 * k, 18 * k, 8 * k, lighten(f, 0.1), 2 * k) + rect(x - 10 * k, base - 4 * k, 2 * k, 4 * k, c.t.woodDark) + rect(x + 8 * k, base - 4 * k, 2 * k, 4 * k, c.t.woodDark);
};
const sofa = (c: Ctx, x: number, base: number, sw: number): string => {
  const k = c.u, f = c.t.soft;
  return ell(x + sw / 2, base, sw * 0.52, 1.6 * k, c.t.dark, 0.12) + rect(x, base - 22 * k, sw, 16 * k, f, 5 * k) + rect(x - 3 * k, base - 15 * k, 6 * k, 13 * k, darken(f, 0.12), 3 * k) + rect(x + sw - 3 * k, base - 15 * k, 6 * k, 13 * k, darken(f, 0.12), 3 * k) + rect(x + 2 * k, base - 11 * k, sw - 4 * k, 8 * k, lighten(f, 0.1), 2 * k) + rect(x + 5 * k, base - 17 * k, 9 * k, 8 * k, c.t.accent, 2 * k) + rect(x + sw - 15 * k, base - 17 * k, 9 * k, 8 * k, c.t.accent2, 2 * k);
};
const lampFloor = (c: Ctx, x: number, base: number): string => {
  const k = c.u;
  return ell(x, base - 40 * k, 14 * k, 9 * k, c.t.glow, c.warm ? 0.4 : 0.2) + rect(x - 0.4 * k, base - 38 * k, 0.8 * k, 38 * k, c.t.metal) + rect(x - 4 * k, base - k, 8 * k, k, c.t.metal, k * 0.5) + path(M(x - 5 * k, base - 38 * k) + L(x + 5 * k, base - 38 * k) + L(x + 3 * k, base - 47 * k) + L(x - 3 * k, base - 47 * k) + Z, c.t.accent2);
};
const pendant = (c: Ctx, x: number, drop: number): string => {
  const k = c.u;
  return line(x, 0, x, drop, c.t.dark, 0.3 * k) + path(M(x - 5 * k, drop + 5 * k) + Q(x, drop - 4 * k, x + 5 * k, drop + 5 * k) + Z, c.t.furniture) + ell(x, drop + 7 * k, 9 * k, 5 * k, c.t.glow, c.warm ? 0.35 : 0.15);
};
const rug = (c: Ctx, cx: number, y: number, rw: number): string => ell(cx, y, rw / 2, c.u * 5, c.t.accent2, 0.5) + ell(cx, y, rw / 2 - c.u * 2, c.u * 3.6, lighten(c.t.accent2, 0.25), 0.5);
const board = (c: Ctx, x: number, y: number, bw: number, bh: number, kind: number): string => {
  const { t, u } = c; let o = rect(x - u * 0.6, y - u * 0.6, bw + u * 1.2, bh + u * 1.2, t.metal, u * 0.5) + rect(x, y, bw, bh, '#FFFFFF', u * 0.3);
  if (kind % 3 === 0) { for (let i = 0; i < 3; i++) o += circ(x + bw * (0.2 + i * 0.3), y + bh * 0.4, bh * 0.14, [t.accent, t.accent2, t.furniture][i] as string, 0.9) + (i < 2 ? line(x + bw * (0.2 + i * 0.3) + bh * 0.16, y + bh * 0.4, x + bw * (0.5 + i * 0.3) - bh * 0.16, y + bh * 0.4, t.dark, u * 0.3) : ''); o += line(x + bw * 0.12, y + bh * 0.74, x + bw * 0.7, y + bh * 0.74, t.dark, u * 0.3, 0.4); }
  else if (kind % 3 === 1) { for (let i = 0; i < 12; i++) o += rect(x + bw * (0.07 + (i % 4) * 0.23), y + bh * (0.1 + Math.floor(i / 4) * 0.29), bw * 0.17, bh * 0.22, ['#F5E050', t.accent, '#F7A8B8', lighten(t.accent2, 0.2)][(i * 7) % 4] as string, u * 0.2); }
  else { o += stroke(M(x + bw * 0.1, y + bh * 0.75) + L(x + bw * 0.3, y + bh * 0.55) + L(x + bw * 0.5, y + bh * 0.62) + L(x + bw * 0.72, y + bh * 0.3) + L(x + bw * 0.9, y + bh * 0.2), t.accent, u * 0.6) + line(x + bw * 0.1, y + bh * 0.85, x + bw * 0.9, y + bh * 0.85, t.dark, u * 0.25, 0.5) + rect(x + bw * 0.1, y + bh * 0.1, bw * 0.3, bh * 0.08, t.dark, u * 0.2, 0.7); }
  return o;
};
const monitorDesk = (c: Ctx, x: number, base: number, s = 1, v = 0): string => {
  const k = c.u * s, t = c.t; const sx = x - 11 * k, sy = base - 20 * k;
  let o = rect(sx, sy, 22 * k, 14 * k, t.dark, k) + rect(sx + k, sy + k, 20 * k, 12 * k, lighten(t.screen, v % 2 ? 0.1 : 0.8), k * 0.4);
  if (v % 2) for (let i = 0; i < 4; i++) o += rect(sx + 3 * k, sy + (2.6 + i * 2.4) * k, (6 + ((i * 5) % 9)) * k, 1.2 * k, i % 2 ? t.accent : lighten(t.screen, 0.5), k * 0.3);
  else o += rect(sx + 3 * k, sy + 7 * k, 2.4 * k, 5 * k, t.accent) + rect(sx + 7 * k, sy + 5 * k, 2.4 * k, 7 * k, t.accent2) + rect(sx + 11 * k, sy + 3 * k, 2.4 * k, 9 * k, t.accent) + circ(sx + 17 * k, sy + 6 * k, 2.4 * k, t.accent2);
  return o + rect(x - k, base - 6 * k, 2 * k, 5 * k, t.metal) + rect(x - 5 * k, base - 1.2 * k, 10 * k, 1.2 * k, t.metal, k * 0.5);
};
const ringLight = (c: Ctx, x: number, base: number, s = 1): string => {
  const k = c.u * s;
  return line(x, base - 30 * k, x - 6 * k, base, c.t.dark, 0.5 * k) + line(x, base - 30 * k, x + 6 * k, base, c.t.dark, 0.5 * k) + line(x, base - 32 * k, x, base, c.t.dark, 0.5 * k) + circ(x, base - 42 * k, 12 * k, c.t.glow, 0.25) + stroke(M(x, base - 52 * k) + `A${n(10 * k)} ${n(10 * k)} 0 1 1 ${n(x - 0.1)} ${n(base - 52 * k)}`, lighten(c.t.glow, 0.5), 2.2 * k);
};
const cameraTripod = (c: Ctx, x: number, base: number, s = 1): string => {
  const k = c.u * s;
  return line(x, base - 24 * k, x - 7 * k, base, c.t.dark, 0.6 * k) + line(x, base - 24 * k, x + 7 * k, base, c.t.dark, 0.6 * k) + line(x, base - 24 * k, x, base, c.t.dark, 0.6 * k) + rect(x - 6 * k, base - 32 * k, 12 * k, 8 * k, c.t.dark, k) + circ(x + 6 * k, base - 28 * k, 3 * k, c.t.metal) + circ(x + 6.4 * k, base - 28 * k, 1.8 * k, c.t.screen);
};
const softboxStand = (c: Ctx, x: number, base: number, s = 1, flip = 1): string => {
  const k = c.u * s;
  return line(x, base - 34 * k, x - 6 * k, base, c.t.dark, 0.5 * k) + line(x, base - 34 * k, x + 6 * k, base, c.t.dark, 0.5 * k) + line(x, base - 36 * k, x, base, c.t.dark, 0.5 * k) + poly([[x - 9 * k, base - 52 * k], [x + 9 * k, base - 52 * k], [x + 6 * k, base - 34 * k], [x - 6 * k, base - 34 * k]], c.t.dark) + poly([[x - 7.6 * k, base - 50.6 * k], [x + 7.6 * k, base - 50.6 * k], [x + 5 * k, base - 35.4 * k], [x - 5 * k, base - 35.4 * k]], c.t.glow) + poly([[x - 5 * k, base - 34 * k], [x + 5 * k, base - 34 * k], [x + flip * 30 * k, base], [x + flip * 6 * k, base]], c.t.glow, 0.1);
};
const curtain = (c: Ctx, x: number, cw: number, col: string): string => {
  let o = rect(x, 0, cw, c.h, col); const folds = Math.max(3, Math.round(cw / (c.u * 5)));
  for (let i = 0; i < folds; i++) o += rect(x + (cw / folds) * i, 0, cw / folds / 2, c.h, darken(col, 0.14), 0, 0.6);
  return o;
};
const spot = (c: Ctx, x: number, tx: number, spread: number): string => poly([[x - c.u, 0], [x + c.u, 0], [tx + spread, c.h * c.hz], [tx - spread, c.h * c.hz]], c.t.glow, 0.16);
const audienceRow = (c: Ctx, y: number, s = 1): string => {
  let o = ''; const k = c.u * s; const step = 13 * k;
  for (let x = -step * 0.3, i = 0; x < c.w + step; x += step, i++) { const yy = y + ((i * 7) % 3) * k * 1.5; o += circ(x, yy, 4.6 * k, c.t.dark) + path(M(x - 8 * k, c.h + k) + L(x - 8 * k, yy + 12 * k) + Q(x - 7 * k, yy + 6 * k, x, yy + 6 * k) + Q(x + 7 * k, yy + 6 * k, x + 8 * k, yy + 12 * k) + L(x + 8 * k, c.h + k) + Z, c.t.dark); }
  return o;
};
const counter = (c: Ctx, x: number, base: number, cw: number): string => {
  const { t, u } = c;
  let o = rect(x, base - 26 * u, cw, 26 * u, t.furniture) + rect(x - u, base - 28 * u, cw + 2 * u, 2.4 * u, t.paper, u * 0.4);
  const doors = Math.max(2, Math.round(cw / (u * 16)));
  for (let i = 0; i < doors; i++) o += rect(x + (cw / doors) * i + u, base - 23 * u, cw / doors - 2 * u, 20 * u, lighten(t.furniture, 0.08), u * 0.4) + rect(x + (cw / doors) * (i + 0.5) - u * 1.5, base - 21 * u, 3 * u, u * 0.7, t.metal, u * 0.3);
  return o;
};
const wallCabinets = (c: Ctx, x: number, top: number, cw: number): string => {
  const { t, u } = c; let o = rect(x, top, cw, 18 * u, t.furniture);
  const doors = Math.max(2, Math.round(cw / (u * 14)));
  for (let i = 0; i < doors; i++) o += rect(x + (cw / doors) * i + u * 0.8, top + u, cw / doors - u * 1.6, 16 * u, lighten(t.furniture, 0.1), u * 0.3);
  return o;
};
const bed = (c: Ctx, x: number, base: number, bw: number): string => {
  const { t, u } = c;
  return rect(x, base - 30 * u, bw, 22 * u, t.woodDark, 2 * u) + rect(x - u, base - 16 * u, bw + 2 * u, 12 * u, t.paper, 2 * u) + rect(x - u, base - 10 * u, bw + 2 * u, 8 * u, t.soft, u) + rect(x + 3 * u, base - 21 * u, bw * 0.36, 7 * u, '#FFFFFF', 2 * u) + rect(x + bw * 0.56, base - 21 * u, bw * 0.36, 7 * u, lighten(t.soft, 0.3), 2 * u) + rect(x, base - 2 * u, 2 * u, 2 * u, t.woodDark) + rect(x + bw - 2 * u, base - 2 * u, 2 * u, 2 * u, t.woodDark);
};
const mirrorStand = (c: Ctx, x: number, base: number, s = 1): string => {
  const k = c.u * s;
  return rect(x - 8 * k, base - 52 * k, 16 * k, 50 * k, c.t.wood, 8 * k) + rect(x - 6.6 * k, base - 50.6 * k, 13.2 * k, 47.2 * k, lighten(c.t.glass, 0.2), 6.6 * k) + line(x - 3 * k, base - 44 * k, x - 5 * k, base - 24 * k, '#FFFFFF', k, 0.6);
};
const candleCluster = (c: Ctx, x: number, base: number): string => {
  const k = c.u; let o = circ(x, base - 9 * k, 12 * k, c.t.glow, 0.2);
  for (const [dx, hh] of [[-4, 7], [0, 11], [4.4, 5]] as Array<[number, number]>) o += rect(x + dx * k - 1.4 * k, base - hh * k, 2.8 * k, hh * k, c.t.paper, 0.6 * k) + path(M(x + dx * k, base - (hh + 3.4) * k) + Q(x + dx * k + 1.4 * k, base - (hh + 1) * k, x + dx * k, base - hh * k) + Q(x + dx * k - 1.4 * k, base - (hh + 1) * k, x + dx * k, base - (hh + 3.4) * k) + Z, '#F6A93B');
  return o;
};
const skyline = (c: Ctx, x: number, top: number, sw: number, sh: number): string => {
  let o = ''; const r = rng(c.t.wall + sw); let bx = x;
  while (bx < x + sw) { const bw = between(r, 0.06, 0.14) * sw, bh = between(r, 0.25, 0.8) * sh; o += rect(bx, top + sh - bh, Math.min(bw, x + sw - bx), bh, mix(c.t.glass, c.t.dark, c.night ? 0.6 : 0.3)); bx += bw + sw * 0.01; }
  return o;
};
const hills = (c: Ctx): string => {
  const { w, h, hz, t } = c; const y = h * hz;
  return path(M(0, y) + Q(w * 0.2, y - h * 0.22, w * 0.45, y - h * 0.06) + Q(w * 0.7, y - h * 0.26, w, y - h * 0.08) + L(w, y) + Z, mix(t.plantDark, t.wall, 0.45)) +
    path(M(0, y) + Q(w * 0.3, y - h * 0.1, w * 0.6, y - h * 0.02) + Q(w * 0.85, y - h * 0.1, w, y - h * 0.02) + L(w, y) + Z, mix(t.plant, t.wall, 0.3));
};
const tree = (c: Ctx, x: number, base: number, s = 1): string => { const k = c.u * s; return rect(x - k, base - 16 * k, 2 * k, 16 * k, c.t.woodDark) + circ(x, base - 24 * k, 11 * k, c.t.plant) + circ(x - 6 * k, base - 18 * k, 7 * k, c.t.plantDark) + circ(x + 6 * k, base - 19 * k, 7 * k, c.t.plant); };
const roundTable = (c: Ctx, x: number, base: number, s = 1): string => { const k = c.u * s; return ell(x, base, 10 * k, 1.4 * k, c.t.dark, 0.12) + rect(x - k, base - 14 * k, 2 * k, 14 * k, c.t.woodDark) + ell(x, base - 14 * k, 13 * k, 2.6 * k, c.t.wood) + rect(x - 5 * k, base - k, 10 * k, k, c.t.woodDark, k * 0.5); };
const acousticPanels = (c: Ctx, x: number, top: number, cols: number, rows: number): string => {
  let o = ''; const s = c.u * 9;
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) o += rect(x + i * s * 1.08, top + j * s * 1.08, s, s, (i + j) % 2 ? c.t.furniture : c.t.furnitureShade, c.u * 0.6) + line(x + i * s * 1.08 + s * 0.2, top + j * s * 1.08 + s * 0.5, x + i * s * 1.08 + s * 0.8, top + j * s * 1.08 + s * 0.5, lighten(c.t.furniture, 0.15), c.u * 0.4);
  return o;
};
const boomMic = (c: Ctx, x: number, y: number, dir = 1): string => { const k = c.u; return stroke(M(x, y) + L(x + dir * 16 * k, y - 14 * k) + L(x + dir * 30 * k, y - 6 * k), c.t.dark, 0.9 * k) + rect(x + dir * 30 * k - 3 * k, y - 8 * k, 6 * k, 12 * k, c.t.dark, 3 * k) + rect(x + dir * 30 * k - 3 * k, y + 0.5 * k, 6 * k, 1.4 * k, c.t.accent); };
const rack = (c: Ctx, x: number, base: number, rw: number): string => {
  const { t, u } = c; let o = rect(x, base - 22 * u, u, 22 * u, t.metal) + rect(x + rw - u, base - 22 * u, u, 22 * u, t.metal);
  for (let row = 0; row < 2; row++) { const y = base - 18 * u + row * 10 * u; o += rect(x, y, rw, u, t.metal); for (let bx = x + 2 * u; bx < x + rw - 8 * u; bx += 9 * u) o += rect(bx, y - 4 * u, 2 * u, 4 * u, t.dark, u * 0.5) + rect(bx + 2 * u, y - 2.8 * u, 3 * u, 1.6 * u, t.metal) + rect(bx + 5 * u, y - 4 * u, 2 * u, 4 * u, row ? t.accent : t.dark, u * 0.5); }
  return o;
};
const mat = (c: Ctx, cx: number, y: number, mw: number, col: string): string => poly([[cx - mw / 2, y], [cx + mw / 2, y], [cx + mw * 0.62, y + c.u * 7], [cx - mw * 0.62, y + c.u * 7]], col, 0.85);
const planks = (c: Ctx): string => { let o = ''; const y0 = c.h * c.hz; for (let i = 1; i < 6; i++) o += line(0, y0 + ((c.h - y0) * i * i) / 36, c.w, y0 + ((c.h - y0) * i * i) / 36, c.t.floorShade, c.u * 0.25, 0.5); for (let i = -4; i < 12; i++) o += line(c.w * (0.5 + (i - 4) * 0.09), y0, c.w * (0.5 + (i - 4) * 0.22), c.h, c.t.floorShade, c.u * 0.2, 0.35); return o; };
const stickyWall = (c: Ctx, x: number, y: number, cols: number, rows: number): string => { let o = ''; const s = c.u * 5; for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) if ((i * 3 + j * 5) % 7 !== 0) o += g(rect(-s / 2, -s / 2, s, s, ['#F5E050', c.t.accent, '#F7A8B8', lighten(c.t.accent2, 0.2), '#9BD4A8'][(i + j * 2) % 5] as string, c.u * 0.2), tr(x + i * s * 1.25, y + j * s * 1.25, 1, ((i * 7 + j * 3) % 9) - 4)); return o; };
const photoWall = (c: Ctx, x: number, y: number, cols: number, rows: number): string => { let o = ''; const s = c.u * 8; for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) { const px = x + i * s * 1.2, py = y + j * s * 1.25; o += rect(px, py, s, s * 1.08, c.t.paper, c.u * 0.3) + rect(px + s * 0.1, py + s * 0.1, s * 0.8, s * 0.7, [c.t.accent2, c.t.soft, c.t.softShade, c.t.accent][(i + j) % 4] as string) + circ(px + s * 0.5, py + s * 0.38, s * 0.16, lighten(c.t.furniture, 0.5)) + path(M(px + s * 0.22, py + s * 0.8) + Q(px + s * 0.5, py + s * 0.44, px + s * 0.78, py + s * 0.8) + Z, lighten(c.t.furniture, 0.5)); } return o; };
const stagePlatform = (c: Ctx): string => { const y = c.h * c.hz; return rect(0, y, c.w, c.h - y, darken(c.t.floor, 0.35)) + rect(0, y, c.w, c.u * 1.4, lighten(c.t.floor, 0.1)); };
const sweep = (c: Ctx, col: string): string => rect(0, 0, c.w, c.h, col) + path(M(0, c.h * c.hz - c.u * 8) + Q(c.w / 2, c.h * c.hz + c.u * 6, c.w, c.h * c.hz - c.u * 8) + L(c.w, c.h) + L(0, c.h) + Z, darken(col, 0.05));
const table = (c: Ctx, x: number, base: number, tw: number): string => rect(x, base - 15 * c.u, tw, 2 * c.u, c.t.wood, c.u * 0.5) + rect(x + 2 * c.u, base - 13 * c.u, 1.4 * c.u, 13 * c.u, c.t.woodDark) + rect(x + tw - 3.4 * c.u, base - 13 * c.u, 1.4 * c.u, 13 * c.u, c.t.woodDark);
const chairSimple = (c: Ctx, x: number, base: number, s = 1): string => { const k = c.u * s; return rect(x - 5 * k, base - 22 * k, 10 * k, 12 * k, c.t.furniture, 2 * k) + rect(x - 6 * k, base - 11 * k, 12 * k, 2 * k, c.t.furnitureShade, k) + rect(x - 5 * k, base - 9 * k, k, 9 * k, c.t.dark) + rect(x + 4 * k, base - 9 * k, k, 9 * k, c.t.dark); };
const easelCanvas = (c: Ctx, x: number, base: number, s = 1): string => { const k = c.u * s; return line(x, base - 50 * k, x - 9 * k, base, c.t.woodDark, k) + line(x, base - 50 * k, x + 9 * k, base, c.t.woodDark, k) + rect(x - 12 * k, base - 46 * k, 24 * k, 30 * k, c.t.paper, k * 0.3) + circ(x - 3 * k, base - 34 * k, 5 * k, c.t.accent) + rect(x + 1 * k, base - 38 * k, 8 * k, 14 * k, c.t.accent2) + path(M(x - 10 * k, base - 18 * k) + Q(x - 2 * k, base - 28 * k, x + 10 * k, base - 20 * k) + L(x + 10 * k, base - 17 * k) + L(x - 10 * k, base - 17 * k) + Z, c.t.furniture); };

// ---------- rooms ----------
function room(c: Ctx): string {
  const { w, h, hz, t, u } = c; const y = h * hz;
  return rect(0, 0, w, y, t.wall) + rect(0, y, w, h - y, t.floor) + rect(0, y - u * 1.2, w, u * 1.2, t.wallShade);
}
type Env = (c: Ctx) => string;

const ENVS: Record<string, Env> = {
  office: c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + windowTall(c, w * 0.6, h * 0.1, w * 0.3, y - h * 0.18, 3) + lightBeam(c, w * 0.6, h * 0.1, w * 0.3, y - h * 0.18, -1) + (v === 0 ? shelf(c, w * 0.72, h * 0.14, w * 0.2, 3, u * 12) : art(c, w * 0.42, h * 0.16, u * 16, u * 20, v)) + desk(c, w * 0.58, y + u * 14, w * 0.34, u * 26) + monitorDesk(c, w * 0.76, y - u * 12, 1, v) + plantFloor(c, w * 0.95, y + u * 10, 1.1) + (v === 2 ? lampFloor(c, w * 0.52, y + u * 4) : ''); },
  'home-office': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + art(c, w * 0.58, h * 0.14, u * 14, u * 18, v) + art(c, w * 0.58 + u * 17, h * 0.18, u * 11, u * 11, v + 1) + shelf(c, w * 0.8, h * 0.2, w * 0.16, 2, u * 11) + desk(c, w * 0.56, y + u * 12, w * 0.36, u * 24) + monitorDesk(c, w * 0.7, y - u * 12, 0.9, v + 1) + lampFloor(c, w * 0.96, y + u * 6) + plantFloor(c, w * 0.5, y + u * 8, 0.9) + rug(c, w * 0.72, y + u * 22, w * 0.4); },
  boardroom: c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.5, h * 0.08, w * 0.46, y - h * 0.14, c.t.glass) + skyline(c, w * 0.5, h * 0.2, w * 0.46, y - h * 0.26) + [0.5, 0.62, 0.74, 0.86, 0.96].map(x => rect(w * x - u * 0.4, h * 0.08, u * 0.8, y - h * 0.14, c.t.light)).join('') + path(M(w * 0.34, y + u * 12) + L(w * 1.02, y + u * 12) + L(w * 1.02, y + u * 17) + L(w * 0.3, y + u * 17) + Z, c.t.wood) + [0.42, 0.56, 0.7, 0.84].map(x => chairSimple(c, w * x, y + u * 12, 1.2)).join('') + rect(w * 0.3, y + u * 17, w * 0.72, u * 3, c.t.woodDark); },
  'coaching-room': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + windowTall(c, w * 0.62, h * 0.1, w * 0.22, y - h * 0.2, 2) + lightBeam(c, w * 0.62, h * 0.1, w * 0.22, y - h * 0.2, -1) + art(c, w * 0.88, h * 0.18, u * 12, u * 16, v) + rug(c, w * 0.72, y + u * 16, w * 0.46) + armchair(c, w * 0.62, y + u * 14, 1.25) + armchair(c, w * 0.86, y + u * 14, 1.25, c.t.accent2) + roundTable(c, w * 0.74, y + u * 18, 0.7) + plantFloor(c, w * 0.97, y + u * 6, 1.2) + (v ? lampFloor(c, w * 0.52, y + u * 4) : ''); },
  'living-room': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + windowTall(c, w * 0.56, h * 0.08, w * 0.18, y - h * 0.18, 2) + art(c, w * 0.78, h * 0.14, u * 13, u * 13, v) + art(c, w * 0.78 + u * 15, h * 0.18, u * 9, u * 12, v + 1) + sofa(c, w * 0.58, y + u * 10, w * 0.34) + rug(c, w * 0.74, y + u * 20, w * 0.44) + lampFloor(c, w * 0.96, y + u * 6) + plantFloor(c, w * 0.52, y + u * 6, 1.2) + (v === 1 ? roundTable(c, w * 0.74, y + u * 24, 0.6) : ''); },
  bedroom: c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + windowTall(c, w * 0.56, h * 0.1, w * 0.16, y - h * 0.22, 2) + bed(c, w * 0.6, y + u * 12, w * 0.34) + roundTable(c, w * 0.97, y + u * 10, 0.6) + lampFloor(c, w * 0.53, y + u * 6) + art(c, w * 0.72, h * 0.12, u * 12, u * 9, 1) + rug(c, w * 0.76, y + u * 22, w * 0.42); },
  kitchen: c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 2);
    let o = room(c) + windowTall(c, w * 0.66, h * 0.12, w * 0.16, y - h * 0.34, 2) + wallCabinets(c, w * 0.84, h * 0.1, w * 0.18) + (v ? wallCabinets(c, w * 0.5, h * 0.1, w * 0.14) : shelf(c, w * 0.5, h * 0.14, w * 0.14, 2, u * 9)) + counter(c, w * 0.48, y + u * 8, w * 0.56);
    o += plantFloor(c, w * 0.6, y - u * 20, 0.5) + rect(w * 0.88, y - u * 26, u * 5, u * 6, c.t.metal, u) + circ(w * 0.78, y - u * 22, u * 2.6, '#E4572E') + circ(w * 0.78 + u * 5, y - u * 21.6, u * 2.2, '#F2A83B') + pendant(c, w * 0.74, h * 0.1);
    return o; },
  'fitness-studio': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 2);
    return room(c) + rect(w * 0.5, h * 0.1, w * 0.48, y - h * 0.16, lighten(c.t.glass, 0.1)) + [0.5, 0.66, 0.82, 0.98].map(x => rect(w * x - u * 0.3, h * 0.1, u * 0.6, y - h * 0.16, c.t.metal)).join('') + rack(c, w * 0.58, y + u * 3, w * 0.3) + mat(c, w * 0.72, y + u * 12, w * 0.3, c.t.accent2) + circ(w * 0.94, y + u * 2, u * 7, c.t.accent, 0.9) + circ(w * 0.94, y + u * 2, u * 2, c.t.dark) + (v ? rect(w * 0.52, y - u * 14, u * 3, u * 18, c.t.dark, u) + rect(w * 0.52 - u * 3, y - u * 16, u * 9, u * 3, c.t.accent, u) : ''); },
  'yoga-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + planks(c) + [0.52, 0.68, 0.84].map(x => path(M(w * x, y - u * 2) + L(w * x, h * 0.26) + Q(w * x + w * 0.06, h * 0.06, w * x + w * 0.12, h * 0.26) + L(w * x + w * 0.12, y - u * 2) + Z, c.t.glass) + lightBeam(c, w * x, h * 0.1, w * 0.12, y - h * 0.12, -1)).join('') + mat(c, w * 0.7, y + u * 10, w * 0.26, c.t.accent2) + plantFloor(c, w * 0.96, y + u * 5, 1.3) + plantFloor(c, w * 0.5, y + u * 3, 0.9) + candleCluster(c, w * 0.88, y + u * 14); },
  'creator-studio': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 2);
    return room(c) + photoWall(c, w * 0.56, h * 0.1, 4, 2) + rect(w * 0.54, h * 0.56 > y - u * 20 ? y - u * 26 : h * 0.56, w * 0.3, u * 1.2, c.t.accent, u * 0.6) + desk(c, w * 0.56, y + u * 12, w * 0.3, u * 22) + monitorDesk(c, w * 0.7, y - u * 10, 0.85, 0) + ringLight(c, w * 0.93, y + u * 10, 0.9) + (v ? cameraTripod(c, w * 0.5, y + u * 12, 1) : plantFloor(c, w * 0.5, y + u * 8, 1)); },
  'youtube-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.52, h * 0.12, w * 0.44, u * 2, c.t.accent, u) + shelf(c, w * 0.56, h * 0.2, w * 0.3, 2, u * 11) + softboxStand(c, w * 0.94, y + u * 10, 1, -1) + cameraTripod(c, w * 0.52, y + u * 14, 1.25) + sofa(c, w * 0.6, y + u * 6, w * 0.26) + plantFloor(c, w * 0.88, y + u * 2, 0.9); },
  'podcast-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + acousticPanels(c, w * 0.54, h * 0.1, Math.max(3, Math.floor((w * 0.42) / (u * 9.8))), 3) + desk(c, w * 0.52, y + u * 12, w * 0.44, u * 22) + boomMic(c, w * 0.92, y - u * 10, -1) + monitorDesk(c, w * 0.62, y - u * 10, 0.8, 1) + lampFloor(c, w * 0.97, y + u * 4); },
  'music-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + acousticPanels(c, w * 0.56, h * 0.1, 3, 2) + rect(w * 0.54, y - u * 8, w * 0.34, u * 14, c.t.dark, u) + [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(i => rect(w * 0.55 + i * ((w * 0.32) / 12), y - u * 7, (w * 0.32) / 12 - u * 0.3, u * 6, '#FFFFFF')).join('') + g(rect(-u, -u * 34, u * 2, u * 30, c.t.woodDark) + ell(0, 0, u * 7, u * 9, c.t.wood) + circ(0, -u * 1, u * 2.4, c.t.dark), tr(w * 0.95, y + u * 4, 1, 8)) + boomMic(c, w * 0.6, y - u * 20, 1); },
  'photo-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return sweep(c, c.t.wall) + rect(w * 0.54, 0, w * 0.34, u * 2, c.t.metal) + softboxStand(c, w * 0.94, y + u * 12, 1.15, -1) + softboxStand(c, w * 0.52, y + u * 8, 0.9, 1) + cameraTripod(c, w * 0.62, y + u * 18, 1.3) + g(ell(0, 0, u * 9, u * 11, lighten(c.t.metal, 0.5)), tr(w * 0.82, y - u * 4, 1, 12)); },
  'product-studio': c => sweep(c, c.t.wall) + softboxStand(c, c.w * 0.92, c.h * c.hz + c.u * 14, 1.1, -1) + ell(c.w * 0.5, c.h * c.hz + c.u * 10, c.w * 0.3, c.u * 5, c.t.light, 0.5),
  stage: c => { const { w, h, u, hz } = c;
    return rect(0, 0, w, h, darken(c.t.wall, 0.55)) + curtain(c, 0, w * 0.1, darken(c.t.accent, 0.45)) + curtain(c, w * 0.9, w * 0.1, darken(c.t.accent, 0.45)) + rect(w * 0.56, h * 0.14, w * 0.3, h * 0.3, mix(c.t.accent, c.t.dark, 0.35), u) + rect(w * 0.6, h * 0.22, w * 0.16, u * 2.4, c.t.light, u, 0.9) + rect(w * 0.6, h * 0.3, w * 0.1, u * 1.6, c.t.light, u, 0.6) + spot(c, w * 0.2, w * 0.3, u * 16) + spot(c, w * 0.8, w * 0.6, u * 16) + stagePlatform(c) + audienceRow(c, h * 0.9, 1.3); },
  'workshop-room': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + board(c, w * 0.56, h * 0.12, w * 0.3, Math.min(u * 34, y - h * 0.2), v) + stickyWall(c, w * 0.9, h * 0.16, 2, 4) + table(c, w * 0.56, y + u * 16, w * 0.34) + chairSimple(c, w * 0.94, y + u * 14, 1.1) + plantFloor(c, w * 0.5, y + u * 6, 1); },
  'marketing-workspace': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return room(c) + board(c, w * 0.54, h * 0.12, w * 0.2, u * 24, 2) + stickyWall(c, w * 0.8, h * 0.14, 3, 3) + desk(c, w * 0.54, y + u * 12, w * 0.42, u * 24) + monitorDesk(c, w * 0.66, y - u * 12, 1, 0) + monitorDesk(c, w * 0.84, y - u * 12, 1, v) + plantFloor(c, w * 0.98, y + u * 10, 0.9); },
  'tech-office': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.54, h * 0.1, w * 0.42, y - h * 0.2, c.t.glass) + skyline(c, w * 0.54, h * 0.2, w * 0.42, y - h * 0.3) + desk(c, w * 0.52, y + u * 12, w * 0.46, u * 24) + monitorDesk(c, w * 0.62, y - u * 12, 1, 1) + monitorDesk(c, w * 0.78, y - u * 12, 1, 0) + monitorDesk(c, w * 0.92, y - u * 12, 0.8, 1) + rect(w * 0.6, y - u * 10.6, u * 16, u * 1.6, c.t.dark, u * 0.5); },
  'design-studio': c => { const { w, h, u, hz, r } = c; const y = h * hz; const cols = 5, rows = 3; let mb = rect(w * 0.54, h * 0.1, w * 0.4, Math.min(u * 36, y - h * 0.18), c.t.paper, u * 0.4);
    for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) if (r() > 0.18) mb += rect(w * 0.555 + i * w * 0.077, h * 0.12 + j * Math.min(u * 11.4, (y - h * 0.2) / 3.3), w * 0.066, Math.min(u * 9.6, (y - h * 0.22) / 3.6), pick(r, [c.t.accent, c.t.accent2, c.t.furniture, c.t.soft, c.t.softShade, c.t.plant]), u * 0.2);
    return room(c) + mb + table(c, w * 0.56, y + u * 16, w * 0.36) + lampFloor(c, w * 0.97, y + u * 8) + plantFloor(c, w * 0.5, y + u * 6, 0.9); },
  'artist-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + windowTall(c, w * 0.58, h * 0.08, w * 0.2, y - h * 0.18, 2) + easelCanvas(c, w * 0.88, y + u * 10, 1.1) + table(c, w * 0.54, y + u * 14, w * 0.24) + rect(w * 0.6, y - u * 7, u * 4, u * 6, c.t.metal, u) + [0, 1, 2].map(i => rect(w * 0.6 + u * (0.6 + i * 1.2), y - u * 14, u * 0.7, u * 8, [c.t.accent, c.t.accent2, c.t.plant][i] as string)).join('') + art(c, w * 0.5, h * 0.2, u * 10, u * 13, 0); },
  'rehearsal-studio': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + planks(c) + rect(w * 0.52, h * 0.1, w * 0.46, y - h * 0.14, lighten(c.t.glass, 0.15)) + [0.52, 0.675, 0.83, 0.98].map(x => rect(w * x - u * 0.3, h * 0.1, u * 0.6, y - h * 0.14, c.t.metal)).join('') + rect(w * 0.52, y - u * 16, w * 0.46, u * 0.9, c.t.wood) + chairSimple(c, w * 0.84, y + u * 12, 1.2) + mirrorStand(c, w * 0.58, y + u * 8, 0.9); },
  'sacred-space': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + circ(w * 0.74, h * 0.3, u * 14, c.t.glow, 0.25) + circ(w * 0.74, h * 0.3, u * 9, c.t.accent, 0.5) + rect(w * 0.58, y - u * 2, w * 0.32, u * 12, c.t.woodDark, u) + rect(w * 0.56, y - u * 4, w * 0.36, u * 2.4, c.t.accent2, u) + candleCluster(c, w * 0.64, y - u * 4) + candleCluster(c, w * 0.86, y - u * 4) + poly([[w * 0.72, y - u * 4], [w * 0.74, y - u * 14], [w * 0.76, y - u * 4]], lighten('#B9A6E0', 0.2)) + plantFloor(c, w * 0.97, y + u * 10, 1.1) + mat(c, w * 0.74, y + u * 14, w * 0.2, c.t.soft); },
  'library-study': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.52, h * 0.06, w * 0.46, y - h * 0.06, c.t.woodDark) + shelf(c, w * 0.53, h * 0.07, w * 0.44, Math.max(2, Math.floor((y - h * 0.08) / (u * 12))), u * 12) + desk(c, w * 0.56, y + u * 16, w * 0.32, u * 22) + lampFloor(c, w * 0.95, y + u * 8) + rug(c, w * 0.74, y + u * 24, w * 0.4); },
  'financial-office': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 2);
    return room(c) + windowTall(c, w * 0.56, h * 0.1, w * 0.16, y - h * 0.2, 2) + shelf(c, w * 0.76, h * 0.14, w * 0.2, 3, u * 11) + desk(c, w * 0.54, y + u * 12, w * 0.4, u * 24) + monitorDesk(c, w * 0.66, y - u * 12, 0.9, 0) + armchair(c, w * 0.9, y + u * 16, 1, mix('#6B4630', c.t.furniture, 0.3)) + (v ? art(c, w * 0.62, h * 0.14, u * 10, u * 12, 2) : ''); },
  'event-prep-table': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + art(c, w * 0.56, h * 0.1, u * 16, u * 20, 2) + art(c, w * 0.56 + u * 19, h * 0.14, u * 12, u * 14, 0) + stickyWall(c, w * 0.86, h * 0.14, 2, 3) + path(M(w * 0.44, y + u * 6) + L(w * 1.02, y + u * 6) + L(w * 1.02, y + u * 12) + L(w * 0.4, y + u * 12) + Z, c.t.paper) + rect(w * 0.4, y + u * 12, w * 0.62, u * 2, darken(c.t.paper, 0.1)) + pendant(c, w * 0.7, h * 0.12) + pendant(c, w * 0.9, h * 0.08); },
  cafe: c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.52, h * 0.12, w * 0.46, y - h * 0.24, c.t.glass) + skyline(c, w * 0.52, h * 0.3, w * 0.46, y - h * 0.42) + pendant(c, w * 0.62, h * 0.16) + pendant(c, w * 0.78, h * 0.12) + pendant(c, w * 0.92, h * 0.18) + roundTable(c, w * 0.66, y + u * 14, 1.1) + roundTable(c, w * 0.9, y + u * 8, 0.9) + chairSimple(c, w * 0.78, y + u * 14, 1) + plantFloor(c, w * 0.98, y + u * 14, 1.2); },
  outdoor: c => { const { w, h, u, hz } = c; const y = h * hz;
    return rect(0, 0, w, y, mix(c.t.glass, c.t.wall, 0.4)) + circ(w * 0.78, h * 0.2, u * 9, c.t.glow, 0.9) + circ(w * 0.78, h * 0.2, u * 16, c.t.glow, 0.25) + hills(c) + rect(0, y, w, h - y, mix(c.t.plant, c.t.floor, 0.45)) + tree(c, w * 0.9, y + u * 4, 1.5) + tree(c, w * 0.58, y + u * 1, 0.9) + path(M(w * 0.6, h) + Q(w * 0.7, y + u * 8, w * 0.66, y) + L(w * 0.7, y) + Q(w * 0.8, y + u * 8, w * 0.84, h) + Z, c.t.floor, 0.7); },
  'magazine-backdrop': c => { const { w, h, u, hz, r } = c; const y = h * hz; const v = Math.floor(r() * 3);
    return rect(0, 0, w, h, c.t.wall) + rect(0, y, w, h - y, c.t.wallShade) + (v === 0 ? rect(w * 0.6, 0, w * 0.26, y, c.t.accent2, 0, 0.55) : v === 1 ? circ(w * 0.74, h * 0.4, Math.min(w, h) * 0.3, c.t.accent2, 0.5) : path(M(w * 0.56, y) + L(w * 0.56, h * 0.34) + Q(w * 0.72, h * 0.04, w * 0.88, h * 0.34) + L(w * 0.88, y) + Z, c.t.accent2, 0.55)) + lightBeam(c, w * 0.5, -u * 10, w * 0.2, u * 10, 1) + plantFloor(c, w * 0.95, y + u * 6, 1.4); },
  'open-window-space': c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + windowTall(c, w * 0.56, h * 0.04, w * 0.36, y - h * 0.08, 3) + lightBeam(c, w * 0.56, h * 0.04, w * 0.36, y - h * 0.08, -1) + curtain(c, w * 0.92, w * 0.06, lighten(c.t.soft, 0.3)) + plantFloor(c, w * 0.5, y + u * 6, 1.2) + mirrorStand(c, w * 0.97, y + u * 12, 0.9); },
  salon: c => { const { w, h, u, hz } = c; const y = h * hz;
    return room(c) + rect(w * 0.56, h * 0.12, w * 0.3, u * 24, c.t.wood, u * 12) + rect(w * 0.572, h * 0.12 + u * 1.2, w * 0.3 - u * 2.4, u * 21.6, lighten(c.t.glass, 0.2), u * 11) + shelf(c, w * 0.88, h * 0.16, w * 0.1, 3, u * 9) + table(c, w * 0.54, y + u * 14, w * 0.36) + chairSimple(c, w * 0.94, y + u * 12, 1.1) + lampFloor(c, w * 0.5, y + u * 6); },
};
ENVS.retreat = ENVS.outdoor!;
ENVS['therapy-office'] = ENVS['coaching-room']!;

export const ENV_KINDS = Object.keys(ENVS);

export function drawEnvironment(kind: string, w: number, h: number, t: Tone, o: EnvOptions): string {
  const lv = o.lighting.toLowerCase();
  const c: Ctx = { w, h, u: h / 100, t, r: rng('env:' + o.seed), hz: o.horizon, night: /blue hour/.test(lv), warm: /golden|tungsten|backlit|window/.test(lv) };
  const env = ENVS[kind] ?? ENVS.office!;
  let body = env(c);
  if (o.busy === 'left') body = g(body, `translate(${n(w)} 0) scale(-1 1)`);
  else if (o.busy === 'both') body = body + g(plantFloor(c, w * 0.06, h * o.horizon + c.u * 8, 1.2) + art(c, w * 0.1, h * 0.14, c.u * 13, c.u * 17, 1), '');
  // ambient light wash from the lit side
  const wash = `<defs><linearGradient id="wash-${hashId(o.seed)}" x1="${o.busy === 'left' ? 0 : 1}" y1="0" x2="${o.busy === 'left' ? 1 : 0}" y2="1"><stop offset="0" stop-color="${t.glow}" stop-opacity="${c.warm ? 0.3 : 0.14}"/><stop offset="0.7" stop-color="${t.glow}" stop-opacity="0"/></linearGradient></defs><rect width="${n(w)}" height="${n(h)}" fill="url(#wash-${hashId(o.seed)})"/>`;
  return body + wash;
}
function hashId(s: string): string { let hsh = 0; for (let i = 0; i < s.length; i++) hsh = (hsh * 31 + s.charCodeAt(i)) >>> 0; return hsh.toString(36); }
void [C, ell];
