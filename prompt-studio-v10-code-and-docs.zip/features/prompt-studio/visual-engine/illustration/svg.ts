/** Tiny trusted SVG string DSL used by the illustration kit. All inputs are numbers or validated hex colours. */
import { darken, isHex, lighten, mix } from '../../shared/util.ts';

export const n = (v: number): string => (Math.round(v * 10) / 10).toString();
const col = (c: string): string => (isHex(c) || c === 'none' ? c : '#808080');
const op = (o?: number): string => (o === undefined || o >= 1 ? '' : ` opacity="${n(o * 100) === '0' ? 0 : Math.round(o * 100) / 100}"`);

export const rect = (x: number, y: number, w: number, h: number, fill: string, rx = 0, o?: number): string =>
  `<rect x="${n(x)}" y="${n(y)}" width="${n(Math.max(0, w))}" height="${n(Math.max(0, h))}"${rx ? ` rx="${n(rx)}"` : ''} fill="${col(fill)}"${op(o)}/>`;
export const circ = (cx: number, cy: number, r: number, fill: string, o?: number): string =>
  `<circle cx="${n(cx)}" cy="${n(cy)}" r="${n(Math.max(0, r))}" fill="${col(fill)}"${op(o)}/>`;
export const ell = (cx: number, cy: number, rx: number, ry: number, fill: string, o?: number): string =>
  `<ellipse cx="${n(cx)}" cy="${n(cy)}" rx="${n(Math.max(0, rx))}" ry="${n(Math.max(0, ry))}" fill="${col(fill)}"${op(o)}/>`;
export const path = (d: string, fill: string, o?: number): string => `<path d="${d}" fill="${col(fill)}"${op(o)}/>`;
export const stroke = (d: string, color: string, width: number, o?: number, cap: 'round' | 'butt' = 'round'): string =>
  `<path d="${d}" fill="none" stroke="${col(color)}" stroke-width="${n(width)}" stroke-linecap="${cap}" stroke-linejoin="round"${op(o)}/>`;
export const line = (x1: number, y1: number, x2: number, y2: number, color: string, width: number, o?: number): string =>
  `<line x1="${n(x1)}" y1="${n(y1)}" x2="${n(x2)}" y2="${n(y2)}" stroke="${col(color)}" stroke-width="${n(width)}" stroke-linecap="round"${op(o)}/>`;
export const poly = (pts: Array<[number, number]>, fill: string, o?: number): string =>
  `<polygon points="${pts.map(p => n(p[0]) + ',' + n(p[1])).join(' ')}" fill="${col(fill)}"${op(o)}/>`;
export const g = (inner: string, transform = '', o?: number): string => `<g${transform ? ` transform="${transform}"` : ''}${op(o)}>${inner}</g>`;
export const tr = (x: number, y: number, s = 1, rot = 0): string => `translate(${n(x)} ${n(y)})${rot ? ` rotate(${n(rot)})` : ''}${s !== 1 ? ` scale(${Math.round(s * 1000) / 1000})` : ''}`;
/** Path builder helpers. */
export const M = (x: number, y: number): string => `M${n(x)} ${n(y)}`;
export const L = (x: number, y: number): string => `L${n(x)} ${n(y)}`;
export const Q = (cx: number, cy: number, x: number, y: number): string => `Q${n(cx)} ${n(cy)} ${n(x)} ${n(y)}`;
export const C = (c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number): string => `C${n(c1x)} ${n(c1y)} ${n(c2x)} ${n(c2y)} ${n(x)} ${n(y)}`;
export const Z = 'Z';

/** Illustration tone: every colour an environment/prop/figure may use, derived from the scene's colour roles. */
export interface Tone {
  wall: string; wallShade: string; floor: string; floorShade: string;
  furniture: string; furnitureShade: string; soft: string; softShade: string;
  accent: string; accent2: string; light: string; dark: string; glass: string; metal: string;
  plant: string; plantDark: string; wood: string; woodDark: string; paper: string; glow: string; screen: string;
}

export interface ToneInput { background: string; surface: string; ink: string; primary: string; secondary: string; accent: string; light: string; dark: string }

/** Build an illustration tone from colour roles + the source lighting variant. */
export function buildTone(c: ToneInput, lighting: string, darkScene = false): Tone {
  const warm = '#F2B872', cool = '#7D9BC4';
  const lv = lighting.toLowerCase();
  const tint = /golden/.test(lv) ? warm : /tungsten/.test(lv) ? '#E8A04E' : /blue hour/.test(lv) ? '#3C4E86' : /overcast/.test(lv) ? '#B9C2CC' : /backlit/.test(lv) ? '#FFE2B0' : /studio/.test(lv) ? '#F4F6FA' : /window/.test(lv) ? '#FFF3DC' : '#FFFFFF';
  const amt = /golden|tungsten/.test(lv) ? 0.22 : /blue hour/.test(lv) ? 0.5 : /overcast/.test(lv) ? 0.2 : /backlit|window/.test(lv) ? 0.14 : 0.04;
  const night = /blue hour/.test(lv) || darkScene;
  const baseWall = night ? mix(c.dark, c.primary, 0.25) : mix(c.light, c.secondary, 0.16);
  const wall = mix(baseWall, tint, amt);
  const floor = night ? darken(wall, 0.25) : mix(mix(c.light, '#B08D6A', 0.42), tint, amt);
  const furniture = mix(c.primary, night ? '#FFFFFF' : c.dark, night ? 0.1 : 0.12);
  const soft = mix(c.secondary, c.light, 0.25);
  return {
    wall, wallShade: darken(wall, 0.08), floor, floorShade: darken(floor, 0.12),
    furniture, furnitureShade: darken(furniture, 0.2), soft, softShade: darken(soft, 0.14),
    accent: c.accent, accent2: mix(c.accent, c.secondary, 0.5), light: mix('#FFFFFF', tint, amt * 0.6), dark: mix(c.dark, '#101418', 0.4),
    glass: night ? '#27365F' : mix('#DCEBF5', tint, amt), metal: mix('#9AA3AD', c.dark, 0.15),
    plant: mix('#5E8F5A', c.primary, 0.18), plantDark: mix('#2F5D3A', c.dark, 0.2),
    wood: mix('#B98A5E', tint, amt * 0.5), woodDark: mix('#7A5536', c.dark, 0.2), paper: mix('#FFFDF8', tint, amt * 0.4),
    glow: /golden|tungsten|blue hour|backlit/.test(lv) ? '#FFD9A0' : '#FFFFFF', screen: mix(c.dark, '#0E1620', 0.5),
  };
}
export { darken, lighten, mix };
