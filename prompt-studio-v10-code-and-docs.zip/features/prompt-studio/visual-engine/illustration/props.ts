/**
 * Illustrative prop library — trusted inline-SVG objects drawn in a 100×100 box (baseline ≈ y92).
 * Props are chosen from the scene's own source text ("Visible props: …") via PROP_RULES, never at random.
 */
import { C, L, M, Q, Z, circ, darken, ell, g, lighten, line, mix, path, poly, rect, stroke, tr, type Tone } from './svg.ts';

type Draw = (t: Tone, v: number) => string;

const screenUI = (kind: string, t: Tone, x: number, y: number, w: number, h: number): string => {
  const a = t.accent, l = lighten(t.screen, 0.82), m = lighten(t.screen, 0.55);
  const bg = rect(x, y, w, h, kind === 'code' ? t.screen : l, 1.2);
  const row = (i: number, ww: number, c: string): string => rect(x + w * 0.1, y + h * (0.16 + i * 0.14), w * ww, h * 0.07, c, 0.8);
  switch (kind) {
    case 'code': return bg + [0.5, 0.7, 0.4, 0.62, 0.3].map((ww, i) => row(i, ww, i % 2 ? a : lighten(t.screen, 0.5))).join('');
    case 'dashboard': return bg + rect(x + w * 0.08, y + h * 0.5, w * 0.12, h * 0.36, a, 0.6) + rect(x + w * 0.26, y + h * 0.34, w * 0.12, h * 0.52, t.accent2, 0.6) + rect(x + w * 0.44, y + h * 0.2, w * 0.12, h * 0.66, a, 0.6) + circ(x + w * 0.78, y + h * 0.42, h * 0.2, m) + path(M(x + w * 0.78, y + h * 0.42) + L(x + w * 0.78, y + h * 0.22) + `A${h * 0.2} ${h * 0.2} 0 0 1 ${x + w * 0.78 + h * 0.2} ${y + h * 0.42}` + Z, a);
    case 'calendar': { let s = bg; for (let i = 0; i < 12; i++) s += rect(x + w * (0.08 + (i % 4) * 0.22), y + h * (0.14 + Math.floor(i / 4) * 0.27), w * 0.18, h * 0.2, i % 5 === 1 ? a : i % 3 === 0 ? t.accent2 : m, 0.6); return s; }
    case 'flow': return bg + line(x + w * 0.2, y + h * 0.3, x + w * 0.5, y + h * 0.5, m, 1) + line(x + w * 0.5, y + h * 0.5, x + w * 0.8, y + h * 0.3, m, 1) + line(x + w * 0.5, y + h * 0.5, x + w * 0.5, y + h * 0.8, m, 1) + circ(x + w * 0.2, y + h * 0.3, h * 0.1, a) + circ(x + w * 0.5, y + h * 0.5, h * 0.1, t.accent2) + circ(x + w * 0.8, y + h * 0.3, h * 0.1, a) + circ(x + w * 0.5, y + h * 0.8, h * 0.1, a);
    case 'community': { let s = bg + rect(x, y, w * 0.22, h, m, 1); for (let i = 0; i < 3; i++) s += circ(x + w * 0.36, y + h * (0.24 + i * 0.26), h * 0.08, i === 1 ? a : t.accent2) + rect(x + w * 0.46, y + h * (0.19 + i * 0.26), w * 0.42, h * 0.1, m, 0.8); return s; }
    case 'design': return bg + rect(x + w * 0.1, y + h * 0.16, w * 0.34, h * 0.66, a, 1) + circ(x + w * 0.68, y + h * 0.38, h * 0.2, t.accent2) + rect(x + w * 0.54, y + h * 0.66, w * 0.34, h * 0.14, m, 0.8);
    case 'doc': return bg + rect(x + w * 0.14, y + h * 0.14, w * 0.5, h * 0.1, t.screen, 0.6) + [0, 1, 2, 3].map(i => rect(x + w * 0.14, y + h * (0.34 + i * 0.13), w * (i === 3 ? 0.4 : 0.72), h * 0.06, m, 0.5)).join('');
    case 'video': return bg + rect(x + w * 0.1, y + h * 0.12, w * 0.8, h * 0.6, t.screen, 1) + poly([[x + w * 0.44, y + h * 0.3], [x + w * 0.44, y + h * 0.54], [x + w * 0.6, y + h * 0.42]], '#FFFFFF') + rect(x + w * 0.1, y + h * 0.8, w * 0.5, h * 0.07, a, 0.8);
    case 'blank': return rect(x, y, w, h, '#FFFFFF', 1.2);
    default: return bg + rect(x + w * 0.1, y + h * 0.16, w * 0.8, h * 0.3, a, 1) + rect(x + w * 0.1, y + h * 0.56, w * 0.36, h * 0.28, m, 1) + rect(x + w * 0.54, y + h * 0.56, w * 0.36, h * 0.28, t.accent2, 1);
  }
};

const laptop = (ui: string): Draw => t =>
  rect(14, 30, 72, 46, t.dark, 3) + screenUI(ui, t, 18, 34, 64, 38) + path(M(6, 78) + L(94, 78) + L(88, 86) + L(12, 86) + Z, t.metal) + rect(42, 79.5, 16, 2.4, darken(t.metal, 0.2), 1);
const book = (c1: (t: Tone) => string): Draw => t => rect(22, 56, 56, 12, c1(t), 2) + rect(24, 58, 50, 8, t.paper, 1) + rect(22, 56, 6, 12, darken(c1(t), 0.2), 2);
const mugShape = (t: Tone, c: string, steam: boolean): string =>
  ell(50, 90, 26, 4, t.dark, 0.14) + stroke(M(68, 60) + Q(86, 62, 68, 78), c, 5) + path(M(30, 50) + L(70, 50) + L(66, 88) + Q(50, 92, 34, 88) + Z, c) + ell(50, 50, 20, 4.5, darken(c, 0.25)) + ell(50, 50.5, 16, 3, '#6B4630') + (steam ? stroke(M(44, 42) + Q(40, 34, 46, 28) + Q(52, 22, 46, 16), t.light, 2.2, 0.75) + stroke(M(56, 42) + Q(52, 36, 58, 30), t.light, 2.2, 0.6) : '');

const PROPS: Record<string, Draw> = {
  laptop: laptop('generic'), 'laptop-code': laptop('code'), 'laptop-dashboard': laptop('dashboard'), 'laptop-calendar': laptop('calendar'),
  'laptop-flow': laptop('flow'), 'laptop-community': laptop('community'), 'laptop-design': laptop('design'), 'laptop-doc': laptop('doc'), 'laptop-video': laptop('video'), 'laptop-blank': laptop('blank'),
  phone: t => rect(34, 14, 32, 68, t.dark, 6) + screenUI('community', t, 37, 19, 26, 58) + ell(50, 90, 18, 3, t.dark, 0.14),
  'phone-blank': t => rect(34, 14, 32, 68, t.dark, 6) + rect(37, 19, 26, 58, '#FFFFFF', 2) + ell(50, 90, 18, 3, t.dark, 0.14),
  tablet: t => rect(20, 22, 60, 58, t.dark, 5) + screenUI('generic', t, 24, 26, 52, 50) + ell(50, 88, 28, 3, t.dark, 0.12),
  'tablet-blank': t => rect(20, 22, 60, 58, t.dark, 5) + rect(24, 26, 52, 50, '#FFFFFF', 2) + ell(50, 88, 28, 3, t.dark, 0.12),
  monitor: t => rect(10, 16, 80, 52, t.dark, 3) + screenUI('dashboard', t, 14, 20, 72, 44) + rect(46, 68, 8, 14, t.metal) + rect(32, 82, 36, 4, t.metal, 2),
  'phone-tripod': t => line(50, 52, 34, 90, t.dark, 2.4) + line(50, 52, 66, 90, t.dark, 2.4) + line(50, 52, 50, 90, t.dark, 2.4) + rect(40, 14, 20, 38, t.dark, 3) + rect(42, 17, 16, 32, lighten(t.screen, 0.7), 1.5) + circ(50, 33, 4, t.accent),
  'ring-light': t => line(50, 54, 36, 92, t.dark, 2.2) + line(50, 54, 64, 92, t.dark, 2.2) + line(50, 50, 50, 92, t.dark, 2.2) + circ(50, 32, 24, t.glow) + circ(50, 32, 17, t.wall) + stroke(M(50, 8) + `A24 24 0 1 1 49.9 8`, lighten(t.glow, 0.4), 2, 0.9) + rect(45, 25, 10, 15, t.dark, 2),
  camera: t => rect(18, 38, 64, 40, t.dark, 5) + rect(34, 30, 22, 10, t.dark, 2) + circ(50, 58, 15, t.metal) + circ(50, 58, 10, t.screen) + circ(46, 54, 3, lighten(t.screen, 0.6)) + rect(68, 43, 8, 5, t.accent, 1) + ell(50, 86, 30, 3, t.dark, 0.14),
  tripod: t => line(50, 40, 28, 92, t.dark, 3) + line(50, 40, 72, 92, t.dark, 3) + line(50, 40, 50, 92, t.dark, 3) + rect(36, 22, 28, 18, t.dark, 3) + circ(50, 31, 6, t.metal),
  softbox: t => line(50, 50, 34, 92, t.dark, 2.4) + line(50, 50, 66, 92, t.dark, 2.4) + line(50, 46, 50, 92, t.dark, 2.4) + poly([[22, 10], [78, 10], [70, 50], [30, 50]], t.dark) + poly([[26, 13], [74, 13], [67, 47], [33, 47]], t.glow),
  reflector: t => ell(50, 50, 30, 38, t.metal) + ell(50, 50, 26, 34, lighten(t.metal, 0.6)) + ell(42, 40, 8, 14, '#FFFFFF', 0.6),
  mic: t => rect(46, 56, 8, 26, t.metal) + rect(32, 82, 36, 5, t.dark, 2) + rect(38, 16, 24, 42, t.dark, 12) + line(41, 28, 59, 28, t.metal, 1.6) + line(41, 36, 59, 36, t.metal, 1.6) + line(41, 44, 59, 44, t.metal, 1.6) + rect(38, 50, 24, 5, t.accent),
  headphones: t => stroke(M(24, 62) + C(24, 14, 76, 14, 76, 62), t.dark, 6) + rect(16, 54, 16, 28, t.dark, 6) + rect(68, 54, 16, 28, t.dark, 6) + rect(19, 58, 7, 20, t.accent, 3) + rect(74, 58, 7, 20, t.accent, 3),
  mug: (t, v) => mugShape(t, v > 0.5 ? t.paper : t.accent, true),
  'two-cups': t => g(mugShape(t, t.paper, true), tr(-8, 6, 0.62)) + g(mugShape(t, t.accent2, true), tr(46, 30, 0.62)),
  'water-glass': t => ell(50, 90, 20, 3, t.dark, 0.12) + path(M(34, 26) + L(66, 26) + L(62, 88) + L(38, 88) + Z, lighten(t.glass, 0.3), 0.8) + path(M(36, 48) + L(64, 48) + L(62, 88) + L(38, 88) + Z, mix(t.glass, '#7FB8D8', 0.5), 0.75) + line(40, 30, 41, 82, '#FFFFFF', 1.6, 0.7),
  bottle: t => ell(50, 91, 16, 3, t.dark, 0.12) + rect(44, 10, 12, 10, t.dark, 2) + path(M(40, 22) + L(60, 22) + Q(66, 30, 66, 38) + L(66, 88) + L(34, 88) + L(34, 38) + Q(34, 30, 40, 22) + Z, t.accent2) + rect(34, 50, 32, 18, t.paper),
  smoothie: t => ell(50, 91, 18, 3, t.dark, 0.12) + path(M(34, 30) + L(66, 30) + L(61, 88) + L(39, 88) + Z, mix('#8BC34A', t.accent, 0.25)) + ell(50, 30, 16, 4, lighten('#8BC34A', 0.3)) + line(56, 30, 64, 8, t.accent, 2.6),
  'wine-glass': t => rect(49, 58, 2, 28, lighten(t.glass, 0.2)) + ell(50, 88, 12, 2.5, lighten(t.glass, 0.2)) + path(M(34, 22) + L(66, 22) + Q(66, 56, 50, 58) + Q(34, 56, 34, 22) + Z, lighten(t.glass, 0.3), 0.8) + path(M(36, 38) + L(64, 38) + Q(62, 55, 50, 56) + Q(38, 55, 36, 38) + Z, '#7A1F35'),
  plant: (t, v) => ell(50, 91, 22, 3, t.dark, 0.14) + path(M(34, 64) + L(66, 64) + L(62, 90) + L(38, 90) + Z, v > 0.5 ? t.paper : t.accent2) + [-34, -14, 8, 30].map((a, i) => g(ell(0, -22, 8 + (i % 2) * 2, 24, i % 2 ? t.plant : t.plantDark), tr(50, 64, 1, a))).join(''),
  flower: t => ell(50, 91, 14, 2.5, t.dark, 0.14) + path(M(42, 58) + L(58, 58) + L(56, 90) + L(44, 90) + Z, lighten(t.glass, 0.2), 0.9) + stroke(M(50, 60) + Q(48, 44, 50, 30), t.plantDark, 2) + ell(42, 44, 7, 3, t.plant) + [0, 72, 144, 216, 288].map(a => g(ell(0, -8, 5, 8, t.accent), tr(50, 24, 1, a))).join('') + circ(50, 24, 4, '#F5CF47'),
  rose: t => stroke(M(50, 88) + Q(46, 60, 50, 38), t.plantDark, 2.4) + ell(40, 62, 9, 4, t.plant) + circ(50, 28, 14, '#B5263C') + stroke(M(42, 28) + Q(50, 18, 58, 28) + Q(50, 36, 46, 28), '#7E1429', 2),
  candle: t => ell(50, 91, 16, 3, t.dark, 0.12) + rect(38, 46, 24, 44, t.paper, 3) + rect(38, 46, 24, 6, darken(t.paper, 0.06), 3) + line(50, 46, 50, 40, t.dark, 1.2) + path(M(50, 22) + Q(58, 34, 50, 42) + Q(42, 34, 50, 22) + Z, '#F6A93B') + circ(50, 34, 16, t.glow, 0.25),
  candles: t => g(PROPS.candle!(t, 0), tr(-6, 20, 0.7)) + g(PROPS.candle!(t, 0), tr(30, 2, 0.9)),
  crystals: t => ell(50, 91, 26, 3, t.dark, 0.12) + poly([[30, 90], [24, 56], [34, 40], [44, 56], [40, 90]], mix('#B9A6E0', t.accent2, 0.3)) + poly([[46, 90], [42, 40], [54, 22], [66, 42], [62, 90]], lighten(mix('#B9A6E0', t.accent2, 0.3), 0.3)) + poly([[66, 90], [64, 60], [72, 50], [80, 62], [76, 90]], mix('#E8B4B8', t.accent, 0.3)) + line(54, 22, 54, 90, '#FFFFFF', 1, 0.5),
  tarot: t => g(rect(-13, -22, 26, 44, t.furniture, 3) + circ(0, 0, 7, t.accent), tr(34, 58, 1, -18)) + g(rect(-13, -22, 26, 44, t.paper, 3) + stroke(M(0, -12) + L(4, -2) + L(14, -2) + L(6, 5) + L(9, 15) + L(0, 9) + L(-9, 15) + L(-6, 5) + L(-14, -2) + L(-4, -2) + Z, t.accent, 1.6), tr(52, 54)) + g(rect(-13, -22, 26, 44, t.furniture, 3) + circ(0, 0, 7, t.accent), tr(70, 58, 1, 18)),
  'singing-bowl': t => ell(50, 90, 28, 3.5, t.dark, 0.14) + path(M(22, 58) + Q(24, 88, 50, 88) + Q(76, 88, 78, 58) + Z, mix('#B8862F', t.accent, 0.2)) + ell(50, 58, 28, 7, darken('#B8862F', 0.25)) + g(rect(-3, -22, 6, 44, t.wood, 3), tr(78, 44, 1, 28)),
  sage: t => g(rect(-7, -26, 14, 52, mix('#9DA98A', t.plant, 0.3), 6) + line(-7, -8, 7, -4, t.paper, 1.6) + line(-7, 6, 7, 10, t.paper, 1.6), tr(50, 60, 1, 24)) + stroke(M(60, 30) + Q(54, 22, 62, 14) + Q(68, 8, 62, 2), t.light, 2, 0.6),
  'oil-bottle': t => ell(50, 91, 12, 2.5, t.dark, 0.12) + rect(45, 22, 10, 14, t.dark, 2) + rect(38, 36, 24, 52, '#7A4A26', 4) + rect(38, 52, 24, 20, t.paper),
  diffuser: t => ell(50, 91, 20, 3, t.dark, 0.12) + path(M(34, 88) + Q(28, 60, 50, 44) + Q(72, 60, 66, 88) + Z, t.paper) + rect(34, 80, 32, 8, t.wood, 2) + stroke(M(50, 40) + Q(44, 30, 52, 22) + Q(58, 14, 50, 6), t.light, 2.4, 0.7),
  book: book(t => t.accent),
  'book-stack': t => ell(50, 91, 32, 3, t.dark, 0.12) + g(book(x => x.furniture)(t, 0), tr(0, 22)) + g(book(x => x.accent)(t, 0), tr(4, 9)) + g(book(x => x.accent2)(t, 0), tr(-3, -4)),
  'open-book': t => path(M(50, 40) + Q(30, 30, 10, 38) + L(10, 78) + Q(30, 70, 50, 80) + Z, t.paper) + path(M(50, 40) + Q(70, 30, 90, 38) + L(90, 78) + Q(70, 70, 50, 80) + Z, darken(t.paper, 0.04)) + [0, 1, 2].map(i => line(18, 48 + i * 8, 42, 46 + i * 8, t.metal, 1.2, 0.6) + line(58, 46 + i * 8, 82, 48 + i * 8, t.metal, 1.2, 0.6)).join('') + line(50, 40, 50, 80, t.metal, 1),
  magazine: t => g(rect(-24, -32, 48, 64, t.accent, 2) + rect(-18, -26, 36, 8, t.paper, 1) + rect(-18, -12, 36, 30, lighten(t.accent, 0.3), 1) + rect(-18, 22, 20, 4, t.paper, 1), tr(50, 54, 1, -6)),
  journal: t => g(rect(-24, -32, 48, 64, t.furniture, 4) + rect(12, -32, 5, 64, t.accent) + rect(-16, -20, 20, 5, lighten(t.furniture, 0.4), 1), tr(50, 54, 1, 8)),
  notebook: t => g(rect(-26, -32, 52, 64, t.paper, 3) + [0, 1, 2, 3, 4].map(i => line(-16, -18 + i * 10, 18, -18 + i * 10, t.metal, 1, 0.5)).join('') + [0, 1, 2, 3, 4, 5].map(i => circ(-22, -26 + i * 10.4, 1.8, t.dark)).join(''), tr(50, 54, 1, -5)),
  planner: t => rect(12, 26, 76, 56, t.furniture, 3) + rect(15, 29, 34, 50, t.paper, 1) + rect(51, 29, 34, 50, t.paper, 1) + [0, 1, 2, 3].map(i => rect(19, 34 + i * 11, 26, 6, i === 1 ? t.accent : lighten(t.metal, 0.5), 1) + rect(55, 34 + i * 11, 26, 6, i === 2 ? t.accent2 : lighten(t.metal, 0.5), 1)).join(''),
  pen: t => g(rect(-3, -34, 6, 58, t.dark, 3) + poly([[-3, 24], [3, 24], [0, 34]], t.metal) + rect(-3, -34, 6, 10, t.accent, 3), tr(50, 54, 1, 38)),
  marker: t => g(rect(-5, -30, 10, 50, t.accent, 3) + rect(-5, 20, 10, 12, t.dark, 2) + rect(-2.5, 32, 5, 5, t.dark, 1), tr(50, 50, 1, -32)),
  highlighter: t => g(rect(-6, -28, 12, 46, '#F5E050', 3) + rect(-6, 18, 12, 10, t.dark, 2) + poly([[-4, 28], [4, 28], [2, 36], [-4, 34]], '#F5E050'), tr(50, 50, 1, 28)),
  'sticky-notes': (t, v) => [[-18, -10, -8, '#F5E050'], [14, -14, 6, t.accent], [-4, 16, -3, lighten(t.accent2, 0.2)], [22, 14, 10, '#F7A8B8']].slice(0, v > 0.5 ? 4 : 3).map(([x, y, r, c]) => g(rect(-13, -13, 26, 26, c as string, 1) + line(-7, -4, 7, -4, t.dark, 1.2, 0.45) + line(-7, 3, 3, 3, t.dark, 1.2, 0.45), tr(50 + (x as number), 52 + (y as number), 1, r as number))).join(''),
  whiteboard: t => rect(8, 14, 84, 60, t.metal, 3) + rect(11, 17, 78, 54, '#FFFFFF', 2) + circ(30, 40, 9, t.accent, 0.9) + line(39, 40, 52, 40, t.dark, 1.4) + rect(52, 32, 18, 16, t.accent2, 2) + line(70, 40, 80, 40, t.dark, 1.4) + line(22, 60, 78, 60, t.dark, 1.2, 0.4) + line(30, 74, 22, 92, t.metal, 2.4) + line(70, 74, 78, 92, t.metal, 2.4),
  checklist: t => g(rect(-24, -32, 48, 64, t.paper, 3) + [0, 1, 2, 3].map(i => rect(-17, -22 + i * 13, 7, 7, i < 2 ? t.accent : lighten(t.metal, 0.5), 1.5) + line(-6, -18.5 + i * 13, 16, -18.5 + i * 13, t.metal, 1.6, 0.7)).join(''), tr(50, 54, 1, -4)),
  worksheet: t => g(rect(-25, -32, 50, 64, t.paper, 2) + rect(-18, -25, 28, 6, t.accent, 1) + [0, 1, 2].map(i => rect(-18, -12 + i * 13, 36, 9, lighten(t.metal, 0.62), 1.5)).join(''), tr(50, 54, 1, 5)),
  documents: t => g(rect(-24, -30, 48, 60, darken(t.paper, 0.06), 2), tr(44, 56, 1, -12)) + g(rect(-24, -30, 48, 60, t.paper, 2) + rect(-17, -22, 22, 5, t.dark, 1) + [0, 1, 2, 3].map(i => line(-17, -9 + i * 8, 17, -9 + i * 8, t.metal, 1.2, 0.6)).join('') + rect(-17, 20, 14, 5, t.accent, 1), tr(56, 52, 1, 6)),
  chart: t => rect(12, 18, 76, 62, t.paper, 3) + [0, 1, 2, 3].map(i => rect(22 + i * 15, 66 - (14 + i * 9), 10, 14 + i * 9, i === 3 ? t.accent : t.accent2, 1.5)).join('') + stroke(M(22, 50) + L(38, 42) + L(54, 34) + L(76, 24), t.dark, 1.6) + line(18, 70, 82, 70, t.metal, 1),
  binder: t => rect(24, 16, 52, 70, t.furniture, 3) + rect(24, 16, 10, 70, darken(t.furniture, 0.2), 3) + rect(42, 30, 26, 14, t.paper, 1.5) + circ(29, 70, 3, t.metal),
  portfolio: t => rect(14, 30, 72, 50, mix('#6B4630', t.furniture, 0.3), 5) + rect(14, 30, 72, 16, darken(mix('#6B4630', t.furniture, 0.3), 0.15), 5) + rect(44, 42, 12, 8, t.accent, 2),
  calculator: t => rect(28, 16, 44, 70, t.dark, 5) + rect(33, 22, 34, 14, lighten(t.plant, 0.5), 2) + [0, 1, 2, 3, 4, 5, 6, 7, 8].map(i => rect(33 + (i % 3) * 12, 42 + Math.floor(i / 3) * 13, 9, 9, i === 8 ? t.accent : t.metal, 2)).join(''),
  bills: t => g(rect(-22, -28, 44, 56, darken(t.paper, 0.05), 2), tr(42, 56, 1, -14)) + g(rect(-22, -28, 44, 56, t.paper, 2) + rect(-15, -20, 16, 4, t.dark, 1) + [0, 1, 2, 3].map(i => line(-15, -8 + i * 7, 6, -8 + i * 7, t.metal, 1.2, 0.6) + line(10, -8 + i * 7, 15, -8 + i * 7, t.dark, 1.2, 0.6)).join('') + rect(2, 18, 13, 5, '#D8343A', 1), tr(58, 52, 1, 8)),
  keys: t => circ(34, 40, 12, 'none') + stroke(M(46, 40) + `A12 12 0 1 0 45.9 40.1`, mix('#C9A14A', t.accent, 0.2), 4) + stroke(M(44, 46) + L(72, 74) + M(64, 66) + L(58, 72) + M(70, 72) + L(64, 78), mix('#C9A14A', t.accent, 0.2), 4) + rect(56, 22, 22, 26, t.accent, 4) + circ(67, 29, 2.6, t.paper),
  dumbbells: t => ell(50, 90, 34, 3, t.dark, 0.14) + rect(26, 66, 48, 7, t.metal, 3) + rect(12, 54, 9, 30, t.dark, 3) + rect(21, 58, 8, 22, t.dark, 3) + rect(71, 58, 8, 22, t.dark, 3) + rect(79, 54, 9, 30, t.dark, 3) + rect(12, 54, 9, 6, t.accent, 3) + rect(79, 54, 9, 6, t.accent, 3),
  kettlebell: t => ell(50, 91, 22, 3, t.dark, 0.14) + stroke(M(36, 52) + C(30, 20, 70, 20, 64, 52), t.dark, 7) + circ(50, 66, 24, t.dark) + circ(50, 66, 9, t.accent) + ell(42, 54, 6, 3, '#FFFFFF', 0.18),
  'resistance-band': t => stroke(M(22, 70) + C(22, 30, 78, 30, 78, 70) + C(78, 92, 22, 92, 22, 70), t.accent, 7) + stroke(M(30, 70) + C(30, 42, 70, 42, 70, 70), lighten(t.accent, 0.25), 3, 0.7),
  'yoga-mat': t => ell(52, 90, 34, 3, t.dark, 0.12) + rect(16, 60, 68, 28, t.accent2, 14) + circ(30, 74, 14, darken(t.accent2, 0.12)) + stroke(M(30, 66) + `A8 8 0 1 1 29.9 66`, lighten(t.accent2, 0.3), 2.4) + line(56, 60, 56, 88, darken(t.accent2, 0.2), 2),
  cushion: t => ell(50, 90, 34, 3.5, t.dark, 0.14) + path(M(16, 78) + Q(18, 56, 50, 56) + Q(82, 56, 84, 78) + Q(82, 90, 50, 90) + Q(18, 90, 16, 78) + Z, t.accent2) + path(M(22, 70) + Q(50, 60, 78, 70), 'none') + stroke(M(22, 72) + Q(50, 62, 78, 72), lighten(t.accent2, 0.3), 2) + circ(50, 71, 3, darken(t.accent2, 0.25)),
  blanket: t => path(M(14, 86) + Q(16, 50, 40, 46) + L(80, 44) + Q(88, 60, 84, 86) + Z, t.soft) + stroke(M(26, 82) + Q(30, 60, 44, 54) + M(46, 84) + Q(50, 64, 62, 54) + M(66, 84) + Q(70, 66, 78, 56), t.softShade, 2.4),
  'cutting-board': t => rect(14, 44, 64, 40, t.wood, 6) + rect(78, 58, 12, 10, t.wood, 3) + circ(84, 63, 2.4, t.woodDark) + circ(36, 62, 10, '#E4572E') + circ(34, 60, 3, '#F2907A') + ell(58, 66, 12, 7, t.plant) + g(rect(-2, -16, 4, 32, t.metal, 1), tr(62, 54, 1, 60)),
  herbs: t => path(M(40, 62) + L(60, 62) + L(57, 90) + L(43, 90) + Z, '#C9825A') + [-40, -20, 0, 20, 40].map((a, i) => g(stroke(M(0, 0) + L(0, -28), t.plantDark, 1.6) + ell(-4, -14, 4, 7, t.plant) + ell(4, -22, 4, 7, t.plant) + ell(0, -30, 4, 6, i % 2 ? t.plant : t.plantDark), tr(50, 62, 1, a))).join(''),
  citrus: t => ell(50, 90, 30, 3, t.dark, 0.12) + circ(36, 66, 20, '#F2A83B') + circ(36, 66, 16, '#F8D27A') + [0, 60, 120].map(a => g(line(-15, 0, 15, 0, '#F2A83B', 1.4), tr(36, 66, 1, a))).join('') + circ(68, 72, 16, '#F5CF47') + ell(62, 66, 4, 3, '#FFFFFF', 0.4),
  produce: t => ell(50, 90, 34, 3, t.dark, 0.12) + path(M(18, 64) + L(82, 64) + Q(80, 90, 50, 90) + Q(20, 90, 18, 64) + Z, t.paper) + circ(36, 56, 13, '#E4572E') + circ(58, 52, 14, '#6BA547') + circ(72, 60, 10, '#F2A83B') + ell(48, 62, 12, 6, '#7B4FB5') + stroke(M(36, 44) + L(38, 38), t.plantDark, 2),
  knife: t => g(path(M(-3, -34) + L(5, -34) + L(5, 8) + L(-3, 8) + Q(-6, -14, -3, -34) + Z, lighten(t.metal, 0.3)) + rect(-3, 8, 8, 26, t.dark, 3), tr(50, 50, 1, 40)),
  timer: t => circ(50, 54, 30, t.accent) + circ(50, 54, 24, t.paper) + line(50, 54, 50, 36, t.dark, 2.4) + line(50, 54, 62, 60, t.dark, 2.4) + rect(45, 16, 10, 8, t.dark, 2) + circ(50, 54, 2.6, t.dark),
  clock: t => circ(50, 50, 34, t.dark) + circ(50, 50, 29, t.paper) + line(50, 50, 50, 30, t.dark, 2.6) + line(50, 50, 64, 56, t.dark, 2.6) + circ(50, 50, 2.6, t.accent),
  trophy: t => ell(50, 91, 20, 3, t.dark, 0.14) + rect(36, 80, 28, 8, t.dark, 2) + rect(46, 62, 8, 18, mix('#C9A14A', t.accent, 0.2)) + path(M(30, 20) + L(70, 20) + Q(70, 60, 50, 64) + Q(30, 60, 30, 20) + Z, mix('#C9A14A', t.accent, 0.2)) + stroke(M(30, 28) + Q(14, 30, 24, 46) + M(70, 28) + Q(86, 30, 76, 46), mix('#C9A14A', t.accent, 0.2), 4) + ell(42, 34, 4, 9, '#FFFFFF', 0.35),
  'photo-frame': t => rect(22, 22, 56, 66, t.wood, 3) + rect(28, 28, 44, 54, t.paper, 1) + circ(42, 50, 6, t.accent2) + circ(58, 50, 6, t.accent) + path(M(32, 76) + Q(42, 58, 50, 70) + Q(58, 58, 68, 76) + Z, t.softShade),
  tissues: t => rect(22, 54, 56, 34, t.soft, 5) + ell(50, 54, 14, 4, t.softShade) + path(M(42, 54) + Q(40, 34, 50, 30) + Q(62, 36, 58, 54) + Z, '#FFFFFF'),
  toys: t => ell(50, 91, 32, 3, t.dark, 0.12) + rect(18, 64, 24, 24, '#E4572E', 3) + rect(44, 64, 24, 24, '#F5CF47', 3) + rect(31, 40, 24, 24, '#3C8DD8', 3) + circ(78, 78, 10, '#6BA547'),
  swatches: (t, v) => [-28, -12, 6, 24].map((a, i) => g(rect(-9, -34, 18, 62, [t.accent, t.accent2, t.furniture, t.soft][i] as string, 2) + rect(-9, 16, 18, 12, t.paper, 2), tr(50, 72, 1, a + v * 6))).join('') + circ(50, 86, 3, t.metal),
  letterpress: t => g(rect(-26, -18, 52, 36, darken(t.paper, 0.05), 2), tr(44, 60, 1, -10)) + g(rect(-26, -18, 52, 36, t.paper, 2) + rect(-12, -9, 24, 3, t.dark, 1) + rect(-16, -1, 32, 2, t.metal, 1) + rect(-9, 6, 18, 2, t.metal, 1), tr(56, 50, 1, 6)),
  'wax-seal': t => circ(50, 54, 22, mix('#8E2B32', t.accent, 0.3)) + [0, 45, 90, 135, 180, 225, 270, 315].map(a => g(circ(0, -21, 5, mix('#8E2B32', t.accent, 0.3)), tr(50, 54, 1, a))).join('') + circ(50, 54, 13, darken(mix('#8E2B32', t.accent, 0.3), 0.18)) + stroke(M(44, 54) + L(50, 46) + L(56, 54) + L(50, 62) + Z, lighten('#8E2B32', 0.5), 1.6),
  ink: t => ell(50, 91, 18, 3, t.dark, 0.12) + rect(42, 44, 16, 8, t.dark, 2) + rect(34, 52, 32, 36, t.dark, 5) + rect(38, 62, 24, 14, t.paper, 1) + g(rect(-1.6, -30, 3.2, 44, t.wood, 1.5) + poly([[-3, 14], [3, 14], [0, 26]], t.metal), tr(74, 40, 1, 18)),
  moodboard: t => rect(10, 14, 80, 66, t.paper, 2) + rect(15, 19, 26, 30, t.accent, 1) + rect(44, 19, 20, 16, t.accent2, 1) + rect(67, 19, 18, 26, t.furniture, 1) + rect(44, 38, 20, 20, t.soft, 1) + rect(15, 52, 26, 22, t.softShade, 1) + rect(44, 61, 41, 13, lighten(t.accent, 0.4), 1) + rect(67, 48, 18, 10, t.plant, 1) + circ(28, 19, 2, '#D8343A') + circ(76, 19, 2, '#D8343A'),
  'brand-guide': t => g(rect(-28, -20, 56, 40, t.paper, 2) + circ(-14, -4, 7, t.accent) + circ(2, -4, 7, t.accent2) + circ(18, -4, 7, t.furniture) + rect(-21, 9, 30, 4, t.dark, 1), tr(50, 56, 1, -6)),
  sketchbook: t => g(rect(-26, -30, 52, 60, t.paper, 2) + stroke(M(-14, 12) + Q(-8, -18, 4, -6) + Q(12, 4, 16, -16), t.dark, 1.8) + circ(8, 14, 6, t.accent, 0.8) + [0, 1, 2, 3, 4, 5, 6].map(i => circ(-18 + i * 6, -30, 2, t.metal)).join(''), tr(50, 54, 1, 7)),
  brushes: t => ell(50, 91, 18, 3, t.dark, 0.12) + [-14, -4, 8].map((a, i) => g(rect(-2, -44, 4, 44, t.wood, 2) + rect(-3.4, -54, 6.8, 12, [t.accent, t.accent2, '#3C8DD8'][i] as string, 3), tr(50, 62, 1, a))).join('') + path(M(34, 56) + L(66, 56) + L(62, 90) + L(38, 90) + Z, t.metal),
  easel: t => line(50, 10, 26, 92, t.woodDark, 3) + line(50, 10, 74, 92, t.woodDark, 3) + line(50, 10, 50, 92, t.woodDark, 3) + rect(22, 22, 56, 44, t.paper, 1) + circ(40, 40, 9, t.accent) + rect(50, 34, 20, 22, t.accent2, 1) + rect(18, 66, 64, 4, t.wood, 1),
  guitar: t => g(rect(-3, -50, 6, 50, t.woodDark, 2) + rect(-6, -58, 12, 12, t.dark, 2) + ell(0, 14, 20, 24, t.wood) + ell(0, -6, 14, 14, t.wood) + circ(0, 6, 7, t.dark) + rect(-8, 22, 16, 3, t.dark, 1), tr(50, 54, 1, 16)),
  keyboard: t => rect(8, 46, 84, 28, t.dark, 4) + [0, 1, 2].map(r => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(c => rect(12 + c * 7.7, 50 + r * 7, 6, 5, (r + c) % 7 === 0 ? t.accent : lighten(t.dark, 0.25), 1)).join('')).join(''),
  typewriter: t => ell(50, 90, 34, 3, t.dark, 0.14) + rect(26, 16, 48, 30, t.paper, 1) + rect(18, 40, 64, 14, t.dark, 4) + path(M(14, 54) + L(86, 54) + L(90, 88) + L(10, 88) + Z, t.furniture) + [0, 1, 2].map(r => [0, 1, 2, 3, 4, 5, 6].map(c => circ(24 + c * 8.6 + r * 2, 62 + r * 8, 2.6, t.paper)).join('')).join(''),
  script: t => g(rect(-22, -30, 44, 60, darken(t.paper, 0.05), 1), tr(46, 56, 1, -8)) + g(rect(-22, -30, 44, 60, t.paper, 1) + [0, 1, 2, 3, 4, 5].map(i => line(i % 2 ? -8 : -15, -20 + i * 8, i % 2 ? 8 : 15, -20 + i * 8, t.metal, 1.3, 0.7)).join('') + rect(-15, -8, 30, 5, '#F5E050', 1, 0.6), tr(56, 52, 1, 5)),
  mirror: t => ell(50, 91, 16, 3, t.dark, 0.12) + rect(30, 8, 40, 80, t.wood, 20) + rect(34, 12, 32, 72, lighten(t.glass, 0.25), 16) + line(42, 22, 38, 50, '#FFFFFF', 3, 0.6),
  lamp: t => ell(50, 91, 16, 3, t.dark, 0.12) + rect(48, 46, 4, 42, t.metal) + rect(38, 86, 24, 4, t.metal, 2) + path(M(34, 46) + L(66, 46) + L(58, 18) + L(42, 18) + Z, t.accent2) + ell(50, 52, 24, 10, t.glow, 0.35),
  lipstick: t => rect(40, 54, 20, 34, t.dark, 2) + rect(42, 44, 16, 12, mix('#C9A14A', t.accent, 0.2), 1) + path(M(44, 44) + L(44, 26) + L(56, 20) + L(56, 44) + Z, '#C2264B'),
  'nail-polish': t => [[30, '#D94F70'], [50, t.accent], [70, '#F2C4CE']].map(([x, c]) => rect((x as number) - 4, 32, 8, 22, t.dark, 2) + rect((x as number) - 9, 54, 18, 34, c as string, 5) + rect((x as number) - 6, 58, 3, 18, '#FFFFFF', 1.5, 0.35)).join(''),
  'nail-tools': t => g(rect(-4, -34, 8, 68, lighten(t.metal, 0.4), 4) + rect(-4, -34, 8, 40, '#E8B4B8', 4), tr(38, 54, 1, -18)) + g(rect(-2, -34, 4, 68, t.metal, 2) + ell(0, -34, 4, 6, t.metal), tr(62, 54, 1, 14)),
  'uv-lamp': t => ell(50, 90, 34, 3, t.dark, 0.14) + path(M(14, 86) + Q(14, 40, 50, 40) + Q(86, 40, 86, 86) + Z, t.paper) + path(M(26, 86) + Q(26, 58, 50, 58) + Q(74, 58, 74, 86) + Z, '#6C4FD8') + circ(50, 50, 3, t.accent),
  'product-box': t => ell(50, 91, 30, 3, t.dark, 0.14) + poly([[20, 40], [50, 28], [80, 40], [50, 52]], lighten(t.accent2, 0.25)) + poly([[20, 40], [50, 52], [50, 90], [20, 78]], t.accent2) + poly([[80, 40], [50, 52], [50, 90], [80, 78]], darken(t.accent2, 0.14)) + rect(28, 56, 14, 8, t.paper, 1),
  'product-jar': t => ell(50, 91, 24, 3, t.dark, 0.14) + rect(30, 26, 40, 14, t.dark, 3) + rect(26, 40, 48, 48, t.paper, 8) + rect(26, 54, 48, 20, t.accent) + rect(34, 60, 22, 4, t.paper, 1) + rect(30, 44, 4, 38, '#FFFFFF', 2, 0.5),
  'product-bottle': t => ell(50, 91, 18, 3, t.dark, 0.14) + rect(44, 8, 12, 8, t.dark, 2) + rect(47, 16, 6, 10, t.metal) + path(M(38, 26) + L(62, 26) + Q(68, 30, 68, 38) + L(68, 88) + L(32, 88) + L(32, 38) + Q(32, 30, 38, 26) + Z, t.accent) + rect(38, 46, 24, 26, t.paper, 2) + rect(42, 52, 16, 3, t.dark, 1) + rect(36, 30, 4, 54, '#FFFFFF', 2, 0.3),
  'shopping-bag': t => ell(50, 91, 26, 3, t.dark, 0.14) + stroke(M(38, 36) + C(38, 14, 62, 14, 62, 36), t.dark, 2.6) + path(M(26, 36) + L(74, 36) + L(78, 88) + L(22, 88) + Z, t.accent) + rect(40, 54, 20, 12, t.paper, 2),
  'gift-box': t => ell(50, 91, 30, 3, t.dark, 0.14) + rect(22, 46, 56, 42, t.accent2, 3) + rect(18, 38, 64, 12, t.accent, 3) + rect(46, 38, 8, 50, t.paper) + stroke(M(50, 38) + Q(34, 18, 30, 34) + Q(40, 40, 50, 38) + Q(66, 18, 70, 34) + Q(60, 40, 50, 38), t.paper, 3.4),
  packaging: t => ell(50, 91, 34, 3, t.dark, 0.14) + rect(18, 50, 64, 38, t.wood, 2) + poly([[18, 50], [8, 34], [40, 34], [50, 50]], darken(t.wood, 0.1)) + poly([[82, 50], [92, 34], [60, 34], [50, 50]], darken(t.wood, 0.16)) + path(M(30, 50) + Q(36, 30, 50, 44) + Q(62, 28, 70, 50) + Z, t.paper) + rect(40, 34, 20, 26, t.accent, 4),
  glasses: t => stroke(M(22, 50) + `A12 12 0 1 0 46 50 A12 12 0 1 0 22 50` + M(54, 50) + `A12 12 0 1 0 78 50 A12 12 0 1 0 54 50` + M(46, 48) + Q(50, 44, 54, 48) + M(22, 48) + L(12, 42) + M(78, 48) + L(88, 42), t.dark, 3),
  shoes: t => ell(50, 90, 34, 3, t.dark, 0.14) + path(M(12, 84) + L(12, 66) + Q(26, 62, 34, 70) + L(54, 76) + Q(62, 78, 62, 86) + L(12, 86) + Z, t.accent) + rect(12, 83, 50, 4, t.paper, 2) + path(M(40, 78) + L(40, 60) + Q(54, 56, 62, 64) + L(82, 70) + Q(90, 72, 90, 80) + L(64, 80) + Z, darken(t.accent, 0.15)),
  watch: t => rect(40, 10, 20, 80, t.dark, 6) + rect(30, 32, 40, 36, t.dark, 9) + rect(34, 36, 32, 28, t.screen, 6) + stroke(M(38, 52) + L(44, 52) + L(47, 44) + L(52, 58) + L(55, 50) + L(62, 50), t.accent, 2),
  cards: t => [-16, 0, 16].map((a, i) => g(rect(-13, -20, 26, 40, i === 1 ? t.accent : t.paper, 3) + rect(-7, -12, 14, 4, i === 1 ? t.paper : t.metal, 1), tr(50 + a * 0.9, 56, 1, a))).join(''),
  'vision-board': t => rect(8, 12, 84, 70, t.wood, 2) + rect(12, 16, 76, 62, mix('#C9A77C', t.soft, 0.3), 1) + rect(16, 20, 22, 18, t.accent, 1) + circ(52, 30, 10, t.accent2) + rect(66, 20, 18, 26, t.paper, 1) + rect(16, 44, 28, 14, t.paper, 1) + rect(48, 46, 14, 26, t.plant, 1) + rect(16, 62, 28, 12, t.furniture, 1) + rect(66, 52, 18, 20, t.softShade, 1),
  lectern: t => ell(50, 91, 22, 3, t.dark, 0.14) + poly([[28, 30], [72, 30], [66, 42], [34, 42]], t.wood) + rect(38, 42, 24, 46, t.woodDark, 2) + rect(34, 86, 32, 4, t.dark, 2) + stroke(M(54, 30) + Q(58, 14, 50, 12), t.dark, 2) + circ(49, 11, 3.4, t.dark),
  armchair: t => ell(50, 91, 36, 4, t.dark, 0.14) + rect(22, 22, 56, 46, t.soft, 14) + rect(12, 46, 16, 36, t.softShade, 7) + rect(72, 46, 16, 36, t.softShade, 7) + rect(24, 56, 52, 22, lighten(t.soft, 0.12), 6) + rect(22, 80, 6, 10, t.woodDark, 2) + rect(72, 80, 6, 10, t.woodDark, 2),
  bookshelf: t => rect(10, 6, 80, 86, t.woodDark, 2) + [0, 1, 2].map(r => rect(14, 10 + r * 28, 72, 24, darken(t.woodDark, 0.25), 1) + [0, 1, 2, 3, 4, 5, 6].map(c => rect(17 + c * 9.6, 12 + r * 28 + ((c + r) % 3) * 2, 7, 22 - ((c + r) % 3) * 2, [t.accent, t.paper, t.accent2, t.furniture, t.soft][(c + r * 2) % 5] as string, 1)).join('')).join(''),
  audience: t => [10, 28, 46, 64, 82, 100].map((x, i) => circ(x - 4, 60 + (i % 2) * 8, 12, t.dark) + path(M(x - 24, 100) + Q(x - 22, 74 + (i % 2) * 8, x - 4, 74 + (i % 2) * 8) + Q(x + 14, 74 + (i % 2) * 8, x + 16, 100) + Z, t.dark)).join(''),
  award: t => circ(50, 40, 24, mix('#C9A14A', t.accent, 0.2)) + circ(50, 40, 17, lighten('#C9A14A', 0.3)) + poly([[38, 60], [32, 92], [44, 84], [50, 92], [50, 62]], t.accent) + poly([[62, 60], [68, 92], [56, 84], [50, 92], [50, 62]], darken(t.accent, 0.15)) + stroke(M(42, 40) + L(48, 46) + L(59, 34), t.dark, 3),
  sheet: t => g(rect(-24, -30, 48, 60, t.paper, 2) + rect(-16, -20, 24, 5, t.accent, 1) + [0, 1, 2].map(i => line(-16, -6 + i * 9, 16, -6 + i * 9, t.metal, 1.3, 0.6)).join(''), tr(50, 54, 1, -6)),
};

/** Ordered keyword rules mapping the source's own prop phrases to a drawable prop. First match wins. */
const PROP_RULES: Array<[RegExp, string]> = [
  [/macbook with (code|architecture)|code \+ figma/, 'laptop-code'], [/figma|webflow|design tablet/, 'laptop-design'],
  [/(macbook|laptop).*(analytics|metrics|dashboard|kpi|ahrefs|semrush|ad metrics|pipeline|traction)|wealth tracker|trading screens|performance metrics screen|spreadsheet on screen/, 'laptop-dashboard'],
  [/(macbook|laptop).*(calendar|content plan|countdown|timestamps)/, 'laptop-calendar'], [/(macbook|laptop).*(automation|flow|esp|sequence)/, 'laptop-flow'],
  [/(macbook|laptop).*(skool|community|platform|linkedin)|dating-app/, 'laptop-community'], [/(macbook|laptop).*(copy|draft|manuscript|blog|newsletter)/, 'laptop-doc'],
  [/blank screen|mockup/, 'laptop-blank'], [/macbook|laptop/, 'laptop'], [/monitor|multi-monitor|dashboard|metrics|analytics|tracker on screen/, 'monitor'],
  [/tablet|ipad/, 'tablet'], [/phone[- ]on[- ]tripod|phone tripod/, 'phone-tripod'], [/ring[- ]light/, 'ring-light'], [/phone/, 'phone'],
  [/softbox|strobe|lights\b/, 'softbox'], [/reflector/, 'reflector'], [/tripod/, 'tripod'], [/camera|dslr|recording gear/, 'camera'],
  [/mic\b|microphone|shure/, 'mic'], [/headphones|headset/, 'headphones'],
  [/two cups|equal water glasses/, 'two-cups'], [/coffee|espresso|mug|tea\b|herbal tea|cup of tea/, 'mug'], [/smoothie/, 'smoothie'], [/wine/, 'wine-glass'], [/water bottle/, 'bottle'], [/water|glass of/, 'water-glass'],
  [/rose\b/, 'rose'], [/flower/, 'flower'], [/herbs|sage\b.*(?!burning)|lavender sprig/, 'herbs'], [/plant/, 'plant'],
  [/burning sage/, 'sage'], [/candles/, 'candles'], [/candle/, 'candle'], [/crystal|selenite|stones/, 'crystals'], [/tarot|oracle|astrology/, 'tarot'], [/singing bowl/, 'singing-bowl'],
  [/essential oil/, 'oil-bottle'], [/diffuser/, 'diffuser'],
  [/sticky|post-it|kanban/, 'sticky-notes'], [/whiteboard|launch-week board|brief board|launch-board|process map/, 'whiteboard'], [/vision board|vision-board/, 'vision-board'],
  [/mood-?boards?|creative-mood-board/, 'moodboard'], [/brand guide|brand-guideline/, 'brand-guide'], [/swatch|pantone/, 'swatches'], [/letterpress/, 'letterpress'], [/wax seal/, 'wax-seal'], [/calligraphy|ink\b|nibs/, 'ink'],
  [/planner|calendar|content calendar|editorial calendar|time-blocked/, 'planner'], [/checklist|habit tracker|goal tracker|payment tracker|health tracker/, 'checklist'],
  [/worksheet|workbook|meal[- ]planning|training plan|guidelines|nutrition guide|sales script/, 'worksheet'], [/diagram|chart|results metrics|timeline|keyword cluster|ikigai|funnel/, 'chart'],
  [/binder/, 'binder'], [/portfolio/, 'portfolio'], [/calculator/, 'calculator'], [/bills|receipt|financial paper|snowball/, 'bills'], [/keys|lockbox/, 'keys'],
  [/children's books|books on|book stack|classic copy books|art books|premium books|stacked books|leadership book/, 'book-stack'], [/reading book|open notebook|open book/, 'open-book'], [/magazine|financial press|design-press/, 'magazine'],
  [/sketchbook/, 'sketchbook'], [/journal|leather notebook/, 'journal'], [/notebook|swipe file|\bnotes\b/, 'notebook'], [/\bbooks?\b/, 'book'], [/documentation|documents|pitch deck|slide deck|cv draft|printouts|brand guides|creative materials|content stack/, 'documents'],
  [/sharpie|marker/, 'marker'], [/highlighter/, 'highlighter'], [/pen\b|fountain pen|gold pen/, 'pen'],
  [/dumbbell/, 'dumbbells'], [/kettlebell/, 'kettlebell'], [/resistance band|fitness gear/, 'resistance-band'], [/yoga mat/, 'yoga-mat'], [/cushion/, 'cushion'], [/blanket/, 'blanket'], [/shoes|trainers/, 'shoes'], [/heart-rate|watch\b/, 'watch'],
  [/cutting board/, 'cutting-board'], [/citrus|lemon/, 'citrus'], [/produce|whole foods|vegetables|food/, 'produce'], [/knife/, 'knife'], [/timer/, 'timer'],
  [/trophy/, 'trophy'], [/award/, 'award'], [/family photo|team photo|photo wall|member-photo|shoutout wall/, 'photo-frame'], [/tissue/, 'tissues'], [/toys|bonding activity|activity supplies/, 'toys'],
  [/brushes|paint/, 'brushes'], [/canvas|easel/, 'easel'], [/guitar|instrument/, 'guitar'], [/keyboard/, 'keyboard'], [/typewriter/, 'typewriter'], [/script/, 'script'],
  [/mirror/, 'mirror'], [/lamp/, 'lamp'], [/lipstick/, 'lipstick'], [/polish/, 'nail-polish'], [/nail files|cuticle/, 'nail-tools'], [/uv lamp/, 'uv-lamp'],
  [/unboxing|packaging/, 'packaging'], [/merchandise|shopping/, 'shopping-bag'], [/bonus|gift/, 'gift-box'], [/the product itself|product\b/, 'product-bottle'],
  [/glasses/, 'glasses'], [/conversation cards|deck of cards|cards\b/, 'cards'], [/lectern|podium/, 'lectern'], [/two chairs|armchair|chair/, 'armchair'], [/shelf|library/, 'bookshelf'], [/clock/, 'clock'],
];

export const PROP_KINDS = Object.keys(PROPS);
export function resolveProp(text: string): string | null {
  const t = text.toLowerCase();
  for (const [re, kind] of PROP_RULES) if (re.test(t)) return kind;
  return null;
}
export function hasProp(kind: string): boolean { return kind in PROPS; }
/** Draw a prop into a w×h box (uniform scale, centred). */
export function drawProp(kind: string, t: Tone, w: number, h: number, v = 0.5): string {
  const d = PROPS[kind] ?? PROPS.sheet!;
  const s = Math.min(w, h) / 100;
  return g(d(t, v), tr((w - 100 * s) / 2, (h - 100 * s) / 2, s));
}
// keep unused import-free: C, Q, L, M, Z, ell, line, poly are all used above
void [C, ell];
