/**
 * Build one CanonicalScene from verbatim source. Pure and deterministic.
 * Customer-facing fields are a documented *semantic* mapping (see docs/PROMPT_STUDIO_DATA_MAP.md):
 *   display_title  ← name (spreadsheet col B "Display Name")
 *   what_creating  ← asset label + niche          ("What am I creating?")
 *   visible_scene  ← tagline (col C) when specific, else derived from scenario/framing/props ("What will visibly appear?")
 *   where_used     ← businessMoment               ("Where do I use it?")
 *   benefit        ← first sentence of sub (col D "Summary") ("What result is it designed to achieve?")
 */
import { extractDNA } from '../compiler/dna.ts';
import { sentence, truncateWords } from '../shared/util.ts';
import { PLATFORM_KEYS, SCHEMA_VERSION, type CanonicalScene, type GalleryEntry, type OriginalScene, type SceneDNA } from './schema.ts';

const GENERIC_TAGLINE = /styled for your brand and designed for your specific use case/i;
const article = (w: string): string => (/^[aeiou]/i.test(w) ? 'An ' : 'A ');
const PROPER = /\b(tiktok|linkedin|youtube|instagram|pinterest|facebook|skool|kajabi|teachable|thinkific|circle|twitter|ig|cta|q&a|faq|bts|vip|dm|ugc|seo|b2b|ceo|hr|ai|x)\b/gi;
const PROPER_CASE: Record<string, string> = { tiktok: 'TikTok', linkedin: 'LinkedIn', youtube: 'YouTube', instagram: 'Instagram', pinterest: 'Pinterest', facebook: 'Facebook', skool: 'Skool', kajabi: 'Kajabi', teachable: 'Teachable', thinkific: 'Thinkific', circle: 'Circle', twitter: 'Twitter', x: 'X' };
/** Sentence-case an asset label for running text, keeping product names and acronyms. */
const lowerLabel = (t: string): string => t.toLowerCase().replace(PROPER, m => PROPER_CASE[m.toLowerCase()] ?? m.toUpperCase());
const lowerFirst = (t: string): string => (/^[A-Z][a-z]/.test(t) && !/^(TikTok|LinkedIn|YouTube|Instagram|Pinterest|Facebook|Skool|Kajabi|Twitter|IG|Q&A|CTA)/.test(t) ? t.charAt(0).toLowerCase() + t.slice(1) : t);

const CROP_WORDS: Record<string, string> = { tight: 'Close-up', close: 'Head-and-shoulders view', medium: 'Waist-up view', 'medium-wide': 'Wide view', wide: 'Wide scene', 'top-down': 'Top-down layout', 'full-body': 'Full-length view' };

export function deriveVisibleScene(o: OriginalScene, d: SceneDNA): string {
  if (!GENERIC_TAGLINE.test(o.tagline)) return sentence(o.tagline.replace(/\s*:\s*/g, ' — ').trim());
  return sentence(derive());
  function derive(): string {
  // plain language: camera/lighting terms stay in the brief, never in the customer-facing line
  const plain = (t: string): string => t.replace(/\s*with bokeh effect/gi, '').replace(/softly blurred environmental background/gi, 'a softly blurred background').replace(/\b(bokeh|softbox(es)?|strobe lights?|DSLR-grade|rim light(ing)?|key light)\b/gi, '').replace(/\s{2,}/g, ' ').replace(/\s+,/g, ',').trim();
  const env = d.environment ? plain(d.environment.split(',')[0]!.trim()) : '';
  const props = d.props.slice(0, 2).map(plain).filter(Boolean).join(' and ');
  const sec = d.framing.secondary && !/zone|space|environment/.test(d.framing.secondary) ? `, with ${d.framing.secondary}` : '';
  switch (d.subjectKind) {
    case 'pattern': return 'A repeating brand-pattern backdrop with a clear area for guests to stand in front of';
    case 'texture': return 'An even textured surface with no focal point, made to sit behind your words';
    case 'devices': return 'Laptop, tablet and phone with blank screens, ready for your own designs';
    case 'environment-only': return `The workspace itself — no person — ${env ? 'a ' + lowerFirst(env) : 'styled to your brand'}${props ? ', with ' + props : ''}`;
    case 'flat-lay': return `Top-down arrangement${props ? ' of ' + props : ''}${env ? ', styled like ' + lowerFirst(env) : ''}`;
    case 'product': return `The product as the hero${env ? ' in a ' + lowerFirst(env) : ''}, with clear space for its name`;
    case 'hands': return `Hands in action${props ? ' with ' + props : ''} — the detail is the story`;
    case 'print-typographic': return `A typography-led printed piece: ${lowerFirst(o.framing)}`;
    case 'group': return `A group with every face readable${env ? ', in ' + lowerFirst(env) : ''}`;
    default: return `${CROP_WORDS[d.framing.crop] ?? 'View'} of you${env ? ' in ' + lowerFirst(env) : ''}${sec}${props ? ' — ' + props + ' in frame' : ''}`;
  }
  }
}

function funnelStage(o: OriginalScene): CanonicalScene['funnel_stage'] {
  if (/^(Onboarding|Community|Email\/Onboarding|Event\/Follow-up|Bonus|Replay|Email\/Recap|Course\/(Module|Lesson|Resource|Bonus))/.test(o.asset)) return 'retain';
  switch (o.conversionIntent) {
    case 'pattern_interrupt': case 'curiosity_gap': return 'attract';
    case 'educational': case 'emotional_connection': case 'community_belonging': return 'engage';
    case 'fomo_urgency': case 'premium_signaling': return 'convert';
    case 'social_proof': return /Sales|Case Study/.test(o.asset) ? 'convert' : 'nurture';
    default: return /^Sales|Lead|Advertising|Conversion|Launch|Bundle|Cohort/.test(o.asset) ? 'convert' : 'nurture';
  }
}

export const GOALS: Array<{ key: string; label: string; test: (o: OriginalScene) => boolean }> = [
  { key: 'promote-offer', label: 'Promote an offer', test: o => /^Sales|Bundle|Cohort|Programme|Course\/Sales|Promo|Executive Service|Services Page|Consulting\/Service|Mentoring|Premium Event|Conversion/.test(o.asset) },
  { key: 'build-trust', label: 'Build trust', test: o => /Social Proof|Case Study|Authority|About|Authenticity|Headshot|Testimonial|Brand\/|Editorial\/Bio/.test(o.asset) || o.conversionIntent === 'social_proof' },
  { key: 'grow-audience', label: 'Grow my audience', test: o => /Lead|Podcast|Video|Channel|Series|Community|Creator|Content|LinkedIn|Pinterest|Tiktok|Show/.test(o.asset) || o.conversionIntent === 'curiosity_gap' },
  { key: 'launch', label: 'Launch something', test: o => /Launch|Cohort|Event\/Invite|Sales\/Event|Live Event|Replay|Event\/Banner|Bonus|Bundle|Promo/.test(o.asset) || o.conversionIntent === 'fomo_urgency' },
  { key: 'social-content', label: 'Create social content', test: o => /^Social|Stock\/Social|Tiktok|Pinterest|Twitter|LinkedIn|Editorial\/Quote|Authority\/Quote|Authority\/Insight|Community\/Engagement|Creator/.test(o.asset) || /Instagram|Tiktok|Linkedin|Facebook|Pinterest|Twitter/.test(o.niche) },
  { key: 'ads', label: 'Make ads', test: o => /^Advertising/.test(o.asset) || o.niche === 'Advertising' || o.conversionIntent === 'pattern_interrupt' },
  { key: 'email', label: 'Design email visuals', test: o => /^Email|Onboarding\/Email|Editorial\/(Masthead|Letter)/.test(o.asset) || o.niche === 'Email Marketing' || /newsletter/i.test(o.businessMoment) },
  { key: 'visualise-idea', label: 'Visualise an idea', test: o => /Methodology|Method|Curriculum|Tutorial|Workshop|Assessment|Strategy|Review|Education|Carousel/.test(o.asset) || o.conversionIntent === 'educational' },
  { key: 'website', label: 'Make my website look better', test: o => /Homepage|About Page|Services Page|Stock\/(Hero|Blog|About)|Sales\/Hero|Generic\/Header|Content\/Article/.test(o.asset) || /^Website/.test(o.niche) },
  { key: 'brand-shoot', label: 'Create my brand shoot', test: o => /^Stock\/|Headshot|Lifestyle|Authenticity|Brand\/|Creator\/|Fashion/.test(o.asset) },
  { key: 'events', label: 'Run an event', test: o => /^Event|Live Event|Premium Event|Enterprise\/Workshop|Workshop/.test(o.asset) || o.niche === 'Events Print' },
  { key: 'courses', label: 'Teach a course', test: o => /^Course|Teachable|Thinkific|Kajabi|Programme|Replay|Onboarding|Mighty|Circle/.test(o.asset) || /Skool|Kajabi|Teachable|Thinkific|Circle|Mighty/.test(o.niche) },
  { key: 'products', label: 'Sell a product', test: o => /^E-commerce|Stock\/Product|Service\//.test(o.asset) },
];

export interface CanonicalInputs {
  original: OriginalScene; category: string; canonicalArchive: string; canonicalPath: string; canonicalSha256: string;
  alternateArchive: string; alternateSha256: string; alternateDifferences: Record<string, string>;
  indexFields: { cat: string; catLabel: string; lighting: string; baseScene: string; keywords: string[] };
  sourceVersion: string; sharedScenarioCount: number;
}

export function buildCanonical(inp: CanonicalInputs): CanonicalScene {
  const o = inp.original; const dna = extractDNA(o, { baseScene: inp.indexFields.baseScene, lighting: inp.indexFields.lighting });
  const nicheLc = o.channelType === 'Platform' ? o.niche : o.niche.toLowerCase();
  const personKinds = ['person', 'two-people', 'group', 'hands'];
  const defects: string[] = [];
  const ph = new Set<string>(); for (const k of PLATFORM_KEYS) for (const m of o.v3.platforms[k].match(/\{[a-zA-Z_]+\}/g) ?? []) ph.add(m);
  if (ph.size) defects.push(`unresolved placeholder(s) in original platform prompts: ${[...ph].join(', ')}`);
  if (PLATFORM_KEYS.some(k => /, 1, 85mm|\b[a-z]{1,3} 85mm (editorial|professional|f\/)/.test(o.v3.platforms[k]))) defects.push('mid-sentence truncation in original platform prompts (lighting clause cut by a character budget)');
  if (inp.indexFields.baseScene && !o.name.toLowerCase().includes(inp.indexFields.baseScene.toLowerCase().slice(0, 12)) && o.v3.platforms.claude.includes(inp.indexFields.baseScene)) defects.push(`original platform prompts title the scene by its internal base scene “${inp.indexFields.baseScene}” rather than its display name`);
  if (inp.sharedScenarioCount > 1) defects.push(`scenario text is shared verbatim with ${inp.sharedScenarioCount - 1} other record(s); this record’s identity lives in framing/safeZones/poseDirection/businessMoment`);
  if (GENERIC_TAGLINE.test(o.tagline)) defects.push('generic tagline in source; visible_scene derived from scenario/framing/props instead');
  const negatives = ['No invented testimonials, results, statistics, prices or awards'];
  if (dna.noOverlay) negatives.push('No added text or graphics — the source specifies the frame stands alone');
  if (!personKinds.includes(dna.subjectKind) && dna.subjectKind !== 'print-typographic') negatives.push('No person in frame — ' + dna.subject);
  if (dna.subjectKind === 'texture') negatives.push('No focal point or recognisable objects');
  negatives.push('No amateur blur, harsh shadows or AI artefacts');

  return {
    schema_version: SCHEMA_VERSION, id: o.id, source_version: inp.sourceVersion, category: inp.category, niche: o.niche,
    display_title: o.name,
    what_creating: `${article(dna.assetLabel)}${lowerLabel(dna.assetLabel)} for ${o.channelType === 'Platform' ? (PROPER_CASE[o.niche.toLowerCase()] ?? o.niche) : nicheLc}`,
    visible_scene: deriveVisibleScene(o, dna),
    where_used: sentence(o.businessMoment),
    benefit: truncateWords(sentence((o.sub.match(/^[^.!?]+[.!?]/)?.[0] ?? o.sub).replace(/\s*:\s*/g, ' — ').trim()), 200),
    asset_type: o.asset, business_moment: o.businessMoment,
    target_audience: o.channelType === 'Platform' ? `Your audience on ${o.niche}` : `Prospective and current clients of ${nicheLc}`,
    conversion_intent: o.conversionIntent, design_principle: o.designPrinciple, funnel_stage: funnelStage(o),
    scenario: o.scenario, industry_context: o.industryContext,
    subject: dna.subject, objects: dna.props, environment: dna.environment,
    framing: o.framing, pose: o.poseDirection, lighting_spec: o.lightingSpec,
    wardrobe_if_applicable: personKinds.includes(dna.subjectKind) || dna.subjectKind === 'print-typographic' ? o.wardrobe : null,
    composition: `${o.designPrinciple.replace(/_/g, ' ')} — ${o.framing}`, copy_safe_zones: dna.zones, aspect_ratio: o.aspect,
    dimensions: { width: dna.width, height: dna.height, label: o.recommendedDimensions || o.dimensions },
    brand_constraints: { palette: dna.palette, palette_notes: o.palette, archetype: o.archetype.replace(/\s*\[USER WIZARD CHOICE[^\]]*\]/, '') },
    reference_requirements: {
      needs_person_reference: personKinds.includes(dna.subjectKind), needs_product_reference: dna.subjectKind === 'product' || (/E-commerce/.test(o.asset) && dna.subjectKind !== 'person'),
      note: personKinds.includes(dna.subjectKind) ? 'A real photograph of the person (uploaded with permission) is needed for a final photographic version.' : dna.subjectKind === 'product' ? 'A real photograph of the actual product is needed for a final version.' : 'No reference photograph required.',
    },
    negative_constraints: negatives, rich_brief: o.richBrief, render_style: o.render, background_style: o.bg,
    best_platforms: o.bestPlatforms.split(/,\s*/).filter(Boolean), keywords: inp.indexFields.keywords,
    dna, original_template: null, original_platform_prompts: o.v3.platforms, original: o,
    provenance: {
      canonical_archive: inp.canonicalArchive, canonical_path: inp.canonicalPath, canonical_sha256: inp.canonicalSha256,
      alternate_archive: inp.alternateArchive, alternate_sha256: inp.alternateSha256, alternate_differences: inp.alternateDifferences,
      index_fields: inp.indexFields, source_defects: defects,
      transformations: ['display_title←name', 'what_creating←name(prefix)+niche', `visible_scene←${GENERIC_TAGLINE.test(o.tagline) ? 'derived(scenario,framing,props)' : 'tagline'}`, 'where_used←businessMoment', 'benefit←sub(first sentence)', 'dna←extractDNA(original)', `palette←${dna.paletteSource}`],
    },
  };
}

export function galleryEntry(c: CanonicalScene, v: { fidelity: GalleryEntry['fidelity']; medium: string; family: string; hash: string }): GalleryEntry {
  const o = c.original; const colon = o.name.indexOf(':');
  const title = c.dna.assetLabel; void colon;
  return {
    id: c.id, cat: c.category, niche: c.niche, title, what: c.what_creating, see: truncateWords(c.visible_scene, 150), where: truncateWords(c.where_used, 130), benefit: truncateWords(c.benefit, 150),
    asset: c.asset_type, job: c.dna.promise.replace(/ for [A-Z].*$/, ''), aspect: c.aspect_ratio, w: c.dimensions.width, h: c.dimensions.height, intent: c.conversion_intent, stage: c.funnel_stage,
    goal: GOALS.filter(g => g.test(o)).map(g => g.key), fidelity: v.fidelity, medium: v.medium, family: v.family,
    needsPhoto: c.reference_requirements.needs_person_reference || c.reference_requirements.needs_product_reference,
    platforms: c.best_platforms, kw: [...new Set([...c.keywords, ...c.dna.props.map(p => p.toLowerCase()), c.dna.environmentKind, c.dna.subjectKind])].join(' ').slice(0, 400),
    biz: o.businessType, channel: o.channelType, style: o.render, thumb: `thumbs/${c.category}/${c.id}.webp`, hash: v.hash,
  };
}
