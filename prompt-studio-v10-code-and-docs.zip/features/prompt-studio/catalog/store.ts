/**
 * Stored ⇄ canonical. To avoid storing every long field twice, the on-disk record keeps the verbatim `original`
 * plus only the fields that cannot be re-derived from it; `hydrateScene` rebuilds the full typed CanonicalScene.
 */
import { CanonicalSceneSchema, CatalogueIntegrityError, type CanonicalScene } from './schema.ts';

const MIRRORED = ['asset_type', 'business_moment', 'conversion_intent', 'design_principle', 'scenario', 'industry_context', 'framing', 'pose', 'lighting_spec', 'rich_brief', 'render_style', 'background_style', 'original_platform_prompts', 'aspect_ratio', 'niche'] as const;
export type StoredScene = Omit<CanonicalScene, (typeof MIRRORED)[number]>;

export function dehydrateScene(c: CanonicalScene): StoredScene {
  const out: Record<string, unknown> = { ...c };
  for (const k of MIRRORED) delete out[k];
  return out as StoredScene;
}
/** Rebuild and VALIDATE the canonical record. Throws CatalogueIntegrityError — never returns a partial or generic scene. */
export function hydrateScene(stored: unknown, expectedId?: string): CanonicalScene {
  const s = stored as StoredScene | null;
  const o = s?.original;
  if (!s || typeof s !== 'object' || !o || typeof o !== 'object') throw new CatalogueIntegrityError(expectedId ?? '(unknown)', 'record is missing its verbatim original source');
  const full = {
    ...s, niche: o.niche, asset_type: o.asset, business_moment: o.businessMoment, conversion_intent: o.conversionIntent, design_principle: o.designPrinciple,
    scenario: o.scenario, industry_context: o.industryContext, framing: o.framing, pose: o.poseDirection, lighting_spec: o.lightingSpec, rich_brief: o.richBrief,
    render_style: o.render, background_style: o.bg, original_platform_prompts: o.v3?.platforms, aspect_ratio: o.aspect,
  };
  const r = CanonicalSceneSchema.safeParse(full);
  if (!r.success) throw new CatalogueIntegrityError(expectedId ?? String(s.id), 'failed schema validation: ' + r.error.issues.slice(0, 3).map(i => `${i.path.join('.')} ${i.message}`).join('; '));
  if (expectedId && r.data.id !== expectedId) throw new CatalogueIntegrityError(expectedId, `record id mismatch (file contains "${r.data.id}")`);
  return r.data;
}
