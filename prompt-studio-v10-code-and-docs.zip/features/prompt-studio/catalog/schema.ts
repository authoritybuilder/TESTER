/**
 * Canonical catalogue schema.
 *
 * `OriginalScene` is the verbatim per-scene JSON shipped in the nested archives
 * (PROMPTSTUDIO-v9918-FINAL.zip is canonical; see docs/PROMPT_STUDIO_DATA_MAP.md).
 * `CanonicalScene` wraps it — never rewrites it — with typed, mapped fields and provenance.
 */
import { z } from 'zod';

export const SCHEMA_VERSION = '10.0.0';
export const PLATFORM_KEYS = ['claude', 'chatgpt', 'mj', 'flux', 'imagen', 'firefly', 'leonardo', 'sdxl', 'ideogram', 'sora'] as const;
export type PlatformKey = (typeof PLATFORM_KEYS)[number];

const str = z.string();
const nonEmpty = z.string().min(1);

/** The source record, exactly as authored. All 39 keys are required: a missing key is a data-integrity error. */
export const OriginalSceneSchema = z.object({
  id: nonEmpty, name: nonEmpty, displayName: nonEmpty, magneticName: nonEmpty,
  tagline: nonEmpty, promptTitle: nonEmpty, sub: nonEmpty, summary: nonEmpty,
  niche: nonEmpty, asset: nonEmpty, industry: str, channelType: z.enum(['Profession', 'Platform']),
  businessType: str, businessMoment: nonEmpty, aspect: nonEmpty, dimensions: nonEmpty,
  recommendedDimensions: str, bestPlatforms: str, bg: nonEmpty, render: nonEmpty,
  designPrinciple: nonEmpty, conversionIntent: nonEmpty, aolPrimary: str, aolSecondary: str,
  archetype: str, palette: str, industryContext: nonEmpty, scenario: nonEmpty,
  lightingSpec: str, wardrobe: str, framing: nonEmpty, safeZones: nonEmpty, poseDirection: str,
  recipe: nonEmpty, richBrief: nonEmpty, visualDescription: nonEmpty,
  v94_background: str, v94_render: str,
  v3: z.object({
    aspect: nonEmpty, dimensions: nonEmpty, archetype: str, lighting_variant: str,
    platforms: z.object(Object.fromEntries(PLATFORM_KEYS.map(k => [k, nonEmpty])) as Record<PlatformKey, typeof nonEmpty>).strict(),
  }).strict(),
}).strict();
export type OriginalScene = z.infer<typeof OriginalSceneSchema>;

export const ZoneSchema = z.object({
  x: z.number().min(0).max(100), y: z.number().min(0).max(100),
  width: z.number().min(0).max(100), height: z.number().min(0).max(100),
  purpose: z.string().max(160), role: z.string().max(40),
});
export type Zone = z.infer<typeof ZoneSchema>;

export const SUBJECT_KINDS = ['person', 'two-people', 'group', 'hands', 'product', 'flat-lay', 'texture', 'pattern', 'print-typographic', 'environment-only', 'devices'] as const;
export type SubjectKind = (typeof SUBJECT_KINDS)[number];

/** The creative DNA extracted from the source (see compiler/dna.ts). Every field traces to named source fields. */
export const SceneDNASchema = z.object({
  assetLabel: z.string(), promise: z.string(), baseScene: z.string(),
  subjectKind: z.enum(SUBJECT_KINDS),
  subject: z.string(), action: z.string(), environment: z.string(), environmentKind: z.string(),
  props: z.array(z.string()), mood: z.string(),
  framing: z.object({
    raw: z.string(), crop: z.enum(['tight', 'close', 'medium', 'medium-wide', 'wide', 'top-down', 'full-body']),
    subjectShare: z.number().min(0).max(1), subjectSide: z.enum(['left', 'right', 'centre', 'edges', 'top', 'none']),
    secondary: z.string(), secondaryShare: z.number().min(0).max(1),
  }),
  pose: z.string(), poseRaw: z.string(),
  zones: z.array(ZoneSchema), noOverlay: z.boolean(),
  palette: z.array(z.string().regex(/^#[0-9A-F]{6}$/)).min(3), paletteSource: z.enum(['source-hex', 'source-colour-words', 'niche-derived']),
  lightingVariant: z.string(), lightingMood: z.string(),
  person: z.object({ presentation: z.enum(['woman', 'man', 'unspecified']), age: z.string(), wardrobe: z.string() }),
  anchors: z.array(z.string()).min(3).max(7),
  width: z.number().int().positive(), height: z.number().int().positive(),
});
export type SceneDNA = z.infer<typeof SceneDNASchema>;

export const CanonicalSceneSchema = z.object({
  schema_version: z.literal(SCHEMA_VERSION),
  id: nonEmpty, source_version: nonEmpty, category: nonEmpty, niche: nonEmpty,
  // customer-facing (semantic mapping — see DATA_MAP)
  display_title: nonEmpty, what_creating: nonEmpty, visible_scene: nonEmpty, where_used: nonEmpty, benefit: nonEmpty,
  // typed marketing + scene fields
  asset_type: nonEmpty, business_moment: nonEmpty, target_audience: nonEmpty,
  conversion_intent: nonEmpty, design_principle: nonEmpty, funnel_stage: z.enum(['attract', 'engage', 'nurture', 'convert', 'retain']),
  scenario: nonEmpty, industry_context: nonEmpty,
  subject: z.string(), objects: z.array(z.string()), environment: z.string(),
  framing: nonEmpty, pose: z.string(), lighting_spec: z.string(), wardrobe_if_applicable: z.string().nullable(),
  composition: z.string(), copy_safe_zones: z.array(ZoneSchema), aspect_ratio: nonEmpty,
  dimensions: z.object({ width: z.number().int().positive(), height: z.number().int().positive(), label: z.string() }),
  brand_constraints: z.object({ palette: z.array(z.string()), palette_notes: z.string(), archetype: z.string() }),
  reference_requirements: z.object({ needs_person_reference: z.boolean(), needs_product_reference: z.boolean(), note: z.string() }),
  negative_constraints: z.array(z.string()),
  rich_brief: nonEmpty,
  render_style: nonEmpty, background_style: nonEmpty, best_platforms: z.array(z.string()), keywords: z.array(z.string()),
  dna: SceneDNASchema,
  original_template: z.string().nullable(), // the legacy `template` field never existed in source; kept null, never fabricated
  original_platform_prompts: z.record(z.enum(PLATFORM_KEYS), nonEmpty),
  original: OriginalSceneSchema, // verbatim
  provenance: z.object({
    canonical_archive: nonEmpty, canonical_path: nonEmpty, canonical_sha256: z.string().length(64),
    alternate_archive: nonEmpty, alternate_sha256: z.string().length(64),
    alternate_differences: z.record(z.string(), z.string()), // field path -> alternate value (rebuilt ZIP)
    index_fields: z.object({ cat: z.string(), catLabel: z.string(), lighting: z.string(), baseScene: z.string(), keywords: z.array(z.string()) }),
    source_defects: z.array(z.string()),
    transformations: z.array(z.string()),
  }),
});
export type CanonicalScene = z.infer<typeof CanonicalSceneSchema>;

/** Slim gallery index entry (public/data/index.json). */
export interface GalleryEntry {
  id: string; cat: string; niche: string; title: string; what: string; see: string; where: string; benefit: string;
  asset: string; job: string; aspect: string; w: number; h: number; intent: string; stage: string; goal: string[];
  fidelity: 'final-html-asset' | 'composition-concept' | 'photo-required'; medium: string; family: string;
  needsPhoto: boolean; platforms: string[]; kw: string; biz: string; channel: string; style: string; thumb: string; hash: string;
}
export interface GalleryIndex {
  version: string; generatedAt: string; totalScenes: number;
  categories: Record<string, { label: string; count: number; channel: string }>;
  scenes: GalleryEntry[];
}

export class CatalogueIntegrityError extends Error {
  constructor(public readonly sceneId: string, public readonly reason: string) {
    super(`Catalogue integrity error for "${sceneId}": ${reason}`);
    this.name = 'CatalogueIntegrityError';
  }
}
