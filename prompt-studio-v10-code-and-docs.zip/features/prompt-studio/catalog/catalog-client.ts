/**
 * Catalogue service (isomorphic). `loadFullSource` is the ONLY way the app obtains a scene:
 * it resolves the canonical per-scene file by stable id and fails loudly. There is no fallback scene.
 */
import { CatalogueIntegrityError, type CanonicalScene, type GalleryEntry, type GalleryIndex } from './schema.ts';
import { hydrateScene } from './store.ts';

export type Fetcher = (path: string) => Promise<{ ok: boolean; status: number; text: () => Promise<string> }>;
export class SceneLoadError extends Error {
  constructor(public readonly sceneId: string, public readonly code: 'unknown-id' | 'not-found' | 'network' | 'corrupt' | 'integrity', message: string, public readonly recoverable: boolean) { super(message); this.name = 'SceneLoadError'; }
}

export class Catalogue {
  private byId = new Map<string, GalleryEntry>();
  private cache = new Map<string, CanonicalScene>();
  constructor(public readonly index: GalleryIndex, private fetcher: Fetcher, private base = 'data/') {
    for (const s of index.scenes) this.byId.set(s.id, s);
    if (this.byId.size !== index.totalScenes) throw new CatalogueIntegrityError('(index)', `index declares ${index.totalScenes} scenes but contains ${this.byId.size} distinct ids`);
  }
  static async open(fetcher: Fetcher, base = 'data/'): Promise<Catalogue> {
    const r = await fetcher(base + 'index.json');
    if (!r.ok) throw new Error(`Catalogue index unavailable (HTTP ${r.status})`);
    return new Catalogue(JSON.parse(await r.text()) as GalleryIndex, fetcher, base);
  }
  entry(id: string): GalleryEntry | undefined { return this.byId.get(id); }
  get count(): number { return this.byId.size; }

  /** Load, hydrate and validate the complete source for one scene. Never substitutes. */
  async loadFullSource(id: string): Promise<CanonicalScene> {
    const hit = this.cache.get(id); if (hit) return hit;
    const e = this.byId.get(id);
    if (!e) throw new SceneLoadError(id, 'unknown-id', `“${id}” is not a Prompt Studio scene id.`, false);
    let res: Awaited<ReturnType<Fetcher>>;
    try { res = await this.fetcher(`${this.base}scenes/${e.cat}/${id}.json`); }
    catch (err) { throw new SceneLoadError(id, 'network', `Couldn’t reach the catalogue to load “${e.title}”. Check your connection and try again.`, true); }
    if (!res.ok) throw new SceneLoadError(id, 'not-found', `The full brief for “${e.title}” (${id}) is missing from this deployment (HTTP ${res.status}). Nothing was substituted — please report this.`, res.status >= 500);
    let raw: unknown;
    try { raw = JSON.parse(await res.text()); } catch { throw new SceneLoadError(id, 'corrupt', `The brief for “${e.title}” (${id}) is corrupt and could not be read. Nothing was substituted.`, false); }
    let scene: CanonicalScene;
    try { scene = hydrateScene(raw, id); } catch (err) { throw new SceneLoadError(id, 'integrity', (err as Error).message, false); }
    if (this.cache.size > 300) this.cache.delete(this.cache.keys().next().value as string);
    this.cache.set(id, scene);
    return scene;
  }
}
