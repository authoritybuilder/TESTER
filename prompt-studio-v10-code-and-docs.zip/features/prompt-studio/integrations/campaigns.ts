/**
 * Campaign intelligence: offer → complementary assets. Recommends *different* catalogue scenes for each job in a
 * flow (never five crops of one image), explains why in three plain reasons, and proposes meaningful A/B pairs.
 * No performance numbers are ever generated — hypotheses only.
 */
import type { GalleryEntry } from '../catalog/schema.ts';
import { hash53 } from '../shared/util.ts';

export interface FlowStep { key: string; label: string; job: string; asset: RegExp; prefer?: (e: GalleryEntry) => number; size?: { width: number; height: number; placement: string } }
export interface Flow { key: string; label: string; description: string; steps: FlowStep[] }
const S = (width: number, height: number, placement: string): FlowStep['size'] => ({ width, height, placement });

export const FLOWS: Flow[] = [
  { key: 'launch', label: 'Launch something', description: 'Teaser → reveal → explanation → proof → call to action', steps: [
    { key: 'teaser', label: 'Teaser', job: 'Open a curiosity gap before the reveal', asset: /Advertising\/Disruption|Video\/Hook|Authority\/Insight|Social\/Carousel|Creator\/BTS|Authenticity/, prefer: e => (e.intent === 'curiosity_gap' || e.intent === 'pattern_interrupt' ? 6 : 0), size: S(1080, 1350, 'Instagram / LinkedIn feed') },
    { key: 'reveal', label: 'Reveal', job: 'Announce the offer with one clear headline', asset: /Launch|Sales\/Hero|Sales\/Programme|Cohort|Stock\/Hero|Advertising\/Hero/, size: S(1920, 1080, 'Sales page hero') },
    { key: 'explain', label: 'Explanation', job: 'Show how it works at a glance', asset: /Methodology|Method|Curriculum|Course\/Module|Education|Consulting\/Delivery/, size: S(1080, 1080, 'Carousel / feed') },
    { key: 'proof', label: 'Proof', job: 'Make room for verified client evidence', asset: /Social Proof|Case Study|Community\/Spotlight/, size: S(1080, 1350, 'Feed / sales page section') },
    { key: 'cta', label: 'Call to action', job: 'Close with the action and any genuine deadline', asset: /Conversion|Sales\/Booking|Bundle|Sales\/High-ticket|Advertising\/Mobile|Email\/Conversion/, size: S(1080, 1920, 'Story / Reel') } ] },
  { key: 'webinar', label: 'Fill a webinar or workshop', description: 'Announcement → reminder → replay', steps: [
    { key: 'announce', label: 'Announcement', job: 'Event name, date and one reason to come', asset: /Sales\/Event|Event\/Invite|Event\/Banner|Live Event|Enterprise\/Workshop/, size: S(1920, 1080, 'Registration page / LinkedIn') },
    { key: 'speaker', label: 'Meet the host', job: 'Establish why you are worth an hour', asset: /Authority\/Speaker|Event\/Speaker|Event\/Keynote|Headshot/, size: S(1080, 1350, 'Feed') },
    { key: 'reminder', label: 'Reminder', job: 'Day-of nudge sized for stories', asset: /Event\/Day-of|Event\/Calendar|Advertising\/Mobile|Video\/Hook/, size: S(1080, 1920, 'Story') },
    { key: 'replay', label: 'Replay', job: 'Keep the session working after the day', asset: /Replay|Video Thumbnail|Video\/Thumbnail|Event\/Follow-up/, size: S(1920, 1080, 'Replay page / YouTube') } ] },
  { key: 'lead-magnet', label: 'Grow my list with a free guide', description: 'Awareness → benefit → sign-up', steps: [
    { key: 'aware', label: 'Awareness', job: 'Name the problem the guide solves', asset: /Authority\/Insight|Social\/Carousel|Authority\/Thought leadership|Content\/Article/, size: S(1080, 1350, 'Feed') },
    { key: 'benefit', label: 'What’s inside', job: 'Show the guide itself', asset: /Lead Magnet|Lead Generation|Workshop\/Materials|Course\/Resource/, size: S(1080, 1080, 'Feed / ad') },
    { key: 'signup', label: 'Sign-up', job: 'One action: get the guide', asset: /Conversion|Advertising\/Banner|Email\/Conversion|Lead Generation/, prefer: e => (e.stage === 'convert' ? 4 : 0), size: S(1200, 628, 'Link preview / ad') } ] },
  { key: 'newsletter', label: 'Promote a newsletter edition', description: 'Email header → social teaser → archive image', steps: [
    { key: 'header', label: 'Email header', job: 'Recognisable masthead at the top of the email', asset: /Email\/Newsletter|Editorial\/Masthead|Email\/Content/, size: S(1200, 400, 'Email header') },
    { key: 'teaser', label: 'Social teaser', job: 'One idea from the edition, made shareable', asset: /Editorial\/Quote|Authority\/Quote|Social\/Quote|Authority\/Insight/, size: S(1080, 1350, 'Feed') },
    { key: 'archive', label: 'Archive / blog image', job: 'Gives the edition a home on your site', asset: /Stock\/Blog Headers|Content\/Article|LinkedIn\/Article/, size: S(1920, 1080, 'Blog header') } ] },
  { key: 'course', label: 'Release a course or module', description: 'Cover → lesson tiles → welcome', steps: [
    { key: 'cover', label: 'Course cover', job: 'What it is and who it is for', asset: /Course\/Sales|Programme\/Cover|Cohort\/Launch|Kajabi|Teachable|Thinkific/, size: S(1920, 1080, 'Course platform') },
    { key: 'module', label: 'Module tile', job: 'A consistent tile for each module', asset: /Course\/Module|Course\/Lesson|Course\/Curriculum/, size: S(1920, 1080, 'Module thumbnail') },
    { key: 'welcome', label: 'Welcome', job: 'First thing a new student sees', asset: /Onboarding|Community\/Welcome|Email\/Onboarding/, size: S(1920, 1080, 'Welcome email / hub') },
    { key: 'bonus', label: 'Bonus', job: 'Makes the extra feel worth having', asset: /Bonus|Course\/Bonus|Course\/Resource/, size: S(1080, 1080, 'Feed / hub') } ] },
  { key: 'podcast', label: 'Promote a podcast episode', description: 'Episode art → quote → clip cover', steps: [
    { key: 'episode', label: 'Episode art', job: 'Title and number, consistent with the show', asset: /Podcast\/Episode|Podcast\/Interview|Show\/Brand/, size: S(1080, 1080, 'Podcast apps / feed') },
    { key: 'quote', label: 'Pull quote', job: 'The line worth sharing', asset: /Authority\/Quote|Editorial\/Quote|Social\/Quote/, size: S(1080, 1350, 'Feed') },
    { key: 'clip', label: 'Clip cover', job: 'Stops the scroll on short video', asset: /Video\/Hook|Video\/Retention|Tiktok|Video\/Reaction/, size: S(1080, 1920, 'Reels / Shorts') } ] },
  { key: 'service', label: 'Sell a service package', description: 'Positioning → process → proof → booking', steps: [
    { key: 'position', label: 'Positioning', job: 'Who you help and how', asset: /Services Page|Consulting\/Service|Sales\/Service|Executive Service/, size: S(1920, 1080, 'Services page') },
    { key: 'process', label: 'Your process', job: 'Make the method visible', asset: /Authority\/Methodology|Authority\/Method|Consulting\/Assessment|Consulting\/Delivery/, size: S(1080, 1080, 'Feed / page section') },
    { key: 'proof', label: 'Proof', job: 'Room for a verified client story', asset: /Case Study|Social Proof/, size: S(1080, 1350, 'Feed') },
    { key: 'book', label: 'Book a call', job: 'Make the next step feel safe', asset: /Sales\/Booking|Consulting\/Review|Sales\/High-ticket/, size: S(1920, 1080, 'Booking page') } ] },
  { key: 'product', label: 'Show a product', description: 'Hero → detail → in use → collection', steps: [
    { key: 'hero', label: 'Hero', job: 'The product, clearly', asset: /E-commerce\/Hero/, size: S(1080, 1080, 'Product page') },
    { key: 'detail', label: 'Detail', job: 'The feature worth zooming in on', asset: /E-commerce\/(Detail|Tactile|Texture)/, size: S(1080, 1080, 'Product page / feed') },
    { key: 'use', label: 'In use', job: 'Real hands, real context', asset: /E-commerce\/(Lifestyle|Unboxing|Model)/, size: S(1080, 1350, 'Feed') },
    { key: 'range', label: 'The range', job: 'Everything together', asset: /E-commerce\/(Collection|Flat lay)/, size: S(1920, 1080, 'Collection page') } ] },
];

export interface Recommendation { step: FlowStep; scene: GalleryEntry; reasons: string[] }
export interface RecommendContext { cat?: string; biz?: string; exclude?: string[] }

/** Choose one scene per step: on-niche first, then visually distinct (different composition family and aspect mix). */
export function recommendForFlow(all: GalleryEntry[], flow: Flow, ctx: RecommendContext = {}): Recommendation[] {
  const out: Recommendation[] = []; const usedFamilies = new Set<string>(); const usedIds = new Set(ctx.exclude ?? []);
  for (const step of flow.steps) {
    let best: { e: GalleryEntry; s: number } | null = null;
    // hard rule first: a composition family already in the pack is only reused if nothing else fits this step
    const fresh = all.some(e => step.asset.test(e.asset) && !usedIds.has(e.id) && !usedFamilies.has(e.family));
    for (const e of all) {
      if (!step.asset.test(e.asset) || usedIds.has(e.id) || (fresh && usedFamilies.has(e.family))) continue;
      let s = 10 + (step.prefer?.(e) ?? 0);
      if (ctx.cat && e.cat === ctx.cat) s += 12; else if (ctx.cat && e.channel === 'Platform') s += 2;
      if (ctx.biz && e.biz === ctx.biz) s += 2;
      if (usedFamilies.has(e.family)) s -= 8;                                   // never a set of look-alikes
      if (step.size && Math.abs(Math.log((e.w / e.h) / (step.size.width / step.size.height))) < 0.25) s += 4; // native fit for the placement
      if (e.fidelity === 'final-html-asset') s += 1;
      s += (hash53(e.id + flow.key) % 100) / 100;                                // stable tie-break
      if (!best || s > best.s) best = { e, s };
    }
    if (!best) continue;
    const e = best.e; usedIds.add(e.id); usedFamilies.add(e.family);
    out.push({ step, scene: e, reasons: [
      `Does this job: ${step.job.toLowerCase()}.`,
      ctx.cat && e.cat === ctx.cat ? `Written for ${e.niche.toLowerCase()} — the setting and props match your field.` : `Chosen from “${e.niche}” because it fits this step best.`,
      `Different from the rest of the pack: ${e.see.charAt(0).toLowerCase() + e.see.slice(1, 90)}${e.see.length > 90 ? '…' : ''}`,
    ] });
  }
  return out;
}

const MECH: Record<string, string> = { trust_builder: 'credibility', aspirational: 'aspiration', emotional_connection: 'human story', social_proof: 'proof', community_belonging: 'belonging', curiosity_gap: 'curiosity', premium_signaling: 'premium restraint', educational: 'demonstration', fomo_urgency: 'deadline (only if real)', pattern_interrupt: 'pattern break' };
/** A meaningful A/B partner: same niche and placement shape, different persuasion mechanism and composition. */
export function abPartner(all: GalleryEntry[], a: GalleryEntry): { scene: GalleryEntry; hypothesis: string; measure: string } | null {
  let best: { e: GalleryEntry; s: number } | null = null;
  for (const e of all) { if (e.id === a.id || e.intent === a.intent || e.family === a.family) continue; let s = 0; if (e.cat === a.cat) s += 10; if (e.aspect === a.aspect) s += 5; if (e.stage === a.stage) s += 3; s += (hash53(e.id + a.id) % 100) / 100; if (s >= 10 && (!best || s > best.s)) best = { e, s }; }
  if (!best) return null;
  return { scene: best.e, hypothesis: `For this audience, leading with ${MECH[best.e.intent] ?? best.e.intent} (“${best.e.title}”) will earn more of the intended action than leading with ${MECH[a.intent] ?? a.intent} (“${a.title}”).`, measure: 'Run both to comparable audiences for the same period and compare the one action you care about (clicks to the page, sign-ups or enquiries). Prompt Studio does not track results; record them in your ad or email platform.' };
}
