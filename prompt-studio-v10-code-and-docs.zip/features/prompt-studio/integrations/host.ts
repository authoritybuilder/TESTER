/**
 * Host (parent SaaS) contract. Prompt Studio never owns auth, tenancy, brand kit, billing or the asset library —
 * it consumes them through this interface. `server/dev-host.ts` is a file-backed stand-in used ONLY for the
 * standalone migration preview and tests; Authority Builder Studio supplies the real implementation.
 */
import type { BrandContext } from '../visual-engine/copy.ts';
import type { VisualSceneSpec } from '../visual-engine/scene-schema.ts';

export interface Principal { userId: string; workspaceId: string; role: 'owner' | 'editor' | 'viewer'; workspaces: string[] }
export interface AssetRecord {
  id: string; workspaceId: string; sceneId: string; title: string; status: 'draft' | 'approved'; kind: 'html-visual' | 'composition-concept' | 'customer-version';
  width: number; height: number; format: 'png' | 'webp' | 'jpeg'; imageBytes: number; imageSha256: string; specHash: string; altText: string;
  createdAt: string; updatedAt: string; createdBy: string; version: number; campaignIds: string[]; insertedInto: Array<{ target: InsertTarget; targetId: string; at: string }>;
  rights: Array<{ layerId: string; source: string; note: string }>;
}
export type InsertTarget = 'email-builder' | 'content-planner' | 'project' | 'page-builder';
export interface CampaignRecord { id: string; workspaceId: string; name: string; objective: string; flow: string; assetIds: string[]; hypothesis: string; createdAt: string; createdBy: string }
export interface Entitlements { canRender: boolean; canSave: boolean; rendersPerMinute: number; photoProvider: { connected: boolean; reason: string }; claudeDirection: { connected: boolean; reason: string } }

export interface HostAdapter {
  /** Resolve the signed-in principal from the request, or null (anonymous browsing is allowed; actions are not). */
  authenticate(headers: Record<string, string | string[] | undefined>): Promise<Principal | null>;
  entitlements(p: Principal | null): Promise<Entitlements>;
  brandKit(p: Principal): Promise<BrandContext | null>;
  saveBrandKit?(p: Principal, kit: BrandContext): Promise<void>;
  saveAsset(p: Principal, input: { sceneId: string; title: string; spec: VisualSceneSpec; image: Buffer; format: AssetRecord['format']; html: string; assetId?: string; status?: AssetRecord['status'] }): Promise<AssetRecord>;
  listAssets(p: Principal): Promise<AssetRecord[]>;
  getAsset(p: Principal, id: string): Promise<{ record: AssetRecord; spec: VisualSceneSpec; versions: number[] } | null>;
  getAssetImage(p: Principal, id: string): Promise<{ data: Buffer; format: string } | null>;
  deleteAsset(p: Principal, id: string): Promise<boolean>;
  insertAsset(p: Principal, id: string, target: InsertTarget, targetId: string): Promise<AssetRecord | null>;
  saveCampaign(p: Principal, c: Omit<CampaignRecord, 'id' | 'workspaceId' | 'createdAt' | 'createdBy'>): Promise<CampaignRecord>;
  listCampaigns(p: Principal): Promise<CampaignRecord[]>;
}
export class Forbidden extends Error { constructor(msg = 'Not permitted') { super(msg); this.name = 'Forbidden'; } }
