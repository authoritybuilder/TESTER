import assert from 'node:assert/strict';
import { test } from 'node:test';
import * as ES from '../editor/editor-state.ts';
import { searchScenes } from '../gallery/search.ts';
import { abPartner, FLOWS, recommendForFlow } from '../integrations/campaigns.ts';
import { hashHex, stableStringify } from '../shared/util.ts';
import { renderArtboardHtml } from '../visual-engine/artboard-renderer.ts';
import { ArtDirectionSchema, CreativeDirector, DirectorUnavailable, FaithfulnessSchema, toStructuredOutputSchema, withArtDirection } from '../visual-engine/creative-director.ts';
import { classifyFidelity, planScene } from '../visual-engine/scene-planner.ts';
import { SpecValidationError, validateSpec, type VisualLayer, type VisualSceneSpec } from '../visual-engine/scene-schema.ts';
import { allScenes, BRAND_A, BRAND_B, FIXTURE_IDS, index, sceneById } from './helpers.ts';

const layers = (s: VisualSceneSpec): VisualLayer[] => s.artDirection.layerPlan;
const sig = (s: VisualSceneSpec): string => layers(s).map(l => `${l.type}:${l.type === 'object' ? l.kind : l.type === 'environment' ? l.kind : l.type === 'figure' ? l.pose : ''}@${Math.round(l.box.x / 8)},${Math.round(l.box.y / 8)},${Math.round(l.box.w / 8)}`).join('|');

test('every one of the 4,437 scenes plans to a valid VisualSceneSpec that is traceable and honestly labelled', () => {
  const hashes = new Set<string>(); const families = new Set<string>(); const sigs = new Map<string, string[]>(); let noText = 0;
  for (const s of allScenes()) {
    const spec = planScene(s); validateSpec(spec);
    assert.equal(spec.sceneId, s.id); assert.equal(spec.originalSceneFingerprint, s.provenance.canonical_sha256); assert.ok(spec.scene.distinctnessAnchors.length >= 3);
    const photoSource = /realistic|photo/.test(s.render_style); const isGraphic = ['pattern', 'texture', 'print-typographic'].includes(s.dna.subjectKind);
    if (photoSource && !isGraphic) assert.notEqual(spec.artDirection.previewFidelity, 'final-html-asset', `${s.id}: an illustrated stand-in for a photograph must not be labelled final`);
    for (const l of layers(spec)) if ('copyStatus' in l) assert.notEqual(l.copyStatus, 'source'); // nothing is presented as verified copy
    for (const l of layers(spec)) if (l.type === 'stat') assert.ok(l.verified === false || /^\d{1,2}$/.test(l.value), `${s.id}: unverified statistic shown as fact`);
    if (s.dna.noOverlay) { noText++; assert.equal(layers(spec).filter(l => ['headline', 'text', 'cta', 'badge', 'stat'].includes(l.type)).length, 0, `${s.id}: source says no overlay`); }
    hashes.add(hashHex(stableStringify(spec))); families.add(spec.artDirection.compositionFamily); const k = sig(spec); sigs.set(k, [...(sigs.get(k) ?? []), s.id]);
  }
  assert.equal(hashes.size, 4437, 'no two scenes share a spec'); assert.ok(families.size >= 100, `composition families: ${families.size}`); assert.ok(noText >= 140);
  const dupGeom = [...sigs.values()].filter(g => g.length > 1); const inDup = dupGeom.reduce((a, g) => a + g.length, 0);
  console.log(`    families ${families.size}; distinct layer-geometry signatures ${sigs.size}; scenes sharing a coarse geometry signature ${inDup}`);
  assert.ok(sigs.size > 2600, `coarse geometry signatures: ${sigs.size}`);
});

test('distinctness ledger: anchors from the source are present in the built artboard (fixture of 56)', () => {
  for (const id of FIXTURE_IDS) {
    const s = sceneById(id), spec = planScene(s); const ls = layers(spec); const txt = JSON.stringify(spec).toLowerCase();
    assert.ok(txt.includes(s.dna.assetLabel.toLowerCase()), `${id}: asset label`);
    if (['person', 'two-people'].includes(s.dna.subjectKind)) assert.ok(ls.some(l => l.type === 'figure'), `${id}: subject missing`);
    if (s.dna.subjectKind === 'group') assert.ok(ls.filter(l => l.type === 'figure').length >= 3, `${id}: group`);
    if (s.dna.subjectKind === 'devices') assert.ok(ls.filter(l => l.type === 'frame').length >= 2 && !ls.some(l => l.type === 'figure'));
    if (['texture', 'pattern', 'environment-only', 'product', 'flat-lay'].includes(s.dna.subjectKind)) assert.ok(!ls.some(l => l.type === 'figure'), `${id}: person added to a no-person scene`);
    if (s.dna.framing.secondary === 'framework') assert.ok(ls.some(l => l.type === 'diagram'), `${id}: framework diagram`);
    if (s.dna.framing.secondary === 'second chair' || s.dna.subjectKind === 'two-people') assert.ok(ls.some(l => (l.type === 'object' && l.kind === 'armchair') || (l.type === 'figure' && l.pose === 'seated-client')), `${id}: second chair`);
    const zone = s.dna.zones.find(z => !['ui', 'visual'].includes(z.role)); if (zone && !s.dna.noOverlay) assert.ok(ls.some(l => ['headline', 'text', 'cta', 'stat', 'diagram', 'logo', 'annotation', ...(zone.role === 'body' ? ['shape'] : [])].includes(l.type) && l.box.x >= zone.x - 2 && l.box.x + l.box.w <= zone.x + zone.width + 14), `${id}: nothing placed in the source copy zone`);
  }
});

test('same niche + same brand: two different templates produce different compositions', () => {
  const a = planScene(sceneById('fitness-coaches-001'), { brand: BRAND_A }), b = planScene(sceneById('fitness-coaches-002'), { brand: BRAND_A });
  assert.notEqual(a.artDirection.compositionFamily, b.artDirection.compositionFamily); assert.notEqual(sig(a), sig(b));
  assert.deepEqual(a.artDirection.colourRoles, b.artDirection.colourRoles, 'identical brand kit'); assert.ok(layers(b).some(l => l.type === 'object' && l.kind === 'documents')); assert.ok(layers(a).some(l => l.type === 'cta'));
});

test('brand change keeps the scene: same layers and anchors, different colours and copy; asset palette ≠ app palette', () => {
  const s = sceneById('executive-coaches-009'); const base = planScene(s), a = planScene(s, { brand: BRAND_A }), b = planScene(s, { brand: BRAND_B });
  assert.deepEqual(layers(a).map(l => l.type + l.id), layers(b).map(l => l.type + l.id)); assert.deepEqual(a.scene.distinctnessAnchors, base.scene.distinctnessAnchors);
  assert.equal(a.artDirection.colourRoles.primary, '#0E4D64'); assert.equal(b.artDirection.colourRoles.primary, '#3A2E5C'); assert.notEqual(base.artDirection.colourRoles.primary, a.artDirection.colourRoles.primary);
  for (const sp of [base, a, b]) assert.ok(!/#A0CF5D|#101D15|#314F18/i.test(JSON.stringify(sp.artDirection.colourRoles)), 'Authority Builder app colours are never stamped on customer art');
  assert.equal(a.brand.workspaceId, 'ws_harbour');
});

test('one scene across 1:1, 4:5, 9:16 and 16:9 is re-composed, not cropped: subject, framework and headline all stay on the artboard', () => {
  const s = sceneById('executive-coaches-009');
  for (const [w, h] of [[1080, 1080], [1080, 1350], [1080, 1920], [1920, 1080]] as const) {
    const spec = planScene(s, { target: { width: w, height: h } }); const ls = layers(spec); assert.equal(spec.output.width, w); assert.equal(spec.output.height, h);
    const fig = ls.find(l => l.type === 'figure')!, dia = ls.find(l => l.type === 'diagram')!, head = ls.find(l => l.type === 'headline')!;
    assert.ok(fig && dia && head, `${w}×${h}: anchors present`);
    for (const l of [dia, head]) assert.ok(l.box.x >= -1 && l.box.y >= -1 && l.box.x + l.box.w <= 101 && l.box.y + l.box.h <= 101, `${w}×${h}: ${l.id} off the artboard`);
    const cx = fig.box.x + fig.box.w / 2; assert.ok(cx > 5 && cx < 95 && fig.box.y < 70, `${w}×${h}: subject off the artboard`);
  }
});

test('schema validation fails closed on hostile or malformed specs', () => {
  const good = planScene(sceneById('tiktok-001')); const mut = (f: (s: any) => void): unknown => { const c = JSON.parse(JSON.stringify(good)); f(c); return c; };
  const bad: Array<[string, unknown]> = [
    ['javascript: image src', mut(s => s.artDirection.layerPlan.push({ id: 'x', name: 'x', type: 'image', box: { x: 0, y: 0, w: 10, h: 10 }, src: 'javascript:alert(1)', fit: 'cover', focusX: 50, focusY: 50, mask: 'none', alt: '', rights: { source: 'user-upload', note: '', confirmedByUser: true } }))],
    ['remote image src', mut(s => s.artDirection.layerPlan.push({ id: 'x', name: 'x', type: 'image', box: { x: 0, y: 0, w: 10, h: 10 }, src: 'https://evil.example/a.png', fit: 'cover', focusX: 50, focusY: 50, mask: 'none', alt: '', rights: { source: 'user-upload', note: '', confirmedByUser: true } }))],
    ['svg data url', mut(s => s.artDirection.layerPlan.push({ id: 'x', name: 'x', type: 'image', box: { x: 0, y: 0, w: 10, h: 10 }, src: 'data:image/svg+xml;base64,PHN2Zz48c2NyaXB0PmFsZXJ0KDEpPC9zY3JpcHQ+PC9zdmc+', fit: 'cover', focusX: 50, focusY: 50, mask: 'none', alt: '', rights: { source: 'user-upload', note: '', confirmedByUser: true } }))],
    ['css injection via colour', mut(s => { s.artDirection.colourRoles.primary = 'red;background:url(http://evil.example)'; })],
    ['path data with markup', mut(s => s.artDirection.layerPlan.push({ id: 'p', name: 'p', type: 'path', box: { x: 0, y: 0, w: 10, h: 10 }, viewBox: [10, 10], d: 'M0 0"><script>alert(1)</script>' }))],
    ['unknown layer type', mut(s => s.artDirection.layerPlan.push({ id: 'h', name: 'h', type: 'html', box: { x: 0, y: 0, w: 10, h: 10 }, html: '<script>1</script>' }))],
    ['extra property', mut(s => { s.artDirection.layerPlan[0].onclick = 'alert(1)'; })], ['layer id with markup', mut(s => { s.artDirection.layerPlan[0].id = '"><img>'; })],
    ['duplicate layer ids', mut(s => { s.artDirection.layerPlan[1].id = s.artDirection.layerPlan[0].id; })], ['oversized artboard', mut(s => { s.output.width = 100000; })],
    ['scene id swap to non-id', mut(s => { s.sceneId = '../../etc/passwd'; })], ['too many layers', mut(s => { for (let i = 0; i < 80; i++) s.artDirection.layerPlan.push({ ...s.artDirection.layerPlan[0], id: 'l' + i }); })],
    ['not an object', 'string'], ['null', null],
  ];
  for (const [name, spec] of bad) assert.throws(() => validateSpec(spec), SpecValidationError, name);
});

test('renderer escapes all text and never emits script, handlers or external URLs — for every catalogue scene', () => {
  const payload = '"><script>alert(1)</script><img src=x onerror=alert(2)> {{7*7}} </style><svg onload=alert(3)>';
  const s = sceneById('fitness-coaches-001'); let spec = planScene(s, { brand: { businessName: payload, promise: payload, cta: payload.slice(0, 40), offer: payload } });
  spec = ES.setText(spec, 'headline', payload);
  const { html } = renderArtboardHtml(spec, { fonts: { mode: 'none' }, guides: true });
  assert.ok(!/<script|<img src=x|<svg onload|<\/style><svg/i.test(html), 'no payload markup survived unescaped'); assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;')); assert.equal((html.match(/<style>/g) ?? []).length, 1);
  let checked = 0;
  for (const sc of allScenes()) { if (checked++ % 9) continue; const h = renderArtboardHtml(planScene(sc), { fonts: { mode: 'linked', base: '/fonts/' } }).html; assert.ok(!/<script|javascript:|\son[a-z]+=|<iframe|<object|<embed|@import|url\((?!\/fonts\/|#)/i.test(h.replace(/url\(#[a-z0-9-]+\)/gi, '')), `${sc.id}: active content in compiled HTML`); assert.equal((h.match(/data-artboard="true"/g) ?? []).length, 1); assert.match(h, /Content-Security-Policy" content="default-src 'none'/); }
});

test('editor state: every edit changes the document; undo/redo; user copy survives brand, size and layout changes', () => {
  const s = sceneById('fitness-coaches-001'); const h = new ES.History(planScene(s));
  h.push(ES.setText(h.value, 'headline', 'Strong for the life you actually live')); h.push(ES.moveLayer(h.value, 'headline', 2, 3)); h.push(ES.toggleHidden(h.value, 'kettlebell'));
  const d = ES.duplicateLayer(h.value, 'cta-bar'); h.push(d.spec); h.push(ES.reorderLayer(h.value, d.newId, 'bottom')); h.push(ES.toggleLocked(h.value, 'headline'));
  assert.throws(() => ES.moveLayer(h.value, 'headline', 1, 1), /locked/); assert.equal(h.value.artDirection.layerPlan[0]!.id, d.newId); assert.equal(h.value.provenance.approvalStatus, 'customer-edited');
  for (let i = 0; i < 6; i++) h.undo(); assert.equal(ES.layerText(ES.findLayer(h.value, 'headline')!), 'Your headline goes here'); assert.ok(!h.canUndo);
  for (let i = 0; i < 6; i++) h.redo(); assert.equal(ES.layerText(ES.findLayer(h.value, 'headline')!), 'Strong for the life you actually live'); assert.ok(!h.canRedo);
  let cur = ES.toggleLocked(h.value, 'headline');
  for (const k of ['colour', 'layout', 'editorial', 'relaxed', 'angle', 'header'] as const) { const next = ES.quickAction(k, s, cur, BRAND_A, 0); assert.notEqual(hashHex(stableStringify(next)), hashHex(stableStringify(cur)), `${k} changed the document`); assert.equal(ES.layerText(ES.findLayer(next, 'headline')!), 'Strong for the life you actually live', `${k} kept the customer's copy`); assert.equal(next.sceneId, s.id); cur = next; }
  assert.equal(cur.output.width, 1920); assert.equal(cur.output.height, 600);
  const sized = ES.replan({ scene: s, current: h.value, brand: BRAND_B, size: { width: 1080, height: 1920 }, note: 'story' }); assert.equal(sized.artDirection.colourRoles.primary, '#3A2E5C'); assert.equal(ES.layerText(ES.findLayer(sized, 'headline')!), 'Strong for the life you actually live');
  const px = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  const withPhoto = ES.usePhoto(sized, px, 'test', 'owned'); assert.equal(withPhoto.artDirection.medium, 'photo-composite'); assert.ok(withPhoto.artDirection.layerPlan.filter(l => l.role === 'concept').every(l => l.hidden));
  const restored = ES.removePhoto(withPhoto, { medium: 'html-illustration', fidelity: 'composition-concept' }); assert.ok(restored.artDirection.layerPlan.filter(l => l.role === 'concept').every(l => !l.hidden));
  const car = ES.matchingCarousel(s, h.value, BRAND_A); assert.equal(car.length, 4); assert.equal(new Set(car.map(c => c.artDirection.compositionFamily)).size, 4); assert.ok(car.every(c => c.output.width === 1080 && c.output.height === 1350));
  assert.ok(Array.isArray(ES.contrastWarnings(h.value)));
});

test('intent search finds the right kind of asset; campaign packs are complementary, never look-alikes', () => {
  const all = index().scenes;
  const top = (q: string): string[] => searchScenes(all, { text: q }).slice(0, 12).map(e => e.asset);
  assert.ok(top('promote my webinar').filter(a => /Event|Workshop|Replay|Cohort/.test(a)).length >= 9); assert.ok(top('I need a sales page hero').filter(a => /Hero|Homepage|Programme|Launch/.test(a)).length >= 9);
  assert.ok(top('email header').filter(a => /Email|Masthead|Newsletter|Header|Banner|Channel|Services|About/.test(a)).length >= 9); assert.ok(top('podcast episode').every(a => /Podcast|Show|Series/.test(a))); assert.ok(top('before and after').some(a => /Before After|Case Study|Social Proof/.test(a)));
  assert.equal(searchScenes(all, {}).length, 4437); assert.equal(searchScenes(all, { cat: 'tiktok' }).length, 30); assert.ok(searchScenes(all, { text: 'zzzzqqq' }).length === 0);
  assert.ok(new Set(searchScenes(all, {}).slice(0, 24).map(e => e.cat)).size >= 12, 'first screen is varied');
  for (const f of FLOWS) { const r = recommendForFlow(all, f, { cat: 'fitness-coaches' }); assert.ok(r.length >= 3, f.key); assert.equal(new Set(r.map(x => x.scene.id)).size, r.length); assert.equal(new Set(r.map(x => x.scene.family)).size, r.length, `${f.key}: look-alike compositions in one pack`); for (const x of r) { assert.equal(x.reasons.length, 3); assert.doesNotMatch(x.reasons.join(' '), /\d+%|guarantee|proven to/i); } }
  const ab = abPartner(all, all.find(e => e.id === 'fitness-coaches-001')!)!; assert.ok(ab && ab.scene.intent !== 'trust_builder' && ab.scene.cat === 'fitness-coaches'); assert.match(ab.measure, /does not track results/);
});

test('fidelity + Claude tier: honest labels; structured-output schema is API-safe; no key ⇒ explicit “unavailable”, never a fake result', async () => {
  assert.deepEqual(classifyFidelity(sceneById('ecommerce-001'), false), { fidelity: 'photo-required', medium: 'html-illustration' }); assert.equal(classifyFidelity(sceneById('ecommerce-001'), true).medium, 'photo-composite'); assert.equal(classifyFidelity(sceneById('events-print-153'), false).fidelity, 'final-html-asset');
  const js = JSON.stringify(toStructuredOutputSchema(ArtDirectionSchema)); assert.ok(!/"(maxLength|minLength|maximum|minimum|maxItems|pattern)"/.test(js)); assert.match(js, /"additionalProperties":false/);
  const s = sceneById('fitness-coaches-002'); const none = new CreativeDirector({ apiKey: '' }); delete process.env.ANTHROPIC_API_KEY; assert.equal(none.available, false); await assert.rejects(none.faithfulness(s), DirectorUnavailable);
  const f = { visualIntent: 'strategy session', anchors: [{ anchor: 'documents', sourcePhrase: 'document layer 30%' }, { anchor: 'second seat', sourcePhrase: 'both implied seats' }, { anchor: 'dumbbells', sourcePhrase: 'dumbbells' }], outputMode: 'composition-concept', rejectGeneric: false, reasons: [] };
  const ad = { subjectSide: 'left', crop: 'medium', environmentKind: 'fitness-studio', pose: 'desk-settled', props: [{ kind: 'dumbbells', sourcePhrase: 'dumbbells' }], headlineFont: 'fraunces', copy: [{ zoneIndex: 0, text: 'Add a real client quote here.', status: 'suggested' }], compositionRationale: 'x', whyThisWorks: 'y' };
  const calls: any[] = []; const mock = new CreativeDirector({ apiKey: 'test', model: 'claude-test', transport: async req => { const b = JSON.parse(req.body); calls.push(b); assert.equal(b.output_config.format.type, 'json_schema'); assert.ok(req.headers['x-api-key']); return { status: 200, text: JSON.stringify({ stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify(calls.length === 1 ? f : ad) }], usage: { input_tokens: 10, output_tokens: 5 } }) }; } });
  const pf = await mock.faithfulness(s); FaithfulnessSchema.parse(pf); const pa = await mock.artDirection(s, pf); const directed = withArtDirection(s, pa); const spec = planScene(directed.scene, { brand: { headlineFont: 'fraunces' }, copy: directed.copy });
  assert.equal(spec.sceneId, s.id); assert.ok(spec.artDirection.layerPlan.some(l => l.type === 'figure' && l.pose === 'desk-settled')); assert.equal(mock.usage.calls, 2); assert.match(calls[0].system, /You are the Authority Builder Visual Creative Director/);
  const bad = new CreativeDirector({ apiKey: 'k', model: 'm', transport: async () => ({ status: 200, text: JSON.stringify({ stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify({ ...ad, environmentKind: 'moon-base', props: [{ kind: '<script>', sourcePhrase: 'x' }] }) }] }) }) }); await assert.rejects(bad.artDirection(s, pf as any));
  const refuse = new CreativeDirector({ apiKey: 'k', model: 'm', transport: async () => ({ status: 200, text: JSON.stringify({ stop_reason: 'refusal', content: [] }) }) }); await assert.rejects(refuse.faithfulness(s), /declined/);
  await assert.rejects(mock.artDirection(s, { ...pf, rejectGeneric: true }), /rejected this brief as generic/);
});
