import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { test } from 'node:test';
import { SceneLoadError } from '../catalog/catalog-client.ts';
import { CanonicalSceneSchema, PLATFORM_KEYS } from '../catalog/schema.ts';
import { hydrateScene } from '../catalog/store.ts';
import { parseZones } from '../compiler/dna.ts';
import { allScenes, index, openCatalogue, PUBLIC, ROOT, sceneById } from './helpers.ts';

test('catalogue: exactly 4,437 distinct scenes in 151 categories, counts derived from records', () => {
  const ix = index(); const scenes = allScenes();
  assert.equal(scenes.length, 4437); assert.equal(new Set(scenes.map(s => s.id)).size, 4437);
  assert.equal(ix.totalScenes, 4437); assert.equal(ix.scenes.length, 4437); assert.equal(Object.keys(ix.categories).length, 151);
  assert.equal(Object.values(ix.categories).reduce((a, c) => a + c.count, 0), 4437);
  for (const e of ix.scenes) assert.ok(existsSync(join(PUBLIC, 'data/scenes', e.cat, e.id + '.json')), `missing full source for ${e.id}`);
});

test('catalogue: every record validates, keeps its verbatim original, all 10 platform prompts and a non-empty rich brief', () => {
  for (const s of allScenes()) {
    CanonicalSceneSchema.parse(s);
    assert.equal(s.original.id, s.id); assert.ok(s.rich_brief.length > 400, `${s.id} rich brief too short`);
    for (const k of PLATFORM_KEYS) assert.ok(s.original_platform_prompts[k].length > 50, `${s.id} missing ${k}`);
    assert.equal(s.original_template, null, 'no fabricated template');
    assert.ok(s.dna.anchors.length >= 3 && s.dna.anchors.length <= 7);
    assert.ok(s.display_title && s.what_creating && s.visible_scene && s.where_used && s.benefit);
  }
});

test('catalogue: source checksums match the canonical archive and the stored records', () => {
  const sums = JSON.parse(readFileSync(join(ROOT, 'data/manifests/source-checksums.json'), 'utf8')) as Record<string, { category: string; final: string; rebuilt: string; canonical: string }>;
  assert.equal(Object.keys(sums).length, 4437);
  for (const s of allScenes()) { const c = sums[s.id]!; assert.equal(c.final, s.provenance.canonical_sha256); assert.equal(c.rebuilt, s.provenance.alternate_sha256); assert.equal(createHash('sha256').update(readFileSync(join(PUBLIC, 'data/scenes', s.category, s.id + '.json'))).digest('hex'), c.canonical); }
  const cache = join(ROOT, '.cache/source/final/promptstudio/prompts/tiktok/tiktok-001.json');
  if (existsSync(cache)) assert.equal(createHash('sha256').update(readFileSync(cache)).digest('hex'), sums['tiktok-001']!.final, 'canonical sha is the sha of the FINAL archive file');
});

test('catalogue: the two nested archives differ and the difference is preserved (tiktok-001 tagline)', () => {
  const s = sceneById('tiktok-001');
  assert.match(s.original.tagline, /first-frame visual impact/); // FINAL (extended) is canonical
  const alt = s.provenance.alternate_differences.tagline; assert.ok(alt && alt !== s.original.tagline && alt.length < s.original.tagline.length, 'rebuilt ZIP short tagline preserved');
  assert.ok(allScenes().every(x => 'tagline' in x.provenance.alternate_differences), 'tagline differs in all 4,437');
  const report = JSON.parse(readFileSync(join(ROOT, 'data/reports/import-report.json'), 'utf8')) as { legacyIndexAgreesWith: { final: number; rebuilt: number }; records: { byteIdenticalAcrossArchives: number } };
  assert.equal(report.legacyIndexAgreesWith.final, 4437); assert.equal(report.legacyIndexAgreesWith.rebuilt, 0); assert.equal(report.records.byteIdenticalAcrossArchives, 0);
});

test('catalogue: customer-facing copy is plain language — no camera/lighting jargon, no stale generic taglines', () => {
  const jargon = /\b(f\/\d|\d{2,3}mm|softbox|rim light|key light|ISO \d|bokeh|DSLR|kelvin|\d{4}K)\b/i;
  let derived = 0;
  for (const s of allScenes()) {
    for (const f of [s.what_creating, s.visible_scene, s.benefit]) assert.ok(!jargon.test(f), `${s.id}: jargon in “${f}”`);
    assert.ok(!/styled for your brand and designed for your specific use case/i.test(s.visible_scene), `${s.id}: generic tagline leaked`);
    if (s.provenance.transformations.some(t => t.startsWith('visible_scene←derived'))) derived++;
  }
  assert.equal(derived, 1812);
  const fit = allScenes().filter(s => s.category === 'fitness-coaches'); assert.equal(new Set(fit.map(s => s.visible_scene + '|' + s.where_used)).size, fit.length, 'neighbours read differently');
});

test('catalogue client: a missing, corrupt, mismatched or gutted record is an explicit error — never a substitute scene', async () => {
  const ok = await openCatalogue(); const good = await ok.loadFullSource('fitness-coaches-001'); assert.equal(good.id, 'fitness-coaches-001');
  await assert.rejects(ok.loadFullSource('not-a-scene'), (e: unknown) => e instanceof SceneLoadError && e.code === 'unknown-id');
  for (const [fault, code] of [['missing', 'not-found'], ['corrupt', 'corrupt'], ['wrong-id', 'integrity'], ['gutted', 'integrity'], ['throw', 'network']] as const) {
    const c = await openCatalogue({ 'scenes/fitness-coaches/fitness-coaches-002.json': fault });
    await assert.rejects(c.loadFullSource('fitness-coaches-002'), (e: unknown) => e instanceof SceneLoadError && e.code === code && /fitness|Strategy|catalogue|brief|record/i.test(e.message), `${fault} → ${code}`);
    assert.equal((await c.loadFullSource('fitness-coaches-001')).id, 'fitness-coaches-001', 'other scenes unaffected');
  }
  assert.throws(() => hydrateScene({ id: 'x' }, 'x'), /missing its verbatim original/);
});

test('safe-zone parser: source sentences become correct artboard rectangles', () => {
  const z1 = parseZones('Top 350px for hook text overlay; bottom 250px for play-button + UI', 1080, 1920).zones;
  assert.deepEqual(z1.map(z => [z.y, Math.round(z.height), z.role]), [[0, 18, 'headline'], [86.98, 13, 'ui']]);
  const z2 = parseZones('Right one-third clean for booking-form headline overlay; bottom 100px clear for CTA bar; ensure 1:1 crop works for IG', 1920, 1080).zones;
  assert.equal(z2.length, 2); assert.equal(z2[0]!.x, 66.7); assert.equal(z2[0]!.role, 'headline'); assert.equal(z2[1]!.role, 'cta');
  assert.equal(parseZones('No overlay needed — frame stands alone', 1080, 1350).noOverlay, true);
  assert.equal(parseZones('Reserve left third for retreat name + dates overlay; subject right two-thirds with venue', 1920, 1080).zones.length, 1, 'subject placement is not a copy zone');
  assert.equal(parseZones('Reserve corner for brand mark; product hero in centre or rule-of-thirds', 1080, 1080).zones.length, 1);
});
