/** API tests against the real server: auth, tenancy, validation, exports, persistence. */
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, test } from 'node:test';
import sharp from 'sharp';
import { startServer } from '../../../../server/index.ts';
import * as ES from '../../editor/editor-state.ts';
import { planScene } from '../../visual-engine/scene-planner.ts';
import { FLOWS, recommendForFlow } from '../../integrations/campaigns.ts';
import { BRAND_A, index, sceneById } from '../helpers.ts';

let srv: Awaited<ReturnType<typeof startServer>>; let base = ''; const dir = mkdtempSync(join(tmpdir(), 'ps-api-'));
const H = (tok?: string): Record<string, string> => ({ 'content-type': 'application/json', ...(tok ? { authorization: 'Bearer ' + tok } : {}) });
const A = 'demo-token-harbour', B = 'demo-token-juniper', V = 'demo-token-viewer';
const post = (path: string, body: unknown, tok?: string): Promise<Response> => fetch(base + path, { method: 'POST', headers: H(tok), body: JSON.stringify(body) });
before(async () => { srv = await startServer({ port: 0, quiet: true, dataDir: dir }); base = `http://localhost:${srv.port}`; });
after(async () => { await srv.close(); rmSync(dir, { recursive: true, force: true }); });
const spec = () => ES.setText(planScene(sceneById('fitness-coaches-001'), { brand: BRAND_A }), 'headline', 'Strong for the life you actually live');

test('anonymous users can browse (index, scene JSON, thumbnails) but actions explain what is needed', async () => {
  assert.equal((await fetch(base + '/')).url.endsWith('/studio/prompt-studio/'), true);
  for (const p of ['/studio/prompt-studio/', '/data/index.json', '/data/scenes/tiktok/tiktok-001.json', '/thumbs/tiktok/tiktok-001.webp', '/fonts/anton-latin-400-normal.woff2', '/studio/prompt-studio/app.js']) assert.equal((await fetch(base + p)).status, 200, p);
  const s = await (await fetch(base + '/api/session')).json() as { principal: unknown; entitlements: { photoProvider: { connected: boolean; reason: string } } }; assert.equal(s.principal, null); assert.equal(s.entitlements.photoProvider.connected, false); assert.match(s.entitlements.photoProvider.reason, /No photographic image provider/);
  const r = await post('/api/render', { spec: spec(), format: 'png' }); assert.equal(r.status, 401); assert.match(((await r.json()) as { error: string }).error, /Sign in/);
  assert.equal((await post('/api/render', { spec: spec() }, 'not-a-token')).status, 401);
  const html = await fetch(base + '/studio/prompt-studio/'); assert.match(html.headers.get('content-security-policy') ?? '', /script-src 'self'/); assert.equal(html.headers.get('x-content-type-options'), 'nosniff');
});

test('render API returns real PNG / WebP / JPEG at the artboard size; invalid specs are rejected (422), never rendered', async () => {
  for (const [f, magic] of [['png', '89504e47'], ['webp', '52494646'], ['jpeg', 'ffd8ff']] as const) { const r = await post('/api/render', { spec: spec(), format: f }, A); assert.equal(r.status, 200, f); const b = Buffer.from(await r.arrayBuffer()); assert.ok(b.toString('hex').startsWith(magic), f); const m = await sharp(b).metadata(); assert.equal(m.width, 1920); assert.equal(m.height, 1080); assert.equal(r.headers.get('x-ab-width'), '1920'); }
  const bad = spec() as unknown as { artDirection: { layerPlan: unknown[] } }; bad.artDirection.layerPlan.push({ id: 'x', name: 'x', type: 'image', box: { x: 0, y: 0, w: 10, h: 10 }, src: 'http://169.254.169.254/latest/meta-data', fit: 'cover', focusX: 50, focusY: 50, mask: 'none', alt: '', rights: { source: 'user-upload', note: '', confirmedByUser: true } });
  const r = await post('/api/render', { spec: bad }, A); assert.equal(r.status, 422); assert.equal(((await r.json()) as { code: string }).code, 'invalid-spec');
  assert.equal((await post('/api/render', { spec: { sceneId: 'x' } }, A)).status, 422); assert.equal((await fetch(base + '/api/render', { method: 'POST', headers: H(A), body: '{not json' })).status, 400);
  const big = await fetch(base + '/api/render', { method: 'POST', headers: H(A), body: JSON.stringify({ pad: 'x'.repeat(9.5 * 1024 * 1024) }) }).then(r => r.status, () => 413 /* connection closed by the server while the oversized body was still uploading */); assert.equal(big, 413);
  const html = await post('/api/export/html', { spec: spec() }, A); const t = await html.text(); assert.match(t, /data-artboard="true"/); assert.match(t, /Strong for the life you actually live/); assert.ok(!/<script/i.test(t)); assert.match(t, /font\/woff2;base64/);
});

test('asset library: save → list → reopen → new version; second session of the same workspace sees it; other tenants cannot', async () => {
  const s1 = await post('/api/assets', { spec: spec(), title: 'Booking hero', format: 'png' }, A); assert.equal(s1.status, 201); const { asset } = (await s1.json()) as { asset: { id: string; version: number; workspaceId: string; imageSha256: string; kind: string } }; assert.equal(asset.workspaceId, 'ws_harbour'); assert.equal(asset.version, 1); assert.match(asset.id, /^ast_[A-Za-z0-9_-]{16}$/);
  const list = (await (await fetch(base + '/api/assets', { headers: H(A) })).json()) as { assets: Array<{ id: string }> }; assert.ok(list.assets.some(a => a.id === asset.id));
  const got = (await (await fetch(base + `/api/assets/${asset.id}`, { headers: H(A) })).json()) as { spec: ReturnType<typeof spec>; versions: number[] }; assert.equal(ES.layerText(ES.findLayer(got.spec, 'headline')!), 'Strong for the life you actually live'); assert.deepEqual(got.versions, [1]);
  const img = await fetch(base + `/api/assets/${asset.id}/image`, { headers: H(A) }); assert.equal(img.status, 200); assert.equal((await sharp(Buffer.from(await img.arrayBuffer())).metadata()).width, 1920);
  const v2 = await post('/api/assets', { spec: ES.setText(got.spec, 'headline', 'Second version'), title: 'Booking hero', assetId: asset.id }, A); assert.equal(((await v2.json()) as { asset: { version: number } }).asset.version, 2);
  const old = (await (await fetch(base + `/api/assets/${asset.id}?version=1`, { headers: H(A) })).json()) as { spec: ReturnType<typeof spec>; versions: number[] }; assert.equal(ES.layerText(ES.findLayer(old.spec, 'headline')!), 'Strong for the life you actually live'); assert.deepEqual(old.versions, [1, 2]);
  // cross-tenant: every route answers as if the asset does not exist
  for (const p of [`/api/assets/${asset.id}`, `/api/assets/${asset.id}/image`]) assert.equal((await fetch(base + p, { headers: H(B) })).status, 404, p);
  assert.equal((await fetch(base + `/api/assets/${asset.id}`, { method: 'DELETE', headers: H(B) })).status, 404); assert.equal((await post(`/api/assets/${asset.id}/insert`, { target: 'email-builder' }, B)).status, 404);
  assert.equal(((await (await fetch(base + '/api/assets', { headers: H(B) })).json()) as { assets: unknown[] }).assets.length, 0);
  const hijack = await post('/api/assets', { spec: spec(), title: 'x', assetId: asset.id }, B); const hj = (await hijack.json()) as { asset: { id: string; workspaceId: string } }; assert.notEqual(hj.asset.id, asset.id, 'another tenant cannot overwrite by id'); assert.equal(hj.asset.workspaceId, 'ws_juniper');
  assert.equal((await post('/api/campaigns', { name: 'steal', assetIds: [asset.id] }, B)).status, 403);
  assert.equal((await fetch(base + `/api/assets/..%2F..%2Fws_harbour`, { headers: H(B) })).status, 404);
  // viewer role: can read, cannot write
  assert.equal((await fetch(base + `/api/assets/${asset.id}`, { headers: H(V) })).status, 200); assert.equal((await post('/api/assets', { spec: spec(), title: 'x' }, V)).status, 403); assert.equal((await fetch(base + `/api/assets/${asset.id}`, { method: 'DELETE', headers: H(V) })).status, 403);
  // insert into another module (recorded through the host adapter) + campaign
  const ins = await post(`/api/assets/${asset.id}/insert`, { target: 'email-builder', targetId: 'welcome-sequence-1' }, A); const ij = (await ins.json()) as { asset: { insertedInto: Array<{ target: string }> }; note: string }; assert.equal(ij.asset.insertedInto[0]!.target, 'email-builder'); assert.match(ij.note, /recorded link/);
  const camp = await post('/api/campaigns', { name: 'March cohort', objective: 'fill the cohort', flow: 'launch', assetIds: [asset.id] }, A); assert.equal(camp.status, 201);
  const after2 = (await (await fetch(base + '/api/assets', { headers: H(A) })).json()) as { assets: Array<{ id: string; campaignIds: string[] }> }; assert.equal(after2.assets.find(a => a.id === asset.id)!.campaignIds.length, 1);
  assert.equal((await fetch(base + `/api/assets/${asset.id}`, { method: 'DELETE', headers: H(A) })).status, 200); assert.equal((await fetch(base + `/api/assets/${asset.id}`, { headers: H(A) })).status, 404);
});

test('campaign pack: ≥3 complementary designs export as one ZIP with images, editable sources and a manifest (alt text, checksums, no invented claims)', async () => {
  const recs = recommendForFlow(index().scenes, FLOWS.find(f => f.key === 'service')!, { cat: 'fitness-coaches' }).slice(0, 3); const ids = recs.map(r => r.scene.id); assert.equal(ids.length, 3);
  const items = ids.map((id, i) => { const sc = sceneById(id); const size = [{ width: 1920, height: 1080 }, { width: 1080, height: 1080 }, { width: 1080, height: 1920 }][i]!; return { spec: ES.replan({ scene: sc, current: planScene(sc, { brand: BRAND_A }), brand: BRAND_A, size, note: 'pack' }), name: sc.dna.assetLabel, lighting: sc.dna.lightingVariant }; });
  assert.equal(new Set(items.map(i => i.spec.artDirection.compositionFamily)).size, 3);
  const r = await post('/api/export/pack', { items, format: 'png', campaign: 'Workshop launch' }, A); assert.equal(r.status, 200); const zip = Buffer.from(await r.arrayBuffer()); assert.equal(zip.readUInt32LE(0), 0x04034b50);
  const names: string[] = []; let off = zip.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06])); const count = zip.readUInt16LE(off + 10); off = zip.readUInt32LE(off + 16); let manifest = '';
  for (let i = 0; i < count; i++) { const n = zip.readUInt16LE(off + 28); const name = zip.subarray(off + 46, off + 46 + n).toString(); names.push(name); if (name === 'manifest.json') { const lo = zip.readUInt32LE(off + 42), sz = zip.readUInt32LE(off + 24), ln = zip.readUInt16LE(lo + 26); manifest = zip.subarray(lo + 30 + ln, lo + 30 + ln + sz).toString(); } off += 46 + n; }
  assert.equal(names.filter(n => n.startsWith('images/') && n.endsWith('.png')).length, 3); assert.equal(names.filter(n => n.endsWith('.html')).length, 3); assert.equal(names.filter(n => n.endsWith('.spec.json')).length, 3);
  const m = JSON.parse(manifest) as { workspaceId: string; assets: Array<{ width: number; height: number; altText: string; sha256: string; fidelity: string }> }; assert.equal(m.workspaceId, 'ws_harbour'); assert.deepEqual(m.assets.map(a => `${a.width}x${a.height}`), ['1920x1080', '1080x1080', '1080x1920']); assert.ok(m.assets.every(a => a.altText.length > 20 && /^[0-9a-f]{64}$/.test(a.sha256)));
  assert.doesNotMatch(manifest + JSON.stringify(items.map(i => i.spec.artDirection.layerPlan)), /\d+% (more|increase|uplift)|guarantee|\$\d|5 stars|rated #1/i, 'no invented results, prices or ratings');
});

test('honest capability states: no photo provider and no Claude key are reported as such; rate limit and traversal are enforced', async () => {
  assert.equal((await post('/api/photo/generate', {}, A)).status, 503); const cd = await post('/api/creative-direction', {}, A); assert.equal(cd.status, 503); assert.match(((await cd.json()) as { error: string }).error, /Nothing was generated or charged/);
  for (const p of ['/..%2f..%2fpackage.json', '/data/../../package.json', '/visual/../../package.json', '/%2e%2e/%2e%2e/etc/passwd']) assert.notEqual((await fetch(base + p)).status, 200, p);
  let limited = 0; const small = ES.replan({ scene: sceneById('events-print-153'), current: planScene(sceneById('events-print-153')), size: { width: 400, height: 400 }, note: 'rl' });
  for (let i = 0; i < 34; i++) { const r = await post('/api/render', { spec: small, format: 'webp', scale: 0.5 }, B); if (r.status === 429) limited++; else await r.arrayBuffer(); } assert.ok(limited >= 3, `rate limit engaged (${limited})`);
});
