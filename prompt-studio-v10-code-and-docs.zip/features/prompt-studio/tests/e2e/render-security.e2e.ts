/** Real-browser tests: pixels, determinism, isolation and hostile-content handling. Run with `npm run test:e2e`. */
import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { join } from 'node:path';
import { after, before, test } from 'node:test';
import { chromium, type Browser } from 'playwright';
import sharp from 'sharp';
import * as ES from '../../editor/editor-state.ts';
import { hamming, meanDiff, measureRaster, sha256 } from '../../visual-engine/asset-pipeline.ts';
import { RenderError, RenderWorker, renderArtboard } from '../../visual-engine/render-worker.ts';
import { MAX_FRAGMENT_BYTES, SanitiseError, sanitiseFragment, wrapFragment } from '../../visual-engine/sanitiser.ts';
import { planScene } from '../../visual-engine/scene-planner.ts';
import { BRAND_A, BRAND_B, ROOT, sceneById } from '../helpers.ts';

let w: RenderWorker; let browser: Browser; let canary: ReturnType<typeof createServer>; let canaryPort = 0; const canaryHits: string[] = [];
before(async () => { w = await RenderWorker.launch(); browser = await chromium.launch(); canary = createServer((q, s) => { canaryHits.push(q.url ?? ''); s.end('canary'); }); await new Promise<void>(r => canary.listen(0, r)); canaryPort = (canary.address() as { port: number }).port; });
after(async () => { await w.close(); await browser.close(); canary.close(); });
const doc = (inner: string, css = ''): string => `<!doctype html><html><head><style>${css}</style></head><body><div data-artboard="true" style="width:400px;height:300px;background:#fff">${inner}</div></body></html>`;

test('six lab artboards exist as HTML + spec + PNG + WebP, decode at native size and are mutually different', async () => {
  const m = JSON.parse(readFileSync(join(ROOT, 'examples/lab/manifest.json'), 'utf8')) as { examples: Array<{ sceneId: string; width: number; height: number; compositionFamily: string; files: Record<string, string>; sha256: { png: string } }> };
  assert.equal(m.examples.length, 6); assert.equal(new Set(m.examples.map(e => e.compositionFamily)).size, 6, 'six different composition families');
  const pngs: Buffer[] = [];
  for (const e of m.examples) {
    for (const f of Object.values(e.files)) assert.ok(existsSync(join(ROOT, 'examples', f)), `${f} missing`);
    const png = readFileSync(join(ROOT, 'examples', e.files.png!)); assert.equal(sha256(png), e.sha256.png); const st = await measureRaster(png);
    assert.equal(st.width, e.width); assert.equal(st.height, e.height); assert.equal(st.blank, false); assert.ok(st.distinctColours > 20 && st.stdevLuma > 12, `${e.sceneId} looks empty`);
    const webp = await sharp(readFileSync(join(ROOT, 'examples', e.files.webp!))).metadata(); assert.equal(webp.format, 'webp'); assert.equal(webp.width, e.width);
    const html = readFileSync(join(ROOT, 'examples', e.files.html!), 'utf8'); assert.ok(!/<script|https?:\/\//i.test(html.replace(/xmlns="http:\/\/www\.w3\.org\/[^"]+"/g, '')), `${e.sceneId} html must be self-contained and script-free`);
    pngs.push(png);
  }
  for (let i = 0; i < pngs.length; i++) for (let j = i + 1; j < pngs.length; j++) assert.ok((await meanDiff(pngs[i]!, pngs[j]!)) > 18, `lab ${i} and ${j} look alike`);
});

test('rendering is deterministic, exact-size, font-complete and makes no network requests', async () => {
  const s = sceneById('fitness-coaches-001'); const spec = planScene(s, { brand: BRAND_A });
  const a = await w.render({ spec, lighting: s.dna.lightingVariant, isolate: true }), b = await w.render({ spec, lighting: s.dna.lightingVariant, isolate: true });
  assert.equal(sha256(a.png), sha256(b.png), 'identical input → identical pixels'); const st = await measureRaster(a.png);
  assert.equal(st.width, 1920); assert.equal(st.height, 1080); assert.deepEqual(a.missingFonts, []); assert.deepEqual(a.blockedRequests, []); assert.deepEqual(a.problems, []);
  const half = await w.render({ spec, scale: 0.5 }); assert.equal((await measureRaster(half.png)).width, 960);
  const legacy = await renderArtboard(a.html, 1920, 1080); assert.equal(sha256(legacy), sha256(a.png), 'convenience API renders the same artboard');
});

test('two different scenes → different images; one scene, two brands → same structure, different colour; sizes re-compose', async () => {
  const s1 = sceneById('fitness-coaches-001'), s2 = sceneById('fitness-coaches-002');
  const r1 = await w.render({ spec: planScene(s1, { brand: BRAND_A }), scale: 0.4 }), r2 = await w.render({ spec: planScene(s2, { brand: BRAND_A }), scale: 0.4 }), r1b = await w.render({ spec: planScene(s1, { brand: BRAND_B }), scale: 0.4 });
  assert.ok((await meanDiff(r1.png, r2.png)) > 20, 'same niche + same brand, different template → visibly different'); assert.ok((await meanDiff(r1.png, r1b.png)) > 8, 'brand change is visible');
  const g = async (b: Buffer): Promise<string> => (await measureRaster(await sharp(b).greyscale().normalise().png().toBuffer())).dhash;
  assert.ok(hamming(await g(r1.png), await g(r1b.png)) < hamming(await g(r1.png), await g(r2.png)), 'a re-brand stays structurally closer to itself than to another template');
  for (const [wd, ht] of [[1080, 1080], [1080, 1350], [1080, 1920], [1920, 1080]] as const) { const spec = ES.replan({ scene: s1, current: planScene(s1), size: { width: wd, height: ht }, note: 't' }); const r = await w.render({ spec, scale: 0.4 }); const st = await measureRaster(r.png); assert.equal(st.width, Math.round(wd * 0.4)); assert.equal(st.height, Math.round(ht * 0.4)); assert.equal(st.blank, false); assert.deepEqual(r.overflow.filter(x => x === 'headline'), [], `${wd}×${ht}: headline overflows`); }
});

test('exact text: the customer’s words, long names, currency and non-Latin text render without overflow or failure', async () => {
  const s = sceneById('fitness-coaches-001');
  for (const t of ['Strong for the life you actually live', 'Größe & Stärke — $1,290 AUD · 14 Mar', 'The Extraordinarily Long Business Name Pty Ltd Presents A Workshop', '強くなる。続けられる。']) { const spec = ES.replan({ scene: s, current: ES.setText(planScene(s), 'headline', t), note: 'refit' }); const fitted = ES.setTextSize(spec, 'headline', Math.min(ES.findLayer(spec, 'headline')!.type === 'headline' ? 5 : 5, 5)); const r = await w.render({ spec: fitted, scale: 0.5 }); assert.ok(r.html.includes(t.replace(/&/g, '&amp;')), 'exact text present'); assert.deepEqual(r.overflow.filter(x => x === 'headline'), [], `“${t}” overflows`); assert.equal((await measureRaster(r.png)).blank, false); }
});

test('transparent PNG export works only when asked; photo composites embed the raster', async () => {
  const s = sceneById('linkedin-001'); const px = 'data:image/png;base64,' + (await sharp({ create: { width: 40, height: 50, channels: 3, background: '#C0392B' } }).png().toBuffer()).toString('base64');
  const spec = ES.usePhoto(planScene(s), px, 'red test raster', 'generated in test'); const r = await w.render({ spec, scale: 0.3 }); const { data } = await sharp(r.png).resize(1, 1).raw().toBuffer({ resolveWithObject: true }); assert.ok(data[0]! > data[1]! + 30, 'the red raster dominates the composite');
  const meta = await sharp((await w.renderHtml(doc('<div style="width:100px;height:100px;background:#f00"></div>').replace('background:#fff', ''), 400, 300, { transparent: true })).png).stats(); assert.ok(meta.channels.length === 4 && meta.channels[3]!.min === 0, 'alpha preserved');
});

test('SANDBOX: scripts never run; external, localhost, file: and font/CSS requests are blocked and reported', async () => {
  const marker = join(ROOT, 'package.json');
  const html = doc(`<p data-text="1" id="t">before</p><script>document.getElementById('t').textContent='SCRIPT RAN'</script><img src="http://localhost:${canaryPort}/img.png" alt=""><img src="file://${marker}" alt=""><svg width="10" height="10" onload="document.title='x'"><image href="http://localhost:${canaryPort}/svg.png"/></svg><iframe src="http://localhost:${canaryPort}/frame"></iframe><link rel="stylesheet" href="http://localhost:${canaryPort}/a.css"><form action="http://localhost:${canaryPort}/post"><input name="a"></form>`, `@import url(http://localhost:${canaryPort}/import.css);@font-face{font-family:x;src:url(http://localhost:${canaryPort}/font.woff2)}p{font-family:x;background:url(http://localhost:${canaryPort}/bg.png)}`);
  await assert.rejects(w.renderHtml(html, 400, 300, { isolate: true }), (e: unknown) => e instanceof RenderError && e.code === 'broken-image');
  const noImg = html.replace(/<img[^>]+>/g, ''); const r = await w.renderHtml(noImg, 400, 300, { isolate: true });
  assert.ok(r.blockedRequests.length >= 4, `blocked: ${r.blockedRequests.length}`); assert.deepEqual(canaryHits, [], 'nothing reached the network (no SSRF / exfiltration)');
  const ctx = await browser.newContext({ javaScriptEnabled: false }); const p = await ctx.newPage(); await p.route('**/*', x => (x.request().url().startsWith('data:') ? x.continue() : x.abort())); await p.setContent(noImg); assert.equal(await p.locator('#t').textContent(), 'before', 'script did not execute'); assert.notEqual(await p.title(), 'x'); await ctx.close();
});

test('RENDERER LIMITS: wrong artboard count, oversized rasters, oversized markup and pathological layout fail cleanly', async () => {
  await assert.rejects(w.renderHtml('<html><body><p>no artboard</p></body></html>', 400, 300), (e: unknown) => e instanceof RenderError && e.code === 'artboard-count');
  await assert.rejects(w.renderHtml(doc('') + doc(''), 400, 300), (e: unknown) => e instanceof RenderError && e.code === 'artboard-count');
  await assert.rejects(w.renderHtml(doc(''), 6000, 6000, { scale: 2 }), (e: unknown) => e instanceof RenderError && e.code === 'too-large');
  await assert.rejects(w.renderHtml(doc(''), 99999, 10), (e: unknown) => e instanceof RenderError && e.code === 'bad-dimensions');
  await assert.rejects(w.renderHtml(doc('x'.repeat(12_500_000)), 400, 300), (e: unknown) => e instanceof RenderError && e.code === 'too-large');
  const heavy = doc(Array.from({ length: 60000 }, (_, i) => `<div style="float:left;width:${1 + (i % 7)}px;height:3px;filter:blur(2px)">.</div>`).join('')); const t0 = Date.now();
  await w.renderHtml(heavy, 400, 300, { isolate: true, timeoutMs: 2500 }).then(() => undefined, e => assert.ok(e instanceof RenderError && /timeout|render-failed/.test(e.code)));
  assert.ok(Date.now() - t0 < 20000, 'a long-running layout is bounded by the timeout');
  const ok = await w.renderHtml(doc('<p>still alive</p>'), 400, 300); assert.equal((await measureRaster(ok.png)).width, 400, 'worker survives hostile input');
});

test('SANITISER (expert custom-fragment path): strips or rejects every active-content vector and fails closed', async () => {
  const clean = await sanitiseFragment(browser, '<div style="color:#123456"><svg viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#A0CF5D"/></svg><p>Hello</p></div>');
  assert.match(clean, /<circle/); assert.match(clean, /Hello/);
  const vectors = ['<script>alert(1)</script><p>a</p>', '<img src=x onerror=alert(1)>', '<svg onload=alert(1)><circle r="1"/></svg>', '<svg><foreignObject><iframe src="javascript:alert(1)"></iframe></foreignObject></svg>', '<a href="javascript:alert(1)">x</a>', '<div style="background:url(http://evil.example/x.png)">x</div>', '<style>@import url(http://evil.example/a.css);</style><p>x</p>', '<svg><use href="http://evil.example/a.svg#x"/></svg>', '<svg><image href="http://evil.example/a.png"/></svg>', '<object data="http://evil.example"></object><embed src="http://evil.example">', '<form action="http://evil.example"><input name=x></form>', '<math><mtext><table><mglyph><style><!--</style><img title="--&gt;&lt;img src=1 onerror=alert(1)&gt;">', '<div style="position:fixed;inset:0">overlay</div>', '<svg><animate attributeName="href" values="javascript:alert(1)"/></svg>', '<link rel="stylesheet" href="http://evil.example/a.css">', '<meta http-equiv="refresh" content="0;url=http://evil.example">', '<base href="http://evil.example/">'];
  for (const v of vectors) { let out = ''; try { out = await sanitiseFragment(browser, v); } catch (e) { assert.ok(e instanceof SanitiseError, v); continue; } assert.ok(!/<script|onerror|onload|javascript:|<iframe|<object|<embed|<form|<link|<meta|<base|<use|<image|<img|url\(|@import|foreignObject|position:\s*fixed|<animate|<style/i.test(out), `vector survived: ${v} → ${out}`); }
  await assert.rejects(sanitiseFragment(browser, 'x'.repeat(MAX_FRAGMENT_BYTES + 1)), SanitiseError); await assert.rejects(sanitiseFragment(browser, 42 as unknown as string), SanitiseError);
  const r = await w.renderHtml(wrapFragment(clean, 400, 300), 400, 300, { isolate: true }); assert.equal((await measureRaster(r.png)).blank, false); assert.deepEqual(r.blockedRequests, []);
});
