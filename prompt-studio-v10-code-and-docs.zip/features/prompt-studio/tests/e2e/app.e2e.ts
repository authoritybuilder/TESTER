/** End-to-end UI tests in real Chromium against the real server (gallery, wizard, editor, export, library, campaign, a11y, responsive). */
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { after, before, test } from 'node:test';
import { chromium, type Browser, type BrowserContext, type Page } from 'playwright';
import sharp from 'sharp';
import { startServer } from '../../../../server/index.ts';
import { meanDiff } from '../../visual-engine/asset-pipeline.ts';
import { sceneById } from '../helpers.ts';
const TABLE = sceneById('events-print-153').dimensions;

let srv: Awaited<ReturnType<typeof startServer>>; let browser: Browser; let url = ''; const dir = mkdtempSync(join(tmpdir(), 'ps-ui-')); const dl = mkdtempSync(join(tmpdir(), 'ps-dl-'));
before(async () => { srv = await startServer({ port: 0, quiet: true, dataDir: dir }); url = `http://localhost:${srv.port}/studio/prompt-studio/`; browser = await chromium.launch(); });
after(async () => { await browser.close(); await srv.close(); rmSync(dir, { recursive: true, force: true }); rmSync(dl, { recursive: true, force: true }); });
async function open(opts: { w?: number; h?: number; token?: string; hash?: string; touch?: boolean } = {}): Promise<{ ctx: BrowserContext; page: Page; errors: string[] }> {
  const ctx = await browser.newContext({ viewport: { width: opts.w ?? 1440, height: opts.h ?? 900 }, acceptDownloads: true, hasTouch: !!opts.touch, locale: 'en-AU' }); const page = await ctx.newPage(); const errors: string[] = [];
  page.on('pageerror', e => errors.push(String(e))); page.on('console', m => { if (m.type() === 'error' && !/favicon/.test(m.text())) errors.push(m.text()); });
  if (opts.token) await page.addInitScript(t => sessionStorage.setItem('ab.preview.token', t), opts.token);
  await page.goto(url + (opts.hash ?? '')); return { ctx, page, errors };
}
const frameText = (page: Page): Promise<string> => page.evaluate(() => { const f = [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].find(x => x.style.visibility !== 'hidden'); return f?.srcdoc ?? ''; });

test('first entry: gallery is immediately usable — no overlay, no dialog, no scroll lock, one initialisation, real per-scene thumbnails', async () => {
  const { ctx, page, errors } = await open(); await page.waitForSelector('.ps-card');
  const st = await page.evaluate(() => ({ dialogs: document.querySelectorAll('dialog[open]').length, fixedOverlays: [...document.querySelectorAll('body *')].filter(el => { const c = getComputedStyle(el); const r = el.getBoundingClientRect(); return c.position === 'fixed' && r.width >= innerWidth * 0.9 && r.height >= innerHeight * 0.9; }).length, overflow: getComputedStyle(document.body).overflow + getComputedStyle(document.documentElement).overflow, views: document.querySelectorAll('.ps-view').length, cards: document.querySelectorAll('.ps-card').length, sideHidden: (document.querySelector('.ps-side') as HTMLElement).hidden, title: document.title, count: document.querySelector('.ps-count')?.textContent, h1: document.querySelector('h1')?.textContent }));
  assert.deepEqual([st.dialogs, st.fixedOverlays, st.views, st.sideHidden], [0, 0, 1, true]); assert.ok(!/hidden/.test(st.overflow)); assert.equal(st.cards, 48); assert.match(st.count ?? '', /4,437/); assert.doesNotMatch(st.title + (await page.content()), /3,392|Elite AI Image Prompts/);
  await page.waitForFunction(() => [...document.querySelectorAll<HTMLImageElement>('.ps-card img')].slice(0, 8).every(i => i.complete && i.naturalWidth > 0));
  const thumbs = await page.evaluate(() => [...document.querySelectorAll<HTMLImageElement>('.ps-card')].slice(0, 12).map(c => ({ id: (c as HTMLElement).dataset.sceneId, src: c.querySelector('img')!.getAttribute('src'), alt: c.querySelector('img')!.alt, label: c.querySelector('.ps-fid')!.textContent })));
  for (const t of thumbs) { assert.ok(t.src!.includes(`/${t.id}.webp`), 'thumbnail is addressed by its own stable scene id'); assert.ok(t.alt.length > 20); assert.match(t.label ?? '', /HTML visual|Composition concept|Needs your photo/); }
  assert.equal(new Set(thumbs.map(t => t.src)).size, 12); assert.equal(await page.evaluate(() => document.querySelectorAll('.ps-thumb.is-missing').length), 0);
  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await page.waitForFunction(() => document.querySelectorAll('.ps-card').length > 48); assert.deepEqual(errors, []); await ctx.close();
});

test('optional brand wizard: in-page side panel, all controls work, autosaves, survives navigation and refresh, never blocks browsing', async () => {
  const { ctx, page } = await open(); await page.waitForSelector('.ps-card'); await page.click('[data-open-wizard]');
  assert.equal(await page.evaluate(() => getComputedStyle(document.querySelector('.ps-side')!).position !== 'fixed' && document.querySelectorAll('dialog[open]').length === 0 && document.activeElement?.id === 'wz-businessName'), true, 'panel is in the page flow, focus moved into it, no modal');
  await page.fill('#wz-businessName', 'Tidewater Strength'); await page.fill('#wz-offer', '12-week strength programme'); await page.getByRole('button', { name: 'Next', exact: true }).click(); await page.fill('#wz-promise', 'Strong for the life you actually live'); await page.fill('#wz-cta', 'Book a call');
  await page.getByRole('button', { name: 'Next', exact: true }).click(); await page.locator('#wz-c-primary').fill('#0e4d64'); await page.getByRole('button', { name: 'Skip', exact: true }).click(); assert.match(await page.locator('.ps-steps li[aria-current=step]').textContent() ?? '', /What you’re making/);
  await page.getByRole('button', { name: 'Back', exact: true }).click(); await page.getByRole('button', { name: 'Back', exact: true }).click(); assert.equal(await page.inputValue('#wz-promise'), 'Strong for the life you actually live'); assert.match(await page.locator('.ps-wiz-status').textContent() ?? '', /Draft saved on this device/);
  assert.ok(await page.locator('.ps-card').first().isVisible(), 'gallery stays usable beside the panel'); await page.locator('.ps-card .ps-fav').first().click();
  await page.keyboard.press('Tab'); await page.getByRole('button', { name: 'Close brand panel' }).click(); assert.equal(await page.evaluate(() => (document.querySelector('.ps-side') as HTMLElement).hidden), true);
  await page.reload(); await page.waitForSelector('.ps-card'); assert.equal(await page.evaluate(() => (document.querySelector('.ps-side') as HTMLElement).hidden), true, 'refresh does not re-open or force the wizard'); await page.click('[data-open-wizard]'); assert.equal(await page.inputValue('#wz-businessName'), 'Tidewater Strength');
  await page.getByRole('button', { name: 'Reset only this draft' }).click(); assert.equal(await page.inputValue('#wz-businessName'), ''); assert.equal(await page.locator('.ps-fav[aria-pressed=true]').count(), 1, 'reset touched only the draft');
  await ctx.close();
});

test('search by intent + filters + keyboard: “promote my webinar” finds event assets; a card opens the in-page editor with Enter', async () => {
  const { ctx, page } = await open(); await page.waitForSelector('.ps-card'); await page.fill('#ps-q', 'promote my webinar'); await page.waitForFunction(() => /match/.test(document.querySelector('.ps-count')?.textContent ?? ''));
  const titles = await page.locator('.ps-card h3').allTextContents(); assert.ok(titles.slice(0, 8).filter(t => /Workshop|Event|Keynote|Replay|Webinar|Cohort|Invit|Speaker|Stage|Panel|Launch|Countdown|Reminder|Announcement|Day/i.test(t)).length >= 6, titles.slice(0, 8).join(' | '));
  await page.getByRole('button', { name: 'Filters' }).click(); await page.selectOption('#f-aspect', '16:9'); await page.waitForTimeout(200); assert.ok((await page.locator('.ps-card-for').allTextContents()).every(t => t.endsWith('16:9')));
  await page.fill('#ps-q', 'zzzzqqq'); await page.waitForSelector('.ps-empty'); await page.getByRole('button', { name: 'Show everything' }).click(); await page.waitForSelector('.ps-card');
  await page.locator('.ps-thumb').first().focus(); await page.keyboard.press('Enter'); await page.waitForSelector('.ed-layer'); assert.match(page.url(), /#\/scene\//); assert.equal(await page.locator('dialog[open]').count(), 0); await ctx.close();
});

test('editor: the live preview IS the artboard; text, brand, layers, undo/redo, size and drag all change the real document', async () => {
  const { ctx, page, errors } = await open({ hash: '#/scene/fitness-coaches-001' }); await page.waitForSelector('.ed-layer'); await page.waitForFunction(() => [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].some(f => f.srcdoc.includes('data-artboard')));
  assert.equal(await page.evaluate(() => [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].every(f => f.getAttribute('sandbox') === '')), true, 'preview iframe is fully sandboxed'); assert.match(await page.locator('.ed-note').textContent() ?? '', /layout concept standing in for a photograph/);
  await page.fill('#tx-headline', 'Strong for the life you actually live'); await page.locator('#tx-headline').blur(); await page.waitForFunction(() => [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].some(f => f.style.visibility !== 'hidden' && f.srcdoc.includes('Strong for the life you actually live')));
  await page.getByRole('button', { name: /Undo/ }).click(); await page.waitForFunction(() => [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].some(f => f.style.visibility !== 'hidden' && f.srcdoc.includes('Your headline goes here'))); await page.getByRole('button', { name: /Redo/ }).click(); await page.waitForTimeout(250); assert.match(await frameText(page), /Strong for the life you actually live/);
  await page.locator('.ed-layer', { hasText: 'kettlebell' }).click(); await page.getByRole('button', { name: 'Hide: kettlebell' }).click(); await page.waitForTimeout(200); const before = await frameText(page);
  await page.fill('#ps-change', 'add a notebook, more white space'); await page.getByRole('button', { name: 'Apply change' }).click(); await page.waitForSelector('.ed-diff'); assert.match(await page.locator('.ed-diff').textContent() ?? '', /Added “notebook”/); await page.waitForFunction(b => { const f = [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].find(x => x.style.visibility !== 'hidden'); return !!f && f.srcdoc !== b && /data-layer="added-notebook"/.test(f.srcdoc); }, before);
  // drag the headline with the pointer
  await page.locator('.ed-layer', { hasText: /^HHeadline/ }).first().click().catch(() => undefined); await page.locator('#tx-headline').focus(); const box = (await page.locator('.ed-sel').boundingBox())!; const x0 = await page.evaluate(() => document.querySelector<HTMLElement>('.ed-sel')!.style.left);
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2); await page.mouse.down(); await page.mouse.move(box.x + box.width / 2 - 60, box.y + box.height / 2 + 30, { steps: 5 }); await page.mouse.up(); await page.waitForTimeout(200); assert.notEqual(await page.evaluate(() => document.querySelector<HTMLElement>('.ed-sel')!.style.left), x0, 'drag moved the layer');
  await page.locator('.ed-overlay').focus(); await page.keyboard.press('ArrowRight'); await page.keyboard.press('Control+z'); await page.keyboard.press('Control+z');
  await page.selectOption('select[aria-label="Size and placement"]', 'story'); await page.waitForFunction(() => /width:1080px;height:1920px/.test([...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].find(f => f.style.visibility !== 'hidden')?.srcdoc ?? '')); assert.match(await frameText(page), /Strong for the life you actually live/, 'copy survived the re-compose');
  await page.getByRole('button', { name: 'Keep the concept, change the colour' }).click(); await page.getByRole('tab', { name: 'Exact prompt' }).click(); assert.match(await page.locator('#ps-prompt').textContent() ?? '', /Booking Page Hero for fitness coaches.*medium shot, subject 60% of frame height/s); assert.doesNotMatch(await page.locator('#ps-prompt').textContent() ?? '', /professional of business|Canon EOS/);
  await page.getByRole('tab', { name: 'Scene details' }).click(); assert.match(await page.locator('.ed-dl').textContent() ?? '', /linked to source ✓/); await page.getByRole('tab', { name: 'History' }).click(); assert.ok((await page.locator('.ed-panel ol li').count()) >= 3);
  assert.equal(await page.getByRole('button', { name: 'Generate a photograph' }).isDisabled(), true); assert.match(await page.locator('#photo-why').textContent() ?? '', /Not connected/);
  await page.reload(); await page.waitForSelector('.ed-layer'); await page.waitForFunction(() => [...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].some(f => f.srcdoc.includes('Strong for the life you actually live')), undefined, { timeout: 8000 }); assert.deepEqual(errors, []); await ctx.close();
});

test('export + save + reopen: exported PNG matches the live artboard; saved design reopens on a “second device”; other workspace is denied', async () => {
  const { ctx, page } = await open({ token: 'demo-token-harbour', hash: '#/scene/events-print-153' }); await page.waitForSelector('.ed-layer'); await page.fill('#tx-number', '7'); await page.locator('#tx-number').blur(); await page.waitForTimeout(300);
  const [d1] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export', exact: true }).click()]); const p1 = join(dl, 'a.png'); await d1.saveAs(p1); const meta = await sharp(p1).metadata(); assert.equal(meta.format, 'png'); assert.equal(meta.width, TABLE.width); assert.equal(meta.height, TABLE.height);
  const shot = await page.locator('.ed-wrap').screenshot(); assert.ok((await meanDiff(readFileSync(p1), shot)) < 14, 'the exported image is the artboard the customer was looking at');
  await page.selectOption('select[aria-label="Export format"]', 'webp'); const [d2] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export', exact: true }).click()]); const p2 = join(dl, 'a.webp'); await d2.saveAs(p2); assert.equal((await sharp(p2).metadata()).format, 'webp');
  await page.selectOption('select[aria-label="Export format"]', 'html'); const [d3] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export', exact: true }).click()]); const p3 = join(dl, 'a.html'); await d3.saveAs(p3); const html = readFileSync(p3, 'utf8'); assert.match(html, /data-artboard="true"/); assert.ok(!/<script/i.test(html));
  await page.getByRole('button', { name: 'Save to library' }).click(); await page.waitForFunction(() => /asset=ast_/.test(location.hash)); const assetId = /asset=(ast_[A-Za-z0-9_-]+)/.exec(page.url())![1]!; await ctx.close();
  const second = await open({ token: 'demo-token-harbour', hash: '#/library', w: 1280 }); await second.page.waitForSelector('.ps-card'); assert.match(await second.page.locator('.ps-card h3').first().textContent() ?? '', /Table Number/i);
  await second.page.locator('select[aria-label^="Use"]').first().selectOption('email-builder'); await second.page.waitForFunction(() => /Linked in: email-builder/.test(document.body.textContent ?? ''));
  await second.page.getByRole('link', { name: 'Reopen and edit' }).first().click(); await second.page.waitForSelector('#tx-number'); assert.equal(await second.page.inputValue('#tx-number'), '7', 'editable source reopened, not a flat bitmap'); await second.ctx.close();
  const other = await open({ token: 'demo-token-juniper', hash: `#/scene/events-print-153?asset=${assetId}` }); await other.page.waitForSelector('.ed-layer'); await other.page.waitForSelector('.ps-toast--error'); assert.equal(await other.page.inputValue('#tx-number'), '12', 'another workspace gets the template, never the saved design'); await other.page.goto(url + '#/library'); await other.page.waitForSelector('.ps-empty'); await other.ctx.close();
});

test('signed-out export still works in the browser (no provider, no server render) and explains saving', async () => {
  const { ctx, page } = await open({ hash: '#/scene/events-print-153' }); await page.waitForSelector('.ed-layer'); await page.waitForTimeout(500);
  const [d] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export', exact: true }).click()]); const p = join(dl, 'b.png'); await d.saveAs(p); const m = await sharp(p).metadata(); assert.equal(m.width, TABLE.width); assert.equal(m.height, TABLE.height); const st = await sharp(p).greyscale().stats(); assert.ok(st.channels[0]!.stdev > 5, 'browser-rasterised image is not blank');
  await page.getByRole('button', { name: 'Save to library' }).click(); await page.waitForSelector('.ps-toast'); assert.match(await page.locator('.ps-toast').last().textContent() ?? '', /Sign in to save/); await ctx.close();
});

test('use my photo: rights confirmation is a real dialog; the photo composites into the artboard; removable', async () => {
  const { ctx, page } = await open({ hash: '#/scene/linkedin-001' }); await page.waitForSelector('.ed-layer'); const img = join(dl, 'p.jpg'); await sharp({ create: { width: 600, height: 750, channels: 3, background: '#B03A2E' } }).jpeg().toFile(img);
  await page.setInputFiles('input[type=file]', img); await page.waitForSelector('dialog[open]'); assert.equal(await page.getByRole('button', { name: 'Use photo' }).isDisabled(), true, 'cannot proceed without confirming rights'); await page.check('#ps-confirm-cb'); await page.getByRole('button', { name: 'Use photo' }).click();
  await page.waitForFunction(() => /data:image\/jpeg;base64/.test([...document.querySelectorAll<HTMLIFrameElement>('.ed-frame')].find(f => f.style.visibility !== 'hidden')?.srcdoc ?? '')); assert.equal(await page.locator('.ed-title .ps-chip').textContent(), 'Customer version'); assert.ok(await page.locator('.ed-layer', { hasText: 'Your photo' }).count());
  await page.getByRole('button', { name: 'Remove photo' }).click(); await page.waitForTimeout(250); assert.equal(await page.locator('.ed-title .ps-chip').textContent(), 'Needs your photo'); await ctx.close();
});

test('missing full brief → explicit, distinct error state (no generic substitute); recovers on retry', async () => {
  const { ctx, page } = await open(); await page.waitForSelector('.ps-card'); let fail = true;
  await page.route('**/data/scenes/tiktok/tiktok-001.json', r => (fail ? r.fulfill({ status: 404, body: 'nf' }) : r.continue()));
  await page.goto(url + '#/scene/tiktok-001'); await page.waitForSelector('.ps-error'); const t = await page.locator('.ps-error').textContent() ?? ''; assert.match(t, /missing from this deployment/); assert.match(t, /Nothing has been substituted/); assert.equal(await page.locator('.ed-frame').count(), 0);
  fail = false; await page.goto(url + '#/'); await page.goto(url + '#/scene/tiktok-001'); await page.waitForSelector('.ed-layer'); await ctx.close();
});

test('campaign: offer → ≥3 complementary, visibly different designs → pack built at channel sizes → ZIP downloads', async () => {
  const { ctx, page } = await open({ token: 'demo-token-harbour', hash: '#/campaign' }); await page.waitForSelector('.ps-flow-step'); await page.selectOption('#cp-flow', 'webinar'); await page.selectOption('#cp-cat', 'fitness-coaches'); await page.waitForSelector('.ps-flow-step');
  const steps = await page.locator('.ps-flow-step').count(); assert.ok(steps >= 3); const srcs = await page.locator('.ps-flow-step img').evaluateAll(els => els.map(e => (e as HTMLImageElement).src)); assert.equal(new Set(srcs).size, srcs.length); assert.ok((await page.locator('.ps-reasons li').count()) === steps * 3);
  assert.doesNotMatch(await page.locator('.ps-view').textContent() ?? '', /\d+% (more|higher|increase)|guaranteed/i);
  await page.getByRole('button', { name: /^Build \d+ designs$/ }).click(); await page.waitForFunction(n => new RegExp(`Pack · ${n} designs`).test(document.querySelector('.ps-pack')?.textContent ?? ''), steps, { timeout: 20000 });
  const [d] = await Promise.all([page.waitForEvent('download', { timeout: 60000 }), page.getByRole('button', { name: 'Export pack (ZIP)' }).click()]); const p = join(dl, 'pack.zip'); await d.saveAs(p); const z = readFileSync(p); assert.equal(z.readUInt32LE(0), 0x04034b50); assert.ok(z.includes(Buffer.from('manifest.json'))); assert.ok(z.length > 100_000); await ctx.close();
});

test('accessibility basics + responsive: labels, names, alt text, focus order, contrast tokens; no horizontal scroll at 320 / 390 / 820 / 1440', async () => {
  for (const [w, h] of [[320, 640], [390, 844], [820, 1180], [1440, 900]] as const) {
    for (const hash of ['', '#/scene/tiktok-001', '#/campaign']) {
      const { ctx, page, errors } = await open({ w, h, hash, touch: w < 800 }); await page.waitForSelector(hash.includes('scene') ? '.ed-layer' : hash ? '.ps-flow-step' : '.ps-card'); await page.waitForTimeout(350);
      const a = (await page.evaluate(`(() => { const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }; return { overflowX: document.documentElement.scrollWidth - document.documentElement.clientWidth, imgsNoAlt: [...document.images].filter(i => !i.hasAttribute('alt')).length, unnamed: [...document.querySelectorAll('button,a[href],select,input:not([type=hidden]),textarea')].filter(e => vis(e) && !((e.textContent || '').trim() || e.getAttribute('aria-label') || e.getAttribute('title') || (e.id && document.querySelector('label[for="' + e.id + '"]')) || e.closest('label'))).map(e => e.outerHTML.slice(0, 90)), small: [...document.querySelectorAll('.ps-btn,.ps-goal,.ps-tab,.ed-ic,.ps-fav')].filter(e => vis(e) && (e.getBoundingClientRect().height < 32 || e.getBoundingClientRect().width < 32)).length, h1: document.querySelectorAll('h1').length, lang: document.documentElement.lang }; })()`)) as { overflowX: number; imgsNoAlt: number; unnamed: string[]; small: number; h1: number; lang: string };
      assert.ok(a.overflowX <= 1, `${w}px ${hash || 'gallery'}: horizontal overflow ${a.overflowX}px`); assert.equal(a.imgsNoAlt, 0); assert.deepEqual(a.unnamed, [], `${w}px ${hash}: controls without an accessible name`); assert.equal(a.small, 0, `${w}px ${hash}: touch targets under 32px`); assert.equal(a.h1, 1); assert.equal(a.lang, 'en-AU'); assert.deepEqual(errors, []);
      if (w === 390 && !hash) { await page.click('#ab-menu'); assert.equal(await page.locator('#ab-nav.is-open').count(), 1); await page.click('#ab-menu'); await page.click('[data-open-wizard]'); await page.waitForSelector('#wz-businessName'); await page.locator('#wz-businessName').tap(); await page.keyboard.type('Tap test'); assert.equal(await page.inputValue('#wz-businessName'), 'Tap test'); }
      await ctx.close();
    }
  }
  const css = readFileSync(new URL('../../../../public/app.css', import.meta.url), 'utf8'); const tok = (n: string): string => new RegExp(`--ab-${n}:(#[0-9A-Fa-f]{6})`).exec(css)![1]!;
  const lum = (hx: string): number => { const c = [1, 3, 5].map(i => parseInt(hx.slice(i, i + 2), 16) / 255).map(v => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0]! + 0.7152 * c[1]! + 0.0722 * c[2]!; }; const cr = (a: string, b: string): number => (Math.max(lum(a), lum(b)) + 0.05) / (Math.min(lum(a), lum(b)) + 0.05);
  for (const [fg, bg, min] of [['ink', 'cream', 7], ['ink', 'white', 7], ['muted', 'cream', 4.5], ['muted', 'white', 4.5], ['ink', 'lime', 4.5], ['ink', 'lime-bright', 4.5], ['white', 'dark', 7], ['green', 'white', 4.5], ['green', 'cream', 4.5], ['banner-ink', 'banner', 4.5], ['placeholder', 'white', 4.5], ['orange-ink', 'cream', 4.5], ['ink', 'lime-pale', 4.5], ['ink', 'sage', 4.5], ['deep', 'cream', 4.5], ['field-border', 'white', 3]] as const) assert.ok(cr(tok(fg), tok(bg)) >= min, `${fg} on ${bg}: ${cr(tok(fg), tok(bg)).toFixed(2)} < ${min}`);
  assert.deepEqual([tok('lime'), tok('lime-bright'), tok('lime-pale'), tok('ink'), tok('green'), tok('muted'), tok('cream'), tok('border'), tok('pill-border'), tok('banner'), tok('dark')], ['#A0CF5D', '#B8E452', '#D5EAB8', '#141B15', '#3E6A1F', '#5F6862', '#F5F5F0', '#DDE0D6', '#C9CCC4', '#E6F3E1', '#101D15'], 'chrome uses the colours sampled from the live Authority Builder Studio screen');
  { const { ctx, page } = await open({ w: 1440 }); await page.waitForSelector('.ps-card'); const bg = (sel: string): Promise<string> => page.evaluate(`getComputedStyle(document.querySelector(${JSON.stringify(sel)})).backgroundColor`) as Promise<string>; const col = (sel: string): Promise<string> => page.evaluate(`getComputedStyle(document.querySelector(${JSON.stringify(sel)})).color`) as Promise<string>;
    assert.deepEqual([await bg('body'), await bg('.ab-nav'), await bg('.ab-top'), await bg('.ab-nav-item.is-active'), await bg('.ab-logo'), await bg('.ps-btn--primary'), await bg('.ps-card'), await bg('.ps-invite')], ['rgb(245, 245, 240)', 'rgb(255, 255, 255)', 'rgb(245, 245, 240)', 'rgb(160, 207, 93)', 'rgb(184, 228, 82)', 'rgb(160, 207, 93)', 'rgb(255, 255, 255)', 'rgb(230, 243, 225)'], 'light Studio shell: cream page, white rail and cards, lime active states');
    assert.deepEqual([await col('h1'), await col('.ps-eyebrow'), await col('.ab-nav-item.is-active'), await col('.ps-btn--primary')], ['rgb(20, 27, 21)', 'rgb(62, 106, 31)', 'rgb(20, 27, 21)', 'rgb(20, 27, 21)']);
    assert.equal(await page.evaluate(`[...document.querySelectorAll('.ab-shell *')].filter(e => { const r = e.getBoundingClientRect(); const c = getComputedStyle(e).backgroundColor.match(/\\d+/g); return c && r.width > 300 && r.height > 40 && (+c[0] + +c[1] + +c[2]) < 200 && (c[3] === undefined || +c[3] > 0.5); }).length`), 0, 'no dark bands anywhere in the chrome'); await ctx.close(); } assert.doesNotMatch(css, /#c5a880|#132620|Cormorant|Playfair|wizard-overlay|--ab-dot|#273A21/i, 'legacy gold/serif look and the dark dot-grid bands are gone');
});
