import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { test } from 'node:test';
import { compileScene, jaccard, parseChangeRequest, PROVIDERS, SceneInvariantError, type ProviderKey } from '../compiler/pipeline.ts';
import { allScenes, BRAND_A, BRAND_B, FIXTURE_IDS, ROOT, sceneById } from './helpers.ts';

const P = Object.keys(PROVIDERS) as ProviderKey[];
const legacy = (f: string): Record<string, { prompt: string; hasV3: boolean }> => JSON.parse(readFileSync(join(ROOT, 'features/prompt-studio/tests/fixtures', f), 'utf8')) as Record<string, { prompt: string; hasV3: boolean }>;

test('REGRESSION “everything comes out the same”: recorded legacy output vs the new compiler', () => {
  const dep = legacy('legacy-as-deployed.json'), wp = legacy('legacy-with-prompts-present.json');
  // BEFORE (as deployed, no prompts/ directory): every scene collapses to the generic template — even a product shot.
  for (const id of ['fitness-coaches-001', 'fitness-coaches-002', 'tiktok-001', 'ecommerce-001']) { assert.equal(dep[id]!.hasV3, false); assert.match(dep[id]!.prompt, /professional of business.*Canon EOS R5/s); }
  assert.ok(jaccard(dep['fitness-coaches-001']!.prompt, dep['ecommerce-001']!.prompt) > 0.75, 'legacy: a booking hero and a product shot were ~the same prompt');
  // BEFORE (prompts present): two different assets in one niche were 97% identical.
  assert.ok(jaccard(wp['fitness-coaches-001']!.prompt, wp['fitness-coaches-002']!.prompt) > 0.85);
  // AFTER
  const a = compileScene(sceneById('fitness-coaches-001'), 'mj'), b = compileScene(sceneById('fitness-coaches-002'), 'mj'), e = compileScene(sceneById('ecommerce-001'), 'mj');
  assert.ok(jaccard(a.prompt, b.prompt) < 0.72, `same niche, different job: ${jaccard(a.prompt, b.prompt)}`);
  assert.ok(jaccard(a.prompt, e.prompt) < 0.3, `hero vs product: ${jaccard(a.prompt, e.prompt)}`);
  assert.match(a.prompt, /medium shot, subject 60% of frame height/); assert.match(a.prompt, /Right one-third clean for booking-form headline/);
  assert.match(b.prompt, /wide shot capturing both implied seats and the documents/); assert.match(b.prompt, /testimonial pull-quote/);
  for (const c of [a, b, e]) assert.doesNotMatch(c.prompt, /professional of business|Canon EOS R5|refined aesthetic|\{[A-Za-z_]+\}/);
  assert.doesNotMatch(e.prompt, /wardrobe|natural skin|the expert/i, 'no portrait boilerplate on a product scene');
});

test('all 4,437 scenes × 10 providers compile with anchors intact, within budget, with no unresolved placeholders', () => {
  let n = 0;
  for (const s of allScenes()) for (const p of P) {
    const c = compileScene(s, p); n++;
    assert.equal(c.anchorsMissing.length, 0); assert.ok(c.length <= c.budget, `${s.id}/${p} ${c.length} > ${c.budget}`);
    assert.doesNotMatch(c.prompt, /\{[A-Za-z_]+\}/, `${s.id}/${p} placeholder`); assert.ok(c.prompt.includes(s.dna.assetLabel), `${s.id}/${p} lost its asset label`);
    assert.equal(c.provenance.sourceFingerprint, s.provenance.canonical_sha256);
  }
  assert.equal(n, 44370);
});

test('50+ pairwise fixture: different templates stay structurally and semantically distinct under one brand kit', () => {
  assert.ok(FIXTURE_IDS.length >= 50);
  const compiled = FIXTURE_IDS.map(id => ({ s: sceneById(id), c: compileScene(sceneById(id), 'chatgpt', { brand: BRAND_A }) }));
  let pairs = 0, worst = 0, worstPair = '';
  for (let i = 0; i < compiled.length; i++) for (let j = i + 1; j < compiled.length; j++) {
    const A = compiled[i]!, B = compiled[j]!; pairs++;
    const sim = jaccard(A.c.prompt, B.c.prompt); if (sim > worst) { worst = sim; worstPair = `${A.s.id} ~ ${B.s.id}`; }
    // structural: at least two of framing / safe zones / asset label / subject kind / environment / props differ
    const sameTemplate = A.s.dna.assetLabel === B.s.dna.assetLabel;
    const diffs = [A.s.niche !== B.s.niche, A.s.original.v3.lighting_variant !== B.s.original.v3.lighting_variant, A.s.framing !== B.s.framing, A.s.original.safeZones !== B.s.original.safeZones, A.s.dna.assetLabel !== B.s.dna.assetLabel, A.s.dna.subjectKind !== B.s.dna.subjectKind, A.s.dna.environment !== B.s.dna.environment, A.s.dna.props.join() !== B.s.dna.props.join()].filter(Boolean).length;
    assert.ok(diffs >= (sameTemplate ? 1 : 2), `${A.s.id} vs ${B.s.id}: only ${diffs} structural difference(s)`);
    // different templates must read differently; the same template written for two niches (e.g. two “Social Background” records) legitimately shares its
    // mechanism, so there we require the niche-specific content to differ instead.
    if (!sameTemplate) assert.ok(sim < 0.86, `${A.s.id} vs ${B.s.id} too similar (${sim.toFixed(2)})`);
    else { assert.notEqual(A.c.prompt, B.c.prompt); assert.ok(A.s.niche !== B.s.niche || A.s.framing !== B.s.framing || A.s.original.v3.lighting_variant !== B.s.original.v3.lighting_variant, `${A.s.id} vs ${B.s.id}: same template with no distinguishing source fact`); }
  }
  assert.ok(pairs >= 1225); console.log(`    fixture pairs ${pairs}, highest word-set similarity ${worst.toFixed(2)} (${worstPair})`);
});

test('same asset, two genuinely different businesses: personalised, yet the scene identity is unchanged', () => {
  const s = sceneById('fitness-coaches-002'); const a = compileScene(s, 'claude', { brand: BRAND_A }), b = compileScene(s, 'claude', { brand: BRAND_B });
  assert.match(a.prompt, /Tidewater Strength/); assert.match(b.prompt, /Juniper Ledger/); assert.match(a.prompt, /#0E4D64/); assert.match(b.prompt, /#3A2E5C/);
  for (const c of [a, b]) { assert.match(c.prompt, /wide shot capturing both implied seats and the documents/); assert.match(c.prompt, /modern fitness studio/); assert.equal(c.provenance.brandApplied, true); }
  assert.ok(a.changes.some(x => x.field === 'palette' && x.reversible)); assert.doesNotMatch(a.prompt, /logo|make-?up|camera brand/i, 'brand kit adds no face, logo or camera');
});

test('platform variants are adapted from one canonical scene (syntax differs, anchors identical); video is labelled as video', () => {
  const s = sceneById('meditation-teachers-014'); const out = Object.fromEntries(P.map(p => [p, compileScene(s, p)]));
  assert.match(out.mj!.prompt, /--ar 16:9/); assert.ok(/Negative:/.test(out.sdxl!.prompt) || out.sdxl!.segmentsDropped.includes('negatives'), 'SDXL negative clause present unless dropped whole for length'); assert.match(compileScene(sceneById('events-print-153'), 'sdxl').prompt, /Negative:/); assert.match(out.claude!.prompt, /^Design this visual as an editable HTML/); assert.equal(out.sora!.kind, 'video'); assert.match(out.sora!.prompt, /^Video brief\./); assert.ok(out.sora!.warnings.some(w => /does not generate video/.test(w)));
  for (const p of P) { assert.deepEqual(out[p]!.anchorsPresent, out.claude!.anchorsPresent); assert.doesNotMatch(out[p]!.prompt, /#[a-z]+\b(?<!#[0-9A-Fa-f]{6})|hashtag|caption:/i); }
  assert.ok(new Set(P.map(p => out[p]!.prompt)).size === P.length);
});

test('short budgets: critical scene detail is kept first; segments shorten or drop whole — never mid-sentence', () => {
  for (const id of FIXTURE_IDS) { const c = compileScene(sceneById(id), 'sdxl'); for (const k of ['asset', 'subject', 'framing', 'setting', 'copy']) assert.ok(!c.segmentsDropped.includes(k), `${id}: critical segment ${k} dropped`); assert.doesNotMatch(c.prompt, /\b[a-z]{1,3} 85mm|, 1, 85mm/); }
});

test('user control: precise, reversible edits with a diff; concept lock holds', () => {
  const s = sceneById('fitness-coaches-001');
  const c = compileScene(s, 'chatgpt', { overrides: { changeRequest: 'remove the kettlebell, add a foam roller. more negative space', purpose: 'leads' } });
  assert.doesNotMatch(c.prompt, /kettlebell/); assert.match(c.prompt, /foam roller/); assert.match(c.prompt, /Increase negative space/); assert.match(c.prompt, /earn an enquiry or sign-up/);
  assert.ok(c.changes.length >= 3 && c.changes.every(x => x.reversible)); assert.equal(c.provenance.conceptLocked, true);
  const locked = compileScene(s, 'chatgpt', { overrides: { changeRequest: 'make it a completely different scene instead, set it in a beach bar' } });
  assert.ok(locked.warnings.some(w => /changes the underlying concept/.test(w))); assert.match(locked.prompt, /modern fitness studio/, 'locked concept keeps the source setting');
  const unlocked = compileScene(s, 'chatgpt', { overrides: { conceptLocked: false, scene: { environment: 'a beach bar at dusk' } } }); assert.match(unlocked.prompt, /Setting: a beach bar at dusk/);
  const product = compileScene(sceneById('ecommerce-001'), 'chatgpt', { overrides: { scene: { subject: 'a smiling person holding it' } } }); assert.ok(product.warnings.some(w => /Adding a person changes this concept/.test(w)));
  assert.deepEqual(parseChangeRequest('').overrides, {}); assert.equal(parseChangeRequest('make it more editorial').overrides.direction?.style, 'editorial');
});

test('invariants: a scene stripped of its brief cannot compile (data-integrity error, not a generic fallback)', () => {
  const s = JSON.parse(JSON.stringify(sceneById('tiktok-001'))) as ReturnType<typeof sceneById>; (s.original as { richBrief?: string }).richBrief = '';
  assert.throws(() => compileScene(s, 'chatgpt'), SceneInvariantError);
  assert.throws(() => compileScene(sceneById('tiktok-001'), 'dalle' as ProviderKey), /Unknown provider/);
});
