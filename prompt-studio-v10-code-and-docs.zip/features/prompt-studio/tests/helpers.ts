import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Catalogue, type Fetcher } from '../catalog/catalog-client.ts';
import type { CanonicalScene, GalleryIndex } from '../catalog/schema.ts';
import { hydrateScene } from '../catalog/store.ts';

export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
export const PUBLIC = join(ROOT, 'public');
export const index = (): GalleryIndex => JSON.parse(readFileSync(join(PUBLIC, 'data/index.json'), 'utf8')) as GalleryIndex;
let all: CanonicalScene[] | null = null;
/** Every canonical scene, hydrated and validated (cached for the test process). */
export function allScenes(): CanonicalScene[] {
  if (all) return all; all = [];
  for (const cat of readdirSync(join(PUBLIC, 'data/scenes'))) for (const f of readdirSync(join(PUBLIC, 'data/scenes', cat))) all.push(hydrateScene(JSON.parse(readFileSync(join(PUBLIC, 'data/scenes', cat, f), 'utf8')), f.slice(0, -5)));
  return all;
}
export const sceneById = (id: string): CanonicalScene => { const s = allScenes().find(x => x.id === id); if (!s) throw new Error('no scene ' + id); return s; };
/** File-backed fetcher with optional fault injection, used to test the catalogue client. */
export function fileFetcher(faults: Record<string, 'missing' | 'corrupt' | 'throw' | 'wrong-id' | 'gutted'> = {}): Fetcher {
  return async path => {
    const fault = Object.entries(faults).find(([k]) => path.includes(k))?.[1];
    if (fault === 'throw') throw new Error('network down');
    const f = join(PUBLIC, path);
    if (fault === 'missing' || !existsSync(f)) return { ok: false, status: 404, text: async () => 'not found' };
    let text = readFileSync(f, 'utf8');
    if (fault === 'corrupt') text = text.slice(0, 200);
    if (fault === 'wrong-id') text = text.replace(/"id":"[^"]+"/g, '"id":"someone-else-001"');
    if (fault === 'gutted') { const o = JSON.parse(text) as { original: Record<string, unknown> }; delete o.original.richBrief; delete o.original.v3; text = JSON.stringify(o); }
    return { ok: true, status: 200, text: async () => text };
  };
}
export const openCatalogue = (faults?: Parameters<typeof fileFetcher>[0]): Promise<Catalogue> => Catalogue.open(fileFetcher(faults));

/** 56 deliberately chosen templates for the cross-scene regression fixture (see tests/fixtures/README.md). */
export const FIXTURE_IDS = [
  // same niche + same brand kit, different jobs
  'fitness-coaches-001', 'fitness-coaches-002', 'fitness-coaches-003', 'fitness-coaches-004', 'fitness-coaches-005', 'fitness-coaches-009', 'fitness-coaches-012', 'fitness-coaches-014',
  'executive-coaches-003', 'executive-coaches-009', 'nutrition-coaches-012', 'meditation-teachers-014', 'automation-consultants-009', 'brand-consultants-019', 'no-code-consultants-001', 'marriage-coaches-015',
  // hero vs feed pattern-break vs product vs diagram vs webinar/course cover
  'abp-hero-image-author-coaches-0011', 'tiktok-002', 'ecommerce-001', 'academic-coaches-009', 'academic-coaches-004', 'linkedin-009', 'skool-035', 'kajabi-welcome-sequence-hero-008',
  // platform, print, texture, pattern, devices, environment-only, flat-lay, hands, group, two-people
  'tiktok-001', 'youtube-023', 'youtube-038', 'lifestyle-057', 'lifestyle-121', 'lifestyle-164', 'events-print-004', 'events-print-016', 'events-print-105', 'events-print-153',
  'abp-social-background-actor-coaches-0389', 'abp-social-background-breakthrough-coaches-0401', 'abp-product-mockup-time-management-coaches-0760', 'abp-workspace-public-speaking-coaches-0863', 'abp-lifestyle-shot-newsletter-creators-0593', 'abp-celebration-membership-creators-0966',
  'ecommerce-005', 'ecommerce-008', 'ecommerce-063', 'ecommerce-066', 'ecommerce-115', 'ecommerce-117', 'linkedin-001', 'linkedin-068', 'facebook-019', 'facebook-023',
  'website-homepage-022', 'website-about-018', 'thinkific-community-cover-010', 'teachable-author-bio-image-011', 'weight-loss-coaches-005', 'speaker-coaches-013',
] as const;
export const BRAND_A = { workspaceId: 'ws_harbour', businessName: 'Tidewater Strength', offer: '12-week strength programme', audience: 'women over 40 returning to training', promise: 'Strong for the life you actually live', cta: 'Book a call', palette: { primary: '#0E4D64', secondary: '#F2B5A0', accent: '#F26B38', light: '#FBF7F2', dark: '#10222B' } } as const;
export const BRAND_B = { workspaceId: 'ws_juniper', businessName: 'Juniper Ledger', offer: 'Bookkeeping clean-up sprint', audience: 'sole traders behind on their books', promise: 'Tidy books in thirty days', cta: 'Get the checklist', palette: { primary: '#3A2E5C', secondary: '#D9D2F0', accent: '#C8A23A', light: '#FAF8F3', dark: '#17122A' } } as const;
