/**
 * Editor state: every edit changes the actual VisualSceneSpec (the document that is rendered and exported) —
 * never a prompt string. Pure functions + a bounded undo/redo history; no DOM. Used by the in-page editor and by tests.
 */
import type { CanonicalScene } from '../catalog/schema.ts';
import { clamp, darken, lighten, round } from '../shared/util.ts';
import type { BrandContext } from '../visual-engine/copy.ts';
import { planScene, type PlanOptions } from '../visual-engine/scene-planner.ts';
import { validateSpec, type VisualLayer, type VisualSceneSpec } from '../visual-engine/scene-schema.ts';

export const SIZE_PRESETS = [
  { key: 'native', label: 'Original size', width: 0, height: 0, placement: '' },
  { key: 'square', label: 'Square post · 1080×1080', width: 1080, height: 1080, placement: 'Instagram / Facebook / LinkedIn feed' },
  { key: 'portrait', label: 'Portrait post · 1080×1350', width: 1080, height: 1350, placement: 'Instagram / LinkedIn feed (4:5)' },
  { key: 'story', label: 'Story / Reel cover · 1080×1920', width: 1080, height: 1920, placement: 'Stories, Reels, TikTok, Shorts (9:16)' },
  { key: 'wide', label: 'Widescreen · 1920×1080', width: 1920, height: 1080, placement: 'YouTube thumbnail, slide, page hero (16:9)' },
  { key: 'link', label: 'Link preview · 1200×628', width: 1200, height: 628, placement: 'LinkedIn / Facebook link preview' },
  { key: 'email', label: 'Email header · 1200×400', width: 1200, height: 400, placement: 'Email header (3:1)' },
  { key: 'web', label: 'Website header · 1920×600', width: 1920, height: 600, placement: 'Website header (16:5)' },
  { key: 'pin', label: 'Pinterest pin · 1000×1500', width: 1000, height: 1500, placement: 'Pinterest (2:3)' },
] as const;
export type SizeKey = (typeof SIZE_PRESETS)[number]['key'];

export class History<T> {
  private past: T[] = []; private future: T[] = [];
  constructor(private present: T, private limit = 60) {}
  get value(): T { return this.present; }
  get canUndo(): boolean { return this.past.length > 0; }
  get canRedo(): boolean { return this.future.length > 0; }
  get depth(): number { return this.past.length; }
  push(v: T): void { this.past.push(this.present); if (this.past.length > this.limit) this.past.shift(); this.present = v; this.future = []; }
  /** Replace the present without creating an undo step (used while dragging). */
  replace(v: T): void { this.present = v; }
  undo(): T { const p = this.past.pop(); if (p !== undefined) { this.future.push(this.present); this.present = p; } return this.present; }
  redo(): T { const f = this.future.pop(); if (f !== undefined) { this.past.push(this.present); this.present = f; } return this.present; }
}

const clone = <T>(v: T): T => JSON.parse(JSON.stringify(v)) as T;
export const TEXT_TYPES = new Set(['headline', 'text', 'badge', 'cta', 'annotation', 'logo']);
export function layerText(l: VisualLayer): string | null { return l.type === 'headline' || l.type === 'text' || l.type === 'badge' || l.type === 'cta' || l.type === 'annotation' || l.type === 'logo' ? l.text : l.type === 'stat' ? l.value : null; }
export const findLayer = (spec: VisualSceneSpec, id: string): VisualLayer | undefined => spec.artDirection.layerPlan.find(l => l.id === id);

function withLayers(spec: VisualSceneSpec, f: (layers: VisualLayer[]) => VisualLayer[] | void, note: string): VisualSceneSpec {
  const next = clone(spec); const r = f(next.artDirection.layerPlan); if (r) next.artDirection.layerPlan = r;
  next.provenance.approvalStatus = 'customer-edited'; next.provenance.changes = [...next.provenance.changes, note.slice(0, 200)].slice(-40);
  return validateSpec(next);
}
function edit(spec: VisualSceneSpec, id: string, note: string, f: (l: VisualLayer) => void, allowLocked = false): VisualSceneSpec {
  return withLayers(spec, ls => { const l = ls.find(x => x.id === id); if (!l) throw new Error(`No layer “${id}”`); if (l.locked && !allowLocked) throw new Error(`“${l.name}” is locked`); f(l); }, note);
}

export function setText(spec: VisualSceneSpec, id: string, text: string): VisualSceneSpec {
  const t = text.replace(/[\u0000-\u0008\u000b-\u001f]/g, '').slice(0, 400);
  return edit(spec, id, `text of ${id} edited`, l => { if (l.type === 'stat') { l.value = t.slice(0, 16); l.copyStatus = 'user'; } else if (TEXT_TYPES.has(l.type)) { (l as { text: string }).text = l.type === 'headline' || l.type === 'text' ? t : t.slice(0, l.type === 'annotation' ? 80 : 40); (l as { copyStatus: string }).copyStatus = 'user'; } else throw new Error('Layer has no editable text'); });
}
export function moveLayer(spec: VisualSceneSpec, id: string, dx: number, dy: number): VisualSceneSpec { return edit(spec, id, `moved ${id}`, l => { l.box.x = round(clamp(l.box.x + dx, -60, 160)); l.box.y = round(clamp(l.box.y + dy, -60, 160)); }); }
export function resizeLayer(spec: VisualSceneSpec, id: string, dw: number, dh: number): VisualSceneSpec { return edit(spec, id, `resized ${id}`, l => { l.box.w = round(clamp(l.box.w + dw, 1, 220)); l.box.h = round(clamp(l.box.h + dh, 1, 220)); }); }
export function setBox(spec: VisualSceneSpec, id: string, box: { x: number; y: number; w: number; h: number }): VisualSceneSpec { return edit(spec, id, `repositioned ${id}`, l => { l.box = { x: round(clamp(box.x, -60, 160)), y: round(clamp(box.y, -60, 160)), w: round(clamp(box.w, 1, 220)), h: round(clamp(box.h, 1, 220)) }; }); }
export function toggleHidden(spec: VisualSceneSpec, id: string): VisualSceneSpec { return edit(spec, id, `visibility of ${id} toggled`, l => { l.hidden = !l.hidden; }, true); }
export function toggleLocked(spec: VisualSceneSpec, id: string): VisualSceneSpec { return edit(spec, id, `lock of ${id} toggled`, l => { l.locked = !l.locked; }, true); }
export function removeLayer(spec: VisualSceneSpec, id: string): VisualSceneSpec { return withLayers(spec, ls => { const l = ls.find(x => x.id === id); if (!l) throw new Error(`No layer “${id}”`); if (l.locked) throw new Error(`“${l.name}” is locked`); if (ls.length <= 1) throw new Error('A design needs at least one layer'); return ls.filter(x => x.id !== id); }, `removed ${id}`); }
export function reorderLayer(spec: VisualSceneSpec, id: string, dir: 'up' | 'down' | 'top' | 'bottom'): VisualSceneSpec {
  return withLayers(spec, ls => { const i = ls.findIndex(x => x.id === id); if (i < 0) throw new Error(`No layer “${id}”`); const [l] = ls.splice(i, 1); const j = dir === 'top' ? ls.length : dir === 'bottom' ? 0 : clamp(i + (dir === 'up' ? 1 : -1), 0, ls.length); ls.splice(j, 0, l!); }, `reordered ${id} ${dir}`);
}
export function duplicateLayer(spec: VisualSceneSpec, id: string): { spec: VisualSceneSpec; newId: string } {
  let newId = '';
  const next = withLayers(spec, ls => { const i = ls.findIndex(x => x.id === id); if (i < 0) throw new Error(`No layer “${id}”`); const c = clone(ls[i]!); let n = 2; const base = id.replace(/-copy(-\d+)?$/, '').slice(0, 30); do { newId = `${base}-copy${n > 2 ? '-' + n : ''}`; n++; } while (ls.some(x => x.id === newId)); c.id = newId; c.name = (c.name + ' copy').slice(0, 60); c.box.x = round(clamp(c.box.x + 3, -60, 160)); c.box.y = round(clamp(c.box.y + 3, -60, 160)); c.locked = false; ls.splice(i + 1, 0, c); }, `duplicated ${id}`);
  return { spec: next, newId };
}
export function setLayerColour(spec: VisualSceneSpec, id: string, colour: string): VisualSceneSpec {
  if (!/^#[0-9a-fA-F]{6}$/.test(colour)) throw new Error('Colour must be #RRGGBB');
  return edit(spec, id, `colour of ${id} changed`, l => { if ('color' in l) (l as { color: string }).color = colour; if (l.type === 'cta' || l.type === 'badge') l.fill = colour; if (l.type === 'shape' && l.fill?.kind === 'solid') l.fill.color = colour; if (l.type === 'background' && l.fill.kind === 'solid') l.fill.color = colour; });
}
export function setTextSize(spec: VisualSceneSpec, id: string, size: number): VisualSceneSpec { return edit(spec, id, `text size of ${id} changed`, l => { if ('size' in l) (l as { size: number }).size = round(clamp(size, 1, 60)); }); }

/** Insert the customer's own photo: the illustrated concept layers are hidden (reversible), never destroyed. */
export function usePhoto(spec: VisualSceneSpec, src: string, alt: string, rightsNote: string): VisualSceneSpec { return finalisePhoto(spec, src, alt, rightsNote); }
function finalisePhoto(spec: VisualSceneSpec, src: string, alt: string, rightsNote: string): VisualSceneSpec {
  const next = clone(spec); const ls = next.artDirection.layerPlan;
  for (const l of ls) if (l.role === 'concept') l.hidden = true;
  const img: VisualLayer = { id: 'your-photo', name: 'Your photo', type: 'image', box: { x: 0, y: 0, w: 100, h: 100 }, src, fit: 'cover', focusX: 50, focusY: 35, mask: 'none', alt: alt.slice(0, 200) || 'Customer-supplied photograph', rights: { source: 'user-upload', note: rightsNote.slice(0, 200), confirmedByUser: true } };
  const i = ls.findIndex(l => l.id === 'your-photo');
  if (i >= 0) { img.box = ls[i]!.box; ls[i] = img; } else { const at = ls.findIndex(l => l.role !== 'concept' && l.type !== 'background'); ls.splice(at < 0 ? ls.length : Math.max(1, at), 0, img); }
  next.artDirection.medium = 'photo-composite'; next.artDirection.previewFidelity = 'final-html-asset'; next.brand.sourceImages = ['user-upload'];
  next.provenance.approvalStatus = 'customer-edited'; next.provenance.changes = [...next.provenance.changes, 'customer photo added; illustrated concept hidden (reversible)'].slice(-40);
  return validateSpec(next);
}
export function removePhoto(spec: VisualSceneSpec, original: { medium: VisualSceneSpec['artDirection']['medium']; fidelity: VisualSceneSpec['artDirection']['previewFidelity'] }): VisualSceneSpec {
  const next = clone(spec); next.artDirection.layerPlan = next.artDirection.layerPlan.filter(l => l.id !== 'your-photo'); for (const l of next.artDirection.layerPlan) if (l.role === 'concept') l.hidden = false;
  next.artDirection.medium = original.medium; next.artDirection.previewFidelity = original.fidelity; next.brand.sourceImages = []; next.provenance.changes = [...next.provenance.changes, 'customer photo removed; illustrated concept restored'].slice(-40);
  return validateSpec(next);
}

/** Text the customer typed, keyed by layer id — carried across re-plans (brand, size, layout) so edits are never lost. */
export function userEdits(spec: VisualSceneSpec): Map<string, string> {
  const m = new Map<string, string>();
  for (const l of spec.artDirection.layerPlan) if ('copyStatus' in l && l.copyStatus === 'user') { const t = layerText(l); if (t !== null) m.set(l.id, t); }
  return m;
}
export interface ReplanInput { scene: CanonicalScene; current: VisualSceneSpec; brand?: BrandContext; size?: { width: number; height: number; placement?: string }; direction?: PlanOptions['direction']; mutate?: (s: CanonicalScene) => CanonicalScene; note: string }
/** Re-compose the same concept (new brand / size / layout) and carry over the customer's copy and photo. */
export function replan(inp: ReplanInput): VisualSceneSpec {
  const scene = inp.mutate ? inp.mutate(clone(inp.scene)) : inp.scene;
  let next = planScene(scene, { brand: inp.brand, target: inp.size, direction: inp.direction });
  const edits = userEdits(inp.current);
  const ls = next.artDirection.layerPlan;
  for (const [id, text] of edits) { const l = ls.find(x => x.id === id); if (!l) continue; if (l.type === 'stat') { l.value = text.slice(0, 16); l.copyStatus = 'user'; } else if (TEXT_TYPES.has(l.type)) { (l as { text: string }).text = text; (l as { copyStatus: string }).copyStatus = 'user'; } }
  const photo = inp.current.artDirection.layerPlan.find(l => l.id === 'your-photo');
  next.provenance.changes = [...inp.current.provenance.changes, inp.note.slice(0, 200)].slice(-40); next.provenance.approvalStatus = 'customer-edited';
  next = validateSpec(next);
  if (photo && photo.type === 'image') next = finalisePhoto(next, photo.src, photo.alt, photo.rights.note);
  return next;
}

// ---------------------------------------------------------------- "Change just this" actions (each edits the document)
export const QUICK_ACTIONS = [
  { key: 'colour', label: 'Keep the concept, change the colour' }, { key: 'layout', label: 'Switch layout, keep copy' }, { key: 'editorial', label: 'Make it more editorial' },
  { key: 'relaxed', label: 'Make it less corporate' }, { key: 'angle', label: 'Create a different visual angle' }, { key: 'header', label: 'Turn this into a website/email header' },
] as const;
export type QuickActionKey = (typeof QUICK_ACTIONS)[number]['key'];

export function quickAction(key: QuickActionKey, scene: CanonicalScene, current: VisualSceneSpec, brand: BrandContext | undefined, step: number): VisualSceneSpec {
  const R = current.artDirection.colourRoles; const size = { width: current.output.width, height: current.output.height, placement: current.output.intendedPlacement };
  switch (key) {
    case 'colour': { // rotate the brand roles: same scene, same layout, different colour emphasis
      const rot = [[R.secondary, R.accent, R.primary], [R.accent, R.primary, R.secondary], [R.primary, R.secondary, R.accent]][step % 3]!;
      return replan({ scene, current, brand: { ...brand, palette: { primary: rot[0]!, secondary: rot[1]!, accent: rot[2]!, light: R.light, dark: R.dark } }, size, note: 'colour emphasis rotated; concept and layout unchanged' });
    }
    case 'layout': return replan({ scene, current, brand, size, note: 'layout mirrored; copy kept', mutate: s => { const f = s.dna.framing; f.subjectSide = f.subjectSide === 'left' ? 'right' : f.subjectSide === 'right' ? 'left' : step % 2 ? 'left' : 'right'; s.dna.zones = s.dna.zones.map(z => ({ ...z, x: round(100 - z.x - z.width) })); return s; } });
    case 'editorial': return replan({ scene, current, brand: { ...brand, headlineFont: 'fraunces' }, size, direction: 'editorial', note: 'editorial type treatment applied' });
    case 'relaxed': return replan({ scene, current, brand: { ...brand, headlineFont: 'fraunces', palette: { primary: lighten(R.primary, 0.12), secondary: lighten(R.secondary, 0.2), accent: R.accent, light: R.light, dark: darken(R.dark, 0) } }, size, note: 'softer, less corporate treatment', mutate: s => { s.dna.person.wardrobe = 'relaxed knit, soft layers'; if (['portrait-direct', 'stage-mic', 'framework-point'].includes(s.dna.pose)) s.dna.pose = 'lean-mug'; return s; } });
    case 'angle': return replan({ scene, current, brand, size, note: 'different visual angle (crop changed)', mutate: s => { const order = ['wide', 'medium', 'close'] as const; const i = order.indexOf(s.dna.framing.crop as (typeof order)[number]); s.dna.framing.crop = order[(i + 1 + (step % 2)) % order.length]!; return s; } });
    case 'header': return replan({ scene, current, brand, size: { width: 1920, height: 600, placement: 'Website / email header (16:5)' }, note: 're-composed as a 1920×600 header' });
  }
}

/** A coherent four-frame carousel from one scene: cover → idea → steps → call to action. Distinct frames, shared system. */
export function matchingCarousel(scene: CanonicalScene, current: VisualSceneSpec, brand?: BrandContext): VisualSceneSpec[] {
  const size = { width: 1080, height: 1350, placement: 'Carousel frame (4:5)' };
  const cover = replan({ scene, current, brand, size, note: 'carousel frame 1: cover' });
  const R = cover.artDirection.colourRoles; const font = cover.artDirection.typography.headline;
  const frame = (n: number, layers: VisualLayer[], note: string): VisualSceneSpec => { const s = clone(cover); s.artDirection.layerPlan = layers; s.artDirection.compositionFamily = `carousel/frame-${n}`; s.artDirection.previewFidelity = 'final-html-asset'; s.artDirection.medium = 'html-graphic'; s.provenance.changes = [note]; s.output.intendedPlacement = `Carousel frame ${n} of 4`; return validateSpec(s); };
  const bg = (c: string): VisualLayer => ({ id: 'bg', name: 'Background', type: 'background', box: { x: 0, y: 0, w: 100, h: 100 }, fill: { kind: 'solid', color: c } });
  const num = (n: number, ink: string): VisualLayer => ({ id: 'frame-number', name: 'Frame number', type: 'text', box: { x: 8, y: 6, w: 30, h: 5 }, text: `0${n} / 04`, font: 'jakarta', weight: 700, size: 2.2, color: ink, align: 'left', lineHeight: 1.2, tracking: 0.12, copyStatus: 'suggested' });
  const two = frame(2, [bg(R.primary), num(2, ink(R.primary)), { id: 'idea', name: 'The one idea', type: 'headline', box: { x: 8, y: 26, w: 84, h: 44 }, text: 'The one idea you want them to remember', font, weight: font === 'jakarta' ? 800 : 600, size: 8, color: ink(R.primary), align: 'left', valign: 'middle', lineHeight: 1.08, copyStatus: 'suggested' }, { id: 'swipe', name: 'Swipe cue', type: 'text', box: { x: 8, y: 88, w: 84, h: 5 }, text: 'Swipe →', font: 'jakarta', weight: 600, size: 2.4, color: ink(R.primary), align: 'right', lineHeight: 1.2, copyStatus: 'suggested' }], 'carousel frame 2: single idea');
  const three = frame(3, [bg(R.light), num(3, R.dark), { id: 'steps-title', name: 'Steps title', type: 'headline', box: { x: 8, y: 14, w: 84, h: 14 }, text: 'How it works', font, weight: font === 'jakarta' ? 800 : 600, size: 6, color: R.dark, align: 'left', valign: 'middle', lineHeight: 1.1, copyStatus: 'suggested' }, { id: 'steps', name: 'Steps (editable)', type: 'diagram', kind: 'list', box: { x: 6, y: 32, w: 88, h: 52 }, nodes: [{ label: 'First step' }, { label: 'Second step' }, { label: 'Third step' }], color: R.primary, color2: R.accent, ink: R.dark, font: 'jakarta', size: 3.4, copyStatus: 'suggested' }], 'carousel frame 3: steps');
  const four = frame(4, [bg(R.dark), num(4, R.light), { id: 'close', name: 'Closing line', type: 'headline', box: { x: 8, y: 28, w: 84, h: 30 }, text: brand?.promise ?? 'Your closing line', font, weight: font === 'jakarta' ? 800 : 600, size: 7.5, color: R.light, align: 'left', valign: 'middle', lineHeight: 1.08, copyStatus: brand?.promise ? 'brand-kit' : 'suggested' }, { id: 'cta', name: 'Call to action', type: 'cta', box: { x: 8, y: 64, w: 46, h: 7 }, text: brand?.cta ?? 'Find out more', fill: R.accent, color: ink(R.accent), font: 'jakarta', size: 2.8, radius: 4, icon: 'arrow', style: 'solid', copyStatus: brand?.cta ? 'brand-kit' : 'suggested' }, { id: 'brand', name: 'Brand mark', type: 'logo', box: { x: 8, y: 86, w: 60, h: 6 }, text: brand?.logoText ?? brand?.businessName ?? 'Your brand', color: R.light, font, size: 3, mark: 'ring', copyStatus: brand?.businessName ? 'brand-kit' : 'suggested' }], 'carousel frame 4: call to action');
  return [cover, two, three, four];
}
const ink = (bg: string): string => { const v = parseInt(bg.slice(1), 16); return (0.299 * ((v >> 16) & 255) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255 > 0.6 ? '#111111' : '#FFFFFF'; };

/** WCAG contrast check for text layers against their most likely backdrop (reported to the customer, never auto-"fixed"). */
export function contrastWarnings(spec: VisualSceneSpec): Array<{ id: string; name: string; ratio: number }> {
  const out: Array<{ id: string; name: string; ratio: number }> = []; const ls = spec.artDirection.layerPlan; const lum = (h: string): number => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0]! + 0.7152 * c[1]! + 0.0722 * c[2]!; };
  ls.forEach((l, i) => {
    if (l.hidden || !(l.type === 'headline' || l.type === 'text')) return;
    let back: string | null = null;
    for (let j = i - 1; j >= 0 && !back; j--) { const b = ls[j]!; if (b.hidden) continue; const covers = b.box.x <= l.box.x + 1 && b.box.y <= l.box.y + 1 && b.box.x + b.box.w >= l.box.x + l.box.w - 1 && b.box.y + b.box.h >= l.box.y + l.box.h - 1; if (!covers) continue; if (b.type === 'shape' && b.fill?.kind === 'solid' && (b.fill.alpha ?? 1) > 0.8) back = b.fill.color; else if (b.type === 'background' && b.fill.kind === 'solid') back = b.fill.color; else if (b.type === 'environment' || b.type === 'image' || (b.type === 'shape' && b.fill && b.fill.kind !== 'solid') || b.type === 'background') return; }
    if (!back) return; const a = lum(l.color), b2 = lum(back); const ratio = (Math.max(a, b2) + 0.05) / (Math.min(a, b2) + 0.05);
    if (ratio < (l.size >= 4 ? 3 : 4.5)) out.push({ id: l.id, name: l.name, ratio: Math.round(ratio * 10) / 10 });
  });
  return out;
}
