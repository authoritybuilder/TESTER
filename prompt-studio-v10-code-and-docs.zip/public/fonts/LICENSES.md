# Bundled fonts

All fonts in this directory are licensed under the SIL Open Font License 1.1 and were vendored from the
`@fontsource/*` npm packages (latin subset, WOFF2). They may be embedded in exported artwork.

| Family | Use | Source package | Licence |
|---|---|---|---|
| Plus Jakarta Sans (400–800) | App UI + default asset typography | `@fontsource/plus-jakarta-sans` | OFL-1.1 |
| Fraunces (400/600/700/900, italic 400/600) | Editorial / print asset typography | `@fontsource/fraunces` | OFL-1.1 |
| Anton (400) | Hook / thumbnail asset typography | `@fontsource/anton` | OFL-1.1 |
| Caveat (700) | Handwritten annotations | `@fontsource/caveat` | OFL-1.1 |

Customer-uploaded brand fonts are not yet supported; the brand kit maps to the closest bundled family.
