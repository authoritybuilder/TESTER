# Prompt Studio — Authority Builder Studio module (v10)

Prompt Studio turns any of 4,437 catalogue scenes into an editable, brand-aware visual: a written brief, a prompt for ten image tools, and an HTML/CSS/SVG artboard that a browser renders to a real PNG, WebP or JPEG. No image-generation API is needed.

Owner: Yasmin Cronin · Authority Builder™
Status: private preview. See `docs/PROMPT_STUDIO_BUILD_STATE.md` for what is and is not finished.

## Run it

```
npm ci
npm run build
npm start          # http://localhost:4173/studio/prompt-studio/
```

Requires Node 22. `npm ci` installs Playwright; if Chromium is missing run `npx playwright install chromium`.

Static hosting also works for browsing, editing and browser-side export: the root `index.html` redirects to `public/`.

## Commands

| Command | What it does |
|---|---|
| `npm run import` | Reads both source archives and writes the canonical records, index, checksums and import report |
| `npm run backfill` | Plans, renders and checks a thumbnail for every scene; writes the coverage report |
| `npm run lab` | Builds the six full-size examples in `examples/` |
| `npm run verify` | Typecheck, lint, 25 unit tests, build, 23 end-to-end tests |
| `npm start` | Preview server with demo workspaces |

## Layout

```
features/prompt-studio/   catalog · compiler · visual-engine · gallery · editor · integrations · app · tests
server/                   preview server and demo host
scripts/                  import, backfill, build, lint, lab
public/                   built app, fonts, scene data, thumbnails
data/                     checksums, reports, specs and artboards
examples/                 visual lab
docs/                     audit, data map, engines, UI, integration, security, test report, build state
legacy/                   the previous single-file app, kept for rollback
```

The two source archives and the two spreadsheets at the repository root are the originals and are never modified.

## Documentation

Start with `docs/PROMPT_STUDIO_BUILD_STATE.md`, then `PROMPT_STUDIO_TEST_REPORT.md`. The rest: `PROMPT_STUDIO_AUDIT.md`, `PROMPT_STUDIO_DATA_MAP.md`, `PROMPT_STUDIO_CREATIVE_ENGINE.md`, `PROMPT_STUDIO_HTML_VISUAL_ENGINE.md`, `PROMPT_STUDIO_THUMBNAIL_COVERAGE.md`, `PROMPT_STUDIO_UI.md`, `PROMPT_STUDIO_SAAS_INTEGRATION.md`, `PROMPT_STUDIO_SECURITY.md`.

## Fonts

Plus Jakarta Sans, Fraunces, Anton and Caveat are bundled under the SIL Open Font Licence 1.1 (`public/fonts/LICENSES.md`).

© Authority Builder™. All rights reserved. Demo brands and names in examples and tests are fictional.
